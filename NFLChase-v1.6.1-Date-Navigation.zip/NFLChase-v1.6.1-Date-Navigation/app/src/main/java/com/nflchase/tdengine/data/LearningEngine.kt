package com.nflchase.tdengine.data

import com.nflchase.tdengine.model.*
import kotlin.math.pow

class LearningEngine {
    private val history = mutableListOf<PredictionSnapshot>()
    fun freeze(game: GameCard) { game.candidates.forEach { history += PredictionSnapshot(it.id,game.id,it.score,it.probability,it.factors,System.currentTimeMillis()) } }
    fun grade(playerId:String, gameId:String, scored:Boolean) {
        val i=history.indexOfLast { it.playerId==playerId && it.gameId==gameId }
        if(i>=0) history[i]=history[i].copy(resultTd=scored)
    }
    fun brier(): Double {
        val g=history.filter { it.resultTd!=null }; if(g.isEmpty()) return 0.0
        return g.map { ((it.probability/100.0) - if(it.resultTd==true) 1.0 else 0.0).pow(2) }.average()
    }
    fun samples()=history.size
    fun graded()=history.count { it.resultTd!=null }
}
