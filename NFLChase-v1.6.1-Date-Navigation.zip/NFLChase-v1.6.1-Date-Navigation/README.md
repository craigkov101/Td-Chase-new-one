# NFL Chase v1.5.0 — Live Eligibility

Game-day eligibility hardening:
- Pull-to-refresh rechecks live scoring and player status.
- Validates each static candidate against the current ESPN team roster for today's slate.
- Removes candidates who are no longer on the team before simulations.
- Removes OUT/INACTIVE/IR/PUP/SUSPENDED/ruled-out players before simulations.
- Recursively scans game summary status objects for mid-game ruled-out updates.
- Automatic refresh remains enabled during live use.

The public ESPN endpoints used here are unofficial/undocumented for third-party use and can change. The app fails closed only when a current roster is successfully retrieved; if roster retrieval fails, it does not remove an entire team by mistake.
