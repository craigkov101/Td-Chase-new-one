NFL Chase v1.6.2 — schedule recovery. Date-range, per-day, and current scoreboard fallbacks. Requires real-device network verification.
