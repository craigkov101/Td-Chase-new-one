package com.nflchase.tdengine.data

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** Counts *observed* touchdowns from completed games. Does not estimate red-zone usage. */
data class TeamScoringTrend(
    val team: String,
    val gamesObserved: Int,
    val rbRush: Int,
    val qbRush: Int,
    val receiving: Int,
    val other: Int,
    val notes: String,
    val error: String? = null
) {
    val total: Int get() = rbRush + qbRush + receiving + other
}

private fun fetchEspnJson(url: String): JSONObject {
    val connection = (URL(url).openConnection() as HttpURLConnection).apply {
        requestMethod = "GET"
        connectTimeout = 8000
        readTimeout = 8000
        setRequestProperty("Accept", "application/json")
        setRequestProperty("User-Agent", "TDChase/1.8.1 (Android; scoring history)")
    }
    return try {
        val status = connection.responseCode
        if (status !in 200..299) error("ESPN HTTP $status")
        JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
    } finally {
        connection.disconnect()
    }
}

/** Parse raw ESPN payloads instead of inferring touchdown type from prose alone. */
internal object EspnScoringParser {
    data class Game(val id: String, val date: String, val espnTeamId: String, val teamPoints: Int?)
    data class Counts(val rushing: Int, val receiving: Int, val other: Int) {
        val total get() = rushing + receiving + other
    }

    internal fun completedGames(schedule: JSONObject, teamCode: String): List<Game> {
        val events = schedule.optJSONArray("events") ?: error("ESPN schedule has no events")
        val result = mutableListOf<Game>()
        for (i in 0 until events.length()) {
            val event = events.optJSONObject(i) ?: continue
            val competition = event.optJSONArray("competitions")?.optJSONObject(0) ?: continue
            val type = competition.optJSONObject("status")?.optJSONObject("type")
                ?: event.optJSONObject("status")?.optJSONObject("type")
            val isFinal = type?.optBoolean("completed", false) == true ||
                (type?.optString("name", "") ?: "").contains("FINAL", ignoreCase = true)
            if (!isFinal) continue
            var teamId = ""
            var teamPoints: Int? = null
            val competitors = competition.optJSONArray("competitors")
            if (competitors != null) for (j in 0 until competitors.length()) {
                val competitor = competitors.optJSONObject(j) ?: continue
                val t = competitor.optJSONObject("team") ?: continue
                if (t.optString("abbreviation", "").equals(teamCode, ignoreCase = true)) {
                    teamId = t.optString("id", competitor.optString("id", ""))
                    teamPoints = competitor.optString("score", "").toIntOrNull()
                    break
                }
            }
            val id = event.optString("id", "")
            if (id.isNotBlank()) result += Game(id, event.optString("date", ""), teamId, teamPoints)
        }
        return result.distinctBy { it.id }.sortedWith(compareByDescending<Game> { it.date }.thenByDescending { it.id }).take(5)
    }

    /** Some ESPN scoringPlays use team.id only, not team.abbreviation; type.text identifies TDs. */
    internal fun touchdownType(typeText: String, description: String): String {
        val type = typeText.lowercase(Locale.US)
        val detail = description.lowercase(Locale.US)
        val combined = "$type $detail"
        val isTd = "touchdown" in combined || Regex("\\btd\\b").containsMatchIn(combined)
        if (!isTd) return "ignore"
        if (listOf("interception", "fumble return", "kickoff return", "punt return", "blocked punt", "blocked field goal", "defensive").any { it in combined }) return "other"
        if ("passing" in type || "receiving" in type || "pass" in detail || "reception" in detail) return "receiving"
        if ("rushing" in type || "rush" in detail || " run" in detail || "scramble" in detail) return "rushing"
        // Real TD, but type cannot be safely inferred (not a non-TD or zero).
        return "other"
    }

    /** Independently cross-check game touchdowns against position-group boxscore TD columns.
     * Never include passing TDs: a QB pass TD is already a receiver TD. */
    internal fun boxscoreTouchdowns(summary: JSONObject, code: String, teamId: String): Counts? {
        val groups = summary.optJSONObject("boxscore")?.optJSONArray("players") ?: return null
        var found = false
        var rushing = 0
        var receiving = 0
        for (i in 0 until groups.length()) {
            val group = groups.optJSONObject(i) ?: continue
            val team = group.optJSONObject("team") ?: continue
            if (team.optString("id", "") != teamId && !team.optString("abbreviation", "").equals(code, true)) continue
            val categories = group.optJSONArray("statistics") ?: continue
            for (j in 0 until categories.length()) {
                val section = categories.optJSONObject(j) ?: continue
                val name = section.optString("name", "").lowercase(Locale.US)
                val isRush = name.contains("rush")
                val isRec = name.contains("receiv")
                if (!isRush && !isRec) continue
                val labels = section.optJSONArray("labels") ?: continue
                val tdIndex = (0 until labels.length()).firstOrNull { labels.optString(it).uppercase(Locale.US) in setOf("TD", "TDS") } ?: continue
                val athletes = section.optJSONArray("athletes") ?: continue
                found = true
                for (k in 0 until athletes.length()) {
                    val row = athletes.optJSONObject(k) ?: continue
                    val count = row.optJSONArray("stats")?.optString(tdIndex, "0")?.toIntOrNull() ?: 0
                    if (isRush) rushing += count else receiving += count
                }
            }
        }
        return if (found) Counts(rushing, receiving, 0) else null
    }

    internal fun scoringForTeam(summary: JSONObject, code: String, scheduleTeamId: String, points: Int?): Counts {
        val scoring = summary.optJSONArray("scoringPlays")
        val boxTotals = boxscoreTouchdowns(summary, code, scheduleTeamId)
        if (scoring == null) return boxTotals?.takeIf { it.total > 0 || (points ?: 0) < 7 }
            ?: error("No scoring plays or verifiable player TD boxscore for $code")
        val ids = mutableSetOf<String>()
        if (scheduleTeamId.isNotBlank()) ids += scheduleTeamId
        val teams = summary.optJSONObject("boxscore")?.optJSONArray("teams")
        if (teams != null) for (i in 0 until teams.length()) {
            val team = teams.optJSONObject(i)?.optJSONObject("team") ?: continue
            if (team.optString("abbreviation", "").equals(code, ignoreCase = true)) {
                team.optString("id", "").takeIf { it.isNotBlank() }?.let(ids::add)
            }
        }
        var receiving = 0
        var rushing = 0
        var other = 0
        var anyTouchdowns = 0
        var unknownTeams = 0
        var matchingScoringEvents = 0
        for (i in 0 until scoring.length()) {
            val play = scoring.optJSONObject(i) ?: continue
            val team = play.optJSONObject("team")
            val teamId = team?.optString("id", "") ?: ""
            val abbrev = team?.optString("abbreviation", "") ?: ""
            val teamMatches = (teamId.isNotBlank() && teamId in ids) ||
                (abbrev.isNotBlank() && abbrev.equals(code, ignoreCase = true))
            if (teamMatches) matchingScoringEvents++
            val category = touchdownType(
                listOf(play.optJSONObject("type")?.optString("text", "") ?: "",
                    play.optJSONObject("scoringType")?.optString("name", "") ?: "").joinToString(" "),
                play.optString("text", ""))
            if (category == "ignore") continue
            anyTouchdowns++
            if (teamId.isBlank() && abbrev.isBlank()) unknownTeams++
            if (!teamMatches) continue
            when (category) {
                "receiving" -> receiving++
                "rushing" -> rushing++
                else -> other++
            }
        }
        // Cross-check ESPN scoring types against player boxscore. The type metadata can vary;
        // positive boxscore TDs are better than silently reporting 0 from an unusable plays feed.
        val result = Counts(rushing, receiving, other)
        if (boxTotals != null && boxTotals.total > result.total) return boxTotals
        if (scoring.length() == 0 && (points ?: 0) > 0) error("Game summary has no scoring plays although team scored $points points")
        if ((points ?: 0) >= 7 && matchingScoringEvents == 0) error("No scoring plays matched team $code despite $points points; team ID may have changed")
        if (anyTouchdowns > 0 && ids.isEmpty() && unknownTeams > 0) error("Team IDs missing from scoring summary")
        if (anyTouchdowns > 0 && unknownTeams == anyTouchdowns) error("Touchdown plays are missing ESPN team IDs")
        return Counts(rushing, receiving, other)
    }
}

class ScoringTendencies(private val fetch: (String) -> JSONObject = ::fetchEspnJson) {
    private val teamCache = ConcurrentHashMap<String, TeamScoringTrend>()
    private val summaryCache = ConcurrentHashMap<String, JSONObject>()

    fun load(team: String, force: Boolean = false): TeamScoringTrend {
        val code = team.uppercase(Locale.US)
        if (!force) teamCache[code]?.let { return it }
        val trend = try {
            val schedule = fetch("https://site.api.espn.com/apis/site/v2/sports/football/nfl/teams/${code.lowercase(Locale.US)}/schedule?season=2026&seasontype=2")
            val games = EspnScoringParser.completedGames(schedule, code)
            if (games.isEmpty()) {
                TeamScoringTrend(code, 0, 0, 0, 0, 0, "No final regular-season games found", "No final games in ESPN schedule")
            } else {
                var checked = 0
                var rushing = 0
                var receiving = 0
                var other = 0
                val failures = mutableListOf<String>()
                games.forEach { game ->
                    try {
                        val summary = if (force) null else summaryCache[game.id]
                        val payload = summary ?: fetch("https://site.api.espn.com/apis/site/v2/sports/football/nfl/summary?event=${game.id}")
                        val counts = EspnScoringParser.scoringForTeam(payload, code, game.espnTeamId, game.teamPoints)
                        summaryCache[game.id] = payload // Cache only summaries that passed schema checks.
                        checked++
                        rushing += counts.rushing
                        receiving += counts.receiving
                        other += counts.other
                    } catch (e: Exception) {
                        failures += "${game.id}: ${e.message ?: "parse/network error"}"
                    }
                }
                val detail = "Last $checked of ${games.size} completed games verified from ESPN scoring plays. " +
                    "Rushing includes RB/QB runs; receiving includes WR/TE/RB catches. Not target or goal-line usage."
                val warning = if (failures.isNotEmpty()) "${failures.size} game(s) could not be verified: ${failures.first().take(110)}" else null
                if (checked == 0) TeamScoringTrend(code, 0, 0, 0, 0, 0, detail, warning ?: "No verified game summaries")
                else TeamScoringTrend(code, checked, rushing, 0, receiving, other, detail, warning)
            }
        } catch (e: Exception) {
            TeamScoringTrend(code, 0, 0, 0, 0, 0, "Scoring history unavailable", e.message ?: "Unable to retrieve ESPN data")
        }
        if (trend.gamesObserved > 0 && trend.error == null) teamCache[code] = trend
        return trend
    }
}
