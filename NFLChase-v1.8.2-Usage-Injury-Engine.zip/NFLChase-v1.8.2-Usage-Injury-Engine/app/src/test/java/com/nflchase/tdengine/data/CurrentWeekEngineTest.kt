package com.nflchase.tdengine.data

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class CurrentWeekEngineTest {
    @Test fun `roster object statuses are not rendered as JSON`() {
        val roster = JSONObject("""{"athletes":[{"items":[
         {"displayName":"JSN","position":{"abbreviation":"WR"},"status":{"id":"1","name":"Active","type":"active"}},
         {"displayName":"Wilson","position":{"abbreviation":"RB"},"status":{"name":"Day-To-Day","type":"day-to-day"}},
         {"displayName":"RB on IR","position":{"abbreviation":"RB"},"status":{"name":"Injured Reserve"}}
        ]}]}""")
        val players = EspnRosterParser.parse(roster)
        assertEquals(3,players.size)
        assertEquals("Active", players[0].rawStatus)
        assertFalse(players[0].status.contains("{"))
        assertFalse(EspnRosterParser.unavailable(players[1].rawStatus))
        assertTrue(EspnRosterParser.unavailable(players[2].rawStatus))
    }

    @Test fun `player usage comes from named columns and correct team`() {
        val summary=JSONObject("""{"boxscore":{"players":[
        {"team":{"id":"26"},"statistics":[
         {"name":"receiving","labels":["REC","YDS","AVG","TD","LONG","TGTS"],"athletes":[
          {"athlete":{"displayName":"Jaxon Smith-Njigba"},"stats":["9","103","11.4","1","28","12"]}]},
         {"name":"rushing","labels":["CAR","YDS","AVG","TD","LONG"],"athletes":[
          {"athlete":{"displayName":"Emanuel Wilson"},"stats":["21","93","4.4","1","17"]}]}
        ]},{"team":{"id":"7"},"statistics":[{"name":"receiving","labels":["REC","YDS","TD","TGTS"],"athletes":[
         {"athlete":{"displayName":"Opposing receiver"},"stats":["4","60","0","5"]}]}]}]}}""")
        val stats = EspnPlayerStatsParser.boxscore(summary,"26","SEA")
        assertEquals(12,stats[normalName("Jaxon Smith-Njigba")]?.targets)
        assertEquals(103,stats[normalName("Jaxon Smith-Njigba")]?.recYards)
        assertEquals(21,stats[normalName("Emanuel Wilson")]?.carries)
        assertEquals(1,stats[normalName("Emanuel Wilson")]?.rushTd)
        assertFalse(stats.containsKey(normalName("Opposing receiver")))
    }

    @Test fun `missing labels never invent targets`() {
        val payload=JSONObject("""{"boxscore":{"players":[{"team":{"id":"26"},"statistics":[
          {"name":"receiving","athletes":[{"athlete":{"displayName":"WR"},"stats":["8","100","1","10"]}]}
        ]}]}}""")
        assertTrue(EspnPlayerStatsParser.boxscore(payload,"26","SEA").isEmpty())
    }

    @Test fun `official injury statuses separate OUT and questionable`() {
        val data=JSONObject("""{"injuries":[
          {"team":{"abbreviation":"DEN"},"injuries":[
           {"athlete":{"displayName":"Pat Surtain II","position":{"abbreviation":"CB"}},"status":"Out"},
           {"athlete":{"displayName":"Riley Moss","position":{"abbreviation":"CB"}},"status":"Questionable"}]},
          {"team":{"abbreviation":"SEA"},"injuries":[
           {"athlete":{"displayName":"Seattle LB","position":{"abbreviation":"LB"}},"status":"Out"}]}
        ]}""")
        val injuries=EspnInjuryParser.extract(data,"DEN")
        assertEquals(2,injuries.size)
        assertTrue(EspnInjuryParser.confirmedOut(injuries[0].status))
        assertFalse(EspnInjuryParser.confirmedOut(injuries[1].status))
    }

    @Test fun `scoring falls back to verified player touchdowns when plays are absent`() {
        val payload=JSONObject("""{"boxscore":{"players":[
        {"team":{"id":"26"},"statistics":[
         {"name":"receiving","labels":["REC","YDS","AVG","TD"],"athletes":[{"athlete":{"displayName":"WR"},"stats":["5","80","16","2"]}]},
         {"name":"rushing","labels":["CAR","YDS","AVG","TD"],"athletes":[{"athlete":{"displayName":"RB"},"stats":["20","90","4.5","1"]}]}
        ]}]}}""")
        val td=EspnScoringParser.scoringForTeam(payload,"SEA","26",21)
        assertEquals(2,td.receiving)
        assertEquals(1,td.rushing)
    }

    @Test fun `unverified scores with no plays or player boxscore are flagged`() {
        try {
            EspnScoringParser.scoringForTeam(JSONObject("""{"boxscore":{"players":[]}}"""),"SEA","26",28)
            fail("Should report a missing data error")
        } catch (_: IllegalStateException) { }
    }
}
