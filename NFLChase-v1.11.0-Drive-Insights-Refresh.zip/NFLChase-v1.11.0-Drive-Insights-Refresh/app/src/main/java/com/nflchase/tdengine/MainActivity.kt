package com.nflchase.tdengine

import android.os.Bundle
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import coil.compose.AsyncImage
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import java.util.Locale
import com.nflchase.tdengine.data.*
import com.nflchase.tdengine.model.*

// A restrained sports-data palette: slate/navy foundation, ice-blue actions,
// sea-glass success, amber opportunities and coral ONLY for verified risk.
private val Bg=Color(0xFF080F1B)
private val Card=Color(0xFF111E2E)
private val Card2=Color(0xFF19283A)
private val Line=Color(0xFF2B3A4D)
private val Blue=Color(0xFF77C8F1)
private val Green=Color(0xFF79D6B5)
private val Muted=Color(0xFFABBDD0)
private val Gold=Color(0xFFF4BD73)
private val Coral=Color(0xFFF1878E)
private val Purple=Color(0xFFB3A4F2)
private fun teamAccent(code:String):Color=when(code.uppercase(Locale.US)) {
 "DEN","CIN","CLE","CHI" -> Color(0xFFED975D)
 "SEA","PHI","NYJ","GB" -> Color(0xFF64C9A6)
 "SF","KC","ARI","ATL","TB","WAS" -> Color(0xFFEB8489)
 "BUF","NE","NYG","TEN","HOU" -> Color(0xFF85B4EC)
 "BAL","MIN" -> Color(0xFFB5A4F0)
 "PIT","NO","JAX","JAC" -> Color(0xFFF0C478)
 else -> Blue
}
@Composable private fun Pill(text:String,tint:Color=Blue) {
 Surface(color=tint.copy(alpha=.11f),shape=RoundedCornerShape(50),border=BorderStroke(1.dp,tint.copy(alpha=.25f))) {
  Text(text,color=tint,fontWeight=FontWeight.Bold,fontSize=10.sp,modifier=Modifier.padding(horizontal=10.dp,vertical=6.dp))
 }
}
@Composable private fun SectionCaption(text:String,tint:Color=Blue) {
 Row(verticalAlignment=Alignment.CenterVertically) {
  Surface(color=tint,shape=RoundedCornerShape(4.dp),modifier=Modifier.width(4.dp).height(17.dp)){}
  Spacer(Modifier.width(9.dp))
  Text(text,color=tint,fontWeight=FontWeight.Black,fontSize=12.sp,letterSpacing=.5.sp)
 }
}
class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{MaterialTheme(colorScheme=darkColorScheme(background=Bg,surface=Card,primary=Blue,secondary=Green,tertiary=Gold,onSurface=Color(0xFFF0F6FC),onBackground=Color(0xFFF0F6FC))){App()}}}}
enum class Tab(val title:String){GAMES("Games"),PICKS("Picks"),SCRIPTS("Scripts"),PARLAYS("Parlays"),MORE("More")}
@Composable fun App(){
 var tab by remember{mutableStateOf(Tab.GAMES)}
 var selected by remember{mutableStateOf<LiveScheduleGame?>(null)}
 val learn=remember{LearningEngine()}
 val client=remember{LiveTdClient()}
 val weekEngine=remember{CurrentWeekEngine()}
 val tendencyEngine=remember{ScoringTendencies()}
 var trends by remember{mutableStateOf<Map<String,TeamScoringTrend>>(emptyMap())}
 var trendsLoading by remember{mutableStateOf<Set<String>>(emptySet())}
 var projections by remember{mutableStateOf<Map<String,WeekProjection>>(emptyMap())}
 var projectionLoading by remember{mutableStateOf<Set<String>>(emptySet())}
 var live by remember{mutableStateOf(LiveTdSnapshot(emptyList(),0,"—"))}
 var loading by remember{mutableStateOf(false)}
 var lastError by remember{mutableStateOf<String?>(null)}
 val scope=rememberCoroutineScope()
 val context=LocalContext.current
 var importedCharting by remember { mutableStateOf(
  runCatching { CoverageCsv.parse(context.openFileInput("tdchase_route_charting.csv").bufferedReader().use { it.readText() }).rows }
   .getOrDefault(emptyList())
 ) }
 var chartingStatus by remember { mutableStateOf(if(importedCharting.isEmpty()) "No coverage charting imported" else "${importedCharting.size} charted rows loaded from device storage") }
 val chartingLauncher=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){ uri ->
  if(uri!=null)scope.launch {
   try {
    val imported=withContext(Dispatchers.IO) {
     val file=context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
      ?: error("Unable to read the selected CSV")
     val parsed=CoverageCsv.parse(file)
     if(parsed.rows.isEmpty()) error(parsed.message)
     context.openFileOutput("tdchase_route_charting.csv", Context.MODE_PRIVATE).bufferedWriter().use { it.write(file) }
     parsed
    }
    importedCharting=imported.rows
    chartingStatus=imported.message
   }catch(e:Exception){ chartingStatus="Coverage import failed: ${e.message}" }
  }
 }
 fun requestProjection(game:LiveScheduleGame,force:Boolean=false){
  if(game.id in projectionLoading)return
  projectionLoading=projectionLoading+game.id
  scope.launch {try {val result=withContext(Dispatchers.IO){weekEngine.load(game,force)};projections=projections+(game.id to result)}
   catch(e:Exception){projections=projections+(game.id to WeekProjection(game.id,emptyList(),"ESPN recent box scores",e.message ?: "Request failed"))}
   finally {projectionLoading=projectionLoading-game.id}}
 }
 fun openGame(game:LiveScheduleGame){
  selected=game;requestProjection(game)
  teamsOf(game).filter{it !in trends && it !in trendsLoading}.forEach { code ->
   trendsLoading=trendsLoading+code
   scope.launch {try {
    val result=withContext(Dispatchers.IO){tendencyEngine.load(code)}
    trends=trends+(code to result)
   }catch(e:Exception){trends=trends+(code to TeamScoringTrend(code,0,0,0,0,0,"Scoring request failed",e.message))}
   finally{trendsLoading=trendsLoading-code}}
  }
 }
 fun refreshTrends(game:LiveScheduleGame){
  teamsOf(game).filter{it !in trendsLoading}.forEach {code->
   trendsLoading=trendsLoading+code
   scope.launch{try{
    val result=withContext(Dispatchers.IO){tendencyEngine.load(code,true)}
    trends=trends+(code to result)
   }catch(e:Exception){trends=trends+(code to TeamScoringTrend(code,0,0,0,0,0,"Scoring refresh failed",e.message))}
   finally{trendsLoading=trendsLoading-code}}
  }
 }
 fun refresh(){if(loading)return;loading=true;scope.launch{try{
  val update=withContext(Dispatchers.IO){client.loadToday()}
  if(update.schedule.isNotEmpty() || live.schedule.isEmpty())live=update
  lastError=update.error
 }catch(e:Exception){lastError=e.message?:"Network unavailable"}finally{loading=false}}}
 LaunchedEffect(Unit){refresh();while(isActive){delay(60000);refresh()}}
 val todayEast=java.time.LocalDate.now(java.time.ZoneId.of("America/New_York"))
 val startOfSlate=if(todayEast.dayOfWeek in listOf(java.time.DayOfWeek.TUESDAY,java.time.DayOfWeek.WEDNESDAY))
  todayEast.with(java.time.temporal.TemporalAdjusters.next(java.time.DayOfWeek.THURSDAY))
 else todayEast.with(java.time.temporal.TemporalAdjusters.previousOrSame(java.time.DayOfWeek.THURSDAY))
 val slate=live.schedule.filter { g -> runCatching {
  val d=java.time.Instant.parse(g.kickoff).atZone(java.time.ZoneId.of("America/New_York")).toLocalDate()
  !d.isBefore(startOfSlate) && !d.isAfter(startOfSlate.plusDays(4))
 }.getOrDefault(false) }.distinctBy{it.matchup}.sortedBy{it.kickoff}
 Scaffold(containerColor=Bg,bottomBar={NavigationBar(containerColor=Color(0xFF0D1827)){
  Tab.entries.forEach{t->NavigationBarItem(selected=tab==t,onClick={tab=t;selected=null},icon={Icon(when(t){Tab.GAMES->Icons.Default.SportsFootball;Tab.PICKS->Icons.Default.Star;Tab.SCRIPTS->Icons.Default.QueryStats;Tab.PARLAYS->Icons.Default.Casino;Tab.MORE->Icons.Default.MoreHoriz},null)},label={Text(t.title)},colors=NavigationBarItemDefaults.colors(selectedIconColor=Blue,indicatorColor=Blue.copy(.18f),selectedTextColor=Color.White,unselectedIconColor=Muted,unselectedTextColor=Muted))}
 }}){pad->Column(Modifier.padding(pad).fillMaxSize()){Header();Crossfade(targetState=Pair(tab,selected),animationSpec=tween(180),label="tab transition"){state->val(currentTab,currentGame)=state;when{
  currentGame!=null->CurrentGameDetail(currentGame,projections[currentGame.id],currentGame.id in projectionLoading,{requestProjection(currentGame,true)},{selected=null},trends,trendsLoading,{refreshTrends(currentGame)},importedCharting,{chartingLauncher.launch(arrayOf("text/*","application/octet-stream"))})
  currentTab==Tab.GAMES->CurrentGamesHome(slate,live,loading,lastError,{refresh()}){openGame(it)}
  currentTab==Tab.PICKS->CurrentPicks(slate,projections.mapValues { (id,p) ->
    val g=slate.firstOrNull{it.id==id}; if(g==null)p else CoverageAnalyzer.enrich(p,CoverageAnalyzer.evaluate(g.matchup,p,importedCharting))
   }){openGame(it)}
  currentTab==Tab.SCRIPTS->CurrentScripts(slate,projections,trends,importedCharting){openGame(it)}
  currentTab==Tab.PARLAYS->CurrentParlays(slate)
  else->Column {
   Surface(color=Card,shape=RoundedCornerShape(16.dp),modifier=Modifier.fillMaxWidth().padding(16.dp)) {
    Column(Modifier.padding(16.dp)) {
     Text("WR / CB ROUTE CHARTING",color=Blue,fontWeight=FontWeight.Black)
     Text("Historical charted routes are required for measured individual coverage. ESPN rosters cannot provide per-route assignments.",color=Muted,fontSize=12.sp)
     Text(chartingStatus,color=Gold,fontSize=12.sp,modifier=Modifier.padding(top=9.dp))
     TextButton(onClick={chartingLauncher.launch(arrayOf("text/*","application/octet-stream"))}) { Text("Import licensed coverage CSV") }
     Text("Example data providers: Fantasy Points Data Suite Shadow Index (with authorized CSV access) or other licensed charting exports. The app stores the file on this device only.",color=Muted,fontSize=11.sp)
    }
   }
   More(learn)
  }
 }}}}
}
@Composable fun Header(){
 Column(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF16283C),Bg)))) {
  Row(Modifier.fillMaxWidth().padding(horizontal=20.dp,vertical=17.dp),verticalAlignment=Alignment.CenterVertically){
   Surface(shape=RoundedCornerShape(17.dp),color=Blue.copy(.13f),border=BorderStroke(1.dp,Blue.copy(.3f))){
    Icon(Icons.Default.SportsFootball,"TD Chase",tint=Blue,modifier=Modifier.padding(12.dp).size(26.dp))
   }
   Spacer(Modifier.width(13.dp))
   Column(Modifier.weight(1f)){
    Row(verticalAlignment=Alignment.CenterVertically){
     Text("TD",fontSize=26.sp,fontWeight=FontWeight.Black,color=Blue)
     Text(" CHASE",fontSize=26.sp,fontWeight=FontWeight.Black)
    }
    Text("FOOTBALL INTELLIGENCE  •  Cxaig",color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold,letterSpacing=.7.sp)
   }
   Pill("SIM LAB",Purple)
  }
  HorizontalDivider(color=Line)
 }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun GamesHome(games:List<GameCard>,sim:SimulationEngine,open:(GameCard)->Unit){
    var remaining by remember{mutableStateOf(true)}
    var top5 by remember{mutableStateOf(true)}
    var best by remember{mutableStateOf(false)}
    var live by remember{mutableStateOf(LiveTdSnapshot(emptyList(),0,"—"))}
    var refreshing by remember{mutableStateOf(false)}
    var lastRefreshError by remember{mutableStateOf<String?>(null)}
    
    val client=remember{LiveTdClient()};val scope=rememberCoroutineScope()
    fun forceRefresh(){if(refreshing)return;refreshing=true;scope.launch{try { val updated=withContext(Dispatchers.IO){client.loadToday()}; if(updated.schedule.isNotEmpty()){live=updated;lastRefreshError=updated.error}else{lastRefreshError=updated.error}; } finally { refreshing=false }}}
    LaunchedEffect(Unit){forceRefresh();while(isActive){delay(60000);forceRefresh()}}
    fun isLiveOut(p:TdCandidate)=live.unavailablePlayers.contains(p.name.lowercase(Locale.US).replace(Regex("[^a-z0-9 ]"),"").replace(Regex("\\s+")," ").trim())
    val liveGames=remember(games,live.unavailablePlayers){games.map{g->g.copy(candidates=g.candidates.map{p->if(isLiveOut(p))p.copy(status="OUT") else p})}}
    val sims=remember(liveGames){liveGames.associate{it.id to sim.simulate(it)}}
    val targetDates=listOf(java.time.LocalDate.of(2026,10,15),java.time.LocalDate.of(2026,10,18))
    val todays=live.schedule.filter { g -> runCatching { java.time.Instant.parse(g.kickoff).atZone(java.time.ZoneId.of("America/New_York")).toLocalDate() in targetDates }.getOrDefault(false) }.sortedBy{it.kickoff}
    val gameDates=targetDates
    var chosenDate by remember { mutableStateOf<java.time.LocalDate?>(null) }
    LaunchedEffect(gameDates) {
        if(gameDates.isNotEmpty() && chosenDate !in gameDates) {
            val today=java.time.LocalDate.now(java.time.ZoneId.of("America/New_York"))
            chosenDate=gameDates.firstOrNull { !it.isBefore(today) } ?: gameDates.last()
        }
    }
    val dateIndex=gameDates.indexOf(chosenDate).coerceAtLeast(0)
    val visibleGames=todays.filter { game -> runCatching { java.time.Instant.parse(game.kickoff).atZone(java.time.ZoneId.of("America/New_York")).toLocalDate()==chosenDate }.getOrDefault(false) }
    
    
    
    val shown=remember(remaining,best,liveGames,sims){
        val base=if(remaining) liveGames.filter{!it.kickoff.contains("FINAL",true)} else liveGames
        if(best) base.sortedByDescending{g->g.candidates.filter{it.status.uppercase() !in setOf("OUT","INACTIVE","IR","PUP","SUSPENDED")}.maxOfOrNull{p->sims[g.id]?.results?.get(p.id)?.tdRate?:0}?:0} else base
    }
    PullToRefreshBox(isRefreshing=refreshing,onRefresh={forceRefresh()},modifier=Modifier.fillMaxSize()){
     LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(bottom=24.dp)){
      item{Column(Modifier.padding(22.dp,16.dp,22.dp,8.dp)){
        Text(java.text.SimpleDateFormat("EEE, MMM d",Locale.US).format(java.util.Date()),fontSize=26.sp,fontWeight=FontWeight.Black)
        Text("THIS WEEK • ${todays.size} SCHEDULED GAMES",color=Blue,fontWeight=FontWeight.Bold,fontSize=12.sp,modifier=Modifier.padding(top=5.dp))
        Text("Swipe down to refresh official NFL feed • ${live.updatedAt}",color=if(live.error==null)Green else Gold,fontSize=10.sp,modifier=Modifier.padding(top=5.dp))
        Spacer(Modifier.height(20.dp));Text("QUICK FILTERS",color=Muted,fontWeight=FontWeight.Black,fontSize=12.sp)
        Row(Modifier.padding(top=10.dp)){
          FilterChip(selected=remaining,onClick={remaining=!remaining},label={Text("Remaining")});Spacer(Modifier.width(7.dp))
          FilterChip(selected=top5,onClick={top5=!top5},label={Text(if(top5) "Top 5" else "All Picks")});Spacer(Modifier.width(7.dp))
          FilterChip(selected=best,onClick={best=!best},label={Text("Best Matchup")})
        }
        Text("${todays.size} current matchups • live schedule",color=Blue,fontSize=11.sp,modifier=Modifier.padding(top=8.dp))
        if(live.unavailablePlayers.isNotEmpty())Text("Reported injury status available; verify game-day inactives",color=Gold,fontWeight=FontWeight.Bold,fontSize=11.sp,modifier=Modifier.padding(top=7.dp))
        Spacer(Modifier.height(22.dp));Text("THIS WEEK’S NFL MATCHUPS",color=Blue,fontWeight=FontWeight.Black,fontSize=12.sp)
        Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth().padding(top=6.dp)) {
            IconButton(onClick={if(dateIndex>0) chosenDate=gameDates[dateIndex-1]},enabled=dateIndex>0) { Icon(Icons.Default.ChevronLeft,"Previous game date",tint=if(dateIndex>0)Blue else Muted) }
            Column(Modifier.weight(1f),horizontalAlignment=Alignment.CenterHorizontally) {
                Text(chosenDate?.format(java.time.format.DateTimeFormatter.ofPattern("EEE, MMM d",Locale.US)) ?: "Loading games",fontSize=24.sp,fontWeight=FontWeight.Black)
                Text("${visibleGames.size} games • ${if(gameDates.isEmpty()) 0 else dateIndex+1} of ${gameDates.size} dates",color=Blue,fontSize=11.sp)
            }
            IconButton(onClick={if(dateIndex<gameDates.lastIndex) chosenDate=gameDates[dateIndex+1]},enabled=dateIndex<gameDates.lastIndex) { Icon(Icons.Default.ChevronRight,"Next game date",tint=if(dateIndex<gameDates.lastIndex)Blue else Muted) }
        }
        Text("Thursday and Sunday only. Fixtures can be shown from a dated backup when live ESPN data fails; historical TD projections are not verified.",color=Muted,fontSize=13.sp,modifier=Modifier.padding(top=4.dp))
      }}
      if(lastRefreshError!=null) item { Text("Refresh failed: ${lastRefreshError}. Showing last available schedule when possible.",color=Gold,modifier=Modifier.padding(20.dp)) }
      if(live.error==null && todays.isEmpty()) item { Text("Schedule unavailable. Pull down to retry.",color=Muted,modifier=Modifier.padding(20.dp)) }
      items(visibleGames,key={it.id}){game->Surface(color=Card,shape=RoundedCornerShape(20.dp),border=BorderStroke(1.dp,Line),modifier=Modifier.fillMaxWidth().padding(horizontal=20.dp,vertical=7.dp)){Column(Modifier.padding(18.dp)){val parts=game.matchup.split(" @ "," at ",limit=2);Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)){if(parts.size==2) TeamLogo(parts[0]);Column(Modifier.weight(1f)){Text(game.matchup,fontSize=20.sp,fontWeight=FontWeight.Black);Text("Kickoff: "+runCatching{java.time.Instant.parse(game.kickoff).atZone(java.time.ZoneId.systemDefault()).format(java.time.format.DateTimeFormatter.ofPattern("h:mm a z",Locale.US))}.getOrDefault(game.kickoff),color=Blue)};if(parts.size==2) TeamLogo(parts[1])};Text(game.state.replace("STATUS_","").replace("_"," ")+" • "+(if(game.id.startsWith("week6-")) "Week 6 schedule backup" else "ESPN schedule"),color=Muted,fontSize=12.sp,modifier=Modifier.padding(top=8.dp))}}}
      item{Column(Modifier.padding(22.dp,28.dp,22.dp,10.dp)){
        Text("THIS WEEK'S TOUCHDOWNS",color=Blue,fontWeight=FontWeight.Black,fontSize=12.sp)
        Text("Touchdown tracker",fontSize=29.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=8.dp))
        Text("Same refresh updates scoring plays and live player availability.",color=Muted,fontSize=13.sp,modifier=Modifier.padding(top=4.dp))
      }}
      item{TouchdownFeed(snapshot=live,loading=refreshing,onRefresh={forceRefresh()})}
     }
    }
}
private val nflTeamIds=mapOf("ARI" to "22","ATL" to "1","BAL" to "33","BUF" to "2","CAR" to "29","CHI" to "3","CIN" to "4","CLE" to "5","DAL" to "6","DEN" to "7","DET" to "8","GB" to "9","HOU" to "34","IND" to "11","JAX" to "30","JAC" to "30","KC" to "12","LV" to "13","LAC" to "24","LAR" to "14","LA" to "14","MIA" to "15","MIN" to "16","NE" to "17","NO" to "18","NYG" to "19","NYJ" to "20","PHI" to "21","PIT" to "23","SF" to "25","SEA" to "26","TB" to "27","TEN" to "10","WAS" to "28")
@Composable fun TeamLogo(abbreviation:String){
 val id=nflTeamIds[abbreviation.uppercase(Locale.US)]
 if(id!=null) AsyncImage(model="https://a.espncdn.com/i/teamlogos/nfl/500/${abbreviation.lowercase(Locale.US).let { if(it=="jac") "jax" else if(it=="la") "lar" else it }}.png",contentDescription="$abbreviation logo",modifier=Modifier.size(43.dp))
 else Surface(shape=CircleShape,color=Line){Text(abbreviation,modifier=Modifier.padding(8.dp),color=Blue,fontWeight=FontWeight.Black)}
}
@Composable fun GameTileSim(g:GameCard,s:GameSimulation,limit:Int,open:(GameCard)->Unit){
    val ranked=g.candidates.filter{it.status.uppercase() !in setOf("OUT","INACTIVE","IR","PUP","SUSPENDED")}.sortedByDescending{s.results[it.id]?.tdRate?:0}.take(limit)
    Surface(onClick={open(g)},color=Card,shape=RoundedCornerShape(24.dp),border=BorderStroke(1.dp,Line),modifier=Modifier.padding(horizontal=20.dp,vertical=7.dp)){
      Column(Modifier.padding(18.dp)){
        Row{Column(Modifier.weight(1f)){Text("${g.away}  @  ${g.home}",fontSize=21.sp,fontWeight=FontWeight.Black);Text(g.kickoff,color=Muted,fontSize=12.sp)}
          Surface(color=Blue.copy(.10f),shape=RoundedCornerShape(12.dp)){Text("${s.simulations/1000}K SIMS",color=Blue,fontWeight=FontWeight.Bold,fontSize=11.sp,modifier=Modifier.padding(8.dp,5.dp))}}
        Text("Sim avg ${"%.1f".format(s.avgTotalTds)} TDs • ${g.away} ${s.awayWinPct}% / ${g.home} ${s.homeWinPct}%",color=Muted,fontSize=12.sp,modifier=Modifier.padding(vertical=10.dp))
        HorizontalDivider(color=Line)
        ranked.forEachIndexed{i,p->val r=s.results[p.id]!!;Row(Modifier.padding(top=10.dp),verticalAlignment=Alignment.CenterVertically){
          Text("#${i+1}",color=if(i==0)Gold else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(30.dp))
          Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.Bold);Text("${p.position} • ${p.team} • ${shortReason(p)}",color=Muted,fontSize=11.sp)}
          Column(horizontalAlignment=Alignment.End){Text("${r.tdRate}%",color=if(i==0)Green else Blue,fontWeight=FontWeight.Black,fontSize=20.sp);Text("SIM TD",color=Muted,fontSize=9.sp)}
        }}
        Text("VIEW SIM + MATCHUP  ›",color=Blue,fontWeight=FontWeight.Black,fontSize=11.sp,modifier=Modifier.padding(top=14.dp))
      }
    }
}
@Composable fun SimBoard(games:List<GameCard>,sim:SimulationEngine){
    val rows=remember(games){games.flatMap{g->val s=sim.simulate(g);g.candidates.filter{it.status.uppercase() !in setOf("OUT","INACTIVE","IR","PUP","SUSPENDED")}.map{p->Triple(p,s.results[p.id]!!,g)}}.sortedByDescending{it.second.tdRate}}
    Title("Simulation TD Board","DEMO MODEL DATA — historical player pool; not verified for current games. Do not use as live picks.")
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
      itemsIndexed(rows){i,row->val p=row.first;val r=row.second;Surface(color=Card,shape=RoundedCornerShape(18.dp),border=BorderStroke(1.dp,Line)){
        Row(Modifier.fillMaxWidth().padding(15.dp),verticalAlignment=Alignment.CenterVertically){Text("#${i+1}",color=Gold,fontWeight=FontWeight.Black);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.Black,fontSize=18.sp);Text("${p.team} • ${p.position} vs ${p.opponent}",color=Muted,fontSize=12.sp);Text(shortReason(p),color=Blue,fontSize=11.sp)};Column(horizontalAlignment=Alignment.End){Text("${r.tdRate}%",color=Green,fontSize=25.sp,fontWeight=FontWeight.Black);Text("${r.multiTdRate}% 2+ TD",color=Muted,fontSize=10.sp)}}}}
    }
}
@Composable fun TouchdownFeed(snapshot:LiveTdSnapshot,loading:Boolean,onRefresh:()->Unit){
 Surface(color=Card,shape=RoundedCornerShape(24.dp),border=BorderStroke(1.dp,Line),modifier=Modifier.padding(horizontal=20.dp).fillMaxWidth()){Column(Modifier.padding(18.dp)){
  Row(verticalAlignment=Alignment.CenterVertically){Surface(shape=CircleShape,color=Blue.copy(.12f)){Icon(Icons.Default.SportsFootball,null,tint=Blue,modifier=Modifier.padding(10.dp))};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text("TODAY • LIVE FEED",color=Blue,fontWeight=FontWeight.Black,fontSize=12.sp);Text(if(snapshot.liveGames>0)"${snapshot.liveGames} LIVE" else "NFL touchdown tracker",fontSize=19.sp,fontWeight=FontWeight.Black)};Text("${snapshot.events.size} TD",color=if(snapshot.events.isNotEmpty())Green else Muted,fontWeight=FontWeight.Bold)}
  Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.padding(top=10.dp)){if(loading)CircularProgressIndicator(modifier=Modifier.size(14.dp),strokeWidth=2.dp,color=Blue);Text("  Auto 60 sec • swipe to force • ${snapshot.updatedAt}",color=Muted,fontSize=10.sp);Spacer(Modifier.weight(1f));TextButton(onClick=onRefresh,enabled=!loading){Text("REFRESH",fontSize=10.sp)}}
  HorizontalDivider(color=Line,modifier=Modifier.padding(vertical=14.dp))
  snapshot.error?.let{Text("Live feed temporarily unavailable",color=Gold,fontWeight=FontWeight.Bold);Text(it,color=Muted,fontSize=11.sp)}
  if(snapshot.error==null&&snapshot.events.isEmpty())Text("No touchdowns found in the current NFL week.",color=Muted,fontWeight=FontWeight.Bold)
  snapshot.events.take(40).forEachIndexed{i,td->if(i>0)HorizontalDivider(color=Line.copy(.55f),modifier=Modifier.padding(vertical=10.dp));Row{Surface(color=Blue.copy(.10f),shape=RoundedCornerShape(10.dp)){Text(td.team.ifBlank{"TD"},color=Blue,fontWeight=FontWeight.Black,modifier=Modifier.padding(8.dp,5.dp))};Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(td.text,fontWeight=FontWeight.Bold,fontSize=14.sp);Text("${td.game} • Q${td.quarter} ${td.clock}",color=Muted,fontSize=11.sp,modifier=Modifier.padding(top=3.dp))}}}
 }}}
@Composable fun GameTile(g:GameCard,open:(GameCard)->Unit){val top=g.candidates.sortedByDescending{it.score}.take(5);Surface(onClick={open(g)},color=Card,shape=RoundedCornerShape(24.dp),border=BorderStroke(1.dp,Line),modifier=Modifier.padding(horizontal=20.dp,vertical=7.dp)){Column(Modifier.padding(18.dp)){Row{Column(Modifier.weight(1f)){Text("${g.away}  @  ${g.home}",fontSize=21.sp,fontWeight=FontWeight.Black);Text(g.kickoff,color=Muted,fontSize=12.sp)};Surface(color=Blue.copy(.10f),shape=RoundedCornerShape(12.dp)){Text("ENV ${g.environment}",color=Blue,fontWeight=FontWeight.Bold,fontSize=11.sp,modifier=Modifier.padding(8.dp,5.dp))}};Text(smartSummary(g),color=Muted,fontSize=12.sp,modifier=Modifier.padding(vertical=10.dp));HorizontalDivider(color=Line);top.forEachIndexed{i,p->Row(Modifier.padding(top=10.dp),verticalAlignment=Alignment.CenterVertically){Text("#${i+1}",color=if(i==0)Gold else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(30.dp));Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.Bold);Text("${p.position} • ${p.team}  •  ${shortReason(p)}",color=Muted,fontSize=11.sp)};Text("${p.score}",color=if(i==0)Green else Blue,fontWeight=FontWeight.Black,fontSize=20.sp)}};Text("VIEW FULL MATCHUP  ›",color=Blue,fontWeight=FontWeight.Black,fontSize=11.sp,modifier=Modifier.padding(top=14.dp))}}}
fun smartSummary(g:GameCard):String{val p=g.candidates.maxByOrNull{it.score}?:return g.script;val e=p.exploit?:return g.script;val lane=when(p.position){"RB","QB"->"rushing/front-seven";"WR"->"secondary";"TE"->"red-zone coverage";else->"overall"};return "${p.team} has the strongest $lane TD edge. ${p.name} leads the model; opponent grades: front ${e.frontSeven}, secondary ${e.secondary}, red zone ${e.redZoneDefense}."}
fun shortReason(p:TdCandidate):String{val e=p.exploit;return when(p.position){"RB","QB"->if((e?.frontSeven?:0)>=75)"front-7 edge + usage" else "goal-line/usage edge";"WR"->if((e?.secondary?:0)>=75)"secondary edge + targets" else "targets + red-zone role";"TE"->if((e?.redZoneDefense?:0)>=75)"red-zone coverage edge" else "TE scoring role";else->"model edge"}}
@Composable fun Board(c:List<TdCandidate>){Title("Best TD picks","League-wide ranking driven by usage, red zone and matchup.");LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){itemsIndexed(c){i,p->CandidateRow(i+1,p)}}}
@Composable fun Title(a:String,b:String){Column(Modifier.padding(20.dp,14.dp)){Text(a,fontSize=28.sp,fontWeight=FontWeight.Black);Text(b,color=Muted,fontSize=13.sp)}}
@Composable fun CandidateRow(rank:Int,p:TdCandidate){Surface(color=Card,shape=RoundedCornerShape(18.dp),border=BorderStroke(1.dp,Line)){Row(Modifier.fillMaxWidth().padding(15.dp),verticalAlignment=Alignment.CenterVertically){Text("#$rank",color=Gold,fontWeight=FontWeight.Black);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.Black,fontSize=18.sp);Text("${p.team} • ${p.position} vs ${p.opponent}",color=Muted,fontSize=12.sp);Text(shortReason(p),color=Blue,fontSize=11.sp,modifier=Modifier.padding(top=4.dp))};Column(horizontalAlignment=Alignment.End){Text("${p.score}",color=Green,fontSize=25.sp,fontWeight=FontWeight.Black);Text("${p.probability}% TD",color=Muted,fontSize=11.sp)}}}}
@Composable fun GameDetail(g:GameCard,onBack:()->Unit,learn:LearningEngine){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{TextButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null);Text("All games")};Text("${g.away} @ ${g.home}",fontSize=30.sp,fontWeight=FontWeight.Black);Text(smartSummary(g),color=Muted,modifier=Modifier.padding(top=5.dp));Row(Modifier.padding(top=12.dp)){Metric("Environment",g.environment.toString());Spacer(Modifier.width(8.dp));Metric("TD looks",g.candidates.size.toString())};Button(onClick={learn.freeze(g)},modifier=Modifier.padding(top=12.dp)){Text("FREEZE PREGAME SNAPSHOT")}};itemsIndexed(g.candidates.filter{it.status.uppercase() !in setOf("OUT","INACTIVE","IR","PUP","SUSPENDED")}.sortedByDescending{it.score}){i,p->Surface(color=Card,shape=RoundedCornerShape(22.dp),border=BorderStroke(1.dp,if(i==0)Blue else Line)){Column(Modifier.padding(18.dp)){Row{Column(Modifier.weight(1f)){Text("#${i+1}  ${p.name}",fontSize=21.sp,fontWeight=FontWeight.Black);Text("${p.position} • ${p.team}",color=Muted)};Text("${p.score}",color=Green,fontSize=30.sp,fontWeight=FontWeight.Black)};Text("MODEL TD ${p.probability}%",color=Gold,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));Factor("Red zone",p.factors.redZone);Factor("Opportunity",p.factors.opportunity);Factor("Matchup",p.effectiveMatchup);Factor("Scheme",p.factors.scheme);Factor("Environment",p.factors.environment);Spacer(Modifier.height(10.dp));p.exploit?.let{ExploitPanel(p.position,it)};MatchupReasons(p);Text(p.reason,modifier=Modifier.padding(top=9.dp))}}}}}
@Composable fun MatchupReasons(p:TdCandidate){val e=p.exploit?:return;val r=buildList{when(p.position){"RB","QB"->{if(e.frontSeven>=75)add("Attackable front seven");if(e.redZoneDefense>=75)add("Favorable goal-line defense")};"WR"->{if(e.secondary>=75)add("Attackable secondary");if(e.redZoneDefense>=75)add("Favorable red-zone coverage")};"TE"->{if(e.secondary>=72)add("Coverage weakness helps TE routes");if(e.redZoneDefense>=75)add("Favorable red-zone matchup")}};if(e.personnelImpact>=70)add("Defensive personnel/injury edge");if(p.goalLineShare>=65)add("Strong goal-line share (${p.goalLineShare}%)");if(p.factors.opportunity>=90)add("Elite projected usage");if(p.factors.redZone>=90)add("Elite scoring-area role")}.take(5);if(r.isNotEmpty()){Text("WHY THIS PICK",color=Blue,fontWeight=FontWeight.Black,fontSize=12.sp,modifier=Modifier.padding(top=12.dp));r.forEach{Text("• $it",fontSize=12.sp,modifier=Modifier.padding(top=3.dp))}}}
@Composable fun ExploitPanel(position:String,e:DefensiveExploit){val edge=when(position){"RB","QB"->((e.frontSeven*.55)+(e.redZoneDefense*.30)+(e.personnelImpact*.15)).toInt();"WR"->((e.secondary*.60)+(e.redZoneDefense*.25)+(e.personnelImpact*.15)).toInt();"TE"->((e.secondary*.35)+(e.redZoneDefense*.45)+(e.personnelImpact*.20)).toInt();else->e.score};Surface(color=Card2,shape=RoundedCornerShape(14.dp),border=BorderStroke(1.dp,Line)){Column(Modifier.fillMaxWidth().padding(12.dp)){Row{Text("DEFENSIVE EXPLOIT",color=Gold,fontWeight=FontWeight.Black);Spacer(Modifier.weight(1f));Text("$edge/100",color=Green,fontWeight=FontWeight.Black)};Text("Front 7 ${e.frontSeven} • Secondary ${e.secondary} • Red zone ${e.redZoneDefense} • Personnel ${e.personnelImpact}",color=Muted,fontSize=11.sp,modifier=Modifier.padding(top=5.dp));Text(e.note,fontSize=12.sp,modifier=Modifier.padding(top=6.dp))}}}
@Composable fun Factor(n:String,v:Double){Row(Modifier.padding(vertical=2.dp)){Text(n,color=Muted,modifier=Modifier.width(100.dp));LinearProgressIndicator(progress={v.toFloat()/100},modifier=Modifier.weight(1f).height(7.dp),color=Blue,trackColor=Line);Text(" ${v.toInt()}",fontWeight=FontWeight.Bold)}}
@Composable fun Metric(n:String,v:String){Surface(color=Card,shape=RoundedCornerShape(15.dp),border=BorderStroke(1.dp,Line)){Column(Modifier.padding(15.dp)){Text(v,fontSize=22.sp,fontWeight=FontWeight.Black,color=Blue);Text(n,color=Muted,fontSize=11.sp)}}}
@Composable fun Scripts(g:List<GameCard>){Title("Game scripts","DEMO SCRIPTS — historical fixtures, not current-week verified projections.");LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){items(g){x->Surface(color=Card,shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(17.dp)){Text("${x.away} @ ${x.home}",fontWeight=FontWeight.Black,fontSize=19.sp);Text(smartSummary(x),color=Muted,modifier=Modifier.padding(top=6.dp));Text("Environment ${x.environment}/100",color=Blue,modifier=Modifier.padding(top=8.dp))}}}}}
@Composable fun Builder(c:List<TdCandidate>){var legs by remember{mutableStateOf(3)};Title("TD Parlays","DEMO PICKS ONLY — not validated against current rosters, games or inactives.");Column(Modifier.padding(16.dp)){Row{(1..5).forEach{n->FilterChip(selected=legs==n,onClick={legs=n},label={Text("$n")});Spacer(Modifier.width(5.dp))}};Spacer(Modifier.height(14.dp));c.take(legs).forEachIndexed{i,p->CandidateRow(i+1,p)};Text("Avoid blindly stacking players competing for the same scoring share.",color=Muted,modifier=Modifier.padding(top=12.dp))}}
@Composable fun More(l:LearningEngine){Title("More","Model learning, snapshots and calibration.");Column(Modifier.padding(16.dp)){Surface(color=Card,shape=RoundedCornerShape(22.dp),border=BorderStroke(1.dp,Line)){Column(Modifier.padding(20.dp)){SectionCaption("MODEL LAB",Purple);Row(Modifier.padding(top=12.dp)){Metric("Snapshots",l.samples().toString());Spacer(Modifier.width(8.dp));Metric("Graded",l.graded().toString())};Text("Red Zone 26% • Opportunity 20% • Matchup 20% • Scheme 12% • Environment 11% • Role/Injury 6% • Explosive 5%",color=Muted,modifier=Modifier.padding(top=16.dp))}}}}

private fun kickoffLabel(game:LiveScheduleGame):String=runCatching{
 java.time.Instant.parse(game.kickoff).atZone(java.time.ZoneId.of("America/New_York"))
 .format(java.time.format.DateTimeFormatter.ofPattern("EEE, MMM d • h:mm a z",Locale.US))
}.getOrDefault(game.kickoff)
private fun teamsOf(game:LiveScheduleGame):List<String> = game.matchup.split(" @ "," at ",limit=2)
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun CurrentGamesHome(slate:List<LiveScheduleGame>,live:LiveTdSnapshot,loading:Boolean,lastError:String?,refresh:()->Unit,open:(LiveScheduleGame)->Unit){
 val days=slate.mapNotNull { runCatching { java.time.Instant.parse(it.kickoff).atZone(java.time.ZoneId.of("America/New_York")).toLocalDate() }.getOrNull() }.distinct().sorted()
 var day by remember{mutableIntStateOf(0)}
 PullToRefreshBox(isRefreshing=loading,onRefresh=refresh,modifier=Modifier.fillMaxSize()){
  LazyColumn(contentPadding=PaddingValues(bottom=24.dp)){
   item{Column(Modifier.padding(20.dp)){
    SectionCaption("WEEKLY SLATE",Green)
    Text("NFL Matchups",fontSize=28.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=7.dp))
    Text("${slate.size} scheduled games  •  tap for simulations",color=Muted,fontSize=12.sp)
    val index=day.coerceIn(0,(days.size-1).coerceAtLeast(0))
    Surface(color=Card2,shape=RoundedCornerShape(16.dp),border=BorderStroke(1.dp,Line),modifier=Modifier.fillMaxWidth().padding(top=13.dp)){
     Row(verticalAlignment=Alignment.CenterVertically){
      IconButton(onClick={day=(index-1).coerceAtLeast(0)},enabled=index>0){Icon(Icons.Default.ChevronLeft,"Previous game day",tint=Blue)}
      Text(days.getOrNull(index)?.format(java.time.format.DateTimeFormatter.ofPattern("EEEE, MMM d",Locale.US)) ?: "Loading current schedule...",modifier=Modifier.weight(1f),fontSize=16.sp,fontWeight=FontWeight.Bold,textAlign=androidx.compose.ui.text.style.TextAlign.Center)
      IconButton(onClick={day=(index+1).coerceAtMost((days.size-1).coerceAtLeast(0))},enabled=index<days.size-1){Icon(Icons.Default.ChevronRight,"Next game day",tint=Blue)}
     }
    }
    Text(if(lastError!=null)"Schedule source: backup or cached • $lastError" else "Schedule source: ESPN / dated backup",color=Muted,fontSize=11.sp)
    Text("Tap any matchup for its game script and TD projection status.",color=Muted,fontSize=12.sp)
   }}
   val selectedDay=days.getOrNull(day.coerceIn(0,(days.size-1).coerceAtLeast(0)))
   val selectedGames=slate.filter{runCatching{java.time.Instant.parse(it.kickoff).atZone(java.time.ZoneId.of("America/New_York")).toLocalDate()==selectedDay}.getOrDefault(false)}
   if(selectedGames.isEmpty())item{Text("No schedule returned for this date. Pull down to retry.",color=Gold,modifier=Modifier.padding(20.dp))}
   items(selectedGames,key={it.id}){game->CurrentMatchupCard(game){open(game)}}
   item{Column(Modifier.padding(top=16.dp,bottom=20.dp)){
    Box(Modifier.padding(horizontal=20.dp,vertical=10.dp)){SectionCaption("LIVE TOUCHDOWN FEED",Green)}
    TouchdownFeed(snapshot=live,loading=loading,onRefresh=refresh)
   }}
  }
 }
}
@Composable fun CurrentMatchupCard(game:LiveScheduleGame,open:()->Unit){
 val teams=teamsOf(game)
 val away=teams.getOrNull(0) ?: "AWAY"
 val home=teams.getOrNull(1) ?: "HOME"
 val accent=teamAccent(home)
 Surface(onClick=open,color=Card,shape=RoundedCornerShape(23.dp),border=BorderStroke(1.dp,Line),
  modifier=Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=7.dp)) {
  Column {
   Box(Modifier.fillMaxWidth().height(4.dp).background(Brush.horizontalGradient(listOf(teamAccent(away),accent,Blue.copy(.5f)))))
   Column(Modifier.padding(17.dp)){
    Row(verticalAlignment=Alignment.CenterVertically){
     TeamLogo(away); Spacer(Modifier.width(12.dp))
     Column(Modifier.weight(1f),horizontalAlignment=Alignment.CenterHorizontally){
      Row(horizontalArrangement=Arrangement.Center,verticalAlignment=Alignment.CenterVertically){
       Text(away,color=teamAccent(away),fontWeight=FontWeight.Black,fontSize=20.sp)
       Text("   @   ",color=Muted,fontWeight=FontWeight.Medium,fontSize=13.sp)
       Text(home,color=accent,fontWeight=FontWeight.Black,fontSize=20.sp)
      }
      Text(kickoffLabel(game),color=Muted,fontSize=11.sp)
     }
     Spacer(Modifier.width(12.dp)); TeamLogo(home)
    }
    Spacer(Modifier.height(12.dp))
    HorizontalDivider(color=Line)
    Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.padding(top=12.dp)){
     Pill("MATCHUP INTELLIGENCE")
     Spacer(Modifier.weight(1f))
     Text("OPEN GAME  →",color=Blue,fontWeight=FontWeight.Black,fontSize=11.sp)
    }
   }
  }
 }
}
@Composable fun CurrentGameDetail(game:LiveScheduleGame,projection:WeekProjection?,loading:Boolean,retry:()->Unit,back:()->Unit,trends:Map<String,TeamScoringTrend>,trendsLoading:Set<String>,refreshTrends:()->Unit,charting:List<ChartedCoverage>,importCharting:()->Unit){
 val coverage = remember(game.id,projection,charting) { CoverageAnalyzer.evaluate(game.matchup,projection,charting) }
 val projected = remember(projection,coverage) { projection?.let { CoverageAnalyzer.enrich(it,coverage) } }
 val script = remember(game.id,projected,trends,coverage) { projected?.let { GameScriptEngine.simulate(game.matchup,it,trends,coverage=coverage) } }
 var showRoster by remember(game.id) { mutableStateOf(false) }
 LazyColumn(contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item {
   TextButton(onClick=back){Icon(Icons.Default.ArrowBack,null);Text("All games")}
   Surface(color=Card,shape=RoundedCornerShape(22.dp),border=BorderStroke(1.dp,Line)) {
    Column {
     val teams=teamsOf(game)
     Box(Modifier.fillMaxWidth().height(4.dp).background(Brush.horizontalGradient(listOf(teamAccent(teams.firstOrNull() ?: ""),teamAccent(teams.lastOrNull() ?: "")))))
     Column(Modifier.padding(18.dp)){
      SectionCaption("MATCHUP INTELLIGENCE",Green)
      Spacer(Modifier.height(12.dp))
      Row(verticalAlignment=Alignment.CenterVertically){
       teams.firstOrNull()?.let { TeamLogo(it) };Spacer(Modifier.width(12.dp))
       Text(game.matchup,fontSize=25.sp,fontWeight=FontWeight.Black,modifier=Modifier.weight(1f))
       teams.lastOrNull()?.let { TeamLogo(it) }
      }
      Text(kickoffLabel(game),color=Muted,fontSize=12.sp,modifier=Modifier.padding(top=8.dp))
      Row(horizontalArrangement=Arrangement.spacedBy(7.dp),modifier=Modifier.padding(top=12.dp)){
       Pill("USAGE",Blue);Pill("INJURIES",Coral);Pill("DRIVE SIM",Green)
      }
     }
    }
   }
  }
  // The same projection and injury inputs power the screen, ranked scorers, and simulated final score.
  // If validated final-score data is missing, do not fabricate a football score.
  item { Surface(color=Card,shape=RoundedCornerShape(18.dp),border=BorderStroke(1.dp,Line)) {
   Column(Modifier.fillMaxWidth().padding(17.dp)){
    SectionCaption("SIMULATION REPORT",Green)
    Text("Scoring outlook & game script",fontSize=21.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=8.dp))
    Text("Recent team form • offensive opportunity • confirmed injuries • drive outcomes",color=Muted,fontSize=11.sp)
    if(loading && script==null) {
     Spacer(Modifier.height(12.dp));CircularProgressIndicator(color=Blue)
     Text("Retrieving team results, usage and injury reports...",color=Muted,fontSize=12.sp)
    } else if(script==null) {
     Text("No defensible score simulation yet: need at least two completed games with verified points scored AND allowed for both teams.",color=Gold,modifier=Modifier.padding(top=12.dp))
     Text(projection?.error ?: "Open this game to load the ESPN data.",color=Muted,fontSize=12.sp)
     TextButton(onClick=retry,enabled=!loading){Text("Retry matchup data")}
    } else {
     if(script.dataWarning!=null)Text("SOURCE WARNING: ${script.dataWarning}",color=Coral,fontSize=12.sp,modifier=Modifier.padding(top=9.dp))
     Surface(color=Card2,shape=RoundedCornerShape(17.dp),modifier=Modifier.fillMaxWidth().padding(top=12.dp)){
      Column(Modifier.padding(14.dp)){
       Text("PROJECTED SCORE  •  5,000 DRIVE TRIALS",color=Green,fontSize=10.sp,fontWeight=FontWeight.Black)
       Text("${script.away} ${script.awayScore}    –    ${script.home} ${script.homeScore}",fontSize=27.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=5.dp))
       Text("Uncalibrated scenario model · final prediction repeated below",color=Muted,fontSize=10.sp)
      }
     }
     script.sections.forEachIndexed { sectionIndex,section ->
      Surface(color=if(sectionIndex%2==0)Card2 else Card,shape=RoundedCornerShape(14.dp),
       modifier=Modifier.fillMaxWidth().padding(top=9.dp)) {
       Column(Modifier.padding(12.dp)) {
        SectionCaption(section.title,when{
         "INJUR" in section.title || "RISK" in section.title -> Coral
         "SHORT-YARDAGE" in section.title || "SCORING" in section.title -> Gold
         "SIMULATION" in section.title -> Green
         else -> Blue
        })
        Text(section.paragraph,modifier=Modifier.padding(top=7.dp),fontSize=13.sp,lineHeight=20.sp)
       }
      }
     }
     HorizontalDivider(modifier=Modifier.padding(top=16.dp,bottom=10.dp),color=Line)
     SectionCaption("TOP 3 TOUCHDOWN CANDIDATES",Gold)
     Text("Ranked by recent opportunities adjusted for projected team scoring; NOT calibrated anytime-TD percentages.",color=Muted,fontSize=11.sp,modifier=Modifier.padding(bottom=6.dp))
     if(script.scorers.isEmpty()) Text("Not enough verified player opportunities for a scorer ranking.",color=Gold,fontSize=12.sp)
     script.scorers.forEachIndexed { i,p ->
      Surface(color=Card2,shape=RoundedCornerShape(14.dp),modifier=Modifier.fillMaxWidth().padding(top=8.dp)){
       Row(Modifier.padding(12.dp),verticalAlignment=Alignment.Top){
        Pill("#${i+1}",if(i==0)Gold else Blue)
        Spacer(Modifier.width(9.dp))
        Column(Modifier.weight(1f)){
         Text(p.name,fontWeight=FontWeight.Black,color=if(i==0)Gold else Color.White)
         Text("${p.team} • ${p.position}",color=teamAccent(p.team),fontSize=11.sp)
         Text(p.rationale,color=Muted,fontSize=12.sp,lineHeight=18.sp,modifier=Modifier.padding(top=5.dp))
        }
       }
      }
     }
     HorizontalDivider(modifier=Modifier.padding(top=18.dp,bottom=10.dp),color=Line)
     SectionCaption("FINAL SCORE PREDICTION",Green)
     Text("${script.away} ${script.awayScore}  –  ${script.home} ${script.homeScore}",fontSize=27.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=6.dp))
     Text("${script.sampleCount} simulated games • Uncalibrated scenario estimate",color=Muted,fontSize=11.sp)
     Text(script.inputSummary,color=Muted,fontSize=10.sp,modifier=Modifier.padding(top=9.dp))
    }
   }
  } }
  item { Surface(color=Card,shape=RoundedCornerShape(18.dp)) { Column(Modifier.padding(16.dp)) {
   SectionCaption("RECENT SCORING DNA",Gold)
   Text("Observed touchdown outcomes, not goal-line usage or a player projection",color=Muted,fontSize=11.sp)
   val isFetching=teamsOf(game).any{it in trendsLoading}
   TextButton(onClick=refreshTrends,enabled=!isFetching){Text(if(isFetching) "Updating ESPN scoring data..." else "Refresh scoring history")}
   teamsOf(game).forEach { code ->
    val trend=trends[code]
    Text(code,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=10.dp))
    if(code in trendsLoading) Text("Loading ESPN game summaries...",color=Blue,fontSize=12.sp)
    else if(trend==null) Text("Scoring history not loaded",color=Muted,fontSize=12.sp)
    else if(trend.gamesObserved==0) Text("Unavailable — not verified: ${trend.error?:trend.notes}",color=Gold,fontSize=12.sp)
    else {
     Text("${trend.gamesObserved} games • ${trend.receiving} receiving TDs • ${trend.rbRush} rushing TDs • ${trend.other} other TDs",fontSize=12.sp)
     Text(trend.notes,color=Muted,fontSize=11.sp)
     if(trend.error!=null) Text("PARTIAL DATA: ${trend.error}",color=Gold,fontSize=11.sp)
    }
   }
  } } }
  item { Surface(color=Card,shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(16.dp)){
   SectionCaption("DEFENSIVE INJURY WATCH",Coral)
   Text("ESPN reported injuries • not a verified game-day inactive list",color=Muted,fontSize=11.sp)
   Text(projection?.injuryReportStatus ?: "Waiting for injury feeds...",color=Muted,fontSize=11.sp,modifier=Modifier.padding(top=6.dp))
   if(projection?.defensiveNotes?.isNotEmpty()==true) projection.defensiveNotes.forEach { note ->
    Text("• $note",color=Gold,fontSize=12.sp,modifier=Modifier.padding(top=7.dp))
   } else Text("No confirmed defensive absences retrieved. This does NOT mean all starters are healthy.",color=Gold,fontSize=12.sp,modifier=Modifier.padding(top=7.dp))
  }} }
  item { Surface(color=Card,shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(16.dp)) {
   SectionCaption("RECEIVER / CORNER COVERAGE",Purple)
   Text("Historical route-level coverage data is shown separately from projected future assignments.",color=Muted,fontSize=11.sp)
   Text(coverage.status,color=if(coverage.matches.isEmpty())Gold else Muted,fontSize=12.sp,modifier=Modifier.padding(top=8.dp))
   coverage.matches.take(8).forEach { m ->
    HorizontalDivider(color=Line,modifier=Modifier.padding(vertical=8.dp))
    Text("${m.receiver} → ${m.defender} (${m.defenderTeam})",fontWeight=FontWeight.Bold,fontSize=13.sp)
    Text(m.note,color=Muted,fontSize=11.sp,lineHeight=17.sp,modifier=Modifier.padding(top=5.dp))
   }
   TextButton(onClick=importCharting) { Text("Import charted coverage CSV") }
   Text("Source option: Fantasy Points Data Suite → Shadow Index. Provider license/export required; no fabricated charting.",color=Muted,fontSize=11.sp)
  }} }
  item { Surface(color=Card,shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(16.dp)) {
   SectionCaption("CURRENT ROSTERS & TRANSACTIONS",Blue)
   Text("Team assignment comes from the current ESPN roster plus dated verified official transactions; final active list still requires verification.",color=Muted,fontSize=11.sp)
   projection?.rosterNotes?.forEach { Text("• $it",color=Gold,fontSize=12.sp,modifier=Modifier.padding(top=6.dp)) }
   TextButton(onClick={showRoster=!showRoster}) { Text(if(showRoster) "Hide offensive rosters" else "Show all offensive roster players") }
   if(showRoster) teamsOf(game).forEach { code ->
    Text(code,color=Blue,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=8.dp))
    Text(projection?.offensiveRoster?.get(code)?.joinToString(" · ") ?: "Roster unavailable",color=Muted,fontSize=11.sp)
   }
  }} }
  item {SectionCaption("TOP 10 TD OPPORTUNITIES",Gold)
   Text("Ranked from both teams using recent verified carries, targets, production and reported injuries. The index is NOT a calibrated TD probability.",color=Muted,fontSize=12.sp)
   if(loading) CircularProgressIndicator(modifier=Modifier.padding(12.dp))
   if(projected?.error!=null)Text("Data warning: ${projected.error}",color=Gold,fontSize=11.sp)
   if(!loading && projection==null)TextButton(onClick=retry){Text("Load recent usage")}
   if(projected!=null && projected.candidates.isEmpty())Text("No candidates have enough verified recent usage. Check connectivity and retry; no fictional rankings are shown.",color=Gold)
  }
  if(projected!=null)itemsIndexed(projected.candidates.take(10),key={_,p->p.team+p.name}){i,p->
   Surface(color=Card,shape=RoundedCornerShape(14.dp),border=BorderStroke(1.dp,if(i==0)Blue else Line)){
    Column(Modifier.fillMaxWidth().padding(13.dp)){
     Row(verticalAlignment=Alignment.CenterVertically){Pill("#${i+1}",if(i==0)Gold else Blue)
      Spacer(Modifier.width(10.dp))
      Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.Bold);Text("${p.team} • ${p.position} • ${p.games} verified games",color=Muted,fontSize=11.sp)}
      Column(horizontalAlignment=Alignment.End){Text("${p.score}/100",color=Green,fontWeight=FontWeight.Black);Text("USAGE INDEX",color=Muted,fontSize=9.sp)}
     }
     if(p.shortRushingTdFinishes>0)Pill("${p.shortRushingTdFinishes} SHORT RUSH TD FINISH(ES)",Gold)
     Text(p.reason,color=Muted,fontSize=11.sp,modifier=Modifier.padding(top=7.dp))
     if(!p.status.startsWith("Roster listed"))Text("Availability: ${p.status}",color=Gold,fontSize=11.sp,modifier=Modifier.padding(top=5.dp))
    }
   }
  }
  item {TextButton(onClick=retry,enabled=!loading){Text("Refresh roster + game logs + injuries")}
   Text("${projection?.source ?: "ESPN sources loading"} • ${projection?.gamesVerified ?: 0} team game-boxscores processed • ${projection?.checkedAt ?: ""}",color=Muted,fontSize=10.sp)
   Text("Data limitations: targets/carries are box-score counts; route charting is historical and future shadow assignments remain projections; goal-line targets and final inactives may be unverified. Scores are opportunity indices, not betting probabilities.",color=Gold,fontSize=11.sp,modifier=Modifier.padding(top=6.dp))}

 }
}
@Composable fun CurrentPicks(slate:List<LiveScheduleGame>,projections:Map<String,WeekProjection>,open:(LiveScheduleGame)->Unit){
 Column {Title("TD Candidates","Current-week roster-backed usage • short-yardage finishing evidence")
  LazyColumn {items(slate,key={it.id}){game->
   CurrentMatchupCard(game){open(game)}
   val p=projections[game.id]
   if(p!=null)Text("Top ${p.candidates.size.coerceAtMost(10)} recent-usage candidates • tap for details",color=Blue,modifier=Modifier.padding(horizontal=20.dp))
   else Text("Tap game to load current player pool",color=Muted,modifier=Modifier.padding(horizontal=20.dp))
  }}
 }
}
@Composable fun CurrentScripts(slate:List<LiveScheduleGame>,projections:Map<String,WeekProjection>,trends:Map<String,TeamScoringTrend>,charting:List<ChartedCoverage>,open:(LiveScheduleGame)->Unit){
 Column {Title("Game Scripts","Drive-by-drive outcomes • protections & turnovers • verified scoring roles")
  LazyColumn {items(slate,key={it.id}){game->
   val report = remember(game.id,projections[game.id],trends,charting) {
    projections[game.id]?.let { p ->
     val coverage=CoverageAnalyzer.evaluate(game.matchup,p,charting)
     GameScriptEngine.simulate(game.matchup,CoverageAnalyzer.enrich(p,coverage),trends,coverage=coverage)
    }
   }
   Surface(onClick={open(game)},color=Card,shape=RoundedCornerShape(18.dp),border=BorderStroke(1.dp,Line),modifier=Modifier.padding(horizontal=16.dp,vertical=7.dp).fillMaxWidth()) {
    Column(Modifier.padding(16.dp)) {
     SectionCaption("GAME SCRIPT PREVIEW",teamAccent(teamsOf(game).lastOrNull() ?: ""))
     Text(game.matchup,fontWeight=FontWeight.Black,fontSize=20.sp,modifier=Modifier.padding(top=8.dp))
     Text(kickoffLabel(game),color=Muted,fontSize=12.sp)
     if(report==null){
      Text("Tap to load recent final scores, player usage, defensive injuries and simulate this matchup.",color=Muted,fontSize=12.sp,modifier=Modifier.padding(top=8.dp))
     } else {
      Surface(color=Card2,shape=RoundedCornerShape(13.dp),modifier=Modifier.padding(top=10.dp).fillMaxWidth()){
       Column(Modifier.padding(11.dp)){
        SectionCaption("PROJECTED SCORE",Green)
        Text("${report.away} ${report.awayScore}  –  ${report.home} ${report.homeScore}",color=Color.White,fontWeight=FontWeight.Black,fontSize=19.sp,modifier=Modifier.padding(top=5.dp))
       }
      }
      Text("Top TD looks: ${report.scorers.joinToString { it.name }.ifBlank { "unverified" }}",color=Muted,fontSize=12.sp,modifier=Modifier.padding(top=7.dp))
     }
     Text("READ FULL SIMULATION + EXPLANATIONS  ›",color=Blue,fontSize=11.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=9.dp))
    }
   }
  }}
 }
}
@Composable fun CurrentParlays(slate:List<LiveScheduleGame>){
 Column{Title("TD parlays","Current-week player eligibility required")
  Text("Automatic TD parlays are temporarily disabled. The previous player pool was historical and could include players not active in these ${slate.size} games. A trustworthy generator requires validated current-week candidates.",color=Gold,modifier=Modifier.padding(20.dp))
 }
}
