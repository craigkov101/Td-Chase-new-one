package com.nflchase.tdengine.data

import org.junit.Assert.*
import org.junit.Test
import java.time.Instant

class SlateAndUsageTest {
    private val now=Instant.parse("2026-10-17T15:00:00Z")

    @Test fun `finished Thursday game is hidden and Sunday game is preferred`() {
        val games=listOf(
            LiveScheduleGame("th","SEA @ DEN","2026-10-16T00:15:00Z","STATUS_FINAL"),
            LiveScheduleGame("past-stale","ARI @ LAR","2026-10-16T00:15:00Z","STATUS_SCHEDULED"),
            LiveScheduleGame("sun","HOU @ JAX","2026-10-18T13:30:00Z","STATUS_SCHEDULED"),
            LiveScheduleGame("sun2","CHI @ ATL","2026-10-18T17:00:00Z","STATUS_SCHEDULED"),
            LiveScheduleGame("mon","DAL @ GB","2026-10-19T00:20:00Z","STATUS_SCHEDULED")
        )
        val filtered=SlatePolicy.upcoming(games,now)
        assertEquals(3, filtered.size)
        assertEquals("sun", filtered.first().id)
        assertEquals("2026-10-18",SlatePolicy.preferredDay(filtered)?.toString())
        assertFalse(filtered.any { it.id=="th" || it.id=="past-stale" })
    }

    @Test fun `a live game remains visible while finals disappear`() {
        val games=listOf(
            LiveScheduleGame("live","SEA @ DEN","2026-10-16T00:15:00Z","STATUS_IN_PROGRESS"),
            LiveScheduleGame("final","CHI @ ATL","2026-10-18T17:00:00Z","STATUS_FINAL")
        )
        assertEquals(listOf("live"),SlatePolicy.upcoming(games,now).map { it.id })
    }

    @Test fun `traded receiver keeps his old team stats but projection is labeled estimate`() {
        val history=listOf(
            WeekGameUsage("2026-10-04","ARI",4,0,45,0,0),
            WeekGameUsage("2026-09-28","ARI",6,0,40,0,1),
            WeekGameUsage("2026-09-21","ARI",3,0,12,0,0)
        )
        val forecast=UsageForecast.forReceiver(history,listOf(31,35,29),"C.J. Stroud",
            listOf("Nico Collins" to 8.4,"Jaylin Noel" to 4.2,"Woody Marks" to 3.0),true)
        assertNotNull(forecast)
        assertEquals("C.J. Stroud",forecast!!.quarterback)
        assertTrue(forecast.high>=forecast.low)
        assertTrue(forecast.high<=35)
        assertTrue(forecast.explanation.contains("New-team transition"))
        assertEquals("ARI",history.first().sourceTeam)
    }

    @Test fun `no made up targets when team volume is missing`() {
        assertNull(UsageForecast.forReceiver(listOf(
            WeekGameUsage("2026-10-04","ARI",3,0,33,0,0),
            WeekGameUsage("2026-10-03","ARI",4,0,21,0,0)
        ),emptyList(),"C.J. Stroud",emptyList(),true))
    }

    @Test fun `unverified route projection never claims shadow coverage`() {
        val players=listOf(WeekCandidate("Marvin Harrison Jr.","HOU","WR","Active",45,"observed",3,4.0),
            WeekCandidate("Nico Collins","HOU","WR","Active",67,"observed",3,8.1))
        val matches=CoverageProjection.estimate(players,mapOf("JAX" to listOf("CB A","CB B")),"HOU","JAX")
        assertEquals(2,matches.size)
        assertEquals("Nico Collins",matches.first().receiver)
        assertTrue(matches.all { it.description.contains("unverified") })
    }
}
