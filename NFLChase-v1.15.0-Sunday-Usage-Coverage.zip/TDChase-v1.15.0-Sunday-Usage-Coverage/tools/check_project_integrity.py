"""Fast source integrity checks. These do not replace a real Android build."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'app/src/main/java/com/nflchase/tdengine'
main=(SRC/'MainActivity.kt').read_text()
injury=(SRC/'data/CurrentWeekEngine.kt').read_text()
feeds=(SRC/'data/ReliableFeeds.kt').read_text()
audits=(SRC/'data/ModelAuditStore.kt').read_text()
build=(ROOT/'app/build.gradle.kts').read_text()
workflow=(ROOT/'.github/workflows/build-apk.yml').read_text()
checks={
 'v1.15.0 version and code': 'versionCode = 1150' in build and 'versionName = "1.15.0"' in build,
 'Persistent audited predictions': 'td-chase-audit-v1.json' in main and 'ModelAuditStore(' in main,
 'Pre-kickoff cutoff': 'clock() >= kickoff' in audits,
 'Final-only grading': 'status.optBoolean("completed"' in audits,
 'Both teams must have box scores': 'awayLines.size < 3 || homeLines.size < 3' in audits,
 'Top-three and top-ten grading': 'topThreeHits' in audits and 'topTenHits' in audits,
 'No fake TD probability': 'NOT a touchdown probability' in audits or 'NOT a touchdown probability' in main,
 'No broken default injury endpoints': 'useLegacyInjuryEndpoints: Boolean = false' in injury,
 'Roster-based limited injury evidence': 'fromRoster(json, rosterFeedState == "STALE CACHE")' in injury,
 'Derived injury status': 'onSupplementalStatus("Injuries", code,' in injury,
 'Cache still used': 'td-chase-espn-v2' in feeds,
 'Partial status displayed': '"$partial PARTIAL"' in main,
 'Secondary context': 'AUTOMATIC SECONDARY CONTEXT' in main,
 'Licensed coverage import retained': 'Import licensed coverage CSV' in main,
 'Saved game details': 'Check finished games and grade saved picks' in main,
 'Existing design palette': (SRC/'ChaseDesign.kt').exists(),
 'New audit tests': (ROOT/'app/src/test/java/com/nflchase/tdengine/data/ModelAuditStoreTest.kt').exists(),
 'Old integrated tests preserved': (ROOT/'app/src/test/java/com/nflchase/tdengine/data/IntegratedMatchupTest.kt').exists(),
 'Manual workflow': 'workflow_dispatch:' in workflow and '\n  push:' not in workflow,
 'No old SDK action': 'android-actions/setup-android@v3' not in workflow,
 'Android Gradle tests and compile': 'testDebugUnitTest' in workflow and 'assembleDebug' in workflow,
 'Internet permission': 'android.permission.INTERNET' in (ROOT/'app/src/main/AndroidManifest.xml').read_text(),
 'Slate uses kickoff and excludes completed games': 'SlatePolicy.upcoming' in main and (SRC/'data/SlatePolicy.kt').exists(),
 'Header uses real TD logo': 'R.drawable.td_chase_mark' in main and (ROOT/'app/src/main/res/drawable-nodpi/td_chase_mark.png').exists(),
 'Game logs retained with former-team attribution': 'val recentGameLog: List<WeekGameUsage>' in injury and 'GameStats(g.id,g.date,move.priorTeam' in injury,
 'New-team WR target projection': 'UsageForecast.forReceiver' in injury and 'C.J. Stroud' in (ROOT/'app/src/test/java/com/nflchase/tdengine/data/SlateAndUsageTest.kt').read_text(),
 'Coverage candidates labeled estimated': 'CoverageProjection.estimate' in injury and 'unverified' in injury,
 'Regression tests for Sunday slate and receiver projection': (ROOT/'app/src/test/java/com/nflchase/tdengine/data/SlateAndUsageTest.kt').exists(),
}
for label,passed in checks.items():
 print(('PASS' if passed else 'FAIL')+': '+label)
if not all(checks.values()): raise SystemExit('Release check(s) failed')
print(f'PASS: {len(checks)} source-integrity checks')
