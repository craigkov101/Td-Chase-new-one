package com.nflchase.tdengine

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nflchase.tdengine.data.*
import com.nflchase.tdengine.model.*

private val Bg=Color(0xFF071019); private val Card=Color(0xFF0D1A24); private val Line=Color(0xFF20303D); private val Green=Color(0xFF55F34B); private val Muted=Color(0xFF8D9AA5); private val Gold=Color(0xFFFFC44D)

class MainActivity:ComponentActivity(){ override fun onCreate(b:Bundle?){super.onCreate(b);setContent{MaterialTheme(colorScheme=darkColorScheme(background=Bg,surface=Card,primary=Green)){App()}}}}

enum class Tab(val title:String){GAMES("Games"),BOARD("TD Board"),SCRIPTS("Scripts"),BUILDER("Builder"),LAB("Model Lab")}

@Composable fun App(){ var tab by remember{mutableStateOf(Tab.GAMES)}; var selected by remember{mutableStateOf<GameCard?>(null)}; val repo=remember{TdRepository()}; val learn=remember{LearningEngine()}
    Scaffold(containerColor=Bg,bottomBar={NavigationBar(containerColor=Color(0xFF061019)){Tab.entries.forEach{t->NavigationBarItem(selected=tab==t,onClick={tab=t;selected=null},icon={Icon(when(t){Tab.GAMES->Icons.Default.SportsFootball;Tab.BOARD->Icons.Default.Leaderboard;Tab.SCRIPTS->Icons.Default.QueryStats;Tab.BUILDER->Icons.Default.Build;Tab.LAB->Icons.Default.Science},null)},label={Text(t.title)},colors=NavigationBarItemDefaults.colors(selectedIconColor=Color.Black,indicatorColor=Green,selectedTextColor=Green,unselectedIconColor=Muted,unselectedTextColor=Muted))}}}){pad->
        Column(Modifier.padding(pad).fillMaxSize()){Header(); when { selected!=null -> GameDetail(selected!!,onBack={selected=null},learn=learn); tab==Tab.GAMES->Games(repo.games()){selected=it}; tab==Tab.BOARD->Board(repo.allCandidates()); tab==Tab.SCRIPTS->Scripts(repo.games()); tab==Tab.BUILDER->Builder(repo.allCandidates()); else->Lab(learn) }} }
}
@Composable fun Header(){Row(Modifier.fillMaxWidth().padding(20.dp,16.dp),verticalAlignment=Alignment.CenterVertically){Text("NFL ",fontSize=28.sp,fontWeight=FontWeight.Black);Text("CHASE",fontSize=28.sp,fontWeight=FontWeight.Black,color=Green);Spacer(Modifier.width(10.dp));Surface(color=Green.copy(.12f),shape=RoundedCornerShape(20.dp)){Text("v0.9.0 • MATCHUP EXPLAINER",color=Green,fontWeight=FontWeight.Bold,modifier=Modifier.padding(10.dp,5.dp))}}}
@Composable fun Title(a:String,b:String){Column(Modifier.padding(horizontal=20.dp,vertical=8.dp)){Text(a,fontSize=28.sp,fontWeight=FontWeight.Black);Text(b,color=Muted,fontSize=14.sp)}}
@Composable fun Games(g:List<GameCard>,open:(GameCard)->Unit){Title("Touchdown Command Center","Every matchup → ranked anytime-TD candidates.");LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){items(g){x->Surface(onClick={open(x)},color=Card,shape=RoundedCornerShape(22.dp),border=BorderStroke(1.dp,Line)){Column(Modifier.padding(18.dp)){Row{Text("${x.away}  @  ${x.home}",fontSize=22.sp,fontWeight=FontWeight.Black);Spacer(Modifier.weight(1f));Text(x.kickoff,color=Muted)};Spacer(Modifier.height(12.dp));Text("TOP TD LOOKS",color=Green,fontSize=12.sp,fontWeight=FontWeight.Bold);x.candidates.take(5).forEachIndexed{i,c->Row(Modifier.padding(top=9.dp),verticalAlignment=Alignment.CenterVertically){Text("${i+1}",color=Gold,fontWeight=FontWeight.Bold);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(c.name,fontWeight=FontWeight.Bold);Text("${c.position} • ${c.team} vs ${c.opponent}",color=Muted,fontSize=12.sp)};Text("${c.score}",fontSize=22.sp,fontWeight=FontWeight.Black,color=Green)}}}}}}}
@Composable fun Board(c:List<TdCandidate>){Title("TD Board","League-wide model ranking. Odds do not drive the football score.");LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){itemsIndexed(c){i,p->CandidateRow(i+1,p)}}}
@Composable fun CandidateRow(rank:Int,p:TdCandidate){Surface(color=Card,shape=RoundedCornerShape(18.dp),border=BorderStroke(1.dp,Line)){Row(Modifier.fillMaxWidth().padding(15.dp),verticalAlignment=Alignment.CenterVertically){Text("#$rank",color=Gold,fontWeight=FontWeight.Black);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.Black,fontSize=18.sp);Text("${p.team} • ${p.position} vs ${p.opponent}",color=Muted,fontSize=12.sp);Text(p.reason,color=Muted,fontSize=12.sp,modifier=Modifier.padding(top=5.dp))};Column(horizontalAlignment=Alignment.End){Text("${p.score}",color=Green,fontSize=25.sp,fontWeight=FontWeight.Black);Text("${p.probability}% TD",color=Muted,fontSize=11.sp)}}}}
@Composable fun GameDetail(g:GameCard,onBack:()->Unit,learn:LearningEngine){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{TextButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null);Text("All games")};Text("${g.away} @ ${g.home}",fontSize=30.sp,fontWeight=FontWeight.Black);GameMatchupSummary(g);Spacer(Modifier.height(10.dp));Row{Metric("Environment",g.environment.toString());Spacer(Modifier.width(8.dp));Metric("TD looks",g.candidates.size.toString())};Button(onClick={learn.freeze(g)},modifier=Modifier.padding(top=12.dp)){Text("FREEZE PREGAME SNAPSHOT")}};itemsIndexed(g.candidates.sortedByDescending{it.score}){i,p->Surface(color=Card,shape=RoundedCornerShape(22.dp),border=BorderStroke(1.dp,if(i==0) Green.copy(.6f) else Line)){Column(Modifier.padding(18.dp)){Row{Column(Modifier.weight(1f)){Text("#${i+1}  ${p.name}",fontSize=21.sp,fontWeight=FontWeight.Black);Text("${p.position} • ${p.team}",color=Muted)};Text("${p.score}",color=Green,fontSize=30.sp,fontWeight=FontWeight.Black)};Text("MODEL TD ${p.probability}%",color=Gold,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));Factor("Red zone",p.factors.redZone);Factor("Opportunity",p.factors.opportunity);Factor("Matchup",p.effectiveMatchup);Factor("Scheme",p.factors.scheme);Factor("Environment",p.factors.environment);Spacer(Modifier.height(10.dp));p.exploit?.let{ex->ExploitPanel(p.position,ex)};Spacer(Modifier.height(10.dp));Text("Goal-line share ${p.goalLineShare}%  •  RZ opps ${p.redZoneTouches}  •  Recent TD ${p.recentTd}",color=Muted,fontSize=12.sp);MatchupReasons(p);Text(p.reason,modifier=Modifier.padding(top=8.dp))}}}}}


@Composable fun GameMatchupSummary(g:GameCard){
    val top=g.candidates.sortedByDescending{it.score}.firstOrNull() ?: return
    val ex=top.exploit ?: return
    val area=when(top.position){"RB","QB"->"rushing/front-seven";"WR"->"secondary";"TE"->"middle-of-field/red-zone coverage";else->"overall defensive"}
    val edge=top.exploitForPosition
    val strength=when{edge>=85->"major";edge>=75->"clear";edge>=65->"moderate";else->"limited"}
    Text("${top.team} has a $strength $area TD edge vs ${top.opponent}. Top-ranked ${top.position}: ${top.name}. Front 7 ${ex.frontSeven}/100 • Secondary ${ex.secondary}/100 • Red-zone vulnerability ${ex.redZoneDefense}/100 • Personnel impact ${ex.personnelImpact}/100.",color=Muted)
}

@Composable fun MatchupReasons(p:TdCandidate){
    val e=p.exploit ?: return
    val reasons=buildList {
        when(p.position){
            "RB","QB"->{ if(e.frontSeven>=75)add("Weak/attackable front seven"); if(e.redZoneDefense>=75)add("Favorable goal-line/red-zone defense") }
            "WR"->{ if(e.secondary>=75)add("Attackable secondary"); if(e.redZoneDefense>=75)add("Favorable red-zone coverage matchup") }
            "TE"->{ if(e.secondary>=72)add("Coverage weakness helps TE routes"); if(e.redZoneDefense>=75)add("Favorable red-zone matchup") }
        }
        if(e.personnelImpact>=70)add("Defensive personnel/injury edge")
        if(p.goalLineShare>=65)add("Strong goal-line share (${p.goalLineShare}%)")
        if(p.factors.opportunity>=90)add("Elite projected usage")
        if(p.factors.redZone>=90)add("Elite scoring-area role")
        if(p.factors.explosive>=94)add("Explosive TD ability")
    }.take(5)
    if(reasons.isNotEmpty()){Spacer(Modifier.height(10.dp));Text("WHY THIS PICK",color=Green,fontWeight=FontWeight.Black,fontSize=12.sp);reasons.forEach{Text("• $it",fontSize=12.sp,modifier=Modifier.padding(top=3.dp))}}
}

@Composable fun ExploitPanel(position:String,e:DefensiveExploit){
    val positionEdge=when(position){"RB","QB"->((e.frontSeven*.55)+(e.redZoneDefense*.30)+(e.personnelImpact*.15)).toInt();"WR"->((e.secondary*.60)+(e.redZoneDefense*.25)+(e.personnelImpact*.15)).toInt();"TE"->((e.secondary*.35)+(e.redZoneDefense*.45)+(e.personnelImpact*.20)).toInt();else->e.score}
    Surface(color=Color(0xFF09151D),shape=RoundedCornerShape(14.dp),border=BorderStroke(1.dp,Line)){Column(Modifier.fillMaxWidth().padding(12.dp)){
        Row{Text("DEFENSIVE EXPLOIT",color=Gold,fontWeight=FontWeight.Black);Spacer(Modifier.weight(1f));Text("$positionEdge/100",color=Green,fontWeight=FontWeight.Black)}
        Text("Front 7 ${e.frontSeven}  •  Secondary ${e.secondary}  •  Red zone ${e.redZoneDefense}  •  Personnel ${e.personnelImpact}",color=Muted,fontSize=11.sp,modifier=Modifier.padding(top=5.dp))
        Text(e.note,fontSize=12.sp,modifier=Modifier.padding(top=6.dp))
    }}
}
@Composable fun Factor(n:String,v:Double){Row(Modifier.padding(vertical=2.dp)){Text(n,color=Muted,modifier=Modifier.width(100.dp));LinearProgressIndicator(progress={v.toFloat()/100},modifier=Modifier.weight(1f).height(7.dp),color=Green,trackColor=Line);Text(" ${v.toInt()}",fontWeight=FontWeight.Bold)}}
@Composable fun Metric(n:String,v:String){Surface(color=Card,shape=RoundedCornerShape(15.dp),border=BorderStroke(1.dp,Line)){Column(Modifier.padding(15.dp)){Text(v,fontSize=22.sp,fontWeight=FontWeight.Black,color=Green);Text(n,color=Muted,fontSize=11.sp)}}}
@Composable fun Scripts(g:List<GameCard>){Title("Game Scripts","TD rankings must agree with projected game flow.");LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){items(g){x->Surface(color=Card,shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(17.dp)){Text("${x.away} @ ${x.home}",fontWeight=FontWeight.Black,fontSize=19.sp);GameMatchupSummary(x);Text("Environment ${x.environment}/100",color=Green,modifier=Modifier.padding(top=8.dp))}}}}}
@Composable fun Builder(c:List<TdCandidate>){var legs by remember{mutableStateOf(3)};Title("TD Builder","Model-first combinations with transparent legs.");Column(Modifier.padding(16.dp)){Row{(1..5).forEach{n->FilterChip(selected=legs==n,onClick={legs=n},label={Text("$n")});Spacer(Modifier.width(5.dp))}};Spacer(Modifier.height(14.dp));c.take(legs).forEachIndexed{i,p->CandidateRow(i+1,p)};Spacer(Modifier.height(12.dp));Text("Correlation check: avoid blindly stacking players competing for the same limited scoring share.",color=Muted)}}
@Composable fun Lab(l:LearningEngine){Title("Model Lab","Freeze → grade → calibrate. Learn from opportunity, not only box-score results.");Column(Modifier.padding(16.dp)){Surface(color=Card,shape=RoundedCornerShape(22.dp),border=BorderStroke(1.dp,Line)){Column(Modifier.padding(20.dp)){Text("LEARNING STATUS",color=Green,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));Row{Metric("Snapshots",l.samples().toString());Spacer(Modifier.width(8.dp));Metric("Graded",l.graded().toString());Spacer(Modifier.width(8.dp));Metric("Brier","%.3f".format(l.brier()))};Spacer(Modifier.height(18.dp));Text("Starting model weights",fontWeight=FontWeight.Black);Text("Red Zone 26% • Opportunity 20% • Matchup 20% • Scheme 12% • Environment 11% • Role/Injury 6% • Explosive 5%",color=Muted,modifier=Modifier.padding(top=7.dp));Text("Next data layer will store actual goal-line/RZ opportunities, snaps, routes, carries, targets and game-state so a near-miss is not learned as the same thing as zero opportunity.",color=Muted,modifier=Modifier.padding(top=15.dp))}}}}
