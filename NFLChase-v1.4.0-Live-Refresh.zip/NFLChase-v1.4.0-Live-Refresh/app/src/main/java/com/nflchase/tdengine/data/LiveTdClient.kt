package com.nflchase.tdengine.data

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

data class LiveTdEvent(val id:String,val game:String,val team:String,val text:String,val quarter:Int,val clock:String)
data class LivePlayerStatus(val name:String,val status:String,val detail:String,val gameId:String)
data class LiveTdSnapshot(
    val events:List<LiveTdEvent>,
    val liveGames:Int,
    val updatedAt:String,
    val unavailablePlayers:Set<String> = emptySet(),
    val playerStatuses:List<LivePlayerStatus> = emptyList(),
    val error:String?=null
)

class LiveTdClient {
 private fun get(u:String):String {
  val c=(URL(u).openConnection() as HttpURLConnection).apply{
   connectTimeout=8000;readTimeout=8000;requestMethod="GET"
   setRequestProperty("Accept","application/json");setRequestProperty("User-Agent","TD-Chase/1.4")
  }
  return try{if(c.responseCode !in 200..299) error("HTTP ${c.responseCode}");c.inputStream.bufferedReader().use{it.readText()}}finally{c.disconnect()}
 }
 private fun norm(s:String)=s.lowercase(Locale.US).replace(Regex("[^a-z0-9 ]"),"").replace(Regex("\\s+")," ").trim()
 private fun unavailable(s:String):Boolean {
  val x=s.uppercase(Locale.US)
  return listOf("OUT","INACTIVE","INJURED RESERVE","IR","PUP","SUSPENDED","RULED OUT","WILL NOT RETURN","DOUBTFUL TO RETURN").any{x.contains(it)}
 }
 private fun collectInjuries(summary:JSONObject,eventId:String,out:MutableList<LivePlayerStatus>){
  fun add(o:JSONObject){
   val athlete=o.optJSONObject("athlete")
   val name=athlete?.optString("displayName")?.takeIf{it.isNotBlank()}
       ?:o.optString("displayName").takeIf{it.isNotBlank()}
       ?:o.optString("name").takeIf{it.isNotBlank()}
   val status=listOf(o.optString("status"),o.optString("type"),o.optString("description"),o.optString("detail"),o.optString("shortComment")).filter{it.isNotBlank()}.joinToString(" • ")
   if(name!=null && status.isNotBlank()) out+=LivePlayerStatus(name,status,status,eventId)
  }
  val injuries=summary.optJSONArray("injuries")
  if(injuries!=null) for(i in 0 until injuries.length()){
   val team=injuries.optJSONObject(i)?:continue
   val arr=team.optJSONArray("injuries") ?: team.optJSONArray("items")
   if(arr!=null) for(j in 0 until arr.length()) arr.optJSONObject(j)?.let{add(it)}
  }
  val direct=summary.optJSONObject("injuries")
  if(direct!=null){val arr=direct.optJSONArray("items");if(arr!=null)for(i in 0 until arr.length())arr.optJSONObject(i)?.let{add(it)}}
 }
 fun loadToday():LiveTdSnapshot=try{
  val day=SimpleDateFormat("yyyyMMdd",Locale.US).format(Date())
  val board=JSONObject(get("https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard?dates=$day"))
  val es=board.optJSONArray("events");val tdOut=mutableListOf<LiveTdEvent>();val statuses=mutableListOf<LivePlayerStatus>();var live=0
  if(es!=null) for(i in 0 until es.length()){
   val e=es.getJSONObject(i);val eid=e.optString("id");val game=e.optString("shortName",e.optString("name","NFL"))
   val cs=e.optJSONArray("competitions");val st=if(cs!=null&&cs.length()>0)cs.getJSONObject(0).optJSONObject("status")?.optJSONObject("type")?.optString("name","")?:"" else ""
   if(st.contains("IN_PROGRESS"))live++
   if(eid.isBlank())continue
   val summary=JSONObject(get("https://site.api.espn.com/apis/site/v2/sports/football/nfl/summary?event=$eid"))
   collectInjuries(summary,eid,statuses)
   val plays=summary.optJSONArray("scoringPlays")
   if(plays!=null) for(j in 0 until plays.length()){
    val p=plays.getJSONObject(j);val typ=p.optJSONObject("scoringType")?.optString("name","")?:"";val txt=p.optString("text","")
    val td=typ.equals("touchdown",true)||txt.contains("touchdown",true)||Regex("""\b\d+\s+Yd\s+(Run|pass|reception)\b""",RegexOption.IGNORE_CASE).containsMatchIn(txt)
    if(td)tdOut+=LiveTdEvent(p.optString("id","$eid-$j-${txt.hashCode()}"),game,p.optJSONObject("team")?.optString("abbreviation","")?:"",txt,p.optJSONObject("period")?.optInt("number",0)?:0,p.optJSONObject("clock")?.optString("displayValue","")?:"")
   }
  }
  val unavailable=statuses.filter{unavailable(it.status)}.map{norm(it.name)}.filter{it.isNotBlank()}.toSet()
  LiveTdSnapshot(tdOut.distinctBy{it.id}.reversed(),live,SimpleDateFormat("h:mm:ss a",Locale.US).format(Date()),unavailable,statuses.distinctBy{norm(it.name)+it.status})
 }catch(t:Throwable){LiveTdSnapshot(emptyList(),0,SimpleDateFormat("h:mm:ss a",Locale.US).format(Date()),error=t.message?:"Live feed unavailable")}
}
