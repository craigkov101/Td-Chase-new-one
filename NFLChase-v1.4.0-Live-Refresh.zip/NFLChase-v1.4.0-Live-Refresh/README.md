# NFL Chase v1.4.0 — Live Refresh

- Pull down on Games to force a live refresh.
- Refresh updates ESPN public-facing game summaries, touchdown feed and player injury/status data.
- Players reported OUT/INACTIVE/IR/PUP/SUSPENDED/RULED OUT/WILL NOT RETURN/DOUBTFUL TO RETURN are removed from the live candidate pool.
- Affected game simulations are rebuilt after refresh.
- Automatic live refresh every 30 seconds plus manual Refresh button.

Note: ESPN endpoints used by this prototype are public-facing but unofficial/undocumented for third-party use and can change.
