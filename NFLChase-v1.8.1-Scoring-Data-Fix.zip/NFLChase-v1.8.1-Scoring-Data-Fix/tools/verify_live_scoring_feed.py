"""Manual-build diagnostic: inspect ESPN scoring metadata with the CI runner's network.

Not a substitute for Kotlin parser tests, and not a player model validation.
"""
import json
import sys
from urllib.request import Request, urlopen

BASE = "https://site.api.espn.com/apis/site/v2/sports/football/nfl/"


def load(endpoint):
    with urlopen(Request(BASE + endpoint, headers={"User-Agent": "TDChase/1.8.1 (GitHub Actions smoke test)", "Accept": "application/json"}), timeout=14) as r:
        if r.status != 200:
            raise RuntimeError(f"ESPN HTTP {r.status}")
        return json.load(r)


def check(code):
    schedule = load(f"teams/{code.lower()}/schedule?season=2026&seasontype=2")
    games = []
    for event in schedule.get("events", []):
        competitions = event.get("competitions") or []
        competition = competitions[0] if competitions else {}
        kind = competition.get("status", {}).get("type", {})
        if not (kind.get("completed") or "FINAL" in kind.get("name", "")):
            continue
        for competitor in competition.get("competitors", []):
            team = competitor.get("team", {})
            if team.get("abbreviation", "").upper() == code:
                games.append((event.get("date", ""), event["id"], str(team.get("id", competitor.get("id", "")))))
    games.sort(reverse=True)
    games = games[:5]
    if not games:
        raise RuntimeError(f"{code}: no final games found")
    receiving = rushing = other = 0
    for _, event_id, team_id in games:
        summary = load(f"summary?event={event_id}")
        if "scoringPlays" not in summary:
            raise RuntimeError(f"{code}: scoringPlays missing for game {event_id}")
        for play in summary["scoringPlays"]:
            if str(play.get("team", {}).get("id", "")) != team_id:
                continue
            phrase = (play.get("type", {}).get("text", "") + " " + play.get("text", "")).lower()
            if "touchdown" not in phrase and " td " not in (" " + phrase + " "):
                continue
            if any(x in phrase for x in ("interception", "fumble return", "kickoff return", "punt return", "blocked punt", "defensive")):
                other += 1
            elif "pass" in phrase or "receiving" in phrase:
                receiving += 1
            elif "rush" in phrase or " run" in phrase or "scramble" in phrase:
                rushing += 1
            else:
                other += 1
    print(f"{code}: {len(games)} final games, {receiving} receiving TDs, {rushing} rushing TDs, {other} other TDs")
    if receiving + rushing + other == 0:
        raise RuntimeError(f"{code}: zero touchdowns from recent games; investigate ESPN response")


if __name__ == "__main__":
    try:
        for team_code in ("SEA", "DEN"):
            check(team_code)
        print("PASS: ESPN remote team identification and scoring plays available")
    except Exception as exc:
        print(f"LIVE DATA CHECK FAILED: {exc}", file=sys.stderr)
        sys.exit(1)
