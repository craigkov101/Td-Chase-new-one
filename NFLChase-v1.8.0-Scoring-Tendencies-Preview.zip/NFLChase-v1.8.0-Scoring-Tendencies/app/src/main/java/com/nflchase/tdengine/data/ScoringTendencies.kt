package com.nflchase.tdengine.data

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/** Descriptive scoring outcomes, never confused with red-zone opportunity shares. */
data class TeamScoringTrend(
 val team: String,
 val gamesObserved: Int,
 val rbRush: Int,
 val qbRush: Int,
 val receiving: Int,
 val other: Int,
 val notes: String,
 val error: String? = null
) {
 val total: Int get() = rbRush + qbRush + receiving + other
}

class ScoringTendencies {
 private fun fetch(url: String): JSONObject {
  val connection = (URL(url).openConnection() as HttpURLConnection).apply {
   connectTimeout = 6500; readTimeout = 6500
   setRequestProperty("Accept", "application/json")
   setRequestProperty("User-Agent", "TDChase/1.8")
  }
  return try {
   if(connection.responseCode !in 200..299) error("HTTP ${connection.responseCode}")
   JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
  } finally { connection.disconnect() }
 }

 /** ESPN play text is not structured player usage; categorize conservatively. */
 internal fun classify(text: String): String {
  val s=text.lowercase(Locale.US)
  if(!s.contains("touchdown") && !Regex("\\btd\\b").containsMatchIn(s)) return "ignore"
  if(s.contains("interception return") || s.contains("fumble return") || s.contains("kickoff return") || s.contains("punt return")) return "other"
  if(s.contains("pass") || s.contains("reception")) return "receiving"
  if(s.contains("run") || s.contains("rush")) return "rushing-unknown"
  return "other"
 }

 fun load(team: String): TeamScoringTrend {
  return try {
   val schedule=fetch("https://site.api.espn.com/apis/site/v2/sports/football/nfl/teams/${team.lowercase(Locale.US)}/schedule?season=2026&seasontype=2")
   val events=schedule.optJSONArray("events") ?: error("Schedule data unavailable")
   val completed=mutableListOf<String>()
   for(i in 0 until events.length()) {
    val e=events.optJSONObject(i) ?: continue
    val state=e.optJSONArray("competitions")?.optJSONObject(0)?.optJSONObject("status")?.optJSONObject("type")?.optString("name","")
      ?:e.optJSONObject("status")?.optJSONObject("type")?.optString("name","") ?: ""
    if(state.contains("FINAL",true) || state.contains("POST",true)) e.optString("id").takeIf{it.isNotBlank()}?.let{completed+=it}
   }
   if(completed.isEmpty()) return TeamScoringTrend(team,0,0,0,0,0,"No verified completed games found; scoring tendencies unavailable")
   var rushing=0;var receiving=0;var other=0;var observed=0
   for(id in completed.takeLast(5)) {
    val summary=runCatching{fetch("https://site.api.espn.com/apis/site/v2/sports/football/nfl/summary?event=$id")}.getOrNull() ?: continue
    val plays=summary.optJSONArray("scoringPlays") ?: continue
    observed++
    for(j in 0 until plays.length()) {
     val play=plays.optJSONObject(j) ?: continue
     if(!play.optJSONObject("team")?.optString("abbreviation","").equals(team,true)) continue
     when(classify(play.optString("text",""))) {
      "receiving"->receiving++
      "rushing-unknown"->rushing++
      "other"->other++
     }
    }
   }
   TeamScoringTrend(team,observed,rushing,0,receiving,other,
    "Last ${observed} available completed games; outcomes only. Rushing TDs include RBs and QBs; receiving TDs include WRs, TEs and RBs. Not a red-zone usage estimate.")
  } catch(e:Exception) {TeamScoringTrend(team,0,0,0,0,0,"Scoring history unavailable",e.message)}
 }
}
