package com.nflchase.tdengine.data

import kotlin.math.*
import java.util.Locale
import java.util.Random
import java.util.concurrent.CancellationException

/** Transparent, reproducible possession-count Monte Carlo. Scenario estimates are not calibrated betting odds. */
data class ScriptSection(val title: String, val paragraph: String)
data class ScorerLook(val name: String, val team: String, val position: String, val rationale: String)
data class SimulationReport(
    val away: String,
    val home: String,
    val awayScore: Int,
    val homeScore: Int,
    val awayExpected: Double,
    val homeExpected: Double,
    val awayWinShare: Double,
    val homeWinShare: Double,
    val typicalTotalLow: Int,
    val typicalTotalHigh: Int,
    val sampleCount: Int,
    val sections: List<ScriptSection>,
    val scorers: List<ScorerLook>,
    val dataWarning: String?,
    val inputSummary: String
)

object GameScriptEngine {
    private fun number(value: Double): String = String.format(Locale.US, "%.1f", value)
    // Risks are based on observed box-score sacks ALLOWED and giveaways, not charted pressure.
    // These deliberately modest weights are initial priors, not historically fitted effects.
    private fun riskAdjustment(form: TeamGameForm): Double {
        val sacks = form.risk.averageSacksAllowed?.let { ((it - 2.3) * 0.55).coerceIn(-1.0, 1.8) } ?: 0.0
        val giveaways = form.risk.averageGiveaways?.let { ((it - 1.1) * 1.1).coerceIn(-1.0, 2.0) } ?: 0.0
        return (sacks + giveaways).coerceIn(-1.8, 3.3)
    }
    // Simulate possessions rather than drawing TDs and field goals directly from a game total.
    // The prior for a game with no trustworthy giveaways data is 1.1 per 11 possessions.
    // This is an illustrative drive-outcome model, not a play-by-play simulation.
    private fun possession(rng: Random, expected: Double, drives: Int, giveaways: Double?, shortField: Boolean): Int {
        val turnoverRate = ((giveaways ?: 1.1) / 11.0).coerceIn(0.02,0.28)
        if(rng.nextDouble() < turnoverRate) return -1
        val opportunity = (1.0-turnoverRate).coerceAtLeast(0.72)
        val touchdown = (expected * 0.79 / 7.0 / drives / opportunity + if(shortField)0.10 else 0.0).coerceIn(0.01,0.65)
        val fieldGoal = (expected * 0.21 / 3.0 / drives / opportunity + if(shortField)0.08 else 0.0).coerceIn(0.01,0.35)
        val outcome = rng.nextDouble()
        return when {
            outcome < touchdown -> 7
            outcome < touchdown + fieldGoal -> 3
            else -> 0
        }
    }
    private fun defender(position: String): Boolean = position in setOf("CB", "DB", "S", "FS", "SS", "SAF", "LB", "ILB", "OLB", "MLB", "DE", "DT", "NT", "DL")
    private fun confirmed(injury: VerifiedInjury): Boolean = EspnInjuryParser.confirmedOut(injury.designation)
    private fun swingOut(injuries: List<VerifiedInjury>, team: String): Double {
        val missing = injuries.filter { it.team == team && confirmed(it) && defender(it.position) }
        val backs = missing.count { it.position in setOf("CB", "DB", "S", "FS", "SS", "SAF") }
        val front = missing.size - backs
        // Deliberately small *heuristic* adjustments, not measured per-player EPA impacts.
        return (backs * 0.35 + front * 0.25).coerceAtMost(1.5)
    }
    private fun topLook(p: WeekCandidate, offensePoints: Double, opponent: String, injured: List<VerifiedInjury>, coverage: CoverageOverview?): ScorerLook {
        val outDb = injured.filter { it.team == opponent && confirmed(it) && it.position in setOf("CB", "DB", "S", "FS", "SS", "SAF") }
        val outFront = injured.filter { it.team == opponent && confirmed(it) && it.position in setOf("LB", "ILB", "OLB", "MLB", "DE", "DT", "DL", "NT") }
        val volume = when(p.position) {
            "RB" -> "${number(p.recentCarries)} carries and ${number(p.recentTargets)} targets per recent game"
            "WR", "TE" -> "${number(p.recentTargets)} targets per recent game"
            else -> "${number(p.recentCarries)} rush attempts per recent game"
        }
        val edge = when {
            (p.position == "WR" || p.position == "TE") && outDb.isNotEmpty() -> " Opponent reports ${outDb.size} defensive-back absence(s); individual coverage is unconfirmed."
            (p.position == "RB" || p.position == "QB") && outFront.isNotEmpty() -> " Opponent reports ${outFront.size} front-seven absence(s); run-lane impact is unmeasured."
            else -> " No confirmed position-specific defensive injury edge in the retrieved report."
        }
        val shortFinish = if(p.shortRushingTdFinishes > 0)
            " ${p.shortRushingTdFinishes} recorded rushing TD finish(es) at 5 yards or closer; this is NOT total goal-line touch share."
            else " Goal-line snap and carry shares have not been verified."
        val cov = coverage?.forReceiver(p.name).orEmpty().firstOrNull()
        val coverageText = if(cov != null) " Historic charting: ${cov.routesObserved} receiver-vs-defender routes with ${cov.defender}; " +
            (cov.predictedRouteShare?.let { "projected alignment overlap ${number(100.0*it)}%." }
                ?: "future assignment frequency unverified.")
            else if(p.position == "WR" || p.position == "TE") " No charted individual coverage edge confirmed."
            else ""
        return ScorerLook(p.name,p.team,p.position,
            "$volume; ${p.fiveGameTouchdowns} TD(s) in the observed game sample. Team scoring baseline ${number(offensePoints)} points.$shortFinish$edge$coverageText")
    }

    /** Returns null when there is insufficient actual scored-and-allowed data for *both* teams. */
    fun simulate(matchup: String, projection: WeekProjection, trends: Map<String, TeamScoringTrend> = emptyMap(), trials: Int = 5000, coverage: CoverageOverview? = null, shouldCancel: () -> Boolean = { false }): SimulationReport? {
        val sides = matchup.split(" @ ", " at ",limit=2)
        if(sides.size != 2) return null
        val away = sides[0]; val home = sides[1]
        val af = projection.teamForms.firstOrNull{it.team == away} ?: return null
        val hf = projection.teamForms.firstOrNull{it.team == home} ?: return null
        if(af.games < 2 || hf.games < 2) return null
        val injuries = projection.injuries
        val awayMissing = swingOut(injuries, home)
        val homeMissing = swingOut(injuries, away)
        // Small, sample-size-gated historical defender adjustment. This does not
        // claim future coverages have occurred, and is NOT fitted TD probability.
        fun coverageAdjustment(offense: String): Double {
            val viable = coverage?.matches?.filter { m ->
                projection.candidates.any { it.team==offense && it.name==m.receiver } &&
                    m.primaryRoutesObserved >= 15 && m.routesObserved >= 20 && m.predictedRouteShare != null
            }.orEmpty()
            if (viable.isEmpty()) return 0.0
            val opportunities=viable.sumOf { it.historicalTargets }.toDouble() /
                viable.sumOf { it.primaryRoutesObserved }.coerceAtLeast(1)
            val overlap=viable.sumOf { it.predictedRouteShare ?: 0.0 }.coerceIn(0.0,1.0)
            return ((opportunities-0.20)*4.0*overlap).coerceIn(-0.6,0.6)
        }
        val awayCoverage = coverageAdjustment(away)
        val homeCoverage = coverageAdjustment(home)
        // Explicit prior reduces overfitting to only 2-5 games and lets the opponent's
        // last-five defensive concessions inform projected scoring. Home field is a small prior.
        val awayRisk = riskAdjustment(af)
        val homeRisk = riskAdjustment(hf)
        val expectedAway = (0.43*af.averageScored + 0.35*hf.averageAllowed + 0.22*22.0 - 1.0 + awayMissing + awayCoverage - awayRisk).coerceIn(8.0,39.0)
        val expectedHome = (0.43*hf.averageScored + 0.35*af.averageAllowed + 0.22*22.0 + 1.0 + homeMissing + homeCoverage - homeRisk).coerceIn(8.0,39.0)
        val seed = (matchup + af.pointsScored + af.pointsAllowed + hf.pointsScored + hf.pointsAllowed +
            injuries.joinToString { it.player + it.designation } + awayCoverage + homeCoverage + af.risk + hf.risk).hashCode().toLong()
        val rng = Random(seed)
        val totals = IntArray(trials.coerceIn(100,20000))
        var awaySum = 0L; var homeSum = 0L; var awayWins = 0; var homeWins = 0
        var awayTurnovers = 0L; var homeTurnovers = 0L
        for (i in totals.indices) {
            if (i % 128 == 0 && shouldCancel()) throw CancellationException("Game script calculation superseded")
            val driveCount = (11.0 + rng.nextGaussian() * 1.2).roundToInt().coerceIn(8,14)
            var ap=0;var hp=0;var awayGift=false;var homeGift=false
            for (drive in 0 until driveCount) {
                val awayResult=possession(rng,expectedAway,driveCount,af.risk.averageGiveaways,awayGift)
                awayGift=false
                if(awayResult<0) { homeGift=true; awayTurnovers++ } else ap+=awayResult
                val homeResult=possession(rng,expectedHome,driveCount,hf.risk.averageGiveaways,homeGift)
                homeGift=false
                if(homeResult<0) { awayGift=true; homeTurnovers++ } else hp+=homeResult
            }
            awaySum+=ap;homeSum+=hp;totals[i]=ap+hp
            if(ap>hp)awayWins++ else if(hp>ap)homeWins++
        }
        totals.sort()
        val count = totals.size
        val aMean = awaySum.toDouble()/count; val hMean = homeSum.toDouble()/count
        val aScore = aMean.roundToInt(); val hScore = hMean.roundToInt()
        val candidates = projection.candidates.sortedByDescending { cand ->
            val expected = if(cand.team==away) expectedAway else expectedHome
            cand.score * (expected/22.0).coerceIn(0.65,1.5)
        }.take(3).map { p -> topLook(p, if(p.team == away)expectedAway else expectedHome, if(p.team==away)home else away, injuries, coverage) }
        fun sentence(offense:String, form:TeamGameForm, defense:String, opposition:TeamGameForm, estimated:Double):String {
            val development = when {
                form.averageScored > opposition.averageAllowed + 5 -> "Their recent offense has scored substantially more than this opponent has typically allowed."
                form.averageScored + 5 < opposition.averageAllowed -> "Their scoring production has trailed what this defense has recently conceded; finishing drives is the key uncertainty."
                else -> "The recent scoring and defensive-allowance baselines are relatively close."
            }
            return "$offense scored ${number(form.averageScored)} points per game across ${form.games} completed games; $defense conceded ${number(opposition.averageAllowed)} per game across ${opposition.games}. $development Blended expected output: ${number(estimated)} points."
        }
        fun defenseNarrative(defTeam:String, attackTeam:String):String {
            val list = injuries.filter{it.team == defTeam && defender(it.position)}
            val unavailable = list.filter(::confirmed)
            val questionable = list.filter { it.designation.contains("question",true) || it.designation.contains("doubt",true) }
            val injuriesString = if(unavailable.isEmpty()) "No confirmed defensive absences were retrieved for $defTeam; this is NOT confirmation that all starters will play."
                else "$defTeam reported out: ${unavailable.take(5).joinToString { "${it.player} (${it.position})" }}."
            val risk = if(questionable.isEmpty()) "" else " Other uncertain defenders: ${questionable.take(4).joinToString { "${it.player} (${it.position}, ${it.designation})" }}."
            val specific = if(unavailable.any { it.position in setOf("CB","S","FS","SS","DB","SAF") })
                "This may leave $attackTeam opportunities against replacement coverages. Next-game shadow matchups cannot be known until charted; consult the separate historical coverage section."
            else if(unavailable.any{it.position in setOf("LB","ILB","OLB","MLB","DL","DT","DE","NT")})
                "Front-seven rotation could affect short-yardage runs or pass protection; the injury impact is a small heuristic, not measured EPA."
            else "No specific exploitable alignment can be confirmed from the retrieved injury list."
            return "$injuriesString$risk $specific"
        }
        fun offenseScript(offense:String, defense:String):String {
            val receivers=projection.candidates.filter{it.team==offense && it.position in setOf("WR","TE")}.take(2)
            val rushers=projection.candidates.filter{it.team==offense && it.position in setOf("RB","QB")}.take(2)
            val receiving = if(receivers.isEmpty()) "Receiving usage could not be confirmed" else "Recent receiving opportunities favor ${receivers.joinToString { "${it.name} (${number(it.recentTargets)} targets/game)" }}"
            val ground = if(rushers.isEmpty()) "rushing usage is unverified" else "rushing work leans toward ${rushers.joinToString { "${it.name} (${number(it.recentCarries)} carries/game)" }}"
            val trend=trends[offense]
            val redZone = if(trend != null && trend.gamesObserved >= 2) {
                "Across ${trend.gamesObserved} verified games: ${trend.receiving} receiving and ${trend.rbRush+trend.qbRush} rushing touchdowns. These are outcomes, NOT red-zone targets or carry shares."
            } else "Recent team TD type breakdown is unavailable; red-zone play-calling cannot be verified."
            return "$offense attack against $defense: $receiving; $ground. $redZone"
        }
        val lower = totals[(count*0.20).toInt().coerceIn(0,count-1)]
        val upper = totals[(count*0.80).toInt().coerceIn(0,count-1)]
        val sections=listOf(
            ScriptSection("MODEL FOUNDATION", "${sentence(away, af, home, hf,expectedAway)} ${sentence(home,hf,away,af,expectedHome)} Home field contributes a 1-point prior; league scoring regression reduces overreaction to a small sample."),
            ScriptSection("FIRST HALF · OPENING PLAN", "${offenseScript(away,home)} ${offenseScript(home,away)} Early possessions will reveal whether passing volume or rushing efficiency matches those recent usage trends."),
            ScriptSection("PASS PROTECTION · TURNOVER EXPOSURE", run {
                fun note(code:String,form:TeamGameForm,adjustment:Double):String {
                    val sacks=form.risk.averageSacksAllowed?.let{ "${number(it)} sacks allowed/game across ${form.risk.sacksGames} logged games" }
                        ?: "sacks-allowed sample unavailable"
                    val giveaways=form.risk.averageGiveaways?.let{ "${number(it)} turnovers/game across ${form.risk.turnoverGames} logged games" }
                        ?: "turnover sample unavailable"
                    return "$code: $sacks; $giveaways. Heuristic scoring adjustment ${number(-adjustment)} points."
                }
                note(away,af,awayRisk)+" "+note(home,hf,homeRisk)+
                    " Box-score sacks suffered are a proxy for protection risk, NOT a measured pressure or pass-block win rate. " +
                    "The simulation includes turnover-ending possessions and possible opponent short fields."
            }),
            ScriptSection("SHORT-YARDAGE SCORING ROLES", run {
                val finished=projection.candidates.filter{it.shortRushingTdFinishes>0}.sortedByDescending{it.shortRushingTdFinishes}.take(5)
                if(finished.isEmpty()) "No 0–5 yard rushing-TD finishes could be confirmed among ranked players. This is NOT evidence that no specialized goal-line backs exist. Full goal-line carries and package participation are unavailable."
                else "Observed rushing TD finishes from 5 yards or closer: ${finished.joinToString { "${it.name} (${it.team}, ${it.shortRushingTdFinishes})" }}. " +
                    "These are completed touchdowns, not all attempts; rank changes are deliberately limited for the small sample."
            }),
            ScriptSection("DEFENSIVE INJURIES · EXPLOITABLE ZONES", "${defenseNarrative(home,away)} ${defenseNarrative(away,home)} Confirmed defensive absences receive small, bounded model adjustments (${number(awayMissing)} points to $away; ${number(homeMissing)} to $home), not automatically a touchdown for any player."),
            ScriptSection("WR/CB COVERAGE · CHARTED ROUTES", if(coverage == null || coverage.matches.isEmpty()) {
                "No verified individual route charting imported for this game. Public rosters do not supply receiver-versus-corner route assignments. The model makes no per-player shadow-coverage claim. Import a licensed Shadow Index or other legitimately charted CSV to activate this section."
            } else {
                coverage.matches.take(5).joinToString(" ") { "${it.receiver} vs ${it.defender} (${it.defenderTeam}): ${it.note}" } +
                    " Recorded defender data can contribute at most 0.6 points per offense to the simulated team score, and only when 15+ primary routes and a valid alignment overlap are available. Upcoming shadow assignments remain projections."
            }),
            ScriptSection("CURRENT ROSTER · TRANSACTION RECONCILIATION", projection.rosterNotes.takeIf { it.isNotEmpty() }
                ?.joinToString(" ") ?: "Roster obtained from the ESPN team endpoint. Transactions not confirmed by an additional official source may still be delayed."),
            ScriptSection("OFFENSIVE AVAILABILITY · USAGE REDISTRIBUTION", run {
                fun teamAbsences(team:String):String {
                    val lost=injuries.filter{it.team==team && confirmed(it) && it.position in setOf("QB","RB","WR","TE","OL","OT","OG","C")}
                    val doubtful=injuries.filter{it.team==team && (it.designation.contains("question",true) || it.designation.contains("doubt",true)) && it.position in setOf("QB","RB","WR","TE","OL","OT","OG","C")}
                    val confirmedText=if(lost.isEmpty())"No confirmed offensive starter absence was retrieved for $team" else "$team unavailable offensive players: ${lost.take(5).joinToString { "${it.player} (${it.position})" }}"
                    val questionableText=if(doubtful.isEmpty())"" else "; questionable/doubtful: ${doubtful.take(4).joinToString { "${it.player} (${it.position}, ${it.designation})" }}"
                    return "$confirmedText$questionableText. Depth-chart roles are not verified; only the observed remaining player opportunities drive scorer rankings."
                }
                teamAbsences(away) + " " + teamAbsences(home)
            }),
            ScriptSection("SECOND HALF · GAME-SCRIPT BRANCHES", when {
                expectedAway > expectedHome+3 -> "$away is modestly favored to protect a lead by using its main rushing option. If $home trails, expect its target leaders to matter more as the pass rate rises. An early turnover could still reverse the script."
                expectedHome > expectedAway+3 -> "$home projects to protect a lead with its primary rushers. A trailing $away would depend increasingly on its target leaders; negative game script could reduce away rushing attempts."
                else -> "The projected teams are close enough that either can finish with a lead. The side that wins early downs and turnover margin is most likely to dictate fourth-quarter rushing volume; a one-possession deficit increases target opportunities."
            }),
            ScriptSection("UNCERTAINTY · TURNOVERS, PRESSURE & INACTIVES", "Pass-rush pressure rates, upcoming shadow coverage, complete goal-line carry share, weather and final active lists are not all verified. The model uses recent sacks allowed and turnovers only where the ESPN box-score labels could be verified. Simulated drives have four outcomes (TD, FG, turnover, no score) and a simplified next-possession short-field effect; they are NOT charted play-by-play. Refresh late scratches; missing reports never mean healthy."),
            ScriptSection("SIMULATION RESULTS", "${count} seeded possession-level trials (8–14 drives/team): $away wins ${number(100.0*awayWins/count)}% and $home wins ${number(100.0*homeWins/count)}% of trials; mean score ${number(aMean)}–${number(hMean)}. Simulated turnovers average ${number(awayTurnovers.toDouble()/count)} for $away and ${number(homeTurnovers.toDouble()/count)} for $home. Middle 60% combined total: $lower–$upper. These scenario frequencies are NOT historically calibrated win probabilities.")
        )
        val warning=buildList{
            if(projection.error!=null)add(projection.error)
            if(projection.gamesVerified==0)add("Player box-score logs were unavailable")
            if(trends[away]?.gamesObserved ?: 0 < 2 || trends[home]?.gamesObserved ?: 0 < 2)add("Team TD tendencies incomplete")
            if(projection.injuryReportStatus.contains("unavailable",true))add("Injury feed incomplete")
            if(coverage == null || coverage.matches.isEmpty())add("Per-route receiver/cornerback charting not supplied for this matchup")
        }.joinToString("; ").takeIf { it.isNotBlank() }
        return SimulationReport(away,home,aScore,hScore,expectedAway,expectedHome,
            awayWins.toDouble()/count,homeWins.toDouble()/count,lower,upper,count,sections,candidates,warning,
            "ESPN final scores: $away ${af.games} games, $home ${hf.games} games • ESPN sacks-allowed/giveaway samples where labeled • observed short rushing-TD finishes • roster/injury reports • ${projection.checkedAt}")
    }
}
