# v1.7.0 — Current matchup roster integration
- Fetches ESPN team roster on tapping a scheduled game; lists current QB/RB/WR/TE player names, positions, and reported roster status.
- Games, Picks, Scripts use the same Thursday/Sunday schedule.
- Current game details have matchup-specific roster results and refresh action.
- No invented TD percentages: the position-based indicators are NOT calibrated TD probabilities.
- Remaining work: current season per-player red-zone/usage stats, reliable depth charts, injury report, opponent coverage data, tested projection calibration, and on-device integration testing.
- Android build and live API responses are NOT verified in this environment.
