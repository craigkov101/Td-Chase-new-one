v1.6.7: Fix LiveTdClient.kt expression-body early return compilation error at line 143 by using a block-bodied loadToday function. Same app behavior as v1.6.6. Android APK build not verified locally.
