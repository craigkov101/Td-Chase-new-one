# TD Chase 1.8.2 — Data integrity repair

## Fixed
- Roster status JSON no longer appears on screen. Active is roster-only, not guaranteed game-day active.
- ESPN five-game **targets, carries, yards, TD** are parsed by table labels; empty/unlabeled data does not generate artificial top player scores.
- Top 10 are combined from both teams, based on available box-score opportunity, not position-only baselines. Only players with at least two verified recent appearances and meaningful opportunities qualify.
- Excludes confirmed OUT/IR/inactive players (including dated official SEA/DEN Week 6 report). Questionable players remain conditional.
- Defenders out (CB/S/LB etc) feed a small bounded opponent matchup factor; does not pretend to know CB/WR shadow assignments.
- A dated **Oct 14 NFL.com official Week 6** injury designation snapshot backs up SEA @ DEN specifically: DEN Pat Surtain II OUT, Talanoa Hufanga OUT, Riley Moss QUESTIONABLE; SEA Zach Charbonnet OUT, Drake Thomas OUT, Chazz Surratt OUT. Not valid for later weeks or a live inactive confirmation.
- ESPN team scoring touchdowns fallback cross-checks player boxscore TD counts when `scoringPlays` is absent or inconsistent.
- No accidental 0-touchdown data masquerading as verified from empty game summaries.
- Refresh per game, prevent racing requests; source warnings and last retrieved timestamp shown. Date pager uses live schedule dates and avoids crash on empty schedule.
- Excludes a target game from its own prediction history to prevent look-ahead leakage.

## Deliberate limitations
- A score of e.g. 65/100 is a **relative opportunity index**, NOT a 65% touchdown probability.
- ESPN public endpoints are unofficial and may change or fail. If absent, the app reports missing data rather than inventing it.
- Actual red-zone targets, player coverage alignments, live official inactive lists for all games, calibrated backtests/model learning, and fully quantified defensive splits remain **unimplemented**. Do not treat the ranking as a validated wagering model.
- Offensive participation (who plays) and defensive injuries need rechecking after game-day inactive announcements.

## Local tests
- Kotlin/JVM compile of core client/parser/ranking classes using local JSON test doubles (Android UI compile not possible here).
- Three consecutive end-to-end synthetic matchup runs passed (known high-volume WR first, unused backup excluded, official OUT excluded, questionable retained, secondary outs tracked).
- GitHub Actions is the final gate: testDebugUnitTest and a live ESPN schema preflight run before APK assembly.
