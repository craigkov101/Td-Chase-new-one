# TD Chase v1.8.1 — ESPN Scoring Data Repair

- Fixes zero-touchdown bug: ESPN scoringPlays identify scoring team by numeric team.id, not necessarily team.abbreviation.
- ESPN play description can omit the word touchdown; event type metadata is now the primary signal.
- Scores only completed regular-season games, filters by team id, takes most recent five.
- Shows **Unavailable**, **Loading** or **PARTIAL DATA** when API or parsing fails instead of fabricating zero touchdowns.
- Manual **Refresh scoring history** button in game detail.
- Caches successfully fetched completed-game summaries in memory, and only caches full verified team aggregates.
- Seven regression tests added for scoring, team matching, offensive/defensive TDs, missing data and partial failures.
- Manual GitHub workflow executes JVM regression tests before assembling the APK.

IMPORTANT: Does **not** add red-zone usage, player target share, defensive injuries or validated player probabilities. Model estimates remain provisional.

Testing: source-level fixtures and local compiler smoke tests have been prepared. Live ESPN response and Android APK compilation must be confirmed in GitHub Actions and on an Android device; offline environment cannot reach ESPN or Maven/Android SDK.
