# v1.7.1 Top 10 Candidates
- Game detail shows at most 10 candidates total from both teams.
- Candidates are ranked by provisional positional scoring opportunity; not calibrated player touchdown probabilities.
- Picks tab shows a top-10 count rather than entire roster.
- Inactive/unavailable players excluded when ESPN roster status reports them.
- This build has not been Android compiled or device tested. Existing weekly data limitations remain.
