# TD Chase v1.10.0 — Coverage + Current Roster Transactions

Based directly on v1.9.0 simulated-game-scripts source.

## Player roster corrections
- Verified 2026-10-12 Houston Texans official transaction for WR Marvin Harrison Jr. from Arizona.
- Apply the dated fallback for posttrade games even if ESPN's live team roster has not caught up; remove him from Arizona's posttrade player pool.
- Fetch pretrade Arizona box-score usage to preserve 2026 player form. Never relabel Arizona appearances as Houston appearances.
- Expose the full offensive roster and explicit transaction notes inside every matchup, separate from top-10 TD rankings.
- ESPN live team roster remains the primary source, and official final inactives still require verification. One verified trade fix does not equal a complete league-wide transaction audit.

## Coverage analysis
- CoverageEngine parses legitimately obtained route charting CSV with named receiver, defender, defender team, routes, primary coverage routes, targets, yards, TDs and optional player/CB left, slot, right percentages.
- The user can import a coverage CSV from the game-detail screen or More tab. It is stored privately on device.
- Historical charting is kept separate from next-game projected alignment overlap. A defender ruled out is removed from the next-game projection. Questionable is NOT treated as out.
- Reject incomplete, malformed or nonsensical rows. No imaginary coverage values are embedded.
- The Scripts tab incorporates verified historical receiver/defender charting when present; top-10 opportunity adjustments are bounded to ±3 with a 15 primary-route + 20 shared-route minimum; modeled team scoring adjustment is bounded to ±0.6 points.
- Without imported charting, receiver/cornerback individual projections are reported UNVERIFIED. This is intentional.

## Data-source caveats
- Fantasy Points Data Suite's Shadow Index contains charted receiver/defender route interactions. Access/export typically requires subscriber credentials and potentially licensing for software redistribution. The app does not bypass paywalls or scrape copyrighted datasets.
- VSiN's publicly viewable WR/CB report includes *projected* weekly matchup summaries, but the public HTML does not provide enough individually identifiable per-route records to automatically establish measured assignments.
- Full Android compile & live ESPN fetch tests must run in GitHub Actions; local Kotlin data-layer tests are necessary but not an APK certification.

## Changes
- Android versionName = 1.10.0; versionCode = 1100.
- Manual GitHub Actions YAML included and executable Gradle unit tests added.
- README: docs/COVERAGE-DATA-SETUP.md; template: coverage-charting-template.csv.
