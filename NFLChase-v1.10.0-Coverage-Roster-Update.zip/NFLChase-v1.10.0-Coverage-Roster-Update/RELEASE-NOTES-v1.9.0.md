# TD Chase v1.9.0 — Game-specific simulated scripts

Changes from v1.8.2:
- The Scripts tab and every clickable matchup now use a repeatable 5,000-trial model instead of generic pre-written paragraphs.
- Display a complete matchup write-up: last five verified final scores for both teams, points allowed, usage leaders, injury records, scoring tendencies where verified, first- and second-half paths, alternative game-script risks, and simulation distributions.
- Display three ranked touchdown candidates grounded in recent targets/carries, not positional averages. Any missing inputs are labeled.
- Show the predicted final score **at the end** of the game script.
- Confirmed defensive absences affect the scoring estimate by a deliberately small heuristic. Questionable/doubtful players are not counted as out.
- Incorporate and explain reported offensive absences without inventing role/target redistribution.
- Recover absent schedule final scores from ESPN game summary headers when available.
- Reject score forecasts where either team has fewer than two verified completed games.
- Include game-simulation unit tests and a live ESPN final-score schema gate in the manual GitHub Actions workflow.

## IMPORTANT model limitations

This is a limited Monte Carlo SCENARIO model, not an empirically trained or historically calibrated probability model. It uses a shrinkage blend (43% recent points scored, 35% opponent points allowed, 22% league prior of 22 points), a one-point home-field prior, small bounded injury adjustments, and randomized touchdown/field-goal outcomes. 5,000 independent draws quantify model variability; **simulation volume alone does not establish accuracy**. The model does not verify live weather, full offensive-line protection metrics, cornerback shadow coverage, route alignments, exact red-zone target shares, final inactives, or historical backtest accuracy. These must not be described as included, measured, or verified.

## Testing

Local JVM Kotlin data-module compilation succeeded with JSON API stubs, and 3 rounds of deterministic controlled scenario checks passed. The full Android Compose build, ESPN network checks from GitHub, and on-device rendering **have not been run in this environment**. GitHub Actions is configured to run unit tests and live schema checks before it publishes the APK.
