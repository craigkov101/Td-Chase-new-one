NFL Chase v1.6.6 fresh manual build. Same Week 6 slate and UI as v1.6.5; version updated for clean install/update. Android compilation not verified.
