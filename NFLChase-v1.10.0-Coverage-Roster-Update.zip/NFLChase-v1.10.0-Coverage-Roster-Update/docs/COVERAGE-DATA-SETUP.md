# TD Chase Coverage Data: What is actually measured?

**Historical receiver-versus-cornerback routes are not present in ESPN roster/box-score APIs.**

One independently verified route-charting provider is Fantasy Points Data Suite 2.0, which provides **Shadow Index** (receiver × defender): routes together, primary coverage routes, targets, receptions, yards, TDs and alignments. Access may require subscription and permission to export/use the records. PFF offers WR/CB grades and CSV export at eligible tiers; VSiN publishes publicly viewable *projected* WR/CB matchups powered by Fantasy Points, but does not supply reliable route-level download data in its public HTML.

TD Chase v1.10.0 includes **an Android CSV importer in the More tab and in each game**. Export only data you have the right to use. If the provider's column names differ, map them to this standard format before importing. Imported CSV remains private on the device. No developer keys or subscriptions are bundled with this project.

Required columns (case, underscores and spaces are flexible):

- `receiver`
- `defender`
- `defender_team` (NFL code, e.g. DEN)
- `routes` (charting-based historical route intersections)

Or `route_id` instead of `routes` for *one row per charted route*.

Recommended columns for accurate future matchup *projections*: `receiver_team`, `season`, `week`, `primary_coverage_routes`, `targets`, `yards`, `touchdowns`, `wr_left_pct`, `wr_slot_pct`, `wr_right_pct`, `cb_left_pct`, `cb_slot_pct`, `cb_right_pct`, `source`.

Percentages may be 0.25, 25 or `25%`. The app compares offense-left vs defense-right, slot vs slot, and offense-right vs defense-left. The label **"historical charted routes"** means recorded routes in previous games, not future assignments. The label **"projected alignment overlap"** is a matchup projection only, never an assertion of a future shadow assignment.

A simplified CSV header-only template is at `coverage-charting-template.csv`. Do not fill it with made-up charting observations; extract real records from a licensed export. The app rejects missing key columns or invalid tallies and does not manufacture matchup edges when no charting is present.

For Texans October 2026: official Oct. 12 transaction confirms Marvin Harrison Jr. arrived from Arizona. A dated reconciliation puts him on HOU and removes him from ARI for post-transaction games, fetching earlier Arizona box scores separately. This is a verified specific correction, **not a guarantee that every league-wide transaction has been audited**. Refresh the app to retrieve current ESPN rosters and check official game-day inactives.

Sources:
- https://www.houstontexans.com/news/houston-texans-transactions-10-12-2026
- https://fantasypointsdata.com/whats-new
- https://fantasypointsdata.com/
- https://vsin.com/wr/
- https://www.pff.com/news/wr-vs-cb-matchup-chart
