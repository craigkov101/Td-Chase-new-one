# TD Chase v1.8.0 — Scoring Tendencies (incremental build)

New: matchup detail requests the two teams' recent completed-game scoring plays from ESPN, categorizes receiving, rushing and other TD outcomes, and displays totals with game sample size and failure states. Data retrieval runs on IO coroutines. Source is unverified until GitHub compiles and an Android device loads live endpoints.

**Not implemented:** red-zone targets, goal-line rush attempts, TE-specific scoring share, individual recent-game usage, defensive starters missing, CB/WR alignment, learned calibrated TD probabilities. The existing top 10 list still uses positional baselines, not validated TD probabilities. Do not use these rankings as betting-grade projections.

**Important:** This app currently filters the slate to Oct 15 and 18, 2026. Later weeks require fixing the schedule filter. Public ESPN endpoints are undocumented and can change.
