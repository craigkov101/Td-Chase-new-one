package com.nflchase.tdengine.data

import java.util.Locale
import kotlin.math.roundToInt

/**
 * Coverage records must originate from charted ROUTES or a licensed provider's aggregated
 * route charting. Normal box scores and an injury list cannot measure a coverage assignment.
 * Imported data is historical. All *next-game* coverage assignments are projections.
 */
data class ChartedCoverage(
    val receiver: String, val receiverTeam: String,
    val defender: String, val defenderTeam: String,
    val season: Int, val week: Int,
    val routes: Int, val primaryRoutes: Int,
    val targets: Int, val yards: Int, val touchdowns: Int,
    val receiverLeft: Double?, val receiverSlot: Double?, val receiverRight: Double?,
    val defenderLeft: Double?, val defenderSlot: Double?, val defenderRight: Double?,
    val provider: String
)

data class CoverageImport(val rows: List<ChartedCoverage>, val rejected: Int, val message: String)

data class CoverageMatch(
    val receiver: String, val defender: String, val defenderTeam: String,
    val routesObserved: Int, val primaryRoutesObserved: Int,
    val historicalTargets: Int, val historicalYards: Int,
    val predictedRouteShare: Double?,
    val note: String
)

data class CoverageOverview(val matches: List<CoverageMatch>, val source: String, val status: String) {
    fun forReceiver(name: String): List<CoverageMatch> = matches.filter { coverageName(it.receiver) == coverageName(name) }
}

internal fun coverageName(name: String): String = name.lowercase(Locale.US)
    .replace(Regex("[^a-z0-9 ]"), "").replace(Regex("\\s+"), " ").trim()

/** Quoted CSV parser (including embedded newlines and escaped double quotes). No network access. */
object CoverageCsv {
    private fun records(text: String): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        var fields = mutableListOf<String>()
        val field = StringBuilder()
        var quoted = false
        var i = 0
        while (i < text.length) {
            val c = text[i]
            when {
                c == '"' && quoted && i + 1 < text.length && text[i + 1] == '"' -> { field.append('"'); i++ }
                c == '"' -> quoted = !quoted
                c == ',' && !quoted -> { fields.add(field.toString().trim()); field.setLength(0) }
                (c == '\n' || c == '\r') && !quoted -> {
                    fields.add(field.toString().trim()); field.setLength(0)
                    if (fields.any { it.isNotEmpty() }) rows.add(fields)
                    fields = mutableListOf()
                    if (c == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++
                }
                else -> field.append(c)
            }
            i++
        }
        if (quoted) error("CSV contains an unfinished quoted field")
        fields.add(field.toString().trim())
        if (fields.any { it.isNotEmpty() }) rows.add(fields)
        return rows
    }
    private fun key(s: String): String = s.lowercase(Locale.US).replace(Regex("[^a-z0-9]"), "")
    private fun numeric(s: String): Int = s.replace(",", "").toDoubleOrNull()?.roundToInt()?.coerceAtLeast(0) ?: 0
    private fun pct(s: String): Double? {
        val raw = s.trim().removeSuffix("%").toDoubleOrNull() ?: return null
        if (!raw.isFinite() || raw < 0.0) return null
        return (if (s.contains('%') || raw > 1.0) raw / 100.0 else raw).takeIf { it <= 1.0 }
    }
    fun parse(text: String): CoverageImport {
        val csv = records(text.removePrefix("\uFEFF"))
        if (csv.size < 2) return CoverageImport(emptyList(), 0, "No charting rows found")
        val cols = csv[0].map(::key)
        fun find(vararg labels: String): Int = labels.firstNotNullOfOrNull { alias -> cols.indexOf(key(alias)).takeIf { it >= 0 } } ?: -1
        val receiver = find("receiver", "receiver_name", "wr_name", "offensive_player", "wr")
        val defender = find("defender", "defender_name", "cb_name", "coverage_defender", "cb")
        val defTeam = find("defender_team", "def_team", "defense", "defensive_team", "def")
        val receiverTeam = find("receiver_team", "off_team", "offense", "offensive_team", "off")
        val routes = find("routes", "charted_routes", "routes_run", "route_count", "rte", "rtes", "routes_together", "matched_routes", "shadow_routes")
        val primary = find("primary_coverage_routes", "primary_routes", "pri_routes", "primary_rtes", "pri_rte")
        val routeId = find("route_id", "play_id", "route_result")
        if (receiver < 0 || defender < 0 || defTeam < 0 || (routes < 0 && routeId < 0)) {
            return CoverageImport(emptyList(), 0,
                "CSV needs receiver, defender, defender_team and routes (or route_id for one-row-per-route charting). No data imported.")
        }
        val season = find("season", "year")
        val week = find("week", "game_week")
        val target = find("targets", "tgt")
        val yards = find("yards", "receiving_yards", "rec_yards", "yds")
        val td = find("touchdowns", "td", "tds")
        val leftWr = find("wr_left_pct", "lwr", "receiver_left_pct")
        val slotWr = find("wr_slot_pct", "swr", "receiver_slot_pct")
        val rightWr = find("wr_right_pct", "rwr", "receiver_right_pct")
        val leftCb = find("cb_left_pct", "lcb", "defender_left_pct")
        val slotCb = find("cb_slot_pct", "scb", "defender_slot_pct")
        val rightCb = find("cb_right_pct", "rcb", "defender_right_pct")
        val source = find("source", "provider")
        val primaryFlag = find("primary_coverage", "is_primary_coverage")
        val out = mutableListOf<ChartedCoverage>()
        var rejected = 0
        csv.drop(1).forEach { line ->
            fun cell(n: Int) = if (n < 0) "" else line.getOrElse(n) { "" }.trim()
            val a = cell(receiver); val b = cell(defender); val team = cell(defTeam).uppercase(Locale.US)
            val n = if(routes >= 0) numeric(cell(routes)) else 1
            val pri = if(primary >= 0) numeric(cell(primary)) else if(primaryFlag >= 0 && cell(primaryFlag).lowercase() in setOf("true", "yes", "1")) n else 0
            if(a.isBlank() || b.isBlank() || team.isBlank() || n < 1 || pri > n || n > 100_000) { rejected++; return@forEach }
            val rec = ChartedCoverage(a, cell(receiverTeam).uppercase(Locale.US), b, team,
                cell(season).toIntOrNull() ?: 0, cell(week).toIntOrNull() ?: 0,
                n, pri, numeric(cell(target)), numeric(cell(yards)), numeric(cell(td)),
                pct(cell(leftWr)), pct(cell(slotWr)), pct(cell(rightWr)),
                pct(cell(leftCb)), pct(cell(slotCb)), pct(cell(rightCb)),
                cell(source).ifBlank { "User-imported route charting" })
            if (rec.targets > rec.routes || rec.touchdowns > rec.targets) { rejected++; return@forEach }
            out += rec
        }
        return CoverageImport(out, rejected, "Imported ${out.size} charted matchups; rejected $rejected invalid rows. Historical route evidence, not future assignments.")
    }
}

object CoverageAnalyzer {
    private val defensivePositions = setOf("CB", "DB", "S", "FS", "SS", "SAF")
    private fun opposition(team: String, away: String, home: String): String = if(team == away) home else away
    private fun isUnavailable(i: VerifiedInjury): Boolean {
        val s = i.designation.lowercase(Locale.US)
        return s == "out" || s == "inactive" || s.contains("injured reserve") || s.startsWith("reserve/injured") || s == "suspended"
    }

    /** Predict an alignment encounter ONLY when receiver + CB have measured alignments. */
    fun alignmentShare(wr: ChartedCoverage, corner: ChartedCoverage): Double? {
        val left = wr.receiverLeft ?: return null
        val slot = wr.receiverSlot ?: return null
        val right = wr.receiverRight ?: return null
        val cbLeft = corner.defenderLeft ?: return null
        val cbSlot = corner.defenderSlot ?: return null
        val cbRight = corner.defenderRight ?: return null
        val sumWr = left + slot + right; val sumCb = cbLeft + cbSlot + cbRight
        if(sumWr !in 0.90..1.10 || sumCb !in 0.90..1.10) return null
        // Receiver offense-left aligns with defender defense-right, and vice versa.
        return (left * cbRight + slot * cbSlot + right * cbLeft).coerceIn(0.0, 1.0)
    }

    /** A small, explicitly uncalibrated adjustment ONLY with meaningful recorded overlap. */
    fun enrich(projection: WeekProjection, report: CoverageOverview): WeekProjection {
        if(report.matches.isEmpty()) return projection
        val updated = projection.candidates.map { player ->
            if(player.position !in setOf("WR", "TE")) return@map player
            val evidence = report.forReceiver(player.name)
                .filter { it.primaryRoutesObserved >= 15 && it.routesObserved >= 20 && it.predictedRouteShare != null }
            if(evidence.isEmpty()) return@map player
            val weighted = evidence.sumOf { it.predictedRouteShare ?: 0.0 }
            val tpr = evidence.sumOf { it.historicalTargets }.toDouble() /
                evidence.sumOf { it.primaryRoutesObserved }.coerceAtLeast(1)
            val delta = ((tpr - 0.20) * 15.0 * weighted.coerceIn(0.0, 1.0)).roundToInt().coerceIn(-3, 3)
            player.copy(score=(player.score+delta).coerceIn(1,95),
                reason=player.reason + " Charted coverage matchup adjustment: ${if(delta>=0) "+" else ""}$delta index pts " +
                    "from ${evidence.sumOf { it.primaryRoutesObserved }} prior primary-coverage routes; NOT a TD probability.")
        }.sortedWith(compareByDescending<WeekCandidate> { it.score }.thenByDescending { it.recentCarries + it.recentTargets })
        return projection.copy(candidates=updated)
    }

    /**
     * Historical charting alone cannot establish that a receiver will be shadowed NEXT week.
     * Returns measured historical routes and (if charted alignments exist) projected overlap.
     */
    fun evaluate(matchup: String, projection: WeekProjection?, imported: List<ChartedCoverage>): CoverageOverview {
        if (projection == null) return CoverageOverview(emptyList(), "none", "Load game data before evaluating coverage")
        if (imported.isEmpty()) return CoverageOverview(emptyList(), "none",
            "No licensed route charting imported. Actual WR/CB coverage has NOT been measured in this app. Import charted data to enable it.")
        val sides = matchup.split(" @ ", " at ", limit = 2)
        if (sides.size != 2) return CoverageOverview(emptyList(), "imported", "Game teams unknown")
        val away = sides[0]; val home = sides[1]
        val absence = projection.injuries.filter(::isUnavailable).map { it.team to coverageName(it.player) }.toSet()
        val eligibleNames = projection.offensiveRoster.flatMap { (team, people) ->
            people.mapNotNull { raw ->
                val pos = Regex("\\((WR|TE)\\)$").find(raw)?.groupValues?.get(1) ?: return@mapNotNull null
                Triple(raw.substringBeforeLast(" (").trim(), team, pos)
            }
        }
        val candidates = projection.candidates.filter { it.position in setOf("WR", "TE") }
        val players = (candidates + eligibleNames.map { (name, team, pos) ->
            WeekCandidate(name, team, pos, "Roster listed", 0, "Coverage context only")
        }).distinctBy { it.team + coverageName(it.name) }.filter { p ->
            projection.injuries.none { it.team == p.team && coverageName(it.player) == coverageName(p.name) && isUnavailable(it) }
        }
        val out = mutableListOf<CoverageMatch>()
        players.forEach { wr ->
            val defense = opposition(wr.team, away, home)
            val group = imported.filter { it.defenderTeam == defense && it.routes > 0 &&
                (it.season == 0 || it.season >= 2025) &&
                (it.week <= 0 || it.week <= 22) &&
                (defense to coverageName(it.defender)) !in absence }
                .groupBy { coverageName(it.defender) }
            // Existing injury reports and defensive roster act as a safeguard against stale CBs.
            val defendersOnRoster = projection.defensiveBacks[defense].orEmpty().map(::coverageName).toSet()
            group.values.forEach defenderLoop@{ entries ->
                val e = entries.first()
                if (defendersOnRoster.isNotEmpty() && coverageName(e.defender) !in defendersOnRoster) return@defenderLoop
                val routes = entries.sumOf { it.routes }
                if(routes < 10) return@defenderLoop // hide a tiny, noisy sample
                val direct = entries.filter { coverageName(it.receiver) == coverageName(wr.name) }
                val receiverCharting = imported.filter { coverageName(it.receiver) == coverageName(wr.name) }
                val receiverAlignment = receiverCharting.firstOrNull { it.receiverLeft != null && it.receiverSlot != null && it.receiverRight != null }
                val cbAlignment = entries.firstOrNull { it.defenderLeft != null && it.defenderSlot != null && it.defenderRight != null }
                val share = if(receiverAlignment != null && cbAlignment != null) alignmentShare(receiverAlignment, cbAlignment) else null
                if (direct.isEmpty() && share == null) return@defenderLoop
                val pri = direct.sumOf { it.primaryRoutes }
                val matches = direct.sumOf { it.routes }
                val targets = direct.sumOf { it.targets }
                val yards = direct.sumOf { it.yards }
                val text = buildString {
                    if(matches > 0) append("Historical charted overlap: $matches routes, $pri primary-coverage routes, $targets targets, $yards yards. ")
                    if(share != null) append("Next-game alignment overlap estimate ${"%.0f".format(Locale.US, 100 * share)}% (projected; not a shadow confirmation). ")
                    else append("No verified alignment split; upcoming coverage share is unknown. ")
                    append("Opponent defender sample: $routes charted routes. Source: ${e.provider}.")
                }
                out += CoverageMatch(wr.name, e.defender, defense, matches, pri, targets, yards, share, text)
            }
        }
        return CoverageOverview(out.sortedWith(compareByDescending<CoverageMatch> { it.predictedRouteShare ?: -1.0 }
            .thenByDescending { it.routesObserved }), "User-imported charting",
            if(out.isEmpty()) "Imported data doesn't establish these current matchups (or lacks current defenders/alignments). No coverage edge is assumed."
            else "Historical observed routes and projected alignment shares are displayed separately; future shadow coverage is unconfirmed.")
    }
}
