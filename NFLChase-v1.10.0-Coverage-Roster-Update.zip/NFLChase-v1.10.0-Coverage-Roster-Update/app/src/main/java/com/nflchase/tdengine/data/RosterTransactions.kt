package com.nflchase.tdengine.data

import java.time.Instant

/** Verified official transaction, not a player-team inference from historical box scores. */
data class OfficialTransaction(val player: String, val position: String, val priorTeam: String,
    val currentTeam: String, val effective: Instant, val source: String)

object RosterTransactions {
    // Sources must be official. This fallback is intentionally dated and auditable.
    val verified = listOf(
        OfficialTransaction("Marvin Harrison Jr.", "WR", "ARI", "HOU",
            Instant.parse("2026-10-12T22:00:00Z"),
            "Houston Texans official 2026-10-12 transaction: houstontexans.com/news/houston-texans-transactions-10-12-2026")
    )
    fun activeFor(team: String, kickoff: Instant): List<OfficialTransaction> = verified.filter {
        !kickoff.isBefore(it.effective) && it.currentTeam == team
    }
    fun departedFrom(team: String, kickoff: Instant): List<OfficialTransaction> = verified.filter {
        !kickoff.isBefore(it.effective) && it.priorTeam == team
    }
}
