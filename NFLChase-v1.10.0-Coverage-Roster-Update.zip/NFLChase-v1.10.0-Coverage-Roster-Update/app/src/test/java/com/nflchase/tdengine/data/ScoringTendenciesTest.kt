package com.nflchase.tdengine.data

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class ScoringTendenciesTest {
    private val schedule = JSONObject("""
      {"events":[
        {"id":"101","date":"2026-10-04T17:00Z","competitions":[{
          "status":{"type":{"completed":true,"name":"STATUS_FINAL"}},
          "competitors":[{"team":{"id":"26","abbreviation":"SEA"},"score":"21"},{"team":{"id":"7","abbreviation":"DEN"},"score":"17"}]}]},
        {"id":"102","date":"2026-10-11T17:00Z","competitions":[{
          "status":{"type":{"completed":true,"name":"STATUS_FINAL"}},
          "competitors":[{"team":{"id":"26","abbreviation":"SEA"},"score":"14"},{"team":{"id":"9","abbreviation":"LAR"},"score":"10"}]}]},
        {"id":"103","date":"2026-10-18T17:00Z","competitions":[{
          "status":{"type":{"completed":false,"name":"STATUS_SCHEDULED"}},
          "competitors":[{"team":{"id":"26","abbreviation":"SEA"},"score":""}]}]}
      ]}
    """.trimIndent())
    private val summary101 = JSONObject("""
      {"boxscore":{"teams":[{"team":{"id":"26","abbreviation":"SEA"}},{"team":{"id":"7","abbreviation":"DEN"}}]},
       "scoringPlays":[
        {"type":{"text":"Rushing Touchdown"},"team":{"id":"26"},"text":"Player 4 yard rush"},
        {"type":{"text":"Passing Touchdown"},"team":{"id":"26"},"text":"Player 19 yard pass to Receiver"},
        {"type":{"text":"Field Goal"},"team":{"id":"26"},"text":"Player 42 yard field goal"},
        {"type":{"text":"Interception Return Touchdown"},"team":{"id":"7"},"text":"Returned interception"}
       ]}
    """.trimIndent())
    private val summary102 = JSONObject("""
      {"boxscore":{"teams":[{"team":{"id":"26","abbreviation":"SEA"}}]},
       "scoringPlays":[
        {"type":{"text":"Passing Touchdown"},"team":{"id":"26"},"text":"QB 8 yard pass"},
        {"type":{"text":"Interception Return Touchdown"},"team":{"id":"26"},"text":"Defender intercepted"}
       ]}
    """.trimIndent())

    @Test fun `team id and type drive counting even when play text does not say touchdown`() {
        val counts=EspnScoringParser.scoringForTeam(summary101,"SEA","26",21)
        assertEquals(1,counts.rushing)
        assertEquals(1,counts.receiving)
        assertEquals(0,counts.other)
    }
    @Test fun `defensive scoring counts separately and field goals are excluded`() {
        val sea=EspnScoringParser.scoringForTeam(summary102,"SEA","26",14)
        assertEquals(1,sea.receiving)
        assertEquals(1,sea.other)
        assertEquals("other",EspnScoringParser.touchdownType("Kickoff Return Touchdown","return"))
        assertEquals("ignore",EspnScoringParser.touchdownType("Field Goal","good from 32"))
    }
    @Test fun `only final games are collected newest first`() {
        val games=EspnScoringParser.completedGames(schedule,"SEA")
        assertEquals(listOf("102","101"),games.map{it.id})
        assertEquals("26",games[0].espnTeamId)
    }
    @Test fun `end to end load produces real counts rather than zero`() {
        val engine=ScoringTendencies{url->when{
            "/schedule" in url -> schedule
            "event=101" in url -> summary101
            "event=102" in url -> summary102
            else -> throw IllegalStateException("Unexpected request: $url")
        }}
        val result=engine.load("SEA")
        assertEquals(2,result.gamesObserved)
        assertEquals(1,result.rbRush)
        assertEquals(2,result.receiving)
        assertEquals(1,result.other)
        assertEquals(4,result.total)
        assertNull(result.error)
    }
    @Test fun `missing scoring plays are marked unavailable not falsely zero`() {
        val engine=ScoringTendencies{url->when{
            "/schedule" in url -> schedule
            else -> JSONObject("""{"boxscore":{"teams":[]}}""")
        }}
        val result=engine.load("SEA")
        assertEquals(0,result.gamesObserved)
        assertNotNull(result.error)
    }
    @Test fun `partial failed game is visibly flagged`() {
        val engine=ScoringTendencies{url->when{
            "/schedule" in url -> schedule
            "event=101" in url -> summary101
            else -> throw IllegalStateException("Temporary connection error")
        }}
        val result=engine.load("SEA")
        assertEquals(1,result.gamesObserved)
        assertNotNull(result.error)
        assertEquals(2,result.total)
    }
    @Test fun `missing team identity cannot be interpreted as zero touchdowns`() {
        val withoutTeams=JSONObject("""{"scoringPlays":[{"type":{"text":"Rushing Touchdown"},"text":"runner rush"}]}""")
        try {
            EspnScoringParser.scoringForTeam(withoutTeams,"SEA","",14)
            fail("Unattributed touchdown must be rejected")
        } catch (_: IllegalStateException) { }
    }
}
