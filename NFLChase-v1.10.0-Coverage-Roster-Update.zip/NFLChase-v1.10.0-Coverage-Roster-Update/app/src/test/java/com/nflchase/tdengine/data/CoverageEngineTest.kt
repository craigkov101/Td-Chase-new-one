package com.nflchase.tdengine.data

import org.junit.Assert.*
import org.junit.Test
import java.time.Instant

class CoverageEngineTest {
    private val sheet = """receiver,receiver_team,defender,defender_team,season,week,routes,primary_coverage_routes,targets,yards,touchdowns,wr_left_pct,wr_slot_pct,wr_right_pct,cb_left_pct,cb_slot_pct,cb_right_pct,source
"Jaxon Smith-Njigba",SEA,"Reserve Corner",DEN,2026,5,40,30,12,160,1,25%,60%,15%,20%,70%,10%,Licensed Example
"Jaxon Smith-Njigba",SEA,"Pat Surtain II",DEN,2026,5,42,33,3,28,0,25%,60%,15%,45%,5%,50%,Licensed Example
"Marvin Harrison Jr.",ARI,"Another Corner",JAX,2026,5,18,12,2,28,0,,,,,,,Licensed Example
""".trimIndent()

    private fun projection() = WeekProjection(
        gameId = "test", source = "test", candidates = listOf(
            WeekCandidate("Jaxon Smith-Njigba", "SEA", "WR", "Active", 82, "usage"),
            WeekCandidate("Marvin Harrison Jr.", "HOU", "WR", "Active", 65, "usage")
        ),
        injuries = listOf(VerifiedInjury("DEN", "Pat Surtain II", "CB", "Out", "Official")),
        defensiveBacks = mapOf("DEN" to listOf("Reserve Corner", "Pat Surtain II"),
            "JAX" to listOf("Another Corner"))
    )

    @Test fun readsQuotedCsvAndRejectsMissingFields() {
        val decoded = CoverageCsv.parse(sheet)
        assertEquals(3, decoded.rows.size)
        assertEquals(0, decoded.rejected)
        assertTrue(CoverageCsv.parse("receiver,defender\na,b").rows.isEmpty())
    }
    @Test fun outDefenderIsNotProjected() {
        val found = CoverageAnalyzer.evaluate("SEA @ DEN", projection(), CoverageCsv.parse(sheet).rows)
        assertEquals(1, found.matches.size)
        assertEquals("Reserve Corner", found.matches[0].defender)
        assertTrue(found.matches[0].predictedRouteShare!! > 0.3)
        assertFalse(found.matches.any { it.defender == "Pat Surtain II" })
    }
    @Test fun neverCreatesCoverageWhenNotImported() {
        val report = CoverageAnalyzer.evaluate("SEA @ DEN", projection(), emptyList())
        assertTrue(report.matches.isEmpty())
        assertTrue(report.status.contains("NOT been measured"))
        assertEquals(projection(), CoverageAnalyzer.enrich(projection(), report))
    }
    @Test fun historicalRouteEvidenceSurvivesReceiverTrade() {
        val report = CoverageAnalyzer.evaluate("HOU @ JAX",projection(), CoverageCsv.parse(sheet).rows)
        assertEquals(1, report.matches.size)
        assertEquals("Marvin Harrison Jr.", report.matches[0].receiver)
        assertEquals(18, report.matches[0].routesObserved)
    }
    @Test fun rejectsExtremeInvalidRouteTallies() {
        val invalid = sheet.replace("40,30,12", "1,30,12")
        assertEquals(1,CoverageCsv.parse(invalid).rejected)
    }
    @Test fun historic2026TransactionUpdatesTeamOnlyAfterEffectiveDate() {
        assertTrue(RosterTransactions.activeFor("HOU", Instant.parse("2026-10-01T00:00:00Z")).isEmpty())
        assertEquals("Marvin Harrison Jr.",RosterTransactions.activeFor("HOU",Instant.parse("2026-10-15T00:00:00Z")).single().player)
        assertEquals(1,RosterTransactions.departedFrom("ARI",Instant.parse("2026-10-15T00:00:00Z")).size)
    }
}
