package com.nflchase.tdengine.data

import org.junit.Assert.*
import org.junit.Test

class GameScriptEngineTest {
    private fun data(): WeekProjection = WeekProjection(
        gameId = "test",
        candidates = listOf(
            WeekCandidate("A Receiver", "SEA", "WR", "Active", 77, "", 5, 10.0, 0.0, 3),
            WeekCandidate("B Back", "DEN", "RB", "Active", 75, "", 5, 1.0, 19.0, 4),
            WeekCandidate("C Tight End", "SEA", "TE", "Active", 55, "", 5, 5.0, 0.0, 1),
            WeekCandidate("D Backup", "SEA", "RB", "Active", 17, "", 3, 0.2, 2.0, 0)
        ),
        source="fixture", gamesVerified=10,
        teamForms=listOf(
            TeamGameForm("SEA", listOf(28, 24, 21, 17, 35), listOf(17, 20, 23, 14, 27)),
            TeamGameForm("DEN", listOf(17, 23, 27, 13, 20), listOf(20, 24, 17, 27, 28))
        ),
        injuries=listOf(
            VerifiedInjury("DEN", "Corner A", "CB", "Out", "report"),
            VerifiedInjury("DEN", "Safety B", "S", "Out", "report"),
            VerifiedInjury("DEN", "Corner C", "CB", "Questionable", "report")
        )
    )
    @Test fun `five thousand simulations are deterministic and game specific`() {
        val first=GameScriptEngine.simulate("SEA @ DEN",data())!!
        val second=GameScriptEngine.simulate("SEA @ DEN",data())!!
        assertEquals(5000,first.sampleCount)
        assertEquals(first.awayScore,second.awayScore)
        assertEquals(first.homeScore,second.homeScore)
        assertEquals(first.awayWinShare,second.awayWinShare,0.0)
        assertEquals(3,first.scorers.size)
        assertEquals("A Receiver",first.scorers[0].name)
        assertTrue(first.sections.any{it.title.contains("INJURIES") && it.paragraph.contains("Corner A")})
        assertTrue(first.sections.any{it.title.contains("FIRST HALF") && it.paragraph.contains("10.0 targets/game")})
        assertTrue(first.sections.any{it.title.contains("SECOND HALF")})
        assertTrue(first.typicalTotalHigh >= first.typicalTotalLow)
    }
    @Test fun `confirmed defensive absences shift expectation while questionable does not`() {
        val base=data().copy(injuries=emptyList())
        val withQuestionable=base.copy(injuries=listOf(VerifiedInjury("DEN","Maybe","CB","Questionable","test")))
        val withOut=base.copy(injuries=listOf(VerifiedInjury("DEN","Definitely","CB","Out","test")))
        val baseline=GameScriptEngine.simulate("SEA @ DEN",base)!!
        val uncertain=GameScriptEngine.simulate("SEA @ DEN",withQuestionable)!!
        val confirmed=GameScriptEngine.simulate("SEA @ DEN",withOut)!!
        assertEquals(baseline.awayExpected,uncertain.awayExpected,0.0)
        assertTrue(confirmed.awayExpected > baseline.awayExpected)
    }
    @Test fun `missing completed game scores never create fictional forecast`() {
        assertNull(GameScriptEngine.simulate("SEA @ DEN",data().copy(teamForms=emptyList())))
        assertNull(GameScriptEngine.simulate("SEA @ DEN",data().copy(teamForms=listOf(
            TeamGameForm("SEA", listOf(21), listOf(20)),
            TeamGameForm("DEN",listOf(14,17),listOf(20,21))))))
    }
    @Test fun `home away projections respond to changed scoring form`() {
        val standard=GameScriptEngine.simulate("SEA @ DEN",data())!!
        val stronger = data().copy(teamForms = listOf(
            TeamGameForm("SEA",listOf(42,40,35,38,42),listOf(10,10,12,14,9)),
            TeamGameForm("DEN",listOf(12,10,13,8,17),listOf(31,38,42,41,33))))
        val changed=GameScriptEngine.simulate("SEA @ DEN",stronger)!!
        assertTrue(changed.awayExpected>standard.awayExpected+5.0)
        assertTrue(changed.awayWinShare>standard.awayWinShare)
    }
    @Test fun `script separates reported scoring outcomes from red zone usage`() {
        val scores=mapOf("SEA" to TeamScoringTrend("SEA",5,3,1,11,0,"verified"),
             "DEN" to TeamScoringTrend("DEN",5,6,1,5,0,"verified"))
        val report=GameScriptEngine.simulate("SEA @ DEN",data(),scores)!!
        assertTrue(report.sections.any { it.paragraph.contains("11 receiving") })
        assertTrue(report.sections.any { it.paragraph.contains("NOT red-zone") })
    }
}
