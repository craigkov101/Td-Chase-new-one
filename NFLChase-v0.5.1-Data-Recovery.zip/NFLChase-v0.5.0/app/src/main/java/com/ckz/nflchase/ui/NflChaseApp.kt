package com.ckz.nflchase.ui

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.ckz.nflchase.LoadState
import com.ckz.nflchase.MainViewModel
import com.ckz.nflchase.data.*
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.abs
import kotlin.math.roundToInt

private val Bg = Color(0xFF05090D)
private val BgTop = Color(0xFF071018)
private val Panel = Color(0xFF0B141C)
private val PanelRaised = Color(0xFF111D27)
private val PanelSoft = Color(0xFF0E1820)
private val Border = Color(0xFF1B2A34)
private val Green = Color(0xFF66F34C)
private val Green2 = Color(0xFF24D98B)
private val Blue = Color(0xFF58B7FF)
private val Text = Color(0xFFF5F8FA)
private val Muted = Color(0xFF8798A5)
private val Subtle = Color(0xFFC7D1D7)
private val Amber = Color(0xFFFFC857)
private val Red = Color(0xFFFF6878)
private val Purple = Color(0xFFAA8BFF)

private enum class Tab(val label: String) {
    GAMES("Games"), BOARD("Board"), SCRIPTS("Scripts"), BUILDER("Builder"), LAB("Lab")
}

@Composable
fun NflChaseApp(vm: MainViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    val tracked by vm.tracked.collectAsState()
    val manualLines by vm.manualLines.collectAsState()
    var tab by remember { mutableStateOf(Tab.GAMES) }
    val context = LocalContext.current

    val shareDashboard = {
        val ready = state as? LoadState.Ready
        if (ready != null) {
            val json = DashboardExporter.toJson(ready.dashboard, manualLines, tracked)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_SUBJECT, "NFL Chase ${ready.dashboard.modelVersion} analysis")
                putExtra(Intent.EXTRA_TEXT, json)
            }
            context.startActivity(Intent.createChooser(send, "Share NFL Chase analysis"))
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Green,
            secondary = Blue,
            tertiary = Green2,
            background = Bg,
            surface = Panel,
            surfaceVariant = PanelRaised,
            onPrimary = Color.Black,
            onBackground = Text,
            onSurface = Text,
            outline = Border,
            error = Red
        )
    ) {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = { AppHeader(state, vm::refresh, shareDashboard) },
            bottomBar = { BottomNav(tab) { tab = it } }
        ) { padding ->
            Box(
                Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(BgTop, Bg)))
            ) {
                when (val s = state) {
                    is LoadState.Loading -> LoadingView()
                    is LoadState.Error -> ErrorView(s.message, vm::refresh)
                    is LoadState.Ready -> when (tab) {
                        Tab.GAMES -> GamesScreen(s.dashboard)
                        Tab.BOARD -> BoardScreen(s.dashboard, tracked, manualLines, vm::toggleTrack, vm::saveManualLine)
                        Tab.SCRIPTS -> ScriptsScreen(s.dashboard)
                        Tab.BUILDER -> BuilderScreen(s.dashboard, tracked, manualLines, vm::toggleTrack, vm::saveManualLine)
                        Tab.LAB -> LabScreen(s.dashboard, tracked, shareDashboard)
                    }
                }
            }
        }
    }
}

@Composable
private fun AppHeader(state: LoadState, onRefresh: () -> Unit, onShare: () -> Unit) {
    Surface(color = BgTop, shadowElevation = 0.dp) {
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(start = 16.dp, end = 8.dp, top = 9.dp, bottom = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("NFL", color = Text, fontSize = 24.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.width(5.dp))
                    Text("CHASE", color = Green, fontSize = 24.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.width(8.dp))
                    Surface(color = Green.copy(alpha = .10f), shape = CircleShape, border = BorderStroke(1.dp, Green.copy(alpha = .34f))) {
                        Text("v0.5.1", color = Green, fontSize = 8.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp))
                    }
                }
                val subtitle = if (state is LoadState.Ready) {
                    "GAME INTELLIGENCE • ${state.dashboard.dataHealth.label.uppercase()}"
                } else "GAME INTELLIGENCE • USAGE • MATCHUPS • LEARNING"
                Text(subtitle, color = Muted, fontSize = 7.5.sp, letterSpacing = .55.sp, maxLines = 1)
            }
            if (state is LoadState.Ready) {
                Column(horizontalAlignment = Alignment.End) {
                    Text("UPDATED", color = Muted, fontSize = 6.5.sp, fontWeight = FontWeight.Bold)
                    Text(timeOnly(state.dashboard.lastUpdatedMillis), color = Subtle, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
                }
                IconButton(onClick = onShare, modifier = Modifier.size(38.dp)) { Icon(Icons.Default.Share, null, tint = Muted, modifier = Modifier.size(19.dp)) }
            }
            IconButton(onClick = onRefresh, modifier = Modifier.size(40.dp)) { Icon(Icons.Default.Refresh, null, tint = Green, modifier = Modifier.size(21.dp)) }
        }
    }
}

@Composable
private fun BottomNav(selected: Tab, onSelect: (Tab) -> Unit) {
    NavigationBar(containerColor = Color(0xFF071018), tonalElevation = 0.dp) {
        Tab.entries.forEach { tab ->
            val icon = when (tab) {
                Tab.GAMES -> Icons.Default.SportsFootball
                Tab.BOARD -> Icons.Default.TrackChanges
                Tab.SCRIPTS -> Icons.Default.QueryStats
                Tab.BUILDER -> Icons.Default.Build
                Tab.LAB -> Icons.Default.Psychology
            }
            NavigationBarItem(
                selected = tab == selected,
                onClick = { onSelect(tab) },
                icon = { Icon(icon, null, modifier = Modifier.size(20.dp)) },
                label = { Text(tab.label, fontSize = 9.5.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color.Black,
                    selectedTextColor = Green,
                    indicatorColor = Green,
                    unselectedIconColor = Muted,
                    unselectedTextColor = Muted
                )
            )
        }
    }
}

@Composable
private fun LoadingView() {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        CircularProgressIndicator(color = Green)
        Spacer(Modifier.height(18.dp))
        Text("Building this week's board", color = Text, fontWeight = FontWeight.Black, fontSize = 18.sp)
        Text("Usage • position matchups • scripts • injuries • calibration", color = Muted, fontSize = 10.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun ErrorView(message: String, retry: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Default.CloudOff, null, tint = Red, modifier = Modifier.size(44.dp))
        Spacer(Modifier.height(12.dp))
        Text("NFL data couldn't load", color = Text, fontWeight = FontWeight.Black, fontSize = 19.sp)
        Text(message, color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Button(onClick = retry, colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.Black)) { Text("Retry", fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun GamesScreen(d: NflDashboard) {
    var selected by remember { mutableStateOf<NflGame?>(null) }
    val upcoming = d.games.filter { it.status != GameStatus.FINAL }
    val topEnv = upcoming.maxByOrNull { d.scripts[it.id]?.environmentScore ?: 0 }
    LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { SectionHero("Week Command Center", "Read the game first. Every player projection is tied back to expected score, pace, volatility and game-state pressure.") }
        item { DataHealthCard(d.dataHealth) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SummaryTile("Games", upcoming.size.toString(), Modifier.weight(1f))
                SummaryTile("Top environment", topEnv?.let { "${it.away.abbreviation}-${it.home.abbreviation}" } ?: "—", Modifier.weight(1f))
                SummaryTile("Prop markets", d.targets.size.toString(), Modifier.weight(1f))
            }
        }
        items(upcoming, key = { it.id }) { game -> GameCard(game, d.scripts[game.id]) { selected = game } }
        item { DataNote(d.dataNote) }
    }
    selected?.let { game ->
        d.scripts[game.id]?.let { script ->
            GameDetailDialog(game, script, d.targets.filter { it.gameId == game.id }, d.injuries.filter { it.team in setOf(game.home.abbreviation, game.away.abbreviation) }) { selected = null }
        }
    }
}

@Composable
private fun DataHealthCard(health: DataHealth) {
    val c = when {
        health.score >= 88 -> Green
        health.score >= 74 -> Green2
        health.score >= 58 -> Blue
        else -> Amber
    }
    Surface(color = Panel, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, c.copy(alpha = .35f)), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(13.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Verified, null, tint = c, modifier = Modifier.size(19.dp))
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text("Data Health", color = Text, fontWeight = FontWeight.Black, fontSize = 13.sp)
                    Text(health.label, color = c, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
                Text("${health.score}%", color = c, fontWeight = FontWeight.Black, fontSize = 20.sp)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { health.score / 100f }, color = c, trackColor = Border, modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape))
            Spacer(Modifier.height(9.dp))
            Row {
                MiniStat("Box scores", health.recentGameSummaries.toString(), Text, Modifier.weight(1f))
                MiniStat("Profiles", health.playerProfiles.toString(), Text, Modifier.weight(1f))
                MiniStat("Defenses", health.defensiveProfiles.toString(), Text, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun GameCard(game: NflGame, script: GameScript?, onClick: () -> Unit) {
    Surface(
        color = Panel,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, Border),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StatusPill(game)
                game.weekLabel?.let { Spacer(Modifier.width(7.dp)); Text(it, color = Muted, fontSize = 8.5.sp) }
                Spacer(Modifier.weight(1f))
                Text(formatKickoff(game), color = Subtle, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(12.dp))
            TeamRow(game.away, if (game.status != GameStatus.SCHEDULED) game.away.score else script?.awayScore)
            Spacer(Modifier.height(7.dp))
            TeamRow(game.home, if (game.status != GameStatus.SCHEDULED) game.home.score else script?.homeScore)
            script?.let { s ->
                Text("MODEL PROJECTION", color = Green, fontSize = 8.sp, fontWeight = FontWeight.Black)
                HorizontalDivider(Modifier.padding(vertical = 11.dp), color = Border)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    MiniStat("Total", s.total.toString(), if (s.total >= 48) Green else Text, Modifier.weight(1f))
                    MiniStat("Range", "${s.totalLow}-${s.totalHigh}", Muted, Modifier.weight(1f))
                    MiniStat("Environment", s.environmentScore.toString(), scoreColor(s.environmentScore), Modifier.weight(1f))
                    MiniStat("Script", "${s.confidence}%", scoreColor(s.confidence), Modifier.weight(1f))
                }
                Spacer(Modifier.height(9.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Tag(s.label, if (s.environmentScore >= 72) Green else Blue)
                    Spacer(Modifier.weight(1f))
                    Text("Close ${s.closeGameScore} • Shootout ${s.shootoutScore}", color = Muted, fontSize = 8.sp)
                }
            }
        }
    }
}

@Composable
private fun TeamRow(team: TeamRef, score: Int?) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)).background(PanelRaised), contentAlignment = Alignment.Center) {
            AsyncImage(model = team.logoUrl, contentDescription = null, modifier = Modifier.size(31.dp))
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("${team.abbreviation}  ${team.name}", color = Text, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            team.record?.let { Text(it, color = Muted, fontSize = 9.sp) }
        }
        if (score != null) Text(score.toString(), color = Text, fontWeight = FontWeight.Black, fontSize = 24.sp)
    }
}

@Composable
private fun StatusPill(game: NflGame) {
    val c = when (game.status) {
        GameStatus.LIVE -> Red
        GameStatus.FINAL -> Muted
        GameStatus.SCHEDULED -> Green2
    }
    Surface(color = c.copy(alpha = .11f), shape = CircleShape, border = BorderStroke(1.dp, c.copy(alpha = .4f))) {
        Text(game.statusText, color = c, fontSize = 7.5.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), maxLines = 1)
    }
}

@Composable
private fun BoardScreen(
    d: NflDashboard,
    tracked: Set<String>,
    lines: Map<String, Double>,
    onTrack: (PropTarget) -> Unit,
    onSaveLine: (String, Double?) -> Unit
) {
    var market by remember { mutableStateOf<PropType?>(null) }
    var premiumOnly by remember { mutableStateOf(false) }
    var trackedOnly by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<PropTarget?>(null) }
    val filtered = remember(d.targets, market, premiumOnly, trackedOnly, query, tracked) {
        d.targets.filter { t ->
            (market == null || t.propType == market) &&
                (!premiumOnly || t.tier in setOf("ELITE", "CORE", "STRONG")) &&
                (!trackedOnly || t.id in tracked) &&
                (query.isBlank() || t.playerName.contains(query, true) || t.team.contains(query, true) || t.opponent.contains(query, true))
        }
    }
    LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item { SectionHero("Prop Intelligence Board", "NFL Chase ranks opportunity, not names. Use the attack zone only after you verify the real sportsbook line.") }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) },
                placeholder = { Text("Search player or team") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            )
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${filtered.size} markets", color = Muted, fontSize = 10.sp)
                Spacer(Modifier.weight(1f))
                FilterChip(selected = premiumOnly, onClick = { premiumOnly = !premiumOnly }, label = { Text("Top tiers") }, leadingIcon = if (premiumOnly) ({ Icon(Icons.Default.Verified, null, Modifier.size(14.dp)) }) else null)
                Spacer(Modifier.width(6.dp))
                FilterChip(selected = trackedOnly, onClick = { trackedOnly = !trackedOnly }, label = { Text("Starred") })
            }
        }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                FilterChip(selected = market == null, onClick = { market = null }, label = { Text("All") })
                listOf(
                    PropType.RECEPTIONS, PropType.RECEIVING_YARDS, PropType.RUSH_ATTEMPTS, PropType.RUSH_YARDS,
                    PropType.PASS_ATTEMPTS, PropType.PASS_COMPLETIONS, PropType.PASS_YARDS, PropType.PASS_TDS, PropType.ANYTIME_TD
                ).forEach { p -> FilterChip(selected = market == p, onClick = { market = p }, label = { Text(p.shortLabel) }) }
            }
        }
        if (filtered.isEmpty()) item { EmptyPanel("Nothing clears these filters. NFL Chase would rather show no play than manufacture one.") }
        items(filtered.take(90), key = { it.id }) { t ->
            TargetCard(t, t.id in tracked, lines[t.id], { onTrack(t) }) { selected = t }
        }
    }
    selected?.let { t ->
        TargetDetailDialog(t, d.scripts[t.gameId], t.id in tracked, lines[t.id], { onTrack(t) }, { line -> onSaveLine(t.id, line) }) { selected = null }
    }
}

@Composable
private fun TargetCard(target: PropTarget, tracked: Boolean, manualLine: Double?, onTrack: () -> Unit, onClick: () -> Unit) {
    val borderColor = when (target.tier) {
        "ELITE" -> Green
        "CORE" -> Green2
        "STRONG" -> Blue
        else -> Border
    }
    Surface(
        color = Panel,
        shape = RoundedCornerShape(17.dp),
        border = BorderStroke(1.dp, borderColor.copy(alpha = if (target.tier in setOf("ELITE", "CORE", "STRONG")) .42f else 1f)),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)).background(PanelRaised), contentAlignment = Alignment.Center) {
                    if (target.headshotUrl != null) AsyncImage(model = target.headshotUrl, contentDescription = null, modifier = Modifier.fillMaxSize())
                    else Text(target.position.name, color = Muted, fontSize = 10.sp)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(target.playerName, color = Text, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        IconButton(onClick = onTrack, modifier = Modifier.size(28.dp)) {
                            Icon(if (tracked) Icons.Default.Star else Icons.Default.StarBorder, null, tint = if (tracked) Amber else Muted, modifier = Modifier.size(17.dp))
                        }
                    }
                    Text("${target.team} vs ${target.opponent} • ${target.propType.label}", color = Muted, fontSize = 9.5.sp)
                    Spacer(Modifier.height(5.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TierPill(target.tier)
                        Spacer(Modifier.width(6.dp))
                        Text(target.roleLabel, color = Subtle, fontSize = 8.5.sp, maxLines = 1)
                    }
                }
                Spacer(Modifier.width(7.dp))
                ScoreBadge(target.chaseScore, "CHASE")
            }
            Spacer(Modifier.height(9.dp))
            if (target.propType == PropType.ANYTIME_TD) {
                Text("Model TD probability ${formatTdProbability(target.modelProjection)}", color = Text, fontWeight = FontWeight.Bold, fontSize = 11.5.sp)
                Text("Price matters — compare probability to your book's odds", color = Muted, fontSize = 8.5.sp)
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Projection ${fmtTarget(target.modelProjection)}", color = Text, fontWeight = FontWeight.Black, fontSize = 12.sp)
                        Text("OVER ≤ ${fmtTarget(target.attackOverAt)}  •  UNDER ≥ ${fmtTarget(target.attackUnderAt)}", color = Green2, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                    manualLine?.let {
                        val e = evaluateLine(target, it)
                        SidePill(e.side, e.color)
                    }
                }
                if (target.recentValues.isNotEmpty()) {
                    Spacer(Modifier.height(6.dp))
                    Text("Recent: ${target.recentValues.joinToString("  •  ") { fmtTarget(it) }}", color = Muted, fontSize = 8.5.sp, maxLines = 1)
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                TinyScore("ROLE", target.roleScore, Modifier.weight(1f))
                TinyScore("VOL", target.volumeScore, Modifier.weight(1f))
                TinyScore("SCRIPT", target.scriptScore, Modifier.weight(1f))
                TinyScore("MATCH", target.matchupScore, Modifier.weight(1f))
                TinyScore("STABLE", target.roleStabilityScore, Modifier.weight(1f))
            }
            if (!target.injuryStatus.isNullOrBlank()) {
                Spacer(Modifier.height(6.dp))
                Text("⚠ ${target.injuryStatus}", color = Amber, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ScriptsScreen(d: NflDashboard) {
    val games = d.games.filter { d.scripts[it.id] != null && it.status != GameStatus.FINAL }
        .sortedByDescending { d.scripts[it.id]?.environmentScore ?: 0 }
    LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { SectionHero("Game Script Engine", "A projection is a range, not a single number. Use the expected score plus the plausible band to understand how props can get there.") }
        items(games, key = { it.id }) { game ->
            val s = d.scripts.getValue(game.id)
            Surface(color = Panel, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Border)) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${game.away.abbreviation} @ ${game.home.abbreviation}", color = Text, fontWeight = FontWeight.Black, fontSize = 17.sp)
                        Spacer(Modifier.weight(1f))
                        ScoreBadge(s.confidence, "SCRIPT")
                    }
                    Text("${s.awayScore} — ${s.homeScore}  •  Total ${s.total}", color = Green, fontWeight = FontWeight.Black, fontSize = 17.sp)
                    Text("Score bands: ${game.away.abbreviation} ${s.awayLow}-${s.awayHigh} • ${game.home.abbreviation} ${s.homeLow}-${s.homeHigh} • total ${s.totalLow}-${s.totalHigh}", color = Muted, fontSize = 9.sp)
                    Spacer(Modifier.height(7.dp))
                    Tag(s.label, if (s.environmentScore >= 72) Green else Blue)
                    Spacer(Modifier.height(8.dp))
                    Text(s.summary, color = Subtle, fontSize = 10.5.sp, lineHeight = 15.sp)
                    Spacer(Modifier.height(11.dp))
                    ScriptLeanRow(game.away.abbreviation, s.passLeanAway, s.runLeanAway)
                    Spacer(Modifier.height(6.dp))
                    ScriptLeanRow(game.home.abbreviation, s.passLeanHome, s.runLeanHome)
                    Spacer(Modifier.height(10.dp))
                    Row {
                        MiniStat("Environment", s.environmentScore.toString(), scoreColor(s.environmentScore), Modifier.weight(1f))
                        MiniStat("Pace", s.paceScore.toString(), scoreColor(s.paceScore), Modifier.weight(1f))
                        MiniStat("Close game", s.closeGameScore.toString(), scoreColor(s.closeGameScore), Modifier.weight(1f))
                        MiniStat("Shootout", s.shootoutScore.toString(), scoreColor(s.shootoutScore), Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(8.dp))
                    s.drivers.take(5).forEach { Bullet(it) }
                }
            }
        }
    }
}

@Composable
private fun BuilderScreen(
    d: NflDashboard,
    tracked: Set<String>,
    lines: Map<String, Double>,
    onTrack: (PropTarget) -> Unit,
    onSaveLine: (String, Double?) -> Unit
) {
    var mode by remember { mutableStateOf(ParlayMode.SAFE) }
    var selected by remember { mutableStateOf<PropTarget?>(null) }
    val trackedTargets = d.targets.filter { it.id in tracked }.sortedByDescending { it.chaseScore }
    val evaluated = trackedTargets.mapNotNull { t -> lines[t.id]?.let { t to evaluateLine(t, it) } }
    val actionable = evaluated.filter { it.second.side != "PASS" }
    val cards = buildVerifiedParlays(actionable, mode)

    LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { SectionHero("Bet Builder", "Star the markets you care about, enter the real sportsbook line, then let NFL Chase separate OVER, UNDER and PASS zones before combining anything.") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SummaryTile("Starred", trackedTargets.size.toString(), Modifier.weight(1f))
                SummaryTile("Lines checked", evaluated.size.toString(), Modifier.weight(1f))
                SummaryTile("Actionable", actionable.size.toString(), Modifier.weight(1f))
            }
        }
        item {
            Text("Verified line board", color = Text, fontWeight = FontWeight.Black, fontSize = 16.sp)
            Text("A saved line is your sportsbook line — NFL Chase never fills this in for you.", color = Muted, fontSize = 9.sp)
        }
        if (trackedTargets.isEmpty()) item { EmptyPanel("Star markets on the Board tab. They'll appear here so you can enter real lines and build a card.") }
        items(trackedTargets, key = { it.id }) { t ->
            TargetCard(t, true, lines[t.id], { onTrack(t) }) { selected = t }
        }
        item {
            HorizontalDivider(color = Border)
            Spacer(Modifier.height(4.dp))
            Text("Correlation-aware cards", color = Text, fontWeight = FontWeight.Black, fontSize = 16.sp)
            Text("Only markets with a verified line and a non-PASS model decision are eligible.", color = Muted, fontSize = 9.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                ParlayMode.entries.forEach { m -> FilterChip(selected = mode == m, onClick = { mode = m }, label = { Text(m.label) }) }
            }
        }
        if (cards.isEmpty()) item { EmptyPanel("Not enough verified edges for this mode. Add sportsbook lines or switch modes — don't force a card.") }
        items(cards.size) { i -> VerifiedParlayCard(cards[i], i + 1) }
    }
    selected?.let { t ->
        TargetDetailDialog(t, d.scripts[t.gameId], true, lines[t.id], { onTrack(t) }, { line -> onSaveLine(t.id, line) }) { selected = null }
    }
}

@Composable
private fun VerifiedParlayCard(legs: List<Pair<PropTarget, LineEvaluation>>, number: Int) {
    val avgConf = legs.map { it.first.confidence }.average().roundToInt()
    Surface(color = Panel, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Border)) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Card $number • ${legs.size} legs", color = Text, fontWeight = FontWeight.Black, fontSize = 14.sp)
                Spacer(Modifier.weight(1f))
                Tag("$avgConf avg conf", if (avgConf >= 78) Green else Blue)
            }
            Spacer(Modifier.height(8.dp))
            legs.forEach { (t, e) ->
                Row(Modifier.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    SidePill(e.side, e.color)
                    Spacer(Modifier.width(7.dp))
                    Column(Modifier.weight(1f)) {
                        Text("${t.playerName} • ${t.propType.shortLabel} ${fmtTarget(e.line)}", color = Text, fontWeight = FontWeight.Bold, fontSize = 10.5.sp)
                        Text("Proj ${fmtTarget(t.modelProjection)} • ${t.team} vs ${t.opponent} • ${t.chaseScore} Chase", color = Muted, fontSize = 8.sp)
                    }
                }
            }
            Spacer(Modifier.height(5.dp))
            Text("Correlation rules block duplicate players and contradictory same-game stories. Odds/price still determine whether the final ticket is worth placing.", color = Muted, fontSize = 8.5.sp, lineHeight = 12.sp)
        }
    }
}

@Composable
private fun LabScreen(d: NflDashboard, tracked: Set<String>, onShare: () -> Unit) {
    val l = d.learning
    val learnedMarkets = l.marketLearning.values.filter { it.settled > 0 }.sortedByDescending { it.settled }
    LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { SectionHero("Model Lab", "This is where NFL Chase proves what it knows, exposes what it doesn't, and learns in small steps instead of chasing last week's results.") }
        item { DataHealthCard(d.dataHealth) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SummaryTile("Games learned", l.settledPredictions.toString(), Modifier.weight(1f))
                SummaryTile("Prop samples", l.settledProps.toString(), Modifier.weight(1f))
                SummaryTile("Tracked", tracked.size.toString(), Modifier.weight(1f))
            }
        }
        if (l.settledPredictions > 0 || l.settledProps > 0) {
            item {
                Surface(color = Panel, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Border)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Calibration snapshot", color = Text, fontWeight = FontWeight.Black, fontSize = 15.sp)
                        Spacer(Modifier.height(8.dp))
                        if (l.settledPredictions > 0) ScoreRow("Team score MAE", (100 - l.meanAbsoluteTeamError * 7).roundToInt().coerceIn(0, 100))
                        if (l.settledProps > 0) ScoreRow("Attack-threshold hit", (l.propThresholdHitRate * 100).roundToInt())
                        Spacer(Modifier.height(8.dp))
                        Text("Weights move slowly and are capped. A weird Sunday cannot rewrite the model.", color = Muted, fontSize = 9.sp)
                    }
                }
            }
        }
        if (learnedMarkets.isNotEmpty()) {
            item { Text("Market learning", color = Text, fontWeight = FontWeight.Black, fontSize = 16.sp) }
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    learnedMarkets.forEach { MarketLearningCard(it) }
                }
            }
        }
        item {
            Surface(color = Panel, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Border)) {
                Column(Modifier.padding(14.dp)) {
                    Text("NFL Chase Process", color = Text, fontWeight = FontWeight.Black, fontSize = 16.sp)
                    Spacer(Modifier.height(8.dp))
                    listOf(
                        "Game script first: score range, environment, pace and likely pass/run pressure.",
                        "Opportunity next: attempts, carries, targets, share, role stability and floor/ceiling.",
                        "Match the position to what the opponent actually allows — RB, WR and TE splits when the data exists.",
                        "Efficiency can separate similar roles, but volume carries more weight than hot-hand results.",
                        "Verify the real line. NFL Chase creates an OVER zone, UNDER zone and a no-bet middle.",
                        "Save pregame projections, settle them after games, then calibrate with capped adjustments."
                    ).forEach { Bullet(it) }
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = onShare, colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.Black), modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Share, null, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(7.dp)); Text("Export / Share Analysis", fontWeight = FontWeight.Black)
                    }
                    Text("Exports the current scripts, rankings, model scores and your saved lines as JSON — useful for ChatGPT analysis later.", color = Muted, fontSize = 8.5.sp, modifier = Modifier.padding(top = 7.dp))
                }
            }
        }
        if (d.injuries.isNotEmpty()) {
            item { Text("Injury board", color = Text, fontWeight = FontWeight.Black, fontSize = 16.sp) }
            items(d.injuries.take(20)) { inj ->
                Surface(color = PanelSoft, shape = RoundedCornerShape(13.dp), border = BorderStroke(1.dp, Border)) {
                    Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(inj.position.name, color = Amber, fontSize = 8.sp, fontWeight = FontWeight.Black, modifier = Modifier.width(28.dp))
                        Column(Modifier.weight(1f)) {
                            Text("${inj.playerName} • ${inj.team}", color = Text, fontWeight = FontWeight.Bold, fontSize = 10.5.sp)
                            inj.detail?.let { Text(it, color = Muted, fontSize = 8.sp, maxLines = 2, overflow = TextOverflow.Ellipsis) }
                        }
                        Tag(inj.status, Amber)
                    }
                }
            }
        }
        item { DataNote(d.dataNote) }
    }
}

@Composable
private fun MarketLearningCard(m: MarketLearningSummary) {
    Surface(color = PanelSoft, shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, Border), modifier = Modifier.width(158.dp)) {
        Column(Modifier.padding(11.dp)) {
            Text(m.propType.shortLabel, color = Text, fontWeight = FontWeight.Black, fontSize = 12.sp)
            Text("${m.settled} settled", color = Muted, fontSize = 9.sp)
            Spacer(Modifier.height(7.dp))
            Text("${(m.thresholdHitRate * 100).roundToInt()}%", color = if (m.thresholdHitRate >= .55) Green else Text, fontWeight = FontWeight.Black, fontSize = 20.sp)
            Text("attack threshold hit", color = Muted, fontSize = 7.5.sp)
            if (m.propType != PropType.ANYTIME_TD) {
                Spacer(Modifier.height(5.dp))
                Text("Bias ${signedPct(m.meanBiasPct * 100)}", color = if (abs(m.meanBiasPct) <= .05) Green2 else Amber, fontSize = 9.sp)
                Text("MAE ${fmtTarget(m.meanAbsoluteError)}", color = Muted, fontSize = 8.sp)
            }
        }
    }
}

@Composable
private fun GameDetailDialog(game: NflGame, script: GameScript, targets: List<PropTarget>, injuries: List<InjuryNote>, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close", color = Green) } },
        containerColor = Panel,
        title = { Text("${game.away.abbreviation} @ ${game.home.abbreviation}", color = Text, fontWeight = FontWeight.Black) },
        text = {
            Column(Modifier.heightIn(max = 610.dp).verticalScroll(rememberScrollState())) {
                Text("Projected ${script.awayScore} — ${script.homeScore}", color = Green, fontWeight = FontWeight.Black, fontSize = 23.sp)
                Text("Range ${game.away.abbreviation} ${script.awayLow}-${script.awayHigh} • ${game.home.abbreviation} ${script.homeLow}-${script.homeHigh}", color = Muted, fontSize = 9.sp)
                Text("Total ${script.total} • plausible ${script.totalLow}-${script.totalHigh}", color = Subtle, fontSize = 10.sp)
                Spacer(Modifier.height(5.dp))
                Text(script.label, color = Text, fontWeight = FontWeight.Bold)
                Text(script.summary, color = Muted, fontSize = 10.5.sp, lineHeight = 15.sp)
                Spacer(Modifier.height(12.dp))
                Row {
                    MiniStat("Environment", script.environmentScore.toString(), scoreColor(script.environmentScore), Modifier.weight(1f))
                    MiniStat("Close", script.closeGameScore.toString(), scoreColor(script.closeGameScore), Modifier.weight(1f))
                    MiniStat("Shootout", script.shootoutScore.toString(), scoreColor(script.shootoutScore), Modifier.weight(1f))
                    MiniStat("Volatility", script.volatilityScore.toString(), if (script.volatilityScore <= 45) Green2 else Amber, Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                script.drivers.forEach { Bullet(it) }
                if (injuries.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text("Injuries", color = Text, fontWeight = FontWeight.Black)
                    injuries.take(8).forEach { Text("• ${it.team} ${it.position}: ${it.playerName} — ${it.status}", color = Muted, fontSize = 9.sp, modifier = Modifier.padding(top = 3.dp)) }
                }
                Spacer(Modifier.height(11.dp))
                Text("Best script-aligned markets", color = Text, fontWeight = FontWeight.Black)
                targets.sortedByDescending { it.chaseScore }.take(7).forEach { t ->
                    Text("• ${t.playerName}: ${propTargetLine(t)} • ${t.chaseScore} Chase", color = Muted, fontSize = 9.5.sp, modifier = Modifier.padding(top = 5.dp))
                }
            }
        }
    )
}

@Composable
private fun TargetDetailDialog(
    target: PropTarget,
    script: GameScript?,
    tracked: Boolean,
    savedLine: Double?,
    onTrack: () -> Unit,
    onSaveLine: (Double?) -> Unit,
    onDismiss: () -> Unit
) {
    var lineInput by remember(target.id, savedLine) { mutableStateOf(savedLine?.let { fmtTarget(it) } ?: "") }
    val line = lineInput.toDoubleOrNull()
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close", color = Green) } },
        dismissButton = { TextButton(onClick = onTrack) { Text(if (tracked) "Unstar" else "Star", color = Amber) } },
        containerColor = Panel,
        title = { Text(target.playerName, color = Text, fontWeight = FontWeight.Black) },
        text = {
            Column(Modifier.heightIn(max = 650.dp).verticalScroll(rememberScrollState())) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${target.team} vs ${target.opponent} • ${target.propType.label}", color = Muted, fontSize = 10.5.sp)
                        Text(target.roleLabel, color = Subtle, fontSize = 9.5.sp)
                    }
                    TierPill(target.tier)
                }
                Spacer(Modifier.height(9.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ScoreBadge(target.chaseScore, "CHASE")
                    Spacer(Modifier.width(11.dp))
                    Column {
                        if (target.propType == PropType.ANYTIME_TD) {
                            Text("TD probability ${formatTdProbability(target.modelProjection)}", color = Text, fontWeight = FontWeight.Black)
                            Text("High variance • compare probability to price", color = Amber, fontSize = 9.sp)
                        } else {
                            Text("Projection ${fmtTarget(target.modelProjection)}", color = Text, fontWeight = FontWeight.Black)
                            Text("OVER zone ≤ ${fmtTarget(target.attackOverAt)}", color = Green, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                            Text("UNDER zone ≥ ${fmtTarget(target.attackUnderAt)}", color = Blue, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                            Text("Model range ${fmtTarget(target.floorProjection)} – ${fmtTarget(target.ceilingProjection)}", color = Muted, fontSize = 8.5.sp)
                        }
                    }
                }
                if (target.recentValues.isNotEmpty() && target.propType != PropType.ANYTIME_TD) {
                    Spacer(Modifier.height(10.dp))
                    Surface(color = PanelSoft, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, Border)) {
                        Column(Modifier.padding(10.dp)) {
                            Text("RECENT RESULTS", color = Muted, fontSize = 7.sp, fontWeight = FontWeight.Black)
                            Text(target.recentValues.joinToString("  •  ") { fmtTarget(it) }, color = Text, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("${(target.recentHitRate * 100).roundToInt()}% cleared the current model OVER attack level", color = Muted, fontSize = 8.sp)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                ScoreRow("Role", target.roleScore)
                ScoreRow("Volume", target.volumeScore)
                ScoreRow("Opportunity", target.opportunityScore)
                ScoreRow("Role stability", target.roleStabilityScore)
                ScoreRow("Efficiency", target.efficiencyScore)
                ScoreRow("Game script", target.scriptScore)
                ScoreRow("Matchup", target.matchupScore)
                ScoreRow("Recent usage", target.recentUsageScore)
                ScoreRow("Consistency", target.consistencyScore)
                ScoreRow("Data confidence", target.dataConfidence)
                ScoreRow("Final confidence", target.confidence)
                Spacer(Modifier.height(10.dp))
                target.rationale.forEach { Bullet(it) }
                script?.let {
                    Spacer(Modifier.height(8.dp))
                    Text("Game: ${it.awayScore}-${it.homeScore} • total ${it.total} (${it.totalLow}-${it.totalHigh}) • env ${it.environmentScore}", color = Muted, fontSize = 9.sp)
                }
                if (target.propType != PropType.ANYTIME_TD) {
                    Spacer(Modifier.height(14.dp))
                    HorizontalDivider(color = Border)
                    Spacer(Modifier.height(12.dp))
                    Text("Sportsbook Line Check", color = Text, fontWeight = FontWeight.Black, fontSize = 15.sp)
                    Text("Enter the exact line you see. NFL Chase stores it locally and returns OVER, UNDER or PASS — it does not guess the line.", color = Muted, fontSize = 8.8.sp, lineHeight = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = lineInput,
                        onValueChange = {
                            val cleaned = it.filter { c -> c.isDigit() || c == '.' }
                            lineInput = cleaned
                            onSaveLine(cleaned.toDoubleOrNull())
                        },
                        singleLine = true,
                        label = { Text("Sportsbook line") },
                        placeholder = { Text(fmtTarget(target.modelProjection)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth(),
                        trailingIcon = if (lineInput.isNotBlank()) ({ IconButton(onClick = { lineInput = ""; onSaveLine(null) }) { Icon(Icons.Default.Clear, null) } }) else null
                    )
                    if (line != null && line > 0) {
                        Spacer(Modifier.height(9.dp))
                        LineCheckCard(target, line)
                    }
                }
            }
        }
    )
}

@Composable
private fun LineCheckCard(target: PropTarget, line: Double) {
    val e = evaluateLine(target, line)
    Surface(color = e.color.copy(alpha = .08f), shape = RoundedCornerShape(13.dp), border = BorderStroke(1.dp, e.color.copy(alpha = .45f))) {
        Column(Modifier.padding(11.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SidePill(e.side, e.color)
                Spacer(Modifier.width(8.dp))
                Text(e.label, color = e.color, fontWeight = FontWeight.Black, fontSize = 11.sp)
                Spacer(Modifier.weight(1f))
                Text("${signedPct(e.edgePct)}", color = e.color, fontWeight = FontWeight.Bold, fontSize = 10.sp)
            }
            Spacer(Modifier.height(6.dp))
            Text("Model ${fmtTarget(target.modelProjection)} • line ${fmtTarget(line)} • OVER ≤ ${fmtTarget(target.attackOverAt)} • UNDER ≥ ${fmtTarget(target.attackUnderAt)}", color = Subtle, fontSize = 8.5.sp)
            Text("Confidence ${target.confidence}% • volatility ${target.volatility}/100 • price/juice still matters", color = Muted, fontSize = 8.sp, modifier = Modifier.padding(top = 3.dp))
        }
    }
}

@Composable
private fun SidePill(side: String, color: Color) {
    Surface(color = color.copy(alpha = .13f), shape = CircleShape, border = BorderStroke(1.dp, color.copy(alpha = .5f))) {
        Text(side, color = color, fontWeight = FontWeight.Black, fontSize = 7.5.sp, modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp))
    }
}

@Composable
private fun ScriptLeanRow(team: String, pass: Int, run: Int) {
    Column {
        Row {
            Text(team, color = Text, fontWeight = FontWeight.Black, fontSize = 10.5.sp, modifier = Modifier.width(44.dp))
            Text("Pass $pass%", color = if (pass >= 60) Blue else Subtle, fontSize = 9.5.sp)
            Spacer(Modifier.weight(1f))
            Text("Run $run%", color = if (run >= 52) Green2 else Subtle, fontSize = 9.5.sp)
        }
        Spacer(Modifier.height(3.dp))
        LinearProgressIndicator(progress = { pass / 100f }, color = Blue, trackColor = Green2.copy(alpha = .5f), modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape))
    }
}

@Composable
private fun SectionHero(title: String, subtitle: String) {
    Column(Modifier.padding(bottom = 3.dp)) {
        Text(title, color = Text, fontWeight = FontWeight.Black, fontSize = 22.sp)
        Text(subtitle, color = Muted, fontSize = 10.5.sp, lineHeight = 15.sp)
    }
}

@Composable
private fun SummaryTile(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(color = PanelSoft, shape = RoundedCornerShape(13.dp), border = BorderStroke(1.dp, Border), modifier = modifier) {
        Column(Modifier.padding(horizontal = 9.dp, vertical = 9.dp)) {
            Text(value, color = Text, fontWeight = FontWeight.Black, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(label, color = Muted, fontSize = 7.5.sp)
        }
    }
}

@Composable
private fun ScoreBadge(score: Int, label: String) {
    Surface(color = Green.copy(alpha = .07f), shape = RoundedCornerShape(11.dp), border = BorderStroke(1.dp, Green.copy(alpha = .62f))) {
        Column(Modifier.padding(horizontal = 9.dp, vertical = 5.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(score.toString(), color = Green, fontWeight = FontWeight.Black, fontSize = 19.sp, lineHeight = 19.sp)
            Text(label, color = Muted, fontSize = 6.5.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun TierPill(tier: String) {
    val c = when (tier) {
        "ELITE" -> Green
        "CORE" -> Green2
        "STRONG" -> Blue
        "WATCH" -> Purple
        else -> Muted
    }
    Surface(color = c.copy(alpha = .10f), shape = CircleShape, border = BorderStroke(1.dp, c.copy(alpha = .42f))) {
        Text(tier, color = c, fontWeight = FontWeight.Black, fontSize = 7.sp, modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp))
    }
}

@Composable
private fun Tag(text: String, color: Color) {
    Surface(color = color.copy(alpha = .09f), shape = CircleShape, border = BorderStroke(1.dp, color.copy(alpha = .35f))) {
        Text(text, color = color, fontSize = 7.8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), maxLines = 1)
    }
}

@Composable
private fun MiniStat(label: String, value: String, valueColor: Color, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = valueColor, fontWeight = FontWeight.Black, fontSize = 14.sp, maxLines = 1)
        Text(label, color = Muted, fontSize = 6.7.sp, maxLines = 1)
    }
}

@Composable
private fun TinyScore(label: String, score: Int, modifier: Modifier = Modifier) {
    Surface(color = PanelRaised, shape = RoundedCornerShape(9.dp), modifier = modifier) {
        Column(Modifier.padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(score.toString(), color = scoreColor(score), fontWeight = FontWeight.Black, fontSize = 11.5.sp)
            Text(label, color = Muted, fontSize = 5.7.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

@Composable
private fun ScoreRow(label: String, value: Int) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.5.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 9.5.sp, modifier = Modifier.width(104.dp))
        LinearProgressIndicator(progress = { value / 100f }, color = scoreColor(value), trackColor = Border, modifier = Modifier.weight(1f).height(6.dp).clip(CircleShape))
        Text(value.toString(), color = Text, fontWeight = FontWeight.Bold, fontSize = 9.5.sp, modifier = Modifier.width(31.dp), textAlign = TextAlign.End)
    }
}

@Composable
private fun Bullet(text: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.Top) {
        Text("•", color = Green, fontWeight = FontWeight.Black, modifier = Modifier.width(12.dp))
        Text(text, color = Muted, fontSize = 9.5.sp, lineHeight = 13.5.sp)
    }
}

@Composable
private fun DataNote(text: String) {
    Surface(color = PanelSoft, shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Default.Info, null, tint = Blue, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(8.dp))
            Text(text, color = Muted, fontSize = 8.8.sp, lineHeight = 13.sp)
        }
    }
}

@Composable
private fun EmptyPanel(text: String) {
    Surface(color = Panel, shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) {
        Text(text, color = Muted, fontSize = 10.5.sp, modifier = Modifier.padding(18.dp), lineHeight = 15.sp)
    }
}

private data class LineEvaluation(val side: String, val label: String, val line: Double, val edgePct: Double, val color: Color)

private fun evaluateLine(t: PropTarget, line: Double): LineEvaluation {
    val edgePct = if (line <= 0) 0.0 else (t.modelProjection - line) / line * 100.0
    return when {
        line <= t.attackOverAt -> LineEvaluation("OVER", if (t.confidence >= 78) "ATTACK ZONE" else "MODEL LEAN", line, edgePct, Green)
        line >= t.attackUnderAt -> LineEvaluation("UNDER", if (t.confidence >= 78) "ATTACK ZONE" else "MODEL LEAN", line, edgePct, Blue)
        else -> LineEvaluation("PASS", "NO EDGE ZONE", line, edgePct, Amber)
    }
}

private enum class ParlayMode(val label: String) { SAFE("Safe"), BALANCED("Balanced"), UPSIDE("Upside") }

private fun buildVerifiedParlays(input: List<Pair<PropTarget, LineEvaluation>>, mode: ParlayMode): List<List<Pair<PropTarget, LineEvaluation>>> {
    val minConf = when (mode) { ParlayMode.SAFE -> 77; ParlayMode.BALANCED -> 70; ParlayMode.UPSIDE -> 64 }
    val maxVol = when (mode) { ParlayMode.SAFE -> 48; ParlayMode.BALANCED -> 62; ParlayMode.UPSIDE -> 85 }
    val pool = input.filter { it.first.confidence >= minConf && it.first.volatility <= maxVol }
        .sortedWith(compareByDescending<Pair<PropTarget, LineEvaluation>> { it.first.confidence }.thenByDescending { it.first.chaseScore })
    val sizes = when (mode) { ParlayMode.SAFE -> listOf(2, 3); ParlayMode.BALANCED -> listOf(2, 3, 4); ParlayMode.UPSIDE -> listOf(3, 4, 5) }
    val cards = mutableListOf<List<Pair<PropTarget, LineEvaluation>>>()

    fun compatible(current: List<Pair<PropTarget, LineEvaluation>>, next: Pair<PropTarget, LineEvaluation>): Boolean {
        val t = next.first
        if (current.any { it.first.athleteId == t.athleteId }) return false
        val sameGame = current.filter { it.first.gameId == t.gameId }
        if (sameGame.isEmpty()) return true
        if (sameGame.size >= 2) return false
        return sameGame.all { existing ->
            val a = existing.first
            val aEval = existing.second
            val passFamily = setOf(PropType.PASS_YARDS, PropType.PASS_ATTEMPTS, PropType.PASS_COMPLETIONS, PropType.RECEIVING_YARDS, PropType.RECEPTIONS, PropType.PASS_TDS)
            val rushFamily = setOf(PropType.RUSH_YARDS, PropType.RUSH_ATTEMPTS)
            when {
                aEval.side != next.second.side -> false
                a.propType in passFamily && t.propType in passFamily -> true
                a.propType in rushFamily && t.propType in rushFamily -> true
                else -> false
            }
        }
    }

    sizes.forEachIndexed { index, size ->
        val selected = mutableListOf<Pair<PropTarget, LineEvaluation>>()
        val rotated = if (pool.isEmpty()) pool else pool.drop(index % pool.size) + pool.take(index % pool.size)
        for (candidate in rotated) {
            if (compatible(selected, candidate)) selected += candidate
            if (selected.size == size) break
        }
        if (selected.size == size) cards += selected
    }
    return cards.distinctBy { card -> card.joinToString("|") { it.first.id + it.second.side } }
}

private fun formatKickoff(game: NflGame): String {
    if (game.status == GameStatus.LIVE || game.status == GameStatus.FINAL) return game.statusText
    return game.kickoff.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("EEE h:mm a"))
}

private fun timeOnly(ms: Long): String = java.time.Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("h:mm a"))
private fun fmtTarget(v: Double): String = if (abs(v - v.roundToInt()) < .05) v.roundToInt().toString() else "%.1f".format(v)
private fun formatTdProbability(v: Double): String = "${(v * 100).roundToInt()}%"
private fun signedPct(v: Double): String = if (v >= 0) "+%.1f%%".format(v) else "%.1f%%".format(v)
private fun scoreColor(score: Int): Color = when { score >= 82 -> Green; score >= 70 -> Green2; score >= 58 -> Blue; else -> Amber }
private fun propTargetLine(t: PropTarget): String = if (t.propType == PropType.ANYTIME_TD) "${t.propType.shortLabel} • ${formatTdProbability(t.modelProjection)} model" else "${t.propType.shortLabel} • O≤${fmtTarget(t.attackOverAt)} / U≥${fmtTarget(t.attackUnderAt)}"
