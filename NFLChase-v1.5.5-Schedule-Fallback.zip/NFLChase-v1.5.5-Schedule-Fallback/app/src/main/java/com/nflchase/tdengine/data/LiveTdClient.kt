package com.nflchase.tdengine.data

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

data class LiveTdEvent(val id:String,val game:String,val team:String,val text:String,val quarter:Int,val clock:String)
data class LivePlayerStatus(val name:String,val status:String,val detail:String,val gameId:String)
data class LiveScheduleGame(val id:String,val matchup:String,val kickoff:String,val state:String)
data class LiveTdSnapshot(
    val events:List<LiveTdEvent>,
    val liveGames:Int,
    val updatedAt:String,
    val unavailablePlayers:Set<String> = emptySet(),
    val playerStatuses:List<LivePlayerStatus> = emptyList(),
    val rosterPlayersByTeam:Map<String,Set<String>> = emptyMap(),
    val error:String?=null,
    val schedule:List<LiveScheduleGame> = emptyList()
)

class LiveTdClient {
 private fun get(u:String):String {
  val c=(URL(u).openConnection() as HttpURLConnection).apply{
   connectTimeout=8000;readTimeout=8000;requestMethod="GET"
   setRequestProperty("Accept","application/json");setRequestProperty("User-Agent","TD-Chase/1.5.1")
  }
  return try{if(c.responseCode !in 200..299) error("HTTP ${c.responseCode}");c.inputStream.bufferedReader().use{it.readText()}}finally{c.disconnect()}
 }
 private fun norm(s:String)=s.lowercase(Locale.US).replace(Regex("[^a-z0-9 ]"),"").replace(Regex("\\s+")," ").trim()
 private fun unavailable(s:String):Boolean {
  val x=s.uppercase(Locale.US)
  return listOf("OUT","INACTIVE","INJURED RESERVE","IR","PUP","SUSPENDED","RULED OUT","WILL NOT RETURN","DOUBTFUL TO RETURN").any{x.contains(it)}
 }
 private fun collectInjuries(summary:JSONObject,eventId:String,out:MutableList<LivePlayerStatus>){
  fun add(o:JSONObject){
   val athlete=o.optJSONObject("athlete")
   val name=athlete?.optString("displayName")?.takeIf{it.isNotBlank()}
       ?:o.optString("displayName").takeIf{it.isNotBlank()}
       ?:o.optString("name").takeIf{it.isNotBlank()}
   val status=listOf(o.optString("status"),o.optString("type"),o.optString("description"),o.optString("detail"),o.optString("shortComment")).filter{it.isNotBlank()}.joinToString(" • ")
   if(name!=null && status.isNotBlank()) out+=LivePlayerStatus(name,status,status,eventId)
  }
  val injuries=summary.optJSONArray("injuries")
  if(injuries!=null) for(i in 0 until injuries.length()){
   val team=injuries.optJSONObject(i)?:continue
   val arr=team.optJSONArray("injuries") ?: team.optJSONArray("items")
   if(arr!=null) for(j in 0 until arr.length()) arr.optJSONObject(j)?.let{add(it)}
  }
  val direct=summary.optJSONObject("injuries")
  if(direct!=null){val arr=direct.optJSONArray("items");if(arr!=null)for(i in 0 until arr.length())arr.optJSONObject(i)?.let{add(it)}}
 }
 private fun loadRoster(team:String):Pair<Set<String>,List<LivePlayerStatus>> {
  val names=mutableSetOf<String>(); val statuses=mutableListOf<LivePlayerStatus>()
  return try{
   val j=JSONObject(get("https://site.api.espn.com/apis/site/v2/sports/football/nfl/teams/${team.lowercase(Locale.US)}/roster"))
   val groups=j.optJSONArray("athletes")
   if(groups!=null) for(i in 0 until groups.length()){
    val group=groups.optJSONObject(i)?:continue
    val items=group.optJSONArray("items")?:continue
    for(k in 0 until items.length()){
     val a=items.optJSONObject(k)?:continue
     val name=a.optString("displayName",a.optString("fullName",a.optString("name","")))
     if(name.isBlank()) continue
     names+=norm(name)
     val st=a.optJSONObject("status")
     val status=listOf(st?.optString("name")?:"",st?.optString("type")?:"",st?.optString("description")?:"",a.optString("status","")).filter{it.isNotBlank()}.joinToString(" • ")
     if(status.isNotBlank()) statuses+=LivePlayerStatus(name,status,"Roster status: $status","roster-$team")
    }
   }
   names to statuses
  }catch(_:Throwable){emptySet<String>() to emptyList()}
 }
 private fun collectStatusObjects(node:Any?,eventId:String,out:MutableList<LivePlayerStatus>){
  when(node){
   is JSONObject->{
    val athlete=node.optJSONObject("athlete")
    val name=athlete?.optString("displayName")?.takeIf{it.isNotBlank()}
      ?:node.optString("displayName").takeIf{it.isNotBlank()}
    if(name!=null){
     val status=listOf(node.optString("status"),node.optString("type"),node.optString("description"),node.optString("detail"),node.optString("shortComment"),node.optString("headline")).filter{it.isNotBlank()}.joinToString(" • ")
     if(status.isNotBlank() && unavailable(status)) out+=LivePlayerStatus(name,status,status,eventId)
    }
    val keys=node.keys();while(keys.hasNext()){val k=keys.next();collectStatusObjects(node.opt(k),eventId,out)}
   }
   is JSONArray->for(i in 0 until node.length())collectStatusObjects(node.opt(i),eventId,out)
  }
 }
 fun loadToday():LiveTdSnapshot=try{
  // The NFL scoreboard without a date filter returns the current week, including non-game days.
  val day=SimpleDateFormat("yyyyMMdd",Locale.US).apply{timeZone=TimeZone.getTimeZone("America/New_York")}.format(Date())
  // Try the date first, then the season/week view if the provider returns an empty day.
  val primary=JSONObject(get("https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard?dates=$day"))
  val board=if((primary.optJSONArray("events")?.length()?:0)>0) primary else
   JSONObject(get("https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard?dates=2026&seasontype=2&week=5&limit=100"))
  val es=board.optJSONArray("events");val tdOut=mutableListOf<LiveTdEvent>();val statuses=mutableListOf<LivePlayerStatus>();val slateTeams=mutableSetOf<String>();var live=0;val schedule=mutableListOf<LiveScheduleGame>()
  if(es!=null) for(i in 0 until es.length()){
   val e=es.optJSONObject(i)?:continue;val eid=e.optString("id");val game=e.optString("shortName",e.optString("name","NFL"))
   val date=e.optString("date","");val eastern=SimpleDateFormat("yyyyMMdd",Locale.US).apply{timeZone=TimeZone.getTimeZone("America/New_York")};
   val eventDay=runCatching{eastern.format(Date(java.time.Instant.parse(date).toEpochMilli()))}.getOrDefault("");
   if(eventDay!=day)continue;
   val state=e.optJSONObject("status")?.optJSONObject("type")?.optString("name","")?:"";schedule+=LiveScheduleGame(eid,game,date,state);val cs=e.optJSONArray("competitions");val st=if(cs!=null&&cs.length()>0)cs.getJSONObject(0).optJSONObject("status")?.optJSONObject("type")?.optString("name","")?:"" else ""
   if(st.contains("IN_PROGRESS"))live++
   if(cs!=null&&cs.length()>0){val comps=cs.getJSONObject(0).optJSONArray("competitors");if(comps!=null)for(ci in 0 until comps.length()){comps.optJSONObject(ci)?.optJSONObject("team")?.optString("abbreviation")?.takeIf{it.isNotBlank()}?.let{slateTeams+=it}}}
   if(eid.isBlank() || state.contains("SCHEDULED",true) || state.contains("PRE",true))continue
   val summary=try{JSONObject(get("https://site.api.espn.com/apis/site/v2/sports/football/nfl/summary?event=$eid"))}catch(_:Throwable){continue}
   collectInjuries(summary,eid,statuses); collectStatusObjects(summary,eid,statuses)
   val plays=summary.optJSONArray("scoringPlays")
   if(plays!=null) for(j in 0 until plays.length()){
    val p=plays.optJSONObject(j)?:continue;val typ=p.optJSONObject("scoringType")?.optString("name","")?:"";val txt=p.optString("text","")
    val td=typ.equals("touchdown",true)||txt.contains("touchdown",true)||Regex("""\b\d+\s+Yd\s+(Run|pass|reception)\b""",RegexOption.IGNORE_CASE).containsMatchIn(txt)
    if(td)tdOut+=LiveTdEvent(p.optString("id","$eid-$j-${txt.hashCode()}"),game,p.optJSONObject("team")?.optString("abbreviation","")?:"",txt,p.optJSONObject("period")?.optInt("number",0)?:0,p.optJSONObject("clock")?.optString("displayValue","")?:"")
   }
  }
  val rosterMap=mutableMapOf<String,Set<String>>()
  for(team in slateTeams){val (names,rs)=loadRoster(team);if(names.isNotEmpty())rosterMap[team]=names;statuses+=rs}
  val unavailable=statuses.filter{unavailable(it.status)}.map{norm(it.name)}.filter{it.isNotBlank()}.toSet()
  LiveTdSnapshot(tdOut.distinctBy{it.id}.reversed(),live,SimpleDateFormat("h:mm:ss a",Locale.US).format(Date()),unavailable,statuses.distinctBy{norm(it.name)+it.status},rosterMap,schedule=schedule)
 }catch(t:Throwable){LiveTdSnapshot(emptyList(),0,SimpleDateFormat("h:mm:ss a",Locale.US).format(Date()),error=t.message?:"Live feed unavailable")}
}
