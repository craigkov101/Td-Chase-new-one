package com.nflchase.tdengine.data

import com.nflchase.tdengine.model.*
import kotlin.math.*
import kotlin.random.Random

/**
 * Possession-level Monte Carlo TD engine.
 * Uses stable seeded randomness so rankings do not jump around on every recomposition.
 * The model combines team scoring environment with each player's opportunity, red-zone role,
 * position-specific defensive exploit, scheme, injury/role security and explosive ability.
 */
class SimulationEngine(private val runs:Int = 25000) {
    fun simulate(game:GameCard):GameSimulation {
        val rng=Random(game.id.hashCode())
        val counts=mutableMapOf<String,Int>(); val multi=mutableMapOf<String,Int>()
        game.candidates.forEach { counts[it.id]=0; multi[it.id]=0 }
        var awayWins=0; var homeWins=0; var totalTds=0
        repeat(runs) {
            val base = 2.1 + (game.environment-65)/35.0
            val awayMean=(base + teamEdge(game,game.away)).coerceIn(.8,4.8)
            val homeMean=(base + .18 + teamEdge(game,game.home)).coerceIn(.8,5.0)
            val a=poisson(rng,awayMean); val h=poisson(rng,homeMean)
            if(a>h) awayWins++ else if(h>a) homeWins++
            totalTds += a+h
            allocate(rng,game,game.away,a,counts,multi)
            allocate(rng,game,game.home,h,counts,multi)
        }
        val results=game.candidates.associate { p ->
            val hit=counts[p.id]?:0; val m=multi[p.id]?:0
            p.id to SimResult(p.id,(hit*100.0/runs).roundToInt(),(m*100.0/runs).roundToInt(),
                ((2.1+(game.environment-65)/35.0)+teamEdge(game,p.team)).coerceIn(.8,5.0),runs)
        }
        return GameSimulation(game.id,(awayWins*100.0/runs).roundToInt(),(homeWins*100.0/runs).roundToInt(),
            totalTds.toDouble()/runs,results,runs)
    }
    private fun teamEdge(g:GameCard,t:String):Double {
        val ps=g.candidates.filter{it.team==t}
        if(ps.isEmpty()) return 0.0
        return (ps.map{it.effectiveMatchup}.average()-70)/32.0 + (ps.map{it.factors.opportunity}.average()-82)/55.0
    }
    private fun weight(p:TdCandidate):Double {
        val pos=when(p.position){"RB"->1.10;"QB"->.68;"WR"->1.0;"TE"->.88;else->.75}
        val availability=if(p.status=="OUT") 0.0 else if(p.status=="QUESTIONABLE") .88 else 1.0
        return max(.01, pos*availability*(
            p.factors.opportunity*.24 + p.factors.redZone*.28 + p.effectiveMatchup*.22 +
            p.factors.scheme*.10 + p.factors.roleInjury*.07 + p.factors.explosive*.09
        ))
    }
    private fun allocate(rng:Random,g:GameCard,team:String,tds:Int,counts:MutableMap<String,Int>,multi:MutableMap<String,Int>){
        if(tds<=0)return
        val ps=g.candidates.filter{it.team==team && it.status!="OUT"}
        if(ps.isEmpty())return
        val scored=mutableMapOf<String,Int>()
        repeat(tds){
            val weights=ps.map{weight(it)}; val sum=weights.sum()
            var x=rng.nextDouble()*sum; var pick=ps.last()
            for(i in ps.indices){x-=weights[i];if(x<=0){pick=ps[i];break}}
            scored[pick.id]=(scored[pick.id]?:0)+1
        }
        scored.forEach{(id,n)-> counts[id]=(counts[id]?:0)+1; if(n>=2) multi[id]=(multi[id]?:0)+1}
    }
    private fun poisson(rng:Random,lambda:Double):Int{
        val l=exp(-lambda); var k=0; var p=1.0
        do{k++;p*=rng.nextDouble()}while(p>l && k<12)
        return k-1
    }
}
