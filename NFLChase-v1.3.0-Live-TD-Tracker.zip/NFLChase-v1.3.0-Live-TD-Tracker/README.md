# NFL Chase v1.1.0 — HR Chase Style

Redesigned game-day UI with TD feed surface, Top 5 matchup cards, Picks, Scripts, Parlays and More/Model Lab. The touchdown feed is structurally ready for event data; this package does not falsely label static data as a live scoring connection.


v1.1.0 adds 25,000-run possession-level Monte Carlo simulations and functional Remaining / Top 5 / Best Matchup filters.
