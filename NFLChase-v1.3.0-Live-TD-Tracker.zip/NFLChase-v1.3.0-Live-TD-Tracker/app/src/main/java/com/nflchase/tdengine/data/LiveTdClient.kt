package com.nflchase.tdengine.data
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

data class LiveTdEvent(val id:String,val game:String,val team:String,val text:String,val quarter:Int,val clock:String)
data class LiveTdSnapshot(val events:List<LiveTdEvent>,val liveGames:Int,val updatedAt:String,val error:String?=null)

class LiveTdClient {
 private fun get(u:String):String {
  val c=(URL(u).openConnection() as HttpURLConnection).apply{connectTimeout=8000;readTimeout=8000;requestMethod="GET";setRequestProperty("Accept","application/json");setRequestProperty("User-Agent","TD-Chase/1.3")}
  return try{if(c.responseCode !in 200..299) error("HTTP ${c.responseCode}");c.inputStream.bufferedReader().use{it.readText()}}finally{c.disconnect()}
 }
 fun loadToday():LiveTdSnapshot=try{
  val day=SimpleDateFormat("yyyyMMdd",Locale.US).format(Date())
  val board=JSONObject(get("https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard?dates=$day"))
  val es=board.optJSONArray("events");val out=mutableListOf<LiveTdEvent>();var live=0
  if(es!=null) for(i in 0 until es.length()){
   val e=es.getJSONObject(i);val eid=e.optString("id");val game=e.optString("shortName",e.optString("name","NFL"))
   val cs=e.optJSONArray("competitions");val st=if(cs!=null&&cs.length()>0)cs.getJSONObject(0).optJSONObject("status")?.optJSONObject("type")?.optString("name","")?:"" else ""
   if(st.contains("IN_PROGRESS"))live++
   if(eid.isBlank())continue
   val plays=JSONObject(get("https://site.api.espn.com/apis/site/v2/sports/football/nfl/summary?event=$eid")).optJSONArray("scoringPlays")?:continue
   for(j in 0 until plays.length()){
    val p=plays.getJSONObject(j);val typ=p.optJSONObject("scoringType")?.optString("name","")?:"";val txt=p.optString("text","")
    val td=typ.equals("touchdown",true)||txt.contains("touchdown",true)||Regex("""\b\d+\s+Yd\s+(Run|pass|reception)\b""",RegexOption.IGNORE_CASE).containsMatchIn(txt)
    if(!td)continue
    out+=LiveTdEvent(p.optString("id","$eid-$j-${txt.hashCode()}"),game,p.optJSONObject("team")?.optString("abbreviation","")?:"",txt,p.optJSONObject("period")?.optInt("number",0)?:0,p.optJSONObject("clock")?.optString("displayValue","")?:"")
   }
  }
  LiveTdSnapshot(out.distinctBy{it.id}.reversed(),live,SimpleDateFormat("h:mm:ss a",Locale.US).format(Date()))
 }catch(t:Throwable){LiveTdSnapshot(emptyList(),0,SimpleDateFormat("h:mm:ss a",Locale.US).format(Date()),t.message?:"Live feed unavailable")}
}
