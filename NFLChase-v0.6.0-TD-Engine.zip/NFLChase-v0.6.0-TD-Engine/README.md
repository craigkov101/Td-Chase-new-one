# NFL Chase v0.6.0 — TD Engine
Clean Android/Jetpack Compose rebuild focused on anytime-touchdown discovery.

## Included now
- Games → per-game ranked TD candidates
- League-wide TD Board
- Player factor breakdowns
- Game Scripts
- 1–5 leg TD Builder
- Model Lab foundation with frozen pregame snapshots + Brier calibration hook
- Starting weights: RZ 26, Opportunity 20, Matchup 20, Scheme 12, Environment 11, Role/Injury 6, Explosive 5
- OUT/inactive-ready status filtering in repository layer
- Portrait UI and GitHub Actions APK build

## Important
The bundled candidate feed is intentionally demo data so the UI/model can run before the live data adapters are connected. Do not treat demo probabilities as live betting projections.

## Build
GitHub Actions: Actions → Build NFL Chase v0.6.0 → Run workflow → download APK artifact.
