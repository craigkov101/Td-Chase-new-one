package com.nflchase.tdengine

import android.os.Bundle
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import coil.compose.AsyncImage
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.util.Locale
import com.nflchase.tdengine.data.*
import com.nflchase.tdengine.model.*

// A restrained sports-data palette: slate/navy foundation, ice-blue actions,
// sea-glass success, amber opportunities and coral ONLY for verified risk.
private val Bg=ChaseColors.background
private val Card=ChaseColors.panel
private val Card2=ChaseColors.inset
private val Line=ChaseColors.border
private val Blue=ChaseColors.ice
private val Green=ChaseColors.mint
private val Muted=ChaseColors.muted
private val Gold=ChaseColors.amber
private val Coral=ChaseColors.coral
private val Purple=ChaseColors.purple
internal fun teamAccent(code:String):Color=when(code.uppercase(Locale.US)) {
 "DEN","CIN","CLE","CHI" -> Color(0xFFED975D)
 "SEA","PHI","NYJ","GB" -> Color(0xFF64C9A6)
 "SF","KC","ARI","ATL","TB","WAS" -> Color(0xFFEB8489)
 "BUF","NE","NYG","TEN","HOU" -> Color(0xFF85B4EC)
 "BAL","MIN" -> Color(0xFFB5A4F0)
 "PIT","NO","JAX","JAC" -> Color(0xFFF0C478)
 else -> Blue
}
@Composable private fun Pill(text:String,tint:Color=Blue) {
 Surface(color=tint.copy(alpha=.11f),shape=RoundedCornerShape(50),border=BorderStroke(1.dp,tint.copy(alpha=.25f))) {
  Text(text,color=tint,fontWeight=FontWeight.Bold,fontSize=10.sp,modifier=Modifier.padding(horizontal=10.dp,vertical=6.dp))
 }
}
@Composable private fun SectionCaption(text:String,tint:Color=Blue) {
 Row(verticalAlignment=Alignment.CenterVertically) {
  Surface(color=tint,shape=RoundedCornerShape(4.dp),modifier=Modifier.width(4.dp).height(17.dp)){}
  Spacer(Modifier.width(9.dp))
  Text(text,color=tint,fontWeight=FontWeight.Black,fontSize=12.sp,letterSpacing=.5.sp)
 }
}
private fun signalTint(kind: SignalKind):Color=when(kind) {
 SignalKind.VOLUME -> Blue
 SignalKind.RISING -> Green
 SignalKind.GOAL_LINE -> Gold
 SignalKind.MATCHUP -> Purple
 SignalKind.AVAILABILITY -> Coral
 SignalKind.SMALL_SAMPLE -> Muted
}
@Composable private fun PlayerSignalTags(player:WeekCandidate, partial:Boolean=false) {
 val signals=PlayerSignals.classify(player,partial).take(2)
 if(signals.isNotEmpty()) Row(horizontalArrangement=Arrangement.spacedBy(6.dp),modifier=Modifier.padding(top=7.dp)) {
  signals.forEach { signal -> Pill(signal.label,signalTint(signal.kind)) }
 }
}
@Composable private fun FeedHealthPanel(records:List<FeedRecord>,files:Int,onCheck:()->Unit){
 Surface(color=Card,shape=RoundedCornerShape(18.dp),border=BorderStroke(1.dp,Line)) {
  Column(Modifier.fillMaxWidth().padding(16.dp)) {
   SectionCaption("DATA CONNECTIONS",Blue)
   Text("Verified provider responses cached on this device • $files saved responses",color=Muted,fontSize=11.sp,modifier=Modifier.padding(top=7.dp))
   if(records.isEmpty())Text("Feeds not checked yet. Open a game or refresh to start.",color=Gold,fontSize=12.sp,modifier=Modifier.padding(top=9.dp))
   else {
    val groups=records.groupBy{it.category}
    groups.forEach { (category,items) ->
     val live=items.count{it.state=="LIVE" || it.state=="RECENT CACHE"}
     val stale=items.count{it.state=="STALE CACHE"}
     val failed=items.count{it.state=="FAILED"}
     val partial=items.count{it.state=="PARTIAL"}
     Row(Modifier.fillMaxWidth().padding(top=9.dp),verticalAlignment=Alignment.CenterVertically) {
      Text(category,modifier=Modifier.weight(1f),fontSize=12.sp,fontWeight=FontWeight.Bold)
      if(live>0) Pill("$live OK",Green)
      if(stale>0){Spacer(Modifier.width(4.dp));Pill("$stale STALE",Gold)}
      if(partial>0){Spacer(Modifier.width(4.dp));Pill("$partial PARTIAL",Gold)}
      if(failed>0){Spacer(Modifier.width(4.dp));Pill("$failed FAILED",Coral)}
     }
    }
   }
   Text("STALE = last known data, not current status. Injuries and final inactives require fresh confirmation.",color=Muted,fontSize=11.sp,modifier=Modifier.padding(top=10.dp))
   var details by remember{mutableStateOf(false)}
   TextButton(onClick={details=!details}) { Text(if(details)"Hide feed details" else "Show feed details") }
   if(details) records.takeLast(18).forEach { item ->
    Text("${item.category} • ${item.state} • ${if(item.ageMinutes>=0) "${item.ageMinutes} min old" else "source detail"}",color=when(item.state){"FAILED"->Coral;"STALE CACHE","PARTIAL"->Gold;else->Green},fontSize=11.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=6.dp))
    Text(item.detail,color=Muted,fontSize=10.sp)
   }
   TextButton(onClick=onCheck){Text("Refresh schedule and recheck connections")}
  }
 }
}
class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{MaterialTheme(colorScheme=darkColorScheme(background=Bg,surface=Card,primary=Blue,secondary=Green,tertiary=Gold,onSurface=Color(0xFFF0F6FC),onBackground=Color(0xFFF0F6FC))){App()}}}}
enum class Tab(val title:String){GAMES("Games"),PICKS("Picks"),SCRIPTS("Scripts"),PARLAYS("Parlays"),MORE("More")}
@Composable fun App(){
 var tab by remember{mutableStateOf(Tab.GAMES)}
 var selected by remember{mutableStateOf<LiveScheduleGame?>(null)}
 val context=LocalContext.current
 val feeds=remember(context){ReliableFeeds(context)}
 val audits=remember(context,feeds){ModelAuditStore(java.io.File(context.filesDir,"td-chase-audit-v1.json"),feeds::json)}
 var auditOverview by remember(audits){mutableStateOf(audits.overview())}
 var auditing by remember{mutableStateOf(false)}
 val client=remember(feeds){LiveTdClient(feeds::text,feeds::urgentText)}
 val weekEngine=remember(feeds){CurrentWeekEngine(feeds::json,feeds::status,onSupplementalStatus=feeds::supplemental)}
 val tendencyEngine=remember(feeds){ScoringTendencies(feeds::json)}
 var feedRecords by remember{mutableStateOf<List<FeedRecord>>(emptyList())}
 var feedFiles by remember{mutableIntStateOf(0)}
 fun updateFeedStatus(){feedRecords=feeds.health();feedFiles=feeds.cacheFiles()}
 var trends by remember{mutableStateOf<Map<String,TeamScoringTrend>>(emptyMap())}
 var trendsLoading by remember{mutableStateOf<Set<String>>(emptySet())}
 var projections by remember{mutableStateOf<Map<String,WeekProjection>>(emptyMap())}
 var reports by remember{mutableStateOf<Map<String,SimulationReport>>(emptyMap())}
 var reportLoading by remember{mutableStateOf<Set<String>>(emptySet())}
 val reportKeys=remember{mutableMapOf<String,String>()}
 val reportSemaphore=remember{Semaphore(2)}
 var projectionLoading by remember{mutableStateOf<Set<String>>(emptySet())}
 var live by remember{mutableStateOf(LiveTdSnapshot(emptyList(),0,"—"))}
 var loading by remember{mutableStateOf(false)}
 var lastError by remember{mutableStateOf<String?>(null)}
 val scope=rememberCoroutineScope()
 var importedCharting by remember { mutableStateOf(
  runCatching { CoverageCsv.parse(context.openFileInput("tdchase_route_charting.csv").bufferedReader().use { it.readText() }).rows }
   .getOrDefault(emptyList())
 ) }
 var chartingStatus by remember { mutableStateOf(if(importedCharting.isEmpty()) "No coverage charting imported" else "${importedCharting.size} charted rows loaded from device storage") }
 val chartingLauncher=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){ uri ->
  if(uri!=null)scope.launch {
   try {
    val imported=withContext(Dispatchers.IO) {
     val file=context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
      ?: error("Unable to read the selected CSV")
     val parsed=CoverageCsv.parse(file)
     if(parsed.rows.isEmpty()) error(parsed.message)
     context.openFileOutput("tdchase_route_charting.csv", Context.MODE_PRIVATE).bufferedWriter().use { it.write(file) }
     parsed
    }
    importedCharting=imported.rows
    chartingStatus=imported.message
   }catch(e:Exception){ chartingStatus="Coverage import failed: ${e.message}" }
  }
 }
 fun requestProjection(game:LiveScheduleGame,force:Boolean=false){
  if(game.id in projectionLoading)return
  if(force)feeds.forceRefresh()
  projectionLoading=projectionLoading+game.id
  scope.launch {try {val result=withContext(Dispatchers.IO){weekEngine.load(game,force)};projections=projections+(game.id to result)}
   catch(e:Exception){projections=projections+(game.id to WeekProjection(game.id,emptyList(),"ESPN recent box scores",e.message ?: "Request failed"))}
   finally {projectionLoading=projectionLoading-game.id;updateFeedStatus()}}
 }
 fun openGame(game:LiveScheduleGame){
  selected=game;requestProjection(game)
  teamsOf(game).filter{it !in trends && it !in trendsLoading}.forEach { code ->
   trendsLoading=trendsLoading+code
   scope.launch {try {
    val result=withContext(Dispatchers.IO){tendencyEngine.load(code)}
    trends=trends+(code to result)
   }catch(e:Exception){trends=trends+(code to TeamScoringTrend(code,0,0,0,0,0,"Scoring request failed",e.message))}
   finally{trendsLoading=trendsLoading-code}}
  }
 }
 fun refreshTrends(game:LiveScheduleGame){
  feeds.forceRefresh()
  teamsOf(game).filter{it !in trendsLoading}.forEach {code->
   trendsLoading=trendsLoading+code
   scope.launch{try{
    val result=withContext(Dispatchers.IO){tendencyEngine.load(code,true)}
    trends=trends+(code to result)
   }catch(e:Exception){trends=trends+(code to TeamScoringTrend(code,0,0,0,0,0,"Scoring refresh failed",e.message))}
   finally{trendsLoading=trendsLoading-code;updateFeedStatus()}}
  }
 }
 fun auditPending() {
  if(auditing)return
  auditing=true
  scope.launch {
   try { withContext(Dispatchers.IO) { audits.gradePending() } }
   finally {auditOverview=audits.overview();auditing=false;updateFeedStatus()}
  }
 }
 fun refresh(force:Boolean=false){if(loading)return;if(force)feeds.forceRefresh();loading=true;scope.launch{try{
  val update=withContext(Dispatchers.IO){client.loadToday()}
  if(update.schedule.isNotEmpty() || live.schedule.isEmpty())live=update
  lastError=update.error ?: if(feeds.health().any{it.category in setOf("Schedule","Box scores") && it.state=="STALE CACHE"})
   "Some schedule or touchdown data is cached; current ESPN connection unavailable" else null
 }catch(e:Exception){lastError=e.message?:"Network unavailable"}finally{loading=false;updateFeedStatus()}}}
 LaunchedEffect(Unit){
  refresh()
  auditPending()
  var ticks=0
  while(isActive){
   delay(120000)
   refresh()
   ticks++
   if(ticks%15==0)auditPending()
  }
 }
 val todayEast=java.time.LocalDate.now(java.time.ZoneId.of("America/New_York"))
 val startOfSlate=if(todayEast.dayOfWeek in listOf(java.time.DayOfWeek.TUESDAY,java.time.DayOfWeek.WEDNESDAY))
  todayEast.with(java.time.temporal.TemporalAdjusters.next(java.time.DayOfWeek.THURSDAY))
 else todayEast.with(java.time.temporal.TemporalAdjusters.previousOrSame(java.time.DayOfWeek.THURSDAY))
 LaunchedEffect(startOfSlate){trends=emptyMap()}
 val slate=live.schedule.filter { g -> runCatching {
  val d=java.time.Instant.parse(g.kickoff).atZone(java.time.ZoneId.of("America/New_York")).toLocalDate()
  !d.isBefore(startOfSlate) && !d.isAfter(startOfSlate.plusDays(4))
 }.getOrDefault(false) }.distinctBy{it.matchup}.sortedBy{it.kickoff}
 // Load the entire visible slate on demand, in small batches. Unlike earlier
 // versions, users do not have to open every individual game to populate Picks.
 LaunchedEffect(tab,slate.joinToString { it.id }) {
  if(tab==Tab.SCRIPTS || tab==Tab.PICKS || tab==Tab.MORE) {
   for(batch in slate.chunked(2)) {
    val pending=batch.filter{it.id !in projections && it.id !in projectionLoading}
    if(pending.isEmpty())continue
    projectionLoading=projectionLoading+pending.map{it.id}
    try {
     val results=coroutineScope { pending.map{game->async(Dispatchers.IO) {
      game to runCatching {weekEngine.load(game)}.getOrElse { e ->
       WeekProjection(game.id,emptyList(),"ESPN recent results",e.message ?: "Feed unavailable") }
     }}.awaitAll() }
     results.forEach{ (game,result)->projections=projections+(game.id to result) }
     updateFeedStatus()
    } finally {projectionLoading=projectionLoading-pending.map{it.id}.toSet()}
   }
  }
 }
 // Scoring DNA now loads progressively on the Scripts tab without requiring a
 // game to be tapped. Requests remain sequential to protect the upstream feed.
 LaunchedEffect(tab,slate.joinToString { it.id }) {
  if(tab==Tab.SCRIPTS) for(code in slate.flatMap(::teamsOf).distinct()) {
   if(code in trends || code in trendsLoading) continue
   trendsLoading=trendsLoading+code
   try {
    val trend=withContext(Dispatchers.IO) { tendencyEngine.load(code) }
    trends=trends+(code to trend)
   } catch(e:Exception) {
    trends=trends+(code to TeamScoringTrend(code,0,0,0,0,0,"Scoring history unavailable",e.message))
   } finally { trendsLoading=trendsLoading-code;updateFeedStatus() }
  }
 }
 // Monte Carlo is never executed during Compose rendering. A signature prevents
 // stale or duplicate simulation results from overwriting a refreshed matchup.
 LaunchedEffect(projections,trends,importedCharting,slate.joinToString{it.id}) {
  projections.forEach { (id,p) ->
   val game=slate.firstOrNull{it.id==id} ?: return@forEach
   val relevant=teamsOf(game)
   val trendKey=relevant.joinToString { "${it}:${trends[it]?.gamesObserved}:${trends[it]?.total}" }
   val signature="${p.checkedAt}:$trendKey:${importedCharting.hashCode()}"
   if(reportKeys[id]==signature)return@forEach
   reportKeys[id]=signature
   reportLoading=reportLoading+id
   scope.launch {
    val report=runCatching { reportSemaphore.withPermit {
     withContext(Dispatchers.Default) {
      val coverage=CoverageAnalyzer.evaluate(game.matchup,p,importedCharting)
      GameScriptEngine.simulate(game.matchup,CoverageAnalyzer.enrich(p,coverage),trends,coverage=coverage)
     }
    }}.getOrNull()
    if(reportKeys[id]==signature){
     reports=if(report==null) reports-id else reports+(id to report)
     reportLoading=reportLoading-id
    }
   }
  }
 }
 // Save ONLY pre-kickoff, verified predictions. This happens as data becomes
 // available; an opened app never claims it made historical predictions.
 LaunchedEffect(projections,reports,slate.joinToString{it.id}) {
  val candidates=slate.mapNotNull { game ->
   projections[game.id]?.let { Triple(game,it,reports[game.id]) }
  }
  val changed=withContext(Dispatchers.IO) {
   candidates.count { (game,p,report) -> audits.freeze(game,p,report) }
  }
  if(changed>0) auditOverview=audits.overview()
 }
 Scaffold(containerColor=Bg,bottomBar={NavigationBar(containerColor=Color(0xFF0D1827)){
  Tab.entries.forEach{t->NavigationBarItem(selected=tab==t,onClick={tab=t;selected=null},icon={Icon(when(t){Tab.GAMES->Icons.Default.SportsFootball;Tab.PICKS->Icons.Default.Star;Tab.SCRIPTS->Icons.Default.QueryStats;Tab.PARLAYS->Icons.Default.Casino;Tab.MORE->Icons.Default.MoreHoriz},null)},label={Text(t.title)},colors=NavigationBarItemDefaults.colors(selectedIconColor=Blue,indicatorColor=Blue.copy(.18f),selectedTextColor=Color.White,unselectedIconColor=Muted,unselectedTextColor=Muted))}
 }}){pad->Column(Modifier.padding(pad).fillMaxSize()){Header();Crossfade(targetState=Pair(tab,selected),animationSpec=tween(180),label="tab transition"){state->val(currentTab,currentGame)=state;when{
  currentGame!=null->CurrentGameDetail(currentGame,projections[currentGame.id],currentGame.id in projectionLoading,reports[currentGame.id],currentGame.id in reportLoading,{requestProjection(currentGame,true)},{selected=null},trends,trendsLoading,{refreshTrends(currentGame)},importedCharting,{chartingLauncher.launch(arrayOf("text/*","application/octet-stream"))})
  currentTab==Tab.GAMES->CurrentGamesHome(slate,live,loading,lastError,{refresh(true)}){openGame(it)}
  currentTab==Tab.PICKS->CurrentPicks(slate,projections.mapValues { (id,p) ->
    val g=slate.firstOrNull{it.id==id}; if(g==null)p else CoverageAnalyzer.enrich(p,CoverageAnalyzer.evaluate(g.matchup,p,importedCharting))
   }){openGame(it)}
  currentTab==Tab.SCRIPTS->CurrentScripts(slate,reports,reportLoading){openGame(it)}
  currentTab==Tab.PARLAYS->CurrentParlays(slate)
  else->Column(Modifier.verticalScroll(rememberScrollState())) {
   Box(Modifier.padding(horizontal=16.dp,vertical=8.dp)) {
    FeedHealthPanel(feedRecords,feedFiles,{refresh(true)})
   }
   CoverageContextPanel(slate,projections)
   Surface(color=Card,shape=RoundedCornerShape(16.dp),modifier=Modifier.fillMaxWidth().padding(16.dp)) {
    Column(Modifier.padding(16.dp)) {
     Text("WR / CB ROUTE CHARTING",color=Blue,fontWeight=FontWeight.Black)
     Text("Measured receiver/defender route matchups require licensed charting. Automatic secondary roster context is shown above; it is not shadow coverage.",color=Muted,fontSize=12.sp)
     Text(chartingStatus,color=Gold,fontSize=12.sp,modifier=Modifier.padding(top=9.dp))
     TextButton(onClick={chartingLauncher.launch(arrayOf("text/*","application/octet-stream"))}) { Text("Import licensed coverage CSV") }
     Text("Example data providers: Fantasy Points Data Suite Shadow Index (with authorized CSV access) or other licensed charting exports. The app stores the file on this device only.",color=Muted,fontSize=11.sp)
    }
   }
   Surface(color=Card2,shape=RoundedCornerShape(18.dp),modifier=Modifier.padding(horizontal=16.dp,vertical=4.dp).fillMaxWidth()) {
    Column(Modifier.padding(16.dp)){ChaseHighlightsLegend()}
   }
   More(auditOverview,auditing,::auditPending)
  }
 }}}}
}
@Composable fun Header(){
 Column(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF16283C),Bg)))) {
  Row(Modifier.fillMaxWidth().padding(horizontal=20.dp,vertical=17.dp),verticalAlignment=Alignment.CenterVertically){
   Surface(shape=RoundedCornerShape(17.dp),color=Blue.copy(.13f),border=BorderStroke(1.dp,Blue.copy(.3f))){
    Icon(Icons.Default.SportsFootball,"TD Chase",tint=Blue,modifier=Modifier.padding(12.dp).size(26.dp))
   }
   Spacer(Modifier.width(13.dp))
   Column(Modifier.weight(1f)){
    Row(verticalAlignment=Alignment.CenterVertically){
     Text("TD",fontSize=26.sp,fontWeight=FontWeight.Black,color=Blue)
     Text(" CHASE",fontSize=26.sp,fontWeight=FontWeight.Black)
    }
    Text("FOOTBALL INTELLIGENCE  ·  CXAIG",color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold,letterSpacing=.7.sp)
   }
   Pill("V1.14 · DATA LAB",Purple)
  }
  HorizontalDivider(color=Line)
 }
}
@Composable fun TeamLogo(abbreviation:String){
 val code=when(abbreviation.uppercase(Locale.US)){"JAC"->"jax";"LA"->"lar";else->abbreviation.lowercase(Locale.US)}
 val name=abbreviation.uppercase(Locale.US)
 Box(Modifier.size(47.dp).background(teamAccent(name).copy(alpha=.16f),RoundedCornerShape(12.dp)),contentAlignment=Alignment.Center){
  Text(name,color=teamAccent(name),fontWeight=FontWeight.Black,fontSize=12.sp)
  // Offline fallback is always present behind Coil's optional team logo.
  AsyncImage(model="https://a.espncdn.com/i/teamlogos/nfl/500/$code.png",
   contentDescription="$name NFL team logo",modifier=Modifier.size(44.dp))
 }
}
@Composable fun TouchdownFeed(snapshot:LiveTdSnapshot,loading:Boolean,onRefresh:()->Unit){
 Surface(color=Card,shape=RoundedCornerShape(24.dp),border=BorderStroke(1.dp,Line),modifier=Modifier.padding(horizontal=20.dp).fillMaxWidth()){Column(Modifier.padding(18.dp)){
  Row(verticalAlignment=Alignment.CenterVertically){Surface(shape=CircleShape,color=Blue.copy(.12f)){Icon(Icons.Default.SportsFootball,null,tint=Blue,modifier=Modifier.padding(10.dp))};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text("TODAY • LIVE FEED",color=Blue,fontWeight=FontWeight.Black,fontSize=12.sp);Text(if(snapshot.liveGames>0)"${snapshot.liveGames} LIVE" else "NFL touchdown tracker",fontSize=19.sp,fontWeight=FontWeight.Black)};Text("${snapshot.events.size} TD",color=if(snapshot.events.isNotEmpty())Green else Muted,fontWeight=FontWeight.Bold)}
  Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.padding(top=10.dp)){if(loading)CircularProgressIndicator(modifier=Modifier.size(14.dp),strokeWidth=2.dp,color=Blue);Text("  Auto 60 sec • swipe to force • ${snapshot.updatedAt}",color=Muted,fontSize=10.sp);Spacer(Modifier.weight(1f));TextButton(onClick=onRefresh,enabled=!loading){Text("REFRESH",fontSize=10.sp)}}
  HorizontalDivider(color=Line,modifier=Modifier.padding(vertical=14.dp))
  snapshot.error?.let{Text("Live feed temporarily unavailable",color=Gold,fontWeight=FontWeight.Bold);Text(it,color=Muted,fontSize=11.sp)}
  if(snapshot.error==null&&snapshot.events.isEmpty())Text("No touchdowns found in the current NFL week.",color=Muted,fontWeight=FontWeight.Bold)
  snapshot.events.take(40).forEachIndexed{i,td->if(i>0)HorizontalDivider(color=Line.copy(.55f),modifier=Modifier.padding(vertical=10.dp));Row{Surface(color=Blue.copy(.10f),shape=RoundedCornerShape(10.dp)){Text(td.team.ifBlank{"TD"},color=Blue,fontWeight=FontWeight.Black,modifier=Modifier.padding(8.dp,5.dp))};Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(td.text,fontWeight=FontWeight.Bold,fontSize=14.sp);Text("${td.game} • Q${td.quarter} ${td.clock}",color=Muted,fontSize=11.sp,modifier=Modifier.padding(top=3.dp))}}}
 }}}
@Composable fun Title(a:String,b:String){Column(Modifier.padding(20.dp,14.dp)){Text(a,fontSize=28.sp,fontWeight=FontWeight.Black);Text(b,color=Muted,fontSize=13.sp)}}
@Composable fun Metric(n:String,v:String){Surface(color=Card,shape=RoundedCornerShape(15.dp),border=BorderStroke(1.dp,Line)){Column(Modifier.padding(15.dp)){Text(v,fontSize=22.sp,fontWeight=FontWeight.Black,color=Blue);Text(n,color=Muted,fontSize=11.sp)}}}
/** No paid charting data is fabricated: verified defensive rosters are shown as context. */
@Composable private fun CoverageContextPanel(slate:List<LiveScheduleGame>,projections:Map<String,WeekProjection>) {
 val available=slate.mapNotNull { g -> projections[g.id]?.let { g to it } }.take(5)
 Surface(color=Card,shape=RoundedCornerShape(18.dp),border=BorderStroke(1.dp,Line),
  modifier=Modifier.padding(horizontal=16.dp,vertical=6.dp).fillMaxWidth()) {
  Column(Modifier.padding(16.dp)) {
   SectionCaption("AUTOMATIC SECONDARY CONTEXT",Purple)
   Text("Loaded from ESPN defensive rosters, with limited roster-status evidence. This is NOT measured WR-vs-CB coverage, route charting, or a shadow assignment.",color=Muted,fontSize=11.sp,modifier=Modifier.padding(top=8.dp))
   if(available.isEmpty()) Text("Loading defensive roster context for this week's matchups...",color=Gold,fontSize=12.sp,modifier=Modifier.padding(top=10.dp))
   available.forEach { (game,p) ->
    HorizontalDivider(color=Line,modifier=Modifier.padding(top=12.dp,bottom=8.dp))
    Text(game.matchup,color=Blue,fontWeight=FontWeight.Bold,fontSize=13.sp)
    teamsOf(game).forEach { code ->
     val defenders=p.defensiveBacks[code].orEmpty()
     val absences=p.injuries.filter { it.team==code && it.position in setOf("CB","DB","S","FS","SS","SAF") && EspnInjuryParser.confirmedOut(it.designation) }
     Text("$code secondary: ${defenders.size} rostered DBs | ${absences.size} reported unavailable",fontSize=11.sp)
     if(defenders.isNotEmpty()) Text(defenders.take(4).joinToString(", ") { name -> name.split(" ").joinToString(" ") { w -> w.replaceFirstChar(Char::uppercaseChar) } } + if(defenders.size>4) " +${defenders.size-4} more" else "",color=Muted,fontSize=10.sp)
    }
   }
  }
 }
}

@Composable fun More(a:AuditOverview,working:Boolean,onGrade:()->Unit){
 Title("More","Data transparency, matchup evidence and model research")
 Surface(color=Card,shape=RoundedCornerShape(18.dp),border=BorderStroke(1.dp,Line),modifier=Modifier.padding(horizontal=16.dp).fillMaxWidth()){
  Column(Modifier.padding(18.dp)){
   SectionCaption("MODEL LAB • SAVED PREGAME AUDITS",Purple)
   Text("TD Chase saves verified rankings before kickoff. Once final, it checks each saved top-10 against complete ESPN box scores. History persists on this device. No past predictions are fabricated.",color=Muted,fontSize=12.sp,lineHeight=18.sp,modifier=Modifier.padding(top=10.dp))
   Row(Modifier.padding(top=12.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
    Box(Modifier.weight(1f)) {Metric("Pregame snapshots",a.snapshots.toString())}
    Box(Modifier.weight(1f)) {Metric("Graded games",a.gradedGames.toString())}
   }
   Row(Modifier.padding(top=8.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
    Box(Modifier.weight(1f)) {Metric("Top-3 TD hits",a.topThreeHits.toString())}
    Box(Modifier.weight(1f)) {Metric("Top-10 TD hits",a.topTenHits.toString())}
   }
   Text("${a.pendingGames} saved game(s) awaiting a verified final box score",color=Muted,fontSize=11.sp,modifier=Modifier.padding(top=10.dp))
   a.averageScoreError?.let {Text("Mean combined absolute score error: ${String.format(Locale.US,"%.1f",it)} pts (${a.recent.count{row->row.scoreError!=null}} recent displayed comparisons)",color=Green,fontSize=11.sp)}
   a.lastError?.let {Text("Last audit refresh issue: $it",color=Gold,fontSize=11.sp)}
   if(a.recent.isEmpty())Text("No pregame snapshots yet. Open Picks or Scripts before kickoff to populate the audit ledger.",color=Gold,fontSize=12.sp,modifier=Modifier.padding(top=10.dp))
   a.recent.forEach{ row ->
    HorizontalDivider(color=Line,modifier=Modifier.padding(top=10.dp,bottom=8.dp))
    Row(verticalAlignment=Alignment.CenterVertically){
     Text(row.matchup,modifier=Modifier.weight(1f),fontWeight=FontWeight.Bold,fontSize=12.sp)
     Pill(row.state,if(row.state=="GRADED")Green else Gold)
    }
    Text(if(row.state=="GRADED") "Top 3: ${row.correctTopThree} TD hits · Top 10: ${row.actualTopTenTdScorers} TD hits" else "Saved ${row.savedAt.take(16)} · awaiting final",color=Muted,fontSize=11.sp)
    if(row.state=="GRADED")Text("Score projected ${row.projectedScore} · final ${row.actualScore}" + (row.scoreError?.let{" · combined error $it"}?:""),color=Muted,fontSize=11.sp)
   }
   TextButton(onClick=onGrade,enabled=!working) {Text(if(working)"Checking final box scores..." else "Check finished games and grade saved picks")}
   Text("A 0–100 opportunity index is NOT a touchdown probability. Calibration/retraining still requires a separate historical validation process.",color=Gold,fontSize=11.sp,modifier=Modifier.padding(top=8.dp))
  }
 }
}

private fun kickoffLabel(game:LiveScheduleGame):String=runCatching{
 java.time.Instant.parse(game.kickoff).atZone(java.time.ZoneId.of("America/New_York"))
 .format(java.time.format.DateTimeFormatter.ofPattern("EEE, MMM d • h:mm a z",Locale.US))
}.getOrDefault(game.kickoff)
private fun teamsOf(game:LiveScheduleGame):List<String> = game.matchup.split(" @ "," at ",limit=2)
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun CurrentGamesHome(slate:List<LiveScheduleGame>,live:LiveTdSnapshot,loading:Boolean,lastError:String?,refresh:()->Unit,open:(LiveScheduleGame)->Unit){
 val days=slate.mapNotNull { runCatching { java.time.Instant.parse(it.kickoff).atZone(java.time.ZoneId.of("America/New_York")).toLocalDate() }.getOrNull() }.distinct().sorted()
 var day by remember{mutableIntStateOf(0)}
 PullToRefreshBox(isRefreshing=loading,onRefresh=refresh,modifier=Modifier.fillMaxSize()){
  LazyColumn(contentPadding=PaddingValues(bottom=24.dp)){
   item{Column(Modifier.padding(20.dp)){
    SectionCaption("WEEKLY SLATE",Green)
    Text("NFL Matchups",fontSize=28.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=7.dp))
    Text("${slate.size} weekly matchups · official schedule or validated cache",color=Muted,fontSize=12.sp)
    Row(Modifier.fillMaxWidth().padding(top=14.dp),horizontalArrangement=Arrangement.spacedBy(9.dp)) {
     Surface(color=Card2,shape=RoundedCornerShape(14.dp),modifier=Modifier.weight(1f)){
      Column(Modifier.padding(12.dp)){Text("${slate.size}",color=Blue,fontSize=23.sp,fontWeight=FontWeight.Black);Text("MATCHUPS",color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold)}
     }
     Surface(color=Card2,shape=RoundedCornerShape(14.dp),modifier=Modifier.weight(1f)){
      Column(Modifier.padding(12.dp)){Text("${slate.count{VisualRules.gameBadge(it.state).label=="LIVE"}}",color=Green,fontSize=23.sp,fontWeight=FontWeight.Black);Text("LIVE GAMES",color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold)}
     }
     Surface(color=Card2,shape=RoundedCornerShape(14.dp),modifier=Modifier.weight(1f)){
      Column(Modifier.padding(12.dp)){Text("${live.events.size}",color=Gold,fontSize=23.sp,fontWeight=FontWeight.Black);Text("TD EVENTS",color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold)}
     }
    }
    val index=day.coerceIn(0,(days.size-1).coerceAtLeast(0))
    Surface(color=Card2,shape=RoundedCornerShape(16.dp),border=BorderStroke(1.dp,Line),modifier=Modifier.fillMaxWidth().padding(top=13.dp)){
     Row(verticalAlignment=Alignment.CenterVertically){
      IconButton(onClick={day=(index-1).coerceAtLeast(0)},enabled=index>0){Icon(Icons.Default.ChevronLeft,"Previous game day",tint=Blue)}
      Text(days.getOrNull(index)?.format(java.time.format.DateTimeFormatter.ofPattern("EEEE, MMM d",Locale.US)) ?: "Loading current schedule...",modifier=Modifier.weight(1f),fontSize=16.sp,fontWeight=FontWeight.Bold,textAlign=androidx.compose.ui.text.style.TextAlign.Center)
      IconButton(onClick={day=(index+1).coerceAtMost((days.size-1).coerceAtLeast(0))},enabled=index<days.size-1){Icon(Icons.Default.ChevronRight,"Next game day",tint=Blue)}
     }
    }
    Text(if(lastError!=null)"Schedule data warning: $lastError" else "Schedule: ESPN live feed or validated device cache",color=if(lastError!=null)Gold else Muted,fontSize=11.sp)
    Text("Tap any matchup for its game script and TD projection status.",color=Muted,fontSize=12.sp)
   }}
   val selectedDay=days.getOrNull(day.coerceIn(0,(days.size-1).coerceAtLeast(0)))
   val selectedGames=slate.filter{runCatching{java.time.Instant.parse(it.kickoff).atZone(java.time.ZoneId.of("America/New_York")).toLocalDate()==selectedDay}.getOrDefault(false)}
   if(selectedGames.isEmpty())item{Text("No schedule returned for this date. Pull down to retry.",color=Gold,modifier=Modifier.padding(20.dp))}
   items(selectedGames,key={it.id}){game->CurrentMatchupCard(game){open(game)}}
   item{Column(Modifier.padding(top=16.dp,bottom=20.dp)){
    Box(Modifier.padding(horizontal=20.dp,vertical=10.dp)){SectionCaption("LIVE TOUCHDOWN FEED",Green)}
    TouchdownFeed(snapshot=live,loading=loading,onRefresh=refresh)
   }}
  }
 }
}
@Composable fun CurrentMatchupCard(game:LiveScheduleGame,open:()->Unit){
 val teams=teamsOf(game)
 val away=teams.getOrNull(0) ?: "AWAY"
 val home=teams.getOrNull(1) ?: "HOME"
 val accent=teamAccent(home)
 Surface(onClick=open,color=Card,shape=RoundedCornerShape(23.dp),border=BorderStroke(1.dp,Line),
  modifier=Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=7.dp)) {
  Column {
   Box(Modifier.fillMaxWidth().height(4.dp).background(Brush.horizontalGradient(listOf(teamAccent(away),accent,Blue.copy(.5f)))))
   Column(Modifier.padding(17.dp)){
    Row(verticalAlignment=Alignment.CenterVertically){
     TeamLogo(away); Spacer(Modifier.width(12.dp))
     Column(Modifier.weight(1f),horizontalAlignment=Alignment.CenterHorizontally){
      Row(horizontalArrangement=Arrangement.Center,verticalAlignment=Alignment.CenterVertically){
       Text(away,color=teamAccent(away),fontWeight=FontWeight.Black,fontSize=20.sp)
       Text("   @   ",color=Muted,fontWeight=FontWeight.Medium,fontSize=13.sp)
       Text(home,color=accent,fontWeight=FontWeight.Black,fontSize=20.sp)
      }
      Text(kickoffLabel(game),color=Muted,fontSize=11.sp)
      if(game.venue.isNotBlank())Text(game.venue,color=Muted,fontSize=10.sp,maxLines=1)
     }
     Spacer(Modifier.width(12.dp)); TeamLogo(home)
    }
    if(game.weather.isNotBlank()) Text("CONDITIONS · ${game.weather}",color=Gold,fontSize=10.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=9.dp))
    Spacer(Modifier.height(12.dp))
    HorizontalDivider(color=Line)
    Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.padding(top=12.dp)){
     ChaseSignalChip(VisualRules.gameBadge(game.state))
     Spacer(Modifier.weight(1f))
     Text("MATCHUP INSIGHTS  ↗",color=Blue,fontWeight=FontWeight.Black,fontSize=11.sp)
    }
   }
  }
 }
}
@Composable fun CurrentGameDetail(game:LiveScheduleGame,projection:WeekProjection?,loading:Boolean,script:SimulationReport?,reportLoading:Boolean,retry:()->Unit,back:()->Unit,trends:Map<String,TeamScoringTrend>,trendsLoading:Set<String>,refreshTrends:()->Unit,charting:List<ChartedCoverage>,importCharting:()->Unit){
 val coverage = remember(game.id,projection,charting) { CoverageAnalyzer.evaluate(game.matchup,projection,charting) }
 val projected = remember(projection,coverage) { projection?.let { CoverageAnalyzer.enrich(it,coverage) } }
 var showRoster by remember(game.id) { mutableStateOf(false) }
 var selectedPlayer by remember(game.id) { mutableStateOf<WeekCandidate?>(null) }
 selectedPlayer?.let { candidate -> ChaseInsightSheet(candidate, projected?.error!=null, onDismiss={selectedPlayer=null}, onMatchup={selectedPlayer=null}) }
 LazyColumn(contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item {
   TextButton(onClick=back){Icon(Icons.Default.ArrowBack,null);Text("All games")}
   Surface(color=Card,shape=RoundedCornerShape(22.dp),border=BorderStroke(1.dp,Line)) {
    Column {
     val teams=teamsOf(game)
     Box(Modifier.fillMaxWidth().height(4.dp).background(Brush.horizontalGradient(listOf(teamAccent(teams.firstOrNull() ?: ""),teamAccent(teams.lastOrNull() ?: "")))))
     Column(Modifier.padding(18.dp)){
      SectionCaption("MATCHUP INTELLIGENCE",Green)
      Spacer(Modifier.height(12.dp))
      Row(verticalAlignment=Alignment.CenterVertically){
       teams.firstOrNull()?.let { TeamLogo(it) };Spacer(Modifier.width(12.dp))
       Text(game.matchup,fontSize=25.sp,fontWeight=FontWeight.Black,modifier=Modifier.weight(1f))
       teams.lastOrNull()?.let { TeamLogo(it) }
      }
      Text(kickoffLabel(game),color=Muted,fontSize=12.sp,modifier=Modifier.padding(top=8.dp))
      Row(horizontalArrangement=Arrangement.spacedBy(7.dp),modifier=Modifier.padding(top=12.dp)){
       Pill("USAGE",Blue);Pill("INJURIES",Coral);Pill("DRIVE SIM",Green)
      }
     }
    }
   }
  }
  // The same projection and injury inputs power the screen, ranked scorers, and simulated final score.
  // If validated final-score data is missing, do not fabricate a football score.
  item { Surface(color=Card,shape=RoundedCornerShape(18.dp),border=BorderStroke(1.dp,Line)) {
   Column(Modifier.fillMaxWidth().padding(17.dp)){
    SectionCaption("SIMULATION REPORT",Green)
    Text("Scoring outlook & game script",fontSize=21.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=8.dp))
    Text("Recent team form • offensive opportunity • confirmed injuries • drive outcomes",color=Muted,fontSize=11.sp)
    if((loading || reportLoading) && script==null) {
     Spacer(Modifier.height(12.dp));CircularProgressIndicator(color=Blue)
     Text("Retrieving team results, usage and injury reports...",color=Muted,fontSize=12.sp)
    } else if(script==null) {
     Text("No defensible score simulation yet: need at least two completed games with verified points scored AND allowed for both teams.",color=Gold,modifier=Modifier.padding(top=12.dp))
     Text(projection?.error ?: "Open this game to load the ESPN data.",color=Muted,fontSize=12.sp)
     TextButton(onClick=retry,enabled=!loading){Text("Retry matchup data")}
    } else {
     if(script.dataWarning!=null)Text("SOURCE WARNING: ${script.dataWarning}",color=Coral,fontSize=12.sp,modifier=Modifier.padding(top=9.dp))
     Spacer(Modifier.height(12.dp))
     ChaseProjectedScore(script.away,script.awayScore,script.home,script.homeScore,script.sampleCount)
     script.sections.forEachIndexed { sectionIndex,section ->
      Surface(color=if(sectionIndex%2==0)Card2 else Card,shape=RoundedCornerShape(14.dp),
       modifier=Modifier.fillMaxWidth().padding(top=9.dp)) {
       Column(Modifier.padding(12.dp)) {
        SectionCaption(section.title,when{
         "INJUR" in section.title || "RISK" in section.title -> Coral
         "SHORT-YARDAGE" in section.title || "SCORING" in section.title -> Gold
         "SIMULATION" in section.title -> Green
         else -> Blue
        })
        Text(section.paragraph,modifier=Modifier.padding(top=7.dp),fontSize=13.sp,lineHeight=20.sp)
       }
      }
     }
     HorizontalDivider(modifier=Modifier.padding(top=16.dp,bottom=10.dp),color=Line)
     SectionCaption("TOP 3 TOUCHDOWN CANDIDATES",Gold)
     Text("Ranked by recent opportunities adjusted for projected team scoring; NOT calibrated anytime-TD percentages.",color=Muted,fontSize=11.sp,modifier=Modifier.padding(bottom=6.dp))
     if(script.scorers.isEmpty()) Text("Not enough verified player opportunities for a scorer ranking.",color=Gold,fontSize=12.sp)
     script.scorers.forEachIndexed { i,p ->
      val matched=projected?.candidates?.firstOrNull { it.name==p.name && it.team==p.team }
      val evidence=matched?.let { PlayerSignals.classify(it,projected.error!=null).firstOrNull() }
      val color=evidence?.let { signalTint(it.kind) } ?: Line
      Surface(color=Card2,shape=RoundedCornerShape(14.dp),border=BorderStroke(1.dp,color.copy(alpha=.55f)),modifier=Modifier.fillMaxWidth().padding(top=8.dp)){
       Row(Modifier.padding(12.dp),verticalAlignment=Alignment.Top){
        Pill("#${i+1}",if(i==0)Gold else Blue)
        Spacer(Modifier.width(9.dp))
        Column(Modifier.weight(1f)){
         Text(p.name,fontWeight=FontWeight.Black,color=if(i==0)Gold else Color.White)
         Text("${p.team} • ${p.position}",color=teamAccent(p.team),fontSize=11.sp)
         matched?.let { PlayerSignalTags(it,projected.error!=null) }
         Text(p.rationale,color=Muted,fontSize=12.sp,lineHeight=18.sp,modifier=Modifier.padding(top=5.dp))
        }
       }
      }
     }
     HorizontalDivider(modifier=Modifier.padding(top=18.dp,bottom=10.dp),color=Line)
     SectionCaption("FINAL SCORE PREDICTION",Green)
     Text("${script.away} ${script.awayScore}  –  ${script.home} ${script.homeScore}",fontSize=27.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=6.dp))
     Text("${script.sampleCount} simulated games • Uncalibrated scenario estimate",color=Muted,fontSize=11.sp)
     Text(script.inputSummary,color=Muted,fontSize=10.sp,modifier=Modifier.padding(top=9.dp))
    }
   }
  } }
  item { Surface(color=Card,shape=RoundedCornerShape(18.dp)) { Column(Modifier.padding(16.dp)) {
   SectionCaption("RECENT SCORING DNA",Gold)
   Text("Observed touchdown outcomes, not goal-line usage or a player projection",color=Muted,fontSize=11.sp)
   val isFetching=teamsOf(game).any{it in trendsLoading}
   TextButton(onClick=refreshTrends,enabled=!isFetching){Text(if(isFetching) "Updating ESPN scoring data..." else "Refresh scoring history")}
   teamsOf(game).forEach { code ->
    val trend=trends[code]
    Text(code,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=10.dp))
    if(code in trendsLoading) Text("Loading ESPN game summaries...",color=Blue,fontSize=12.sp)
    else if(trend==null) Text("Scoring history not loaded",color=Muted,fontSize=12.sp)
    else if(trend.gamesObserved==0) Text("Unavailable — not verified: ${trend.error?:trend.notes}",color=Gold,fontSize=12.sp)
    else {
     Text("${trend.gamesObserved} games • ${trend.receiving} receiving TDs • ${trend.rbRush} rushing TDs • ${trend.other} other TDs",fontSize=12.sp)
     Text(trend.notes,color=Muted,fontSize=11.sp)
     if(trend.error!=null) Text("PARTIAL DATA: ${trend.error}",color=Gold,fontSize=11.sp)
    }
   }
  } } }
  item { Surface(color=Card,shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(16.dp)){
   SectionCaption("DEFENSIVE INJURY WATCH",Coral)
   Text("ESPN reported injuries • not a verified game-day inactive list",color=Muted,fontSize=11.sp)
   Text(projection?.injuryReportStatus ?: "Waiting for injury feeds...",color=Muted,fontSize=11.sp,modifier=Modifier.padding(top=6.dp))
   if(projection?.defensiveNotes?.isNotEmpty()==true) projection.defensiveNotes.forEach { note ->
    Text("• $note",color=Gold,fontSize=12.sp,modifier=Modifier.padding(top=7.dp))
   } else Text("No confirmed defensive absences retrieved. This does NOT mean all starters are healthy.",color=Gold,fontSize=12.sp,modifier=Modifier.padding(top=7.dp))
  }} }
  item { Surface(color=Card,shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(16.dp)) {
   SectionCaption("RECEIVER / CORNER COVERAGE",Purple)
   Text("Historical route-level coverage data is shown separately from projected future assignments.",color=Muted,fontSize=11.sp)
   Text(coverage.status,color=if(coverage.matches.isEmpty())Gold else Muted,fontSize=12.sp,modifier=Modifier.padding(top=8.dp))
   coverage.matches.take(8).forEach { m ->
    HorizontalDivider(color=Line,modifier=Modifier.padding(vertical=8.dp))
    Text("${m.receiver} → ${m.defender} (${m.defenderTeam})",fontWeight=FontWeight.Bold,fontSize=13.sp)
    Text(m.note,color=Muted,fontSize=11.sp,lineHeight=17.sp,modifier=Modifier.padding(top=5.dp))
   }
   TextButton(onClick=importCharting) { Text("Import charted coverage CSV") }
   Text("Source option: Fantasy Points Data Suite → Shadow Index. Provider license/export required; no fabricated charting.",color=Muted,fontSize=11.sp)
  }} }
  item { Surface(color=Card,shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(16.dp)) {
   SectionCaption("CURRENT ROSTERS & TRANSACTIONS",Blue)
   Text("Team assignment comes from the current ESPN roster plus dated verified official transactions; final active list still requires verification.",color=Muted,fontSize=11.sp)
   projection?.rosterNotes?.forEach { Text("• $it",color=Gold,fontSize=12.sp,modifier=Modifier.padding(top=6.dp)) }
   TextButton(onClick={showRoster=!showRoster}) { Text(if(showRoster) "Hide offensive rosters" else "Show all offensive roster players") }
   if(showRoster) teamsOf(game).forEach { code ->
    Text(code,color=Blue,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=8.dp))
    Text(projection?.offensiveRoster?.get(code)?.joinToString(" · ") ?: "Roster unavailable",color=Muted,fontSize=11.sp)
   }
  }} }
  item {SectionCaption("TOP 10 TD OPPORTUNITIES",Gold)
   Text("Ranked from both teams using recent verified carries, targets, production and reported injuries. The index is NOT a calibrated TD probability.",color=Muted,fontSize=12.sp)
   if(loading) CircularProgressIndicator(modifier=Modifier.padding(12.dp))
   if(projected?.error!=null)Text("Data warning: ${projected.error}",color=Gold,fontSize=11.sp)
   if(!loading && projection==null)TextButton(onClick=retry){Text("Load recent usage")}
   if(projected!=null && projected.candidates.isEmpty())Text("No candidates have enough verified recent usage. Check connectivity and retry; no fictional rankings are shown.",color=Gold)
  }
  if(projected!=null)itemsIndexed(projected.candidates.take(10),key={_,p->p.team+p.name}){i,p->
   ChasePlayerCard(player=p,rank=i+1,partial=projected.error!=null,onOpen={selectedPlayer=p})
  }
  item {TextButton(onClick=retry,enabled=!loading){Text("Refresh roster + game logs + injuries")}
   Text("${projection?.source ?: "ESPN sources loading"} • ${projection?.gamesVerified ?: 0} team game-boxscores processed • ${projection?.checkedAt ?: ""}",color=Muted,fontSize=10.sp)
   Text("Data limitations: targets/carries are box-score counts; route charting is historical and future shadow assignments remain projections; goal-line targets and final inactives may be unverified. Scores are opportunity indices, not betting probabilities.",color=Gold,fontSize=11.sp,modifier=Modifier.padding(top=6.dp))}

 }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun CurrentPicks(slate:List<LiveScheduleGame>,projections:Map<String,WeekProjection>,open:(LiveScheduleGame)->Unit){
 var position by remember { mutableStateOf("ALL") }
 var focused by remember { mutableStateOf<Pair<LiveScheduleGame,WeekCandidate>?>(null) }
 val loaded = slate.mapNotNull { game -> projections[game.id]?.let { game to it } }
 val ranked = loaded.flatMap { (game, projection) -> projection.candidates.map { candidate -> Triple(game, projection, candidate) } }
  .filter { position == "ALL" || it.third.position == position }
  .sortedWith(compareByDescending<Triple<LiveScheduleGame,WeekProjection,WeekCandidate>> { it.third.score }.thenBy { it.third.name })
 focused?.let { (game, candidate) ->
  ChaseInsightSheet(candidate,projections[game.id]?.error!=null,onDismiss={focused=null},onMatchup={focused=null;open(game)})
 }
 Column(Modifier.fillMaxSize()) {
  Column(Modifier.padding(horizontal=18.dp,vertical=12.dp)) {
   SectionCaption("PLAYER INTELLIGENCE",Green)
   Text("Top TD Opportunities",fontSize=26.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=6.dp))
   Text("${loaded.size}/${slate.size} matchups loaded • ranked opportunity index, not touchdown odds",color=Muted,fontSize=11.sp)
   Spacer(Modifier.height(12.dp))
   Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(7.dp)){
    VisualRules.positionFilters.forEach { p ->
     FilterChip(selected=position==p,onClick={position=p},label={Text(p,fontSize=11.sp)})
    }
   }
  }
  LazyColumn(contentPadding=PaddingValues(horizontal=16.dp,vertical=8.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
   if(ranked.isEmpty()) item {
    Surface(color=Card2,shape=RoundedCornerShape(16.dp),modifier=Modifier.fillMaxWidth()) {
     Column(Modifier.padding(18.dp)){
      Text(if(slate.isEmpty())"Waiting for the NFL schedule" else if(loaded.isEmpty())"Loading verified player usage..." else "No eligible $position candidates in loaded games",color=Gold,fontWeight=FontWeight.Bold)
      Text("The app will not fill missing rankings with synthetic players.",color=Muted,fontSize=12.sp,modifier=Modifier.padding(top=6.dp))
     }
    }
   }
   itemsIndexed(ranked,key={index,triple -> "${triple.first.id}:${triple.third.team}:${triple.third.name}:$index"}) { i,triple ->
    val (game, projection, player) = triple
    ChasePlayerCard(player=player,rank=i+1,partial=projection.error!=null,onOpen={focused=game to player})
    Text(game.matchup+" · "+kickoffLabel(game),color=Muted,fontSize=10.sp,modifier=Modifier.padding(start=9.dp,top=4.dp))
   }
   item {
    Surface(color=Card2,shape=RoundedCornerShape(16.dp),modifier=Modifier.fillMaxWidth()) {
     Column(Modifier.padding(16.dp)){
      ChaseHighlightsLegend()
      Text("The signal badge explains why a player is highlighted; it is not a calibrated probability or a promise of an active game-day designation.",color=Muted,fontSize=11.sp,modifier=Modifier.padding(top=11.dp))
     }
    }
   }
  }
 }
}
@Composable fun CurrentScripts(slate:List<LiveScheduleGame>,reports:Map<String,SimulationReport>,simulating:Set<String>,open:(LiveScheduleGame)->Unit){
 Column {Title("Game Scripts","Drive-by-drive outcomes • protections & turnovers • verified scoring roles")
  LazyColumn {items(slate,key={it.id}){game->
   val report = reports[game.id]
   Surface(onClick={open(game)},color=Card,shape=RoundedCornerShape(18.dp),border=BorderStroke(1.dp,Line),modifier=Modifier.padding(horizontal=16.dp,vertical=7.dp).fillMaxWidth()) {
    Column(Modifier.padding(16.dp)) {
     SectionCaption("GAME SCRIPT PREVIEW",teamAccent(teamsOf(game).lastOrNull() ?: ""))
     Text(game.matchup,fontWeight=FontWeight.Black,fontSize=20.sp,modifier=Modifier.padding(top=8.dp))
     Text(kickoffLabel(game),color=Muted,fontSize=12.sp)
     if(report==null){
      Text(if(game.id in simulating) "Calculating simulation off the UI thread…" else "Loading recent results or awaiting usable source data. Tap to inspect.",color=Muted,fontSize=12.sp,modifier=Modifier.padding(top=8.dp))
     } else {
      Spacer(Modifier.height(10.dp))
      ChaseProjectedScore(report.away,report.awayScore,report.home,report.homeScore,report.sampleCount)
      Row(Modifier.padding(top=9.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
       Pill("DRIVE SIM",Green)
       if(report.dataWarning!=null)Pill("DATA CHECK",Coral) else Pill("SCORING OUTLOOK",Gold)
      }
      Text("Top TD looks: ${report.scorers.joinToString { it.name }.ifBlank { "unverified" }}",color=Muted,fontSize=12.sp,modifier=Modifier.padding(top=7.dp))
     }
     Text("READ FULL SIMULATION + EXPLANATIONS  ›",color=Blue,fontSize=11.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=9.dp))
    }
   }
  }}
 }
}
@Composable fun CurrentParlays(slate:List<LiveScheduleGame>){
 Column{Title("TD parlays","Current-week player eligibility required")
  Text("Automatic TD parlays are temporarily disabled. The previous player pool was historical and could include players not active in these ${slate.size} games. A trustworthy generator requires validated current-week candidates.",color=Gold,modifier=Modifier.padding(20.dp))
 }
}
