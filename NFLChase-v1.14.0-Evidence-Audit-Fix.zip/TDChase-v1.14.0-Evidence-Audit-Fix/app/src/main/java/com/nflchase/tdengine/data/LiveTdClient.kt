package com.nflchase.tdengine.data

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.DayOfWeek
import java.time.temporal.TemporalAdjusters
import java.time.format.DateTimeFormatter

data class LiveTdEvent(val id:String,val game:String,val team:String,val text:String,val quarter:Int,val clock:String)
data class LivePlayerStatus(val name:String,val status:String,val detail:String,val gameId:String)
data class LiveScheduleGame(
 val id:String, val matchup:String, val kickoff:String, val state:String,
 // Optional ESPN venue/weather metadata; never infer stadium conditions.
 val venue:String = "", val weather:String = ""
)
data class LiveTdSnapshot(
    val events:List<LiveTdEvent>,
    val liveGames:Int,
    val updatedAt:String,
    val unavailablePlayers:Set<String> = emptySet(),
    val playerStatuses:List<LivePlayerStatus> = emptyList(),
    val rosterPlayersByTeam:Map<String,Set<String>> = emptyMap(),
    val error:String?=null,
    val schedule:List<LiveScheduleGame> = emptyList()
)

// NFL 2026 Week 6 fixture backup. This is a dated schedule snapshot, not live data.
// It keeps navigation available when the ESPN scoreboard is empty or unreachable.
private fun weekSixBackup():List<LiveScheduleGame> = listOf(
 LiveScheduleGame("week6-sea-den","SEA @ DEN","2026-10-16T00:15:00Z","SCHEDULED"),
 LiveScheduleGame("week6-hou-jax","HOU @ JAX","2026-10-18T13:30:00Z","SCHEDULED"),
 LiveScheduleGame("week6-chi-atl","CHI @ ATL","2026-10-18T17:00:00Z","SCHEDULED"),
 LiveScheduleGame("week6-bal-cle","BAL @ CLE","2026-10-18T17:00:00Z","SCHEDULED"),
 LiveScheduleGame("week6-ten-ind","TEN @ IND","2026-10-18T17:00:00Z","SCHEDULED"),
 LiveScheduleGame("week6-nyj-ne","NYJ @ NE","2026-10-18T17:00:00Z","SCHEDULED"),
 LiveScheduleGame("week6-no-nyg","NO @ NYG","2026-10-18T17:00:00Z","SCHEDULED"),
 LiveScheduleGame("week6-car-phi","CAR @ PHI","2026-10-18T17:00:00Z","SCHEDULED"),
 LiveScheduleGame("week6-pit-tb","PIT @ TB","2026-10-18T17:00:00Z","SCHEDULED"),
 LiveScheduleGame("week6-ari-lar","ARI @ LAR","2026-10-18T20:05:00Z","SCHEDULED"),
 LiveScheduleGame("week6-lac-kc","LAC @ KC","2026-10-18T20:25:00Z","SCHEDULED"),
 LiveScheduleGame("week6-buf-lv","BUF @ LV","2026-10-18T20:25:00Z","SCHEDULED"),
 LiveScheduleGame("week6-dal-gb","DAL @ GB","2026-10-19T00:20:00Z","SCHEDULED")
)

class LiveTdClient(
 private val fetchText:(String)->String = ::espnText,
 private val fetchCurrent:(String)->String = fetchText
) {
 private fun get(u:String):String = fetchText(u)
 private fun norm(s:String)=s.lowercase(Locale.US).replace(Regex("[^a-z0-9 ]"),"").replace(Regex("\\s+")," ").trim()
 private fun unavailable(s:String):Boolean {
  val x=s.trim().lowercase(Locale.US)
  return EspnRosterParser.unavailable(x) || Regex("\\bruled out\\b|\\bwill not return\\b|\\bdoubtful to return\\b").containsMatchIn(x)
 }
 private fun collectInjuries(summary:JSONObject,eventId:String,out:MutableList<LivePlayerStatus>){
  fun add(o:JSONObject){
   val athlete=o.optJSONObject("athlete")
   val name=athlete?.optString("displayName")?.takeIf{it.isNotBlank()}
       ?:o.optString("displayName").takeIf{it.isNotBlank()}
       ?:o.optString("name").takeIf{it.isNotBlank()}
   val status=EspnInjuryParser.statusLabel(o).ifBlank { o.optString("description","").take(90) }
   if(name!=null && status.isNotBlank()) out+=LivePlayerStatus(name,status,status,eventId)
  }
  val injuries=summary.optJSONArray("injuries")
  if(injuries!=null) for(i in 0 until injuries.length()){
   val team=injuries.optJSONObject(i)?:continue
   val arr=team.optJSONArray("injuries") ?: team.optJSONArray("items")
   if(arr!=null) for(j in 0 until arr.length()) arr.optJSONObject(j)?.let{add(it)}
  }
  val direct=summary.optJSONObject("injuries")
  if(direct!=null){val arr=direct.optJSONArray("items");if(arr!=null)for(i in 0 until arr.length())arr.optJSONObject(i)?.let{add(it)}}
 }
 private fun loadRoster(team:String):Pair<Set<String>,List<LivePlayerStatus>> {
  val names=mutableSetOf<String>(); val statuses=mutableListOf<LivePlayerStatus>()
  return try{
   val j=JSONObject(get("https://site.api.espn.com/apis/site/v2/sports/football/nfl/teams/${teamSlug(team)}/roster"))
   val groups=j.optJSONArray("athletes")
   if(groups!=null) for(i in 0 until groups.length()){
    val group=groups.optJSONObject(i)?:continue
    val items=group.optJSONArray("items")?:continue
    for(k in 0 until items.length()){
     val a=items.optJSONObject(k)?:continue
     val name=a.optString("displayName",a.optString("fullName",a.optString("name","")))
     if(name.isBlank()) continue
     names+=norm(name)
     // The ESPN field can be an object: only extract its readable value.
     val status=EspnRosterParser.statusText(a)
     if(status.isNotBlank()) statuses+=LivePlayerStatus(name,status,"Roster status: $status","roster-$team")
    }
   }
   names to statuses
  }catch(_:Throwable){emptySet<String>() to emptyList()}
 }
 fun loadToday(now:Instant=Instant.now()):LiveTdSnapshot {
  val eastern=ZoneId.of("America/New_York")
  val weekStart=ScheduleWindow.start(now)
  val weekDates=ScheduleWindow.days(now)
  val dateKeys=weekDates.map { it.format(DateTimeFormatter.BASIC_ISO_DATE) }
  val eventsById=linkedMapOf<String,JSONObject>()
  val problems=mutableListOf<String>()
  fun merge(url:String){
   try {
    val json=JSONObject(get(url))
    val arr=json.optJSONArray("events") ?: error("Schedule response omitted events")
    for(i in 0 until arr.length()){
     val event=arr.optJSONObject(i) ?: continue
     val id=event.optString("id")
     val eventDay=runCatching { Instant.parse(event.optString("date")).atZone(eastern).toLocalDate() }.getOrNull()
     if(id.isNotBlank() && eventDay in weekDates) eventsById[id]=event
    }
   } catch(e:Exception){problems+=e.message?.take(90) ?: "ESPN request failed"}
  }
  val start=dateKeys.first()
  val end=dateKeys.last()
  merge("https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard?dates=$start-$end&limit=100")
  // ESPN's multi-day scoreboard can return a partial or empty slate. Day-specific
  // queries recover games without referencing any fixed October 2026 dates.
  if(eventsById.size < 8) {
   listOf(0,2,3,4,5,6).distinct().forEach { offset ->
    val day=dateKeys[offset]
    merge("https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard?dates=$day&limit=100")
   }
  }
  if(eventsById.isEmpty()) merge("https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard?limit=100")
  val backup=if(weekStart==LocalDate.of(2026,10,15)) weekSixBackup() else emptyList()
  if(eventsById.isEmpty()) return LiveTdSnapshot(
   emptyList(),0,SimpleDateFormat("h:mm:ss a",Locale.US).format(Date()),
   error="Schedule feed unavailable; ${if(backup.isEmpty()) "no current backup exists" else "dated Week 6 fallback only"}. ${problems.firstOrNull() ?: ""}",
   schedule=backup
  )
  val tdOut=mutableListOf<LiveTdEvent>()
  val statuses=mutableListOf<LivePlayerStatus>()
  val activeTeams=mutableSetOf<String>()
  var liveCount=0
  val schedule=mutableListOf<LiveScheduleGame>()
  for(event in eventsById.values){
   val eventId=event.optString("id")
   val matchup=event.optString("shortName", event.optString("name", ""))
   val kickoff=event.optString("date", "")
   if(eventId.isBlank() || matchup.isBlank() || kickoff.isBlank())continue
   val competitions=event.optJSONArray("competitions")
   val comp=competitions?.optJSONObject(0)
   val gameState=comp?.optJSONObject("status")?.optJSONObject("type")?.optString("name", "")
    ?.takeIf{it.isNotBlank()} ?: event.optJSONObject("status")?.optJSONObject("type")?.optString("name", "") ?: "UNKNOWN"
   val venue = comp?.optJSONObject("venue")?.optString("fullName", "")?.trim().orEmpty().take(65)
   val weather = (comp?.optJSONObject("weather")?.optString("displayValue", "")
    ?.takeIf { it.isNotBlank() } ?: event.optJSONObject("weather")?.optString("displayValue", "")).orEmpty().trim().take(70)
   schedule+=LiveScheduleGame(eventId,matchup,kickoff,gameState,venue,weather)
   val isLive=gameState.contains("IN_PROGRESS",true) || gameState.contains("IN PROGRESS",true)
   if(isLive){
    liveCount++
    val opponents=comp?.optJSONArray("competitors")
    if(opponents!=null)for(i in 0 until opponents.length()){
     opponents.optJSONObject(i)?.optJSONObject("team")?.optString("abbreviation", "")?.takeIf{it.isNotBlank()}?.let(activeTeams::add)
    }
   }
   val completed=gameState.contains("FINAL",true) || gameState.contains("POST",true)
   if(!isLive && !completed)continue
   val startTime=runCatching{Instant.parse(kickoff)}.getOrNull() ?: continue
   if(startTime.isBefore(now.minusSeconds(40*3600)))continue
   try {
    val summaryUrl="https://site.api.espn.com/apis/site/v2/sports/football/nfl/summary?event=$eventId"
    val summary=JSONObject(if(isLive)fetchCurrent(summaryUrl) else get(summaryUrl))
    collectInjuries(summary,eventId,statuses)
    // Never recursively turn arbitrary JSON status/type objects into player strings.
    val plays=summary.optJSONArray("scoringPlays")
    if(plays!=null)for(j in 0 until plays.length()){
     val play=plays.optJSONObject(j) ?: continue
     val text=play.optString("text", "")
     val kind=play.optJSONObject("type")?.optString("text", "") ?: ""
     val scoring=play.optJSONObject("scoringType")?.optString("name", "") ?: ""
     if(EspnScoringParser.touchdownType("$kind $scoring",text)=="ignore")continue
     tdOut+=LiveTdEvent(play.optString("id", "$eventId-$j"),matchup,
      play.optJSONObject("team")?.optString("abbreviation", "") ?: "",
      text,play.optJSONObject("period")?.optInt("number",0) ?: 0,
      play.optJSONObject("clock")?.optString("displayValue", "") ?: "")
    }
   }catch(e:Exception){problems+="Game summary $eventId: ${e.message?.take(60)}"}
  }
  val rosters=mutableMapOf<String,Set<String>>()
  for(team in activeTeams.take(2)){
   val (names,playerStatuses)=loadRoster(team)
   if(names.isNotEmpty())rosters[team]=names
   statuses+=playerStatuses
  }
  val notAvailable=statuses.filter{unavailable(it.status)}.map{norm(it.name)}.filter{it.isNotBlank()}.toSet()
  return LiveTdSnapshot(tdOut.distinctBy{it.id}.reversed(),liveCount,
   SimpleDateFormat("h:mm:ss a",Locale.US).format(Date()),notAvailable,
   statuses.distinctBy{norm(it.name)+it.status},rosters,
   error=if(problems.isNotEmpty())"Partial feed: ${problems.size} request(s) unavailable; ${problems.first()}" else null,
   schedule=schedule.sortedBy{it.kickoff})
 }
}

/** NFL schedule selection computed at runtime, never fixed to one week. */
object ScheduleWindow {
 private val zone=ZoneId.of("America/New_York")
 fun start(instant:Instant):LocalDate {
  val current=instant.atZone(zone).toLocalDate()
  return if(current.dayOfWeek==DayOfWeek.TUESDAY || current.dayOfWeek==DayOfWeek.WEDNESDAY)
   current.with(TemporalAdjusters.next(DayOfWeek.THURSDAY))
  else current.with(TemporalAdjusters.previousOrSame(DayOfWeek.THURSDAY))
 }
 fun days(instant:Instant):List<LocalDate> = (0L..6L).map { start(instant).plusDays(it) }
}

private fun espnText(url:String):String {
 val conn=(URL(url).openConnection() as HttpURLConnection).apply {
  connectTimeout=5500;readTimeout=9000;requestMethod="GET"
  setRequestProperty("Accept","application/json")
  setRequestProperty("User-Agent","TDChase/1.13.0")
 }
 return try {
  if(conn.responseCode !in 200..299)error("ESPN HTTP ${conn.responseCode}")
  conn.inputStream.bufferedReader().use { it.readText() }
 } finally {conn.disconnect()}
}
