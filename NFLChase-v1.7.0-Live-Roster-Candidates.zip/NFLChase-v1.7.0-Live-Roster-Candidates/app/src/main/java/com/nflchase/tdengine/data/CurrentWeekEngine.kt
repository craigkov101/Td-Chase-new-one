package com.nflchase.tdengine.data

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

// Roster-backed candidate discovery. Estimates are intentionally labeled provisional;
// an NFL roster is not a verified snap-count, red-zone, or injury feed.
data class WeekCandidate(val name:String,val team:String,val position:String,val status:String,val score:Int,val reason:String)
data class WeekProjection(val gameId:String,val candidates:List<WeekCandidate>,val source:String,val error:String?=null)

class CurrentWeekEngine {
 private val cache=mutableMapOf<String,WeekProjection>()
 private fun read(url:String):JSONObject {
  val c=(URL(url).openConnection() as HttpURLConnection).apply {
   connectTimeout=9000;readTimeout=9000;requestMethod="GET"
   setRequestProperty("Accept","application/json")
   setRequestProperty("User-Agent","TDChase/1.7 (Android; NFL roster lookup)")
  }
  return try {
   if(c.responseCode !in 200..299) error("Roster HTTP ${c.responseCode}")
   JSONObject(c.inputStream.bufferedReader().use { it.readText() })
  } finally { c.disconnect() }
 }
 private fun teamRoster(team:String):List<WeekCandidate> {
  val json=read("https://site.api.espn.com/apis/site/v2/sports/football/nfl/teams/${team.lowercase(Locale.US)}/roster")
  val groups=json.optJSONArray("athletes") ?: return emptyList()
  val output=mutableListOf<WeekCandidate>()
  for(i in 0 until groups.length()) {
   val group=groups.optJSONObject(i) ?: continue
   val arr=group.optJSONArray("items") ?: continue
   for(j in 0 until arr.length()) {
    val a=arr.optJSONObject(j) ?: continue
    val name=a.optString("displayName",a.optString("fullName",""))
    val pos=a.optJSONObject("position")?.optString("abbreviation","") ?: ""
    if(name.isBlank() || pos !in setOf("QB","RB","WR","TE")) continue
    val st=a.optJSONObject("status")
    val status=listOf(st?.optString("name","")?:"",st?.optString("type","")?:"",a.optString("status","")).filter{it.isNotBlank()}.joinToString(" ")
    val ineligible=Regex("\\b(OUT|INACTIVE|INJURED RESERVE|IR|PUP|SUSPENDED)\\b",RegexOption.IGNORE_CASE).containsMatchIn(status)
    // Role-neutral position priors are NOT player TD probabilities.
    val prior=when(pos){"RB"->65;"WR"->58;"TE"->49;else->40}
    output+=WeekCandidate(name,team,pos,if(ineligible) "REPORTED UNAVAILABLE" else if(status.isNotBlank())status else "NOT VERIFIED",prior,
     "${pos} positional scoring-opportunity baseline only. Depth-chart role, snaps, goal-line share, opponent splits and final game-day availability need verification.")
   }
  }
  return output
 }
 @Synchronized fun getCached(id:String):WeekProjection?=cache[id]
 fun load(game:LiveScheduleGame,force:Boolean=false):WeekProjection {
  if(!force) synchronized(this){cache[game.id]?.let{return it}}
  val teams=game.matchup.split(" @ "," at ",limit=2)
  if(teams.size!=2)return WeekProjection(game.id,emptyList(),"ESPN team roster", "Unable to identify both teams")
  val found=mutableListOf<WeekCandidate>();val failures=mutableListOf<String>()
  for(team in teams){try{val roster=teamRoster(team);if(roster.isEmpty())failures+="$team: empty roster" else found+=roster}catch(e:Exception){failures+="$team: ${e.message?:"network error"}"}}
  val result=WeekProjection(game.id,found.filter{it.status!="REPORTED UNAVAILABLE"}.sortedWith(compareByDescending<WeekCandidate>{it.score}.thenBy{it.team}.thenBy{it.name}),
   "ESPN team roster • provisional positional ordering",failures.takeIf{it.isNotEmpty()}?.joinToString("; "))
  if(found.isNotEmpty())synchronized(this){cache[game.id]=result}
  return result
 }
}
