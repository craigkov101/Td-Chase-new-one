package com.nflchase.tdengine

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import coil.compose.AsyncImage
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import java.util.Locale
import com.nflchase.tdengine.data.*
import com.nflchase.tdengine.model.*

private val Bg=Color(0xFF06111D); private val Card=Color(0xFF0C1927); private val Card2=Color(0xFF101F2F); private val Line=Color(0xFF1C3348); private val Blue=Color(0xFF45C8FF); private val Green=Color(0xFF52F35A); private val Muted=Color(0xFF91A0B2); private val Gold=Color(0xFFFFB84D)
class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{MaterialTheme(colorScheme=darkColorScheme(background=Bg,surface=Card,primary=Blue)){App()}}}}
enum class Tab(val title:String){GAMES("Games"),PICKS("Picks"),SCRIPTS("Scripts"),PARLAYS("Parlays"),MORE("More")}
@Composable fun App(){
 var tab by remember{mutableStateOf(Tab.GAMES)}
 var selected by remember{mutableStateOf<LiveScheduleGame?>(null)}
 val learn=remember{LearningEngine()}
 val client=remember{LiveTdClient()}
 val weekEngine=remember{CurrentWeekEngine()}
 val tendencyEngine=remember{ScoringTendencies()}
 var trends by remember{mutableStateOf<Map<String,TeamScoringTrend>>(emptyMap())}
 var trendsLoading by remember{mutableStateOf<Set<String>>(emptySet())}
 var projections by remember{mutableStateOf<Map<String,WeekProjection>>(emptyMap())}
 var projectionLoading by remember{mutableStateOf<Set<String>>(emptySet())}
 var live by remember{mutableStateOf(LiveTdSnapshot(emptyList(),0,"—"))}
 var loading by remember{mutableStateOf(false)}
 var lastError by remember{mutableStateOf<String?>(null)}
 val scope=rememberCoroutineScope()
 fun requestProjection(game:LiveScheduleGame,force:Boolean=false){
  if(game.id in projectionLoading)return
  projectionLoading=projectionLoading+game.id
  scope.launch {try {val result=withContext(Dispatchers.IO){weekEngine.load(game,force)};projections=projections+(game.id to result)}
   catch(e:Exception){projections=projections+(game.id to WeekProjection(game.id,emptyList(),"ESPN recent box scores",e.message ?: "Request failed"))}
   finally {projectionLoading=projectionLoading-game.id}}
 }
 fun openGame(game:LiveScheduleGame){
  selected=game;requestProjection(game)
  teamsOf(game).filter{it !in trends && it !in trendsLoading}.forEach { code ->
   trendsLoading=trendsLoading+code
   scope.launch {try {
    val result=withContext(Dispatchers.IO){tendencyEngine.load(code)}
    trends=trends+(code to result)
   }catch(e:Exception){trends=trends+(code to TeamScoringTrend(code,0,0,0,0,0,"Scoring request failed",e.message))}
   finally{trendsLoading=trendsLoading-code}}
  }
 }
 fun refreshTrends(game:LiveScheduleGame){
  teamsOf(game).filter{it !in trendsLoading}.forEach {code->
   trendsLoading=trendsLoading+code
   scope.launch{try{
    val result=withContext(Dispatchers.IO){tendencyEngine.load(code,true)}
    trends=trends+(code to result)
   }catch(e:Exception){trends=trends+(code to TeamScoringTrend(code,0,0,0,0,0,"Scoring refresh failed",e.message))}
   finally{trendsLoading=trendsLoading-code}}
  }
 }
 fun refresh(){if(loading)return;loading=true;scope.launch{try{
  val update=withContext(Dispatchers.IO){client.loadToday()}
  if(update.schedule.isNotEmpty() || live.schedule.isEmpty())live=update
  lastError=update.error
 }catch(e:Exception){lastError=e.message?:"Network unavailable"}finally{loading=false}}}
 LaunchedEffect(Unit){refresh();while(isActive){delay(60000);refresh()}}
 val todayEast=java.time.LocalDate.now(java.time.ZoneId.of("America/New_York"))
 val startOfSlate=if(todayEast.dayOfWeek in listOf(java.time.DayOfWeek.TUESDAY,java.time.DayOfWeek.WEDNESDAY))
  todayEast.with(java.time.temporal.TemporalAdjusters.next(java.time.DayOfWeek.THURSDAY))
 else todayEast.with(java.time.temporal.TemporalAdjusters.previousOrSame(java.time.DayOfWeek.THURSDAY))
 val slate=live.schedule.filter { g -> runCatching {
  val d=java.time.Instant.parse(g.kickoff).atZone(java.time.ZoneId.of("America/New_York")).toLocalDate()
  !d.isBefore(startOfSlate) && !d.isAfter(startOfSlate.plusDays(4))
 }.getOrDefault(false) }.distinctBy{it.matchup}.sortedBy{it.kickoff}
 Scaffold(containerColor=Bg,bottomBar={NavigationBar(containerColor=Color(0xFF071522)){
  Tab.entries.forEach{t->NavigationBarItem(selected=tab==t,onClick={tab=t;selected=null},icon={Icon(when(t){Tab.GAMES->Icons.Default.SportsFootball;Tab.PICKS->Icons.Default.Star;Tab.SCRIPTS->Icons.Default.QueryStats;Tab.PARLAYS->Icons.Default.Casino;Tab.MORE->Icons.Default.MoreHoriz},null)},label={Text(t.title)},colors=NavigationBarItemDefaults.colors(selectedIconColor=Blue,indicatorColor=Blue.copy(.14f),selectedTextColor=Color.White,unselectedIconColor=Muted,unselectedTextColor=Muted))}
 }}){pad->Column(Modifier.padding(pad).fillMaxSize()){Header();Crossfade(targetState=Pair(tab,selected),animationSpec=tween(180),label="tab transition"){state->val(currentTab,currentGame)=state;when{
  currentGame!=null->CurrentGameDetail(currentGame,projections[currentGame.id],currentGame.id in projectionLoading,{requestProjection(currentGame,true)},{selected=null},trends,trendsLoading,{refreshTrends(currentGame)})
  currentTab==Tab.GAMES->CurrentGamesHome(slate,live,loading,lastError,{refresh()}){openGame(it)}
  currentTab==Tab.PICKS->CurrentPicks(slate,projections){openGame(it)}
  currentTab==Tab.SCRIPTS->CurrentScripts(slate,projections,trends){openGame(it)}
  currentTab==Tab.PARLAYS->CurrentParlays(slate)
  else->More(learn)
 }}}}
}
@Composable fun Header(){Row(Modifier.fillMaxWidth().padding(22.dp,18.dp),verticalAlignment=Alignment.CenterVertically){Surface(shape=CircleShape,color=Blue.copy(.08f),border=BorderStroke(1.dp,Blue.copy(.45f))){Icon(Icons.Default.SportsFootball,null,tint=Blue,modifier=Modifier.padding(12.dp).size(25.dp))};Spacer(Modifier.width(14.dp));Column(Modifier.weight(1f)){Row(verticalAlignment=Alignment.CenterVertically){Text("TD",fontSize=29.sp,fontWeight=FontWeight.Black,color=Blue);Text(" CHASE",fontSize=29.sp,fontWeight=FontWeight.Black)};Text("TOUCHDOWN INTELLIGENCE · Cxaig",color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold)};Surface(shape=RoundedCornerShape(18.dp),color=Color(0xFF161A39),border=BorderStroke(1.dp,Color(0xFF343B78))){Text("SIM ENGINE",color=Color(0xFF9E91FF),fontSize=10.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(10.dp,7.dp))}};HorizontalDivider(color=Line)}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun GamesHome(games:List<GameCard>,sim:SimulationEngine,open:(GameCard)->Unit){
    var remaining by remember{mutableStateOf(true)}
    var top5 by remember{mutableStateOf(true)}
    var best by remember{mutableStateOf(false)}
    var live by remember{mutableStateOf(LiveTdSnapshot(emptyList(),0,"—"))}
    var refreshing by remember{mutableStateOf(false)}
    var lastRefreshError by remember{mutableStateOf<String?>(null)}
    
    val client=remember{LiveTdClient()};val scope=rememberCoroutineScope()
    fun forceRefresh(){if(refreshing)return;refreshing=true;scope.launch{try { val updated=withContext(Dispatchers.IO){client.loadToday()}; if(updated.schedule.isNotEmpty()){live=updated;lastRefreshError=updated.error}else{lastRefreshError=updated.error}; } finally { refreshing=false }}}
    LaunchedEffect(Unit){forceRefresh();while(isActive){delay(60000);forceRefresh()}}
    fun isLiveOut(p:TdCandidate)=live.unavailablePlayers.contains(p.name.lowercase(Locale.US).replace(Regex("[^a-z0-9 ]"),"").replace(Regex("\\s+")," ").trim())
    val liveGames=remember(games,live.unavailablePlayers){games.map{g->g.copy(candidates=g.candidates.map{p->if(isLiveOut(p))p.copy(status="OUT") else p})}}
    val sims=remember(liveGames){liveGames.associate{it.id to sim.simulate(it)}}
    val targetDates=listOf(java.time.LocalDate.of(2026,10,15),java.time.LocalDate.of(2026,10,18))
    val todays=live.schedule.filter { g -> runCatching { java.time.Instant.parse(g.kickoff).atZone(java.time.ZoneId.of("America/New_York")).toLocalDate() in targetDates }.getOrDefault(false) }.sortedBy{it.kickoff}
    val gameDates=targetDates
    var chosenDate by remember { mutableStateOf<java.time.LocalDate?>(null) }
    LaunchedEffect(gameDates) {
        if(gameDates.isNotEmpty() && chosenDate !in gameDates) {
            val today=java.time.LocalDate.now(java.time.ZoneId.of("America/New_York"))
            chosenDate=gameDates.firstOrNull { !it.isBefore(today) } ?: gameDates.last()
        }
    }
    val dateIndex=gameDates.indexOf(chosenDate).coerceAtLeast(0)
    val visibleGames=todays.filter { game -> runCatching { java.time.Instant.parse(game.kickoff).atZone(java.time.ZoneId.of("America/New_York")).toLocalDate()==chosenDate }.getOrDefault(false) }
    
    
    
    val shown=remember(remaining,best,liveGames,sims){
        val base=if(remaining) liveGames.filter{!it.kickoff.contains("FINAL",true)} else liveGames
        if(best) base.sortedByDescending{g->g.candidates.filter{it.status.uppercase() !in setOf("OUT","INACTIVE","IR","PUP","SUSPENDED")}.maxOfOrNull{p->sims[g.id]?.results?.get(p.id)?.tdRate?:0}?:0} else base
    }
    PullToRefreshBox(isRefreshing=refreshing,onRefresh={forceRefresh()},modifier=Modifier.fillMaxSize()){
     LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(bottom=24.dp)){
      item{Column(Modifier.padding(22.dp,16.dp,22.dp,8.dp)){
        Text(java.text.SimpleDateFormat("EEE, MMM d",Locale.US).format(java.util.Date()),fontSize=26.sp,fontWeight=FontWeight.Black)
        Text("THIS WEEK • ${todays.size} SCHEDULED GAMES",color=Blue,fontWeight=FontWeight.Bold,fontSize=12.sp,modifier=Modifier.padding(top=5.dp))
        Text("Swipe down to refresh official NFL feed • ${live.updatedAt}",color=if(live.error==null)Green else Gold,fontSize=10.sp,modifier=Modifier.padding(top=5.dp))
        Spacer(Modifier.height(20.dp));Text("QUICK FILTERS",color=Muted,fontWeight=FontWeight.Black,fontSize=12.sp)
        Row(Modifier.padding(top=10.dp)){
          FilterChip(selected=remaining,onClick={remaining=!remaining},label={Text("Remaining")});Spacer(Modifier.width(7.dp))
          FilterChip(selected=top5,onClick={top5=!top5},label={Text(if(top5) "Top 5" else "All Picks")});Spacer(Modifier.width(7.dp))
          FilterChip(selected=best,onClick={best=!best},label={Text("Best Matchup")})
        }
        Text("${todays.size} current matchups • live schedule",color=Blue,fontSize=11.sp,modifier=Modifier.padding(top=8.dp))
        if(live.unavailablePlayers.isNotEmpty())Text("Reported injury status available; verify game-day inactives",color=Gold,fontWeight=FontWeight.Bold,fontSize=11.sp,modifier=Modifier.padding(top=7.dp))
        Spacer(Modifier.height(22.dp));Text("THIS WEEK’S NFL MATCHUPS",color=Blue,fontWeight=FontWeight.Black,fontSize=12.sp)
        Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth().padding(top=6.dp)) {
            IconButton(onClick={if(dateIndex>0) chosenDate=gameDates[dateIndex-1]},enabled=dateIndex>0) { Icon(Icons.Default.ChevronLeft,"Previous game date",tint=if(dateIndex>0)Blue else Muted) }
            Column(Modifier.weight(1f),horizontalAlignment=Alignment.CenterHorizontally) {
                Text(chosenDate?.format(java.time.format.DateTimeFormatter.ofPattern("EEE, MMM d",Locale.US)) ?: "Loading games",fontSize=24.sp,fontWeight=FontWeight.Black)
                Text("${visibleGames.size} games • ${if(gameDates.isEmpty()) 0 else dateIndex+1} of ${gameDates.size} dates",color=Blue,fontSize=11.sp)
            }
            IconButton(onClick={if(dateIndex<gameDates.lastIndex) chosenDate=gameDates[dateIndex+1]},enabled=dateIndex<gameDates.lastIndex) { Icon(Icons.Default.ChevronRight,"Next game date",tint=if(dateIndex<gameDates.lastIndex)Blue else Muted) }
        }
        Text("Thursday and Sunday only. Fixtures can be shown from a dated backup when live ESPN data fails; historical TD projections are not verified.",color=Muted,fontSize=13.sp,modifier=Modifier.padding(top=4.dp))
      }}
      if(lastRefreshError!=null) item { Text("Refresh failed: ${lastRefreshError}. Showing last available schedule when possible.",color=Gold,modifier=Modifier.padding(20.dp)) }
      if(live.error==null && todays.isEmpty()) item { Text("Schedule unavailable. Pull down to retry.",color=Muted,modifier=Modifier.padding(20.dp)) }
      items(visibleGames,key={it.id}){game->Surface(color=Card,shape=RoundedCornerShape(20.dp),border=BorderStroke(1.dp,Line),modifier=Modifier.fillMaxWidth().padding(horizontal=20.dp,vertical=7.dp)){Column(Modifier.padding(18.dp)){val parts=game.matchup.split(" @ "," at ",limit=2);Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)){if(parts.size==2) TeamLogo(parts[0]);Column(Modifier.weight(1f)){Text(game.matchup,fontSize=20.sp,fontWeight=FontWeight.Black);Text("Kickoff: "+runCatching{java.time.Instant.parse(game.kickoff).atZone(java.time.ZoneId.systemDefault()).format(java.time.format.DateTimeFormatter.ofPattern("h:mm a z",Locale.US))}.getOrDefault(game.kickoff),color=Blue)};if(parts.size==2) TeamLogo(parts[1])};Text(game.state.replace("STATUS_","").replace("_"," ")+" • "+(if(game.id.startsWith("week6-")) "Week 6 schedule backup" else "ESPN schedule"),color=Muted,fontSize=12.sp,modifier=Modifier.padding(top=8.dp))}}}
      item{Column(Modifier.padding(22.dp,28.dp,22.dp,10.dp)){
        Text("THIS WEEK'S TOUCHDOWNS",color=Blue,fontWeight=FontWeight.Black,fontSize=12.sp)
        Text("Touchdown tracker",fontSize=29.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=8.dp))
        Text("Same refresh updates scoring plays and live player availability.",color=Muted,fontSize=13.sp,modifier=Modifier.padding(top=4.dp))
      }}
      item{TouchdownFeed(snapshot=live,loading=refreshing,onRefresh={forceRefresh()})}
     }
    }
}
private val nflTeamIds=mapOf("ARI" to "22","ATL" to "1","BAL" to "33","BUF" to "2","CAR" to "29","CHI" to "3","CIN" to "4","CLE" to "5","DAL" to "6","DEN" to "7","DET" to "8","GB" to "9","HOU" to "34","IND" to "11","JAX" to "30","JAC" to "30","KC" to "12","LV" to "13","LAC" to "24","LAR" to "14","LA" to "14","MIA" to "15","MIN" to "16","NE" to "17","NO" to "18","NYG" to "19","NYJ" to "20","PHI" to "21","PIT" to "23","SF" to "25","SEA" to "26","TB" to "27","TEN" to "10","WAS" to "28")
@Composable fun TeamLogo(abbreviation:String){
 val id=nflTeamIds[abbreviation.uppercase(Locale.US)]
 if(id!=null) AsyncImage(model="https://a.espncdn.com/i/teamlogos/nfl/500/${abbreviation.lowercase(Locale.US).let { if(it=="jac") "jax" else if(it=="la") "lar" else it }}.png",contentDescription="$abbreviation logo",modifier=Modifier.size(43.dp))
 else Surface(shape=CircleShape,color=Line){Text(abbreviation,modifier=Modifier.padding(8.dp),color=Blue,fontWeight=FontWeight.Black)}
}
@Composable fun GameTileSim(g:GameCard,s:GameSimulation,limit:Int,open:(GameCard)->Unit){
    val ranked=g.candidates.filter{it.status.uppercase() !in setOf("OUT","INACTIVE","IR","PUP","SUSPENDED")}.sortedByDescending{s.results[it.id]?.tdRate?:0}.take(limit)
    Surface(onClick={open(g)},color=Card,shape=RoundedCornerShape(24.dp),border=BorderStroke(1.dp,Line),modifier=Modifier.padding(horizontal=20.dp,vertical=7.dp)){
      Column(Modifier.padding(18.dp)){
        Row{Column(Modifier.weight(1f)){Text("${g.away}  @  ${g.home}",fontSize=21.sp,fontWeight=FontWeight.Black);Text(g.kickoff,color=Muted,fontSize=12.sp)}
          Surface(color=Blue.copy(.10f),shape=RoundedCornerShape(12.dp)){Text("${s.simulations/1000}K SIMS",color=Blue,fontWeight=FontWeight.Bold,fontSize=11.sp,modifier=Modifier.padding(8.dp,5.dp))}}
        Text("Sim avg ${"%.1f".format(s.avgTotalTds)} TDs • ${g.away} ${s.awayWinPct}% / ${g.home} ${s.homeWinPct}%",color=Muted,fontSize=12.sp,modifier=Modifier.padding(vertical=10.dp))
        HorizontalDivider(color=Line)
        ranked.forEachIndexed{i,p->val r=s.results[p.id]!!;Row(Modifier.padding(top=10.dp),verticalAlignment=Alignment.CenterVertically){
          Text("#${i+1}",color=if(i==0)Gold else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(30.dp))
          Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.Bold);Text("${p.position} • ${p.team} • ${shortReason(p)}",color=Muted,fontSize=11.sp)}
          Column(horizontalAlignment=Alignment.End){Text("${r.tdRate}%",color=if(i==0)Green else Blue,fontWeight=FontWeight.Black,fontSize=20.sp);Text("SIM TD",color=Muted,fontSize=9.sp)}
        }}
        Text("VIEW SIM + MATCHUP  ›",color=Blue,fontWeight=FontWeight.Black,fontSize=11.sp,modifier=Modifier.padding(top=14.dp))
      }
    }
}
@Composable fun SimBoard(games:List<GameCard>,sim:SimulationEngine){
    val rows=remember(games){games.flatMap{g->val s=sim.simulate(g);g.candidates.filter{it.status.uppercase() !in setOf("OUT","INACTIVE","IR","PUP","SUSPENDED")}.map{p->Triple(p,s.results[p.id]!!,g)}}.sortedByDescending{it.second.tdRate}}
    Title("Simulation TD Board","DEMO MODEL DATA — historical player pool; not verified for current games. Do not use as live picks.")
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
      itemsIndexed(rows){i,row->val p=row.first;val r=row.second;Surface(color=Card,shape=RoundedCornerShape(18.dp),border=BorderStroke(1.dp,Line)){
        Row(Modifier.fillMaxWidth().padding(15.dp),verticalAlignment=Alignment.CenterVertically){Text("#${i+1}",color=Gold,fontWeight=FontWeight.Black);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.Black,fontSize=18.sp);Text("${p.team} • ${p.position} vs ${p.opponent}",color=Muted,fontSize=12.sp);Text(shortReason(p),color=Blue,fontSize=11.sp)};Column(horizontalAlignment=Alignment.End){Text("${r.tdRate}%",color=Green,fontSize=25.sp,fontWeight=FontWeight.Black);Text("${r.multiTdRate}% 2+ TD",color=Muted,fontSize=10.sp)}}}}
    }
}
@Composable fun TouchdownFeed(snapshot:LiveTdSnapshot,loading:Boolean,onRefresh:()->Unit){
 Surface(color=Card,shape=RoundedCornerShape(24.dp),border=BorderStroke(1.dp,Line),modifier=Modifier.padding(horizontal=20.dp).fillMaxWidth()){Column(Modifier.padding(18.dp)){
  Row(verticalAlignment=Alignment.CenterVertically){Surface(shape=CircleShape,color=Blue.copy(.12f)){Icon(Icons.Default.SportsFootball,null,tint=Blue,modifier=Modifier.padding(10.dp))};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text("TODAY • LIVE FEED",color=Blue,fontWeight=FontWeight.Black,fontSize=12.sp);Text(if(snapshot.liveGames>0)"${snapshot.liveGames} LIVE" else "NFL touchdown tracker",fontSize=19.sp,fontWeight=FontWeight.Black)};Text("${snapshot.events.size} TD",color=if(snapshot.events.isNotEmpty())Green else Muted,fontWeight=FontWeight.Bold)}
  Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.padding(top=10.dp)){if(loading)CircularProgressIndicator(modifier=Modifier.size(14.dp),strokeWidth=2.dp,color=Blue);Text("  Auto 60 sec • swipe to force • ${snapshot.updatedAt}",color=Muted,fontSize=10.sp);Spacer(Modifier.weight(1f));TextButton(onClick=onRefresh,enabled=!loading){Text("REFRESH",fontSize=10.sp)}}
  HorizontalDivider(color=Line,modifier=Modifier.padding(vertical=14.dp))
  snapshot.error?.let{Text("Live feed temporarily unavailable",color=Gold,fontWeight=FontWeight.Bold);Text(it,color=Muted,fontSize=11.sp)}
  if(snapshot.error==null&&snapshot.events.isEmpty())Text("No touchdowns found in the current NFL week.",color=Muted,fontWeight=FontWeight.Bold)
  snapshot.events.take(40).forEachIndexed{i,td->if(i>0)HorizontalDivider(color=Line.copy(.55f),modifier=Modifier.padding(vertical=10.dp));Row{Surface(color=Blue.copy(.10f),shape=RoundedCornerShape(10.dp)){Text(td.team.ifBlank{"TD"},color=Blue,fontWeight=FontWeight.Black,modifier=Modifier.padding(8.dp,5.dp))};Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(td.text,fontWeight=FontWeight.Bold,fontSize=14.sp);Text("${td.game} • Q${td.quarter} ${td.clock}",color=Muted,fontSize=11.sp,modifier=Modifier.padding(top=3.dp))}}}
 }}}
@Composable fun GameTile(g:GameCard,open:(GameCard)->Unit){val top=g.candidates.sortedByDescending{it.score}.take(5);Surface(onClick={open(g)},color=Card,shape=RoundedCornerShape(24.dp),border=BorderStroke(1.dp,Line),modifier=Modifier.padding(horizontal=20.dp,vertical=7.dp)){Column(Modifier.padding(18.dp)){Row{Column(Modifier.weight(1f)){Text("${g.away}  @  ${g.home}",fontSize=21.sp,fontWeight=FontWeight.Black);Text(g.kickoff,color=Muted,fontSize=12.sp)};Surface(color=Blue.copy(.10f),shape=RoundedCornerShape(12.dp)){Text("ENV ${g.environment}",color=Blue,fontWeight=FontWeight.Bold,fontSize=11.sp,modifier=Modifier.padding(8.dp,5.dp))}};Text(smartSummary(g),color=Muted,fontSize=12.sp,modifier=Modifier.padding(vertical=10.dp));HorizontalDivider(color=Line);top.forEachIndexed{i,p->Row(Modifier.padding(top=10.dp),verticalAlignment=Alignment.CenterVertically){Text("#${i+1}",color=if(i==0)Gold else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(30.dp));Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.Bold);Text("${p.position} • ${p.team}  •  ${shortReason(p)}",color=Muted,fontSize=11.sp)};Text("${p.score}",color=if(i==0)Green else Blue,fontWeight=FontWeight.Black,fontSize=20.sp)}};Text("VIEW FULL MATCHUP  ›",color=Blue,fontWeight=FontWeight.Black,fontSize=11.sp,modifier=Modifier.padding(top=14.dp))}}}
fun smartSummary(g:GameCard):String{val p=g.candidates.maxByOrNull{it.score}?:return g.script;val e=p.exploit?:return g.script;val lane=when(p.position){"RB","QB"->"rushing/front-seven";"WR"->"secondary";"TE"->"red-zone coverage";else->"overall"};return "${p.team} has the strongest $lane TD edge. ${p.name} leads the model; opponent grades: front ${e.frontSeven}, secondary ${e.secondary}, red zone ${e.redZoneDefense}."}
fun shortReason(p:TdCandidate):String{val e=p.exploit;return when(p.position){"RB","QB"->if((e?.frontSeven?:0)>=75)"front-7 edge + usage" else "goal-line/usage edge";"WR"->if((e?.secondary?:0)>=75)"secondary edge + targets" else "targets + red-zone role";"TE"->if((e?.redZoneDefense?:0)>=75)"red-zone coverage edge" else "TE scoring role";else->"model edge"}}
@Composable fun Board(c:List<TdCandidate>){Title("Best TD picks","League-wide ranking driven by usage, red zone and matchup.");LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){itemsIndexed(c){i,p->CandidateRow(i+1,p)}}}
@Composable fun Title(a:String,b:String){Column(Modifier.padding(20.dp,14.dp)){Text(a,fontSize=28.sp,fontWeight=FontWeight.Black);Text(b,color=Muted,fontSize=13.sp)}}
@Composable fun CandidateRow(rank:Int,p:TdCandidate){Surface(color=Card,shape=RoundedCornerShape(18.dp),border=BorderStroke(1.dp,Line)){Row(Modifier.fillMaxWidth().padding(15.dp),verticalAlignment=Alignment.CenterVertically){Text("#$rank",color=Gold,fontWeight=FontWeight.Black);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.Black,fontSize=18.sp);Text("${p.team} • ${p.position} vs ${p.opponent}",color=Muted,fontSize=12.sp);Text(shortReason(p),color=Blue,fontSize=11.sp,modifier=Modifier.padding(top=4.dp))};Column(horizontalAlignment=Alignment.End){Text("${p.score}",color=Green,fontSize=25.sp,fontWeight=FontWeight.Black);Text("${p.probability}% TD",color=Muted,fontSize=11.sp)}}}}
@Composable fun GameDetail(g:GameCard,onBack:()->Unit,learn:LearningEngine){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{TextButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null);Text("All games")};Text("${g.away} @ ${g.home}",fontSize=30.sp,fontWeight=FontWeight.Black);Text(smartSummary(g),color=Muted,modifier=Modifier.padding(top=5.dp));Row(Modifier.padding(top=12.dp)){Metric("Environment",g.environment.toString());Spacer(Modifier.width(8.dp));Metric("TD looks",g.candidates.size.toString())};Button(onClick={learn.freeze(g)},modifier=Modifier.padding(top=12.dp)){Text("FREEZE PREGAME SNAPSHOT")}};itemsIndexed(g.candidates.filter{it.status.uppercase() !in setOf("OUT","INACTIVE","IR","PUP","SUSPENDED")}.sortedByDescending{it.score}){i,p->Surface(color=Card,shape=RoundedCornerShape(22.dp),border=BorderStroke(1.dp,if(i==0)Blue else Line)){Column(Modifier.padding(18.dp)){Row{Column(Modifier.weight(1f)){Text("#${i+1}  ${p.name}",fontSize=21.sp,fontWeight=FontWeight.Black);Text("${p.position} • ${p.team}",color=Muted)};Text("${p.score}",color=Green,fontSize=30.sp,fontWeight=FontWeight.Black)};Text("MODEL TD ${p.probability}%",color=Gold,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));Factor("Red zone",p.factors.redZone);Factor("Opportunity",p.factors.opportunity);Factor("Matchup",p.effectiveMatchup);Factor("Scheme",p.factors.scheme);Factor("Environment",p.factors.environment);Spacer(Modifier.height(10.dp));p.exploit?.let{ExploitPanel(p.position,it)};MatchupReasons(p);Text(p.reason,modifier=Modifier.padding(top=9.dp))}}}}}
@Composable fun MatchupReasons(p:TdCandidate){val e=p.exploit?:return;val r=buildList{when(p.position){"RB","QB"->{if(e.frontSeven>=75)add("Attackable front seven");if(e.redZoneDefense>=75)add("Favorable goal-line defense")};"WR"->{if(e.secondary>=75)add("Attackable secondary");if(e.redZoneDefense>=75)add("Favorable red-zone coverage")};"TE"->{if(e.secondary>=72)add("Coverage weakness helps TE routes");if(e.redZoneDefense>=75)add("Favorable red-zone matchup")}};if(e.personnelImpact>=70)add("Defensive personnel/injury edge");if(p.goalLineShare>=65)add("Strong goal-line share (${p.goalLineShare}%)");if(p.factors.opportunity>=90)add("Elite projected usage");if(p.factors.redZone>=90)add("Elite scoring-area role")}.take(5);if(r.isNotEmpty()){Text("WHY THIS PICK",color=Blue,fontWeight=FontWeight.Black,fontSize=12.sp,modifier=Modifier.padding(top=12.dp));r.forEach{Text("• $it",fontSize=12.sp,modifier=Modifier.padding(top=3.dp))}}}
@Composable fun ExploitPanel(position:String,e:DefensiveExploit){val edge=when(position){"RB","QB"->((e.frontSeven*.55)+(e.redZoneDefense*.30)+(e.personnelImpact*.15)).toInt();"WR"->((e.secondary*.60)+(e.redZoneDefense*.25)+(e.personnelImpact*.15)).toInt();"TE"->((e.secondary*.35)+(e.redZoneDefense*.45)+(e.personnelImpact*.20)).toInt();else->e.score};Surface(color=Card2,shape=RoundedCornerShape(14.dp),border=BorderStroke(1.dp,Line)){Column(Modifier.fillMaxWidth().padding(12.dp)){Row{Text("DEFENSIVE EXPLOIT",color=Gold,fontWeight=FontWeight.Black);Spacer(Modifier.weight(1f));Text("$edge/100",color=Green,fontWeight=FontWeight.Black)};Text("Front 7 ${e.frontSeven} • Secondary ${e.secondary} • Red zone ${e.redZoneDefense} • Personnel ${e.personnelImpact}",color=Muted,fontSize=11.sp,modifier=Modifier.padding(top=5.dp));Text(e.note,fontSize=12.sp,modifier=Modifier.padding(top=6.dp))}}}
@Composable fun Factor(n:String,v:Double){Row(Modifier.padding(vertical=2.dp)){Text(n,color=Muted,modifier=Modifier.width(100.dp));LinearProgressIndicator(progress={v.toFloat()/100},modifier=Modifier.weight(1f).height(7.dp),color=Blue,trackColor=Line);Text(" ${v.toInt()}",fontWeight=FontWeight.Bold)}}
@Composable fun Metric(n:String,v:String){Surface(color=Card,shape=RoundedCornerShape(15.dp),border=BorderStroke(1.dp,Line)){Column(Modifier.padding(15.dp)){Text(v,fontSize=22.sp,fontWeight=FontWeight.Black,color=Blue);Text(n,color=Muted,fontSize=11.sp)}}}
@Composable fun Scripts(g:List<GameCard>){Title("Game scripts","DEMO SCRIPTS — historical fixtures, not current-week verified projections.");LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){items(g){x->Surface(color=Card,shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(17.dp)){Text("${x.away} @ ${x.home}",fontWeight=FontWeight.Black,fontSize=19.sp);Text(smartSummary(x),color=Muted,modifier=Modifier.padding(top=6.dp));Text("Environment ${x.environment}/100",color=Blue,modifier=Modifier.padding(top=8.dp))}}}}}
@Composable fun Builder(c:List<TdCandidate>){var legs by remember{mutableStateOf(3)};Title("TD Parlays","DEMO PICKS ONLY — not validated against current rosters, games or inactives.");Column(Modifier.padding(16.dp)){Row{(1..5).forEach{n->FilterChip(selected=legs==n,onClick={legs=n},label={Text("$n")});Spacer(Modifier.width(5.dp))}};Spacer(Modifier.height(14.dp));c.take(legs).forEachIndexed{i,p->CandidateRow(i+1,p)};Text("Avoid blindly stacking players competing for the same scoring share.",color=Muted,modifier=Modifier.padding(top=12.dp))}}
@Composable fun More(l:LearningEngine){Title("More","Model learning, snapshots and calibration.");Column(Modifier.padding(16.dp)){Surface(color=Card,shape=RoundedCornerShape(22.dp),border=BorderStroke(1.dp,Line)){Column(Modifier.padding(20.dp)){Text("MODEL LAB",color=Blue,fontWeight=FontWeight.Bold);Row(Modifier.padding(top=12.dp)){Metric("Snapshots",l.samples().toString());Spacer(Modifier.width(8.dp));Metric("Graded",l.graded().toString())};Text("Red Zone 26% • Opportunity 20% • Matchup 20% • Scheme 12% • Environment 11% • Role/Injury 6% • Explosive 5%",color=Muted,modifier=Modifier.padding(top=16.dp))}}}}

private fun kickoffLabel(game:LiveScheduleGame):String=runCatching{
 java.time.Instant.parse(game.kickoff).atZone(java.time.ZoneId.of("America/New_York"))
 .format(java.time.format.DateTimeFormatter.ofPattern("EEE, MMM d • h:mm a z",Locale.US))
}.getOrDefault(game.kickoff)
private fun teamsOf(game:LiveScheduleGame):List<String> = game.matchup.split(" @ "," at ",limit=2)
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun CurrentGamesHome(slate:List<LiveScheduleGame>,live:LiveTdSnapshot,loading:Boolean,lastError:String?,refresh:()->Unit,open:(LiveScheduleGame)->Unit){
 val days=slate.mapNotNull { runCatching { java.time.Instant.parse(it.kickoff).atZone(java.time.ZoneId.of("America/New_York")).toLocalDate() }.getOrNull() }.distinct().sorted()
 var day by remember{mutableIntStateOf(0)}
 PullToRefreshBox(isRefreshing=loading,onRefresh=refresh,modifier=Modifier.fillMaxSize()){
  LazyColumn(contentPadding=PaddingValues(bottom=24.dp)){
   item{Column(Modifier.padding(20.dp)){
    Text("THIS WEEK • NFL MATCHUPS",fontSize=24.sp,fontWeight=FontWeight.Black)
    Text("Current NFL schedule • ${slate.size} games",color=Blue)
    val index=day.coerceIn(0,(days.size-1).coerceAtLeast(0))
    Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()){
     IconButton(onClick={day=(index-1).coerceAtLeast(0)},enabled=index>0){Icon(Icons.Default.ChevronLeft,"Previous game day")}
     Text(days.getOrNull(index)?.format(java.time.format.DateTimeFormatter.ofPattern("EEEE, MMM d",Locale.US)) ?: "Loading current schedule...",modifier=Modifier.weight(1f),fontSize=19.sp,fontWeight=FontWeight.Bold)
     IconButton(onClick={day=(index+1).coerceAtMost((days.size-1).coerceAtLeast(0))},enabled=index<days.size-1){Icon(Icons.Default.ChevronRight,"Next game day")}
    }
    Text(if(lastError!=null)"Schedule source: backup or cached • $lastError" else "Schedule source: ESPN / dated backup",color=Muted,fontSize=11.sp)
    Text("Tap any matchup for its game script and TD projection status.",color=Muted,fontSize=12.sp)
   }}
   val selectedDay=days.getOrNull(day.coerceIn(0,(days.size-1).coerceAtLeast(0)))
   val selectedGames=slate.filter{runCatching{java.time.Instant.parse(it.kickoff).atZone(java.time.ZoneId.of("America/New_York")).toLocalDate()==selectedDay}.getOrDefault(false)}
   if(selectedGames.isEmpty())item{Text("No schedule returned for this date. Pull down to retry.",color=Gold,modifier=Modifier.padding(20.dp))}
   items(selectedGames,key={it.id}){game->CurrentMatchupCard(game){open(game)}}
   item{Column(Modifier.padding(20.dp)){Text("LIVE TOUCHDOWN FEED",color=Blue,fontWeight=FontWeight.Black);TouchdownFeed(snapshot=live,loading=loading,onRefresh=refresh)}}
  }
 }
}
@Composable fun CurrentMatchupCard(game:LiveScheduleGame,open:()->Unit){
 Surface(onClick=open,color=Card,shape=RoundedCornerShape(18.dp),border=BorderStroke(1.dp,Line),modifier=Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=7.dp)){
  Column(Modifier.padding(17.dp)){
   val teams=teamsOf(game)
   Row(verticalAlignment=Alignment.CenterVertically){if(teams.size==2)TeamLogo(teams[0]);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(game.matchup,fontWeight=FontWeight.Black,fontSize=20.sp);Text(kickoffLabel(game),color=Blue,fontSize=12.sp)};if(teams.size==2)TeamLogo(teams[1])}
   Text("VIEW GAME SCRIPT + TD OUTLOOK  ›",color=Blue,fontWeight=FontWeight.Bold,fontSize=11.sp,modifier=Modifier.padding(top=12.dp))
  }
 }
}
@Composable fun CurrentGameDetail(game:LiveScheduleGame,projection:WeekProjection?,loading:Boolean,retry:()->Unit,back:()->Unit,trends:Map<String,TeamScoringTrend>,trendsLoading:Set<String>,refreshTrends:()->Unit){
 val script = remember(game.id,projection,trends) { projection?.let { GameScriptEngine.simulate(game.matchup,it,trends) } }
 LazyColumn(contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item { TextButton(onClick=back){Icon(Icons.Default.ArrowBack,null);Text("All games")}
   Text(game.matchup,fontSize=28.sp,fontWeight=FontWeight.Black)
   Text(kickoffLabel(game),color=Blue)
   Text("CURRENT MATCHUP • LIVE ROSTER LOOKUP",color=Blue,fontWeight=FontWeight.Bold)
  }
  // The same projection and injury inputs power the screen, ranked scorers, and simulated final score.
  // If validated final-score data is missing, do not fabricate a football score.
  item { Surface(color=Card,shape=RoundedCornerShape(18.dp),border=BorderStroke(1.dp,Line)) {
   Column(Modifier.fillMaxWidth().padding(17.dp)){
    Text("SIMULATED GAME SCRIPT",color=Blue,fontSize=19.sp,fontWeight=FontWeight.Black)
    Text("Game-specific • recent results + player opportunities + defensive availability",color=Muted,fontSize=11.sp)
    if(loading && script==null) {
     Spacer(Modifier.height(12.dp));CircularProgressIndicator(color=Blue)
     Text("Retrieving team results, usage and injury reports...",color=Muted,fontSize=12.sp)
    } else if(script==null) {
     Text("No defensible score simulation yet: need at least two completed games with verified points scored AND allowed for both teams.",color=Gold,modifier=Modifier.padding(top=12.dp))
     Text(projection?.error ?: "Open this game to load the ESPN data.",color=Muted,fontSize=12.sp)
     TextButton(onClick=retry,enabled=!loading){Text("Retry matchup data")}
    } else {
     if(script.dataWarning!=null)Text("SOURCE WARNING: ${script.dataWarning}",color=Gold,fontSize=12.sp,modifier=Modifier.padding(top=9.dp))
     script.sections.forEach { section ->
      HorizontalDivider(modifier=Modifier.padding(top=14.dp,bottom=10.dp),color=Line)
      Text(section.title,color=Blue,fontWeight=FontWeight.Black,fontSize=13.sp)
      Text(section.paragraph,modifier=Modifier.padding(top=5.dp),fontSize=13.sp,lineHeight=21.sp)
     }
     HorizontalDivider(modifier=Modifier.padding(top=16.dp,bottom=10.dp),color=Line)
     Text("TOP 3 MOST LIKELY TD SCORERS",color=Blue,fontWeight=FontWeight.Black,fontSize=14.sp)
     Text("Ranked by recent opportunities adjusted for projected team scoring; NOT calibrated anytime-TD percentages.",color=Muted,fontSize=11.sp,modifier=Modifier.padding(bottom=6.dp))
     if(script.scorers.isEmpty()) Text("Not enough verified player opportunities for a scorer ranking.",color=Gold,fontSize=12.sp)
     script.scorers.forEachIndexed { i,p ->
      Text("${i+1}. ${p.name} · ${p.team} ${p.position}",color=if(i==0)Gold else Color.White,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=9.dp))
      Text(p.rationale,color=Muted,fontSize=12.sp,lineHeight=18.sp,modifier=Modifier.padding(top=3.dp))
     }
     HorizontalDivider(modifier=Modifier.padding(top=18.dp,bottom=10.dp),color=Line)
     Text("FINAL SCORE PREDICTION",color=Blue,fontWeight=FontWeight.Black,fontSize=14.sp)
     Text("${script.away} ${script.awayScore}  –  ${script.home} ${script.homeScore}",fontSize=27.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=6.dp))
     Text("${script.sampleCount} simulated games • Uncalibrated scenario estimate",color=Muted,fontSize=11.sp)
     Text(script.inputSummary,color=Muted,fontSize=10.sp,modifier=Modifier.padding(top=9.dp))
    }
   }
  } }
  item { Surface(color=Card,shape=RoundedCornerShape(18.dp)) { Column(Modifier.padding(16.dp)) {
   Text("RECENT TEAM SCORING TENDENCIES",color=Blue,fontWeight=FontWeight.Black)
   Text("Observed touchdown outcomes, not goal-line usage or a player projection",color=Muted,fontSize=11.sp)
   val isFetching=teamsOf(game).any{it in trendsLoading}
   TextButton(onClick=refreshTrends,enabled=!isFetching){Text(if(isFetching) "Updating ESPN scoring data..." else "Refresh scoring history")}
   teamsOf(game).forEach { code ->
    val trend=trends[code]
    Text(code,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=10.dp))
    if(code in trendsLoading) Text("Loading ESPN game summaries...",color=Blue,fontSize=12.sp)
    else if(trend==null) Text("Scoring history not loaded",color=Muted,fontSize=12.sp)
    else if(trend.gamesObserved==0) Text("Unavailable — not verified: ${trend.error?:trend.notes}",color=Gold,fontSize=12.sp)
    else {
     Text("${trend.gamesObserved} games • ${trend.receiving} receiving TDs • ${trend.rbRush} rushing TDs • ${trend.other} other TDs",fontSize=12.sp)
     Text(trend.notes,color=Muted,fontSize=11.sp)
     if(trend.error!=null) Text("PARTIAL DATA: ${trend.error}",color=Gold,fontSize=11.sp)
    }
   }
  } } }
  item { Surface(color=Card,shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(16.dp)){
   Text("DEFENSIVE INJURY WATCH",color=Blue,fontWeight=FontWeight.Black)
   Text("ESPN reported injuries • not a verified game-day inactive list",color=Muted,fontSize=11.sp)
   Text(projection?.injuryReportStatus ?: "Waiting for injury feeds...",color=Muted,fontSize=11.sp,modifier=Modifier.padding(top=6.dp))
   if(projection?.defensiveNotes?.isNotEmpty()==true) projection.defensiveNotes.forEach { note ->
    Text("• $note",color=Gold,fontSize=12.sp,modifier=Modifier.padding(top=7.dp))
   } else Text("No confirmed defensive absences retrieved. This does NOT mean all starters are healthy.",color=Gold,fontSize=12.sp,modifier=Modifier.padding(top=7.dp))
  }} }
  item {Text("TOP 10 TD OPPORTUNITY RANKINGS",color=Blue,fontWeight=FontWeight.Black)
   Text("Ranked from both teams using recent verified carries, targets, production and reported injuries. The index is NOT a calibrated TD probability.",color=Muted,fontSize=12.sp)
   if(loading) CircularProgressIndicator(modifier=Modifier.padding(12.dp))
   if(projection?.error!=null)Text("Data warning: ${projection.error}",color=Gold,fontSize=11.sp)
   if(!loading && projection==null)TextButton(onClick=retry){Text("Load recent usage")}
   if(projection!=null && projection.candidates.isEmpty())Text("No candidates have enough verified recent usage. Check connectivity and retry; no fictional rankings are shown.",color=Gold)
  }
  if(projection!=null)itemsIndexed(projection.candidates.take(10),key={_,p->p.team+p.name}){i,p->
   Surface(color=Card,shape=RoundedCornerShape(14.dp),border=BorderStroke(1.dp,if(i==0)Blue else Line)){
    Column(Modifier.fillMaxWidth().padding(13.dp)){
     Row(verticalAlignment=Alignment.CenterVertically){Text("#${i+1}",color=if(i==0)Gold else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(38.dp))
      Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.Bold);Text("${p.team} • ${p.position} • ${p.games} recent games",color=Blue,fontSize=11.sp)}
      Text("${p.score}/100",color=Green,fontWeight=FontWeight.Black)
     }
     Text(p.reason,color=Muted,fontSize=11.sp,modifier=Modifier.padding(top=7.dp))
     if(!p.status.startsWith("Roster listed"))Text("Availability: ${p.status}",color=Gold,fontSize=11.sp,modifier=Modifier.padding(top=5.dp))
    }
   }
  }
  item {TextButton(onClick=retry,enabled=!loading){Text("Refresh roster + game logs + injuries")}
   Text("${projection?.source ?: "ESPN sources loading"} • ${projection?.gamesVerified ?: 0} team game-boxscores processed • ${projection?.checkedAt ?: ""}",color=Muted,fontSize=10.sp)
   Text("Data limitations: targets/carries are box-score counts; red-zone targets, coverage assignments and final inactives are not verified. Scores are opportunity indices, not betting probabilities.",color=Gold,fontSize=11.sp,modifier=Modifier.padding(top=6.dp))}

 }
}
@Composable fun CurrentPicks(slate:List<LiveScheduleGame>,projections:Map<String,WeekProjection>,open:(LiveScheduleGame)->Unit){
 Column {Title("Touchdown candidates","This week's ESPN roster-backed player pool • provisional, not calibrated TD odds")
  LazyColumn {items(slate,key={it.id}){game->
   CurrentMatchupCard(game){open(game)}
   val p=projections[game.id]
   if(p!=null)Text("Top ${p.candidates.size.coerceAtMost(10)} recent-usage candidates • tap for details",color=Blue,modifier=Modifier.padding(horizontal=20.dp))
   else Text("Tap game to load current player pool",color=Muted,modifier=Modifier.padding(horizontal=20.dp))
  }}
 }
}
@Composable fun CurrentScripts(slate:List<LiveScheduleGame>,projections:Map<String,WeekProjection>,trends:Map<String,TeamScoringTrend>,open:(LiveScheduleGame)->Unit){
 Column {Title("Simulated game scripts","Full matchup reports • scored-games model, player usage, injuries and three TD candidates")
  LazyColumn {items(slate,key={it.id}){game->
   val report = remember(game.id,projections[game.id],trends) {
    projections[game.id]?.let { GameScriptEngine.simulate(game.matchup,it,trends) }
   }
   Surface(onClick={open(game)},color=Card,shape=RoundedCornerShape(18.dp),border=BorderStroke(1.dp,Line),modifier=Modifier.padding(horizontal=16.dp,vertical=7.dp).fillMaxWidth()) {
    Column(Modifier.padding(16.dp)) {
     Text(game.matchup,fontWeight=FontWeight.Black,fontSize=20.sp)
     Text(kickoffLabel(game),color=Blue,fontSize=12.sp)
     if(report==null){
      Text("Tap to load recent final scores, player usage, defensive injuries and simulate this matchup.",color=Muted,fontSize=12.sp,modifier=Modifier.padding(top=8.dp))
     } else {
      Text("MODEL SCORE  ${report.away} ${report.awayScore} – ${report.home} ${report.homeScore}",color=Gold,fontWeight=FontWeight.Bold,fontSize=15.sp,modifier=Modifier.padding(top=8.dp))
      Text("Top TD looks: ${report.scorers.joinToString { it.name }.ifBlank { "unverified" }}",color=Muted,fontSize=12.sp,modifier=Modifier.padding(top=4.dp))
     }
     Text("READ FULL SIMULATION + EXPLANATIONS  ›",color=Blue,fontSize=11.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=9.dp))
    }
   }
  }}
 }
}
@Composable fun CurrentParlays(slate:List<LiveScheduleGame>){
 Column{Title("TD parlays","Current-week player eligibility required")
  Text("Automatic TD parlays are temporarily disabled. The previous player pool was historical and could include players not active in these ${slate.size} games. A trustworthy generator requires validated current-week candidates.",color=Gold,modifier=Modifier.padding(20.dp))
 }
}
