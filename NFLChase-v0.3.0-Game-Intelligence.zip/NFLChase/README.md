# NFL Chase v0.3.0

NFL Chase is an Android NFL game-script and player-prop research app. v0.3 focuses on making the workflow useful from one screen: understand the game, find the player market, verify the real sportsbook line, then decide whether the line sits in the model's OVER zone, UNDER zone or PASS zone.

## Main tabs
- **Games** — weekly command center, score ranges, environment and data health
- **Board** — searchable player/market rankings with model projections and attack zones
- **Scripts** — projected game flow, pass/run pressure and plausible score bands
- **Builder** — starred targets, saved sportsbook lines and correlation-aware verified cards
- **Lab** — model calibration, market history, injuries, data health and JSON export

## Data
The app currently uses ESPN public endpoints for schedules, box-score summaries, leaders and injuries. These endpoints are treated as best-effort sources and may change. NFL Chase does not fabricate sportsbook lines. Real lines are manually entered in v0.3.

## Build
Android 8.0+ (minSdk 26), compileSdk / targetSdk 35, Java 17, Kotlin + Jetpack Compose.

Use the included GitHub Actions workflow or run:

```bash
./gradlew assembleDebug
```

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Important
This is a research/modeling tool. Model projections are estimates and do not guarantee outcomes.
