# NFL Chase model notes — 0.1.0

## Translated principles from the Chase/ULX workflow

The baseball process translated cleanly to football:

- **Do not chase the last game.** Recent results are context, not the foundation.
- **Opportunity is king.** Routes, targets, carries, pass attempts and red-zone work will become the primary player inputs as licensed feeds are added.
- **Match the player to the market.** High-volume possession players fit receptions; vertical threats fit receiving yards; workhorse backs fit carries/rush yards; TDs remain the highest-variance tier.
- **Game script comes before props.** A trailing team creates pass attempts and receiver opportunities. A leading team creates rushing volume and clock control.
- **Context matters.** Injuries, offensive line, defensive matchup, weather/roof, pace, target concentration and red-zone role belong in the model.
- **Odds movement is a value layer, not a prediction engine.** It should be added only when a licensed odds feed is connected.
- **Longshots need a profile.** A big price alone never qualifies a player.

## Target score (prototype)

Chase Score blends:
- role: 25%
- script fit: 25%
- opportunity: 20%
- matchup: 18%
- recent team environment: 12%

Injury penalties are then applied. Confidence also discounts volatile markets.

## Planned 0.2 inputs

QB:
- dropbacks / attempts
- pressure rate and OL pass-block health
- opponent pressure/blitz/man-zone splits
- designed rush rate
- red-zone pass/rush share

RB:
- snap share
- carry share
- route participation
- target share
- goal-line share
- yards before contact / missed tackles forced

WR/TE:
- route participation
- target share
- targets per route run
- first-read share
- air-yard share / aDOT
- red-zone and end-zone targets
- coverage and CB matchup

Team/game:
- neutral pace
- situation-neutral pass rate
- implied total and spread
- weather/roof
- injury-adjusted OL/DL
- explosive pass/rush allowed
- opponent EPA/success rate
