# NFL Chase Model v0.3 — Game Intelligence

## Model philosophy
NFL Chase starts with game environment, then role and opportunity, then opponent context. Recent fantasy points or last-game box scores never drive the board by themselves.

### 1. Game Script Engine
Each matchup gets:
- projected score and total
- plausible team score ranges and total range
- pace / environment score
- close-game score
- shootout score
- pass/run pressure for both teams
- volatility and script confidence
- weather adjustment when ESPN returns usable weather context

### 2. Usage Engine
Up to four recent box scores are parsed per upcoming team. Player profiles track:
- pass attempts, completions, pass yards and TDs
- carries and rush yards
- targets, receptions and receiving yards
- carry share / target share
- recent share vs sample share
- opportunity floor and ceiling
- role stability
- consistency
- usage trend
- efficiency (Y/A, YPC, yards/target, catch rate as position-appropriate)

### 3. Position-aware defense
Recent opponent production is grouped by position. RB, WR and TE markets use position-specific allowance samples when available instead of only team-level defense.

### 4. Prop Intelligence Score
Market scores blend:
- role 17%
- volume 18%
- script fit 16%
- matchup 16%
- recent usage 9%
- consistency 7%
- role stability 7%
- efficiency 5%
- data confidence 5%

Injury, sample-size and market-volatility penalties are applied after the base score.

### 5. Attack zones
NFL Chase does not fabricate sportsbook lines. For non-TD markets it produces:
- model projection
- OVER attack line
- UNDER attack line
- PASS zone between them

The width of the PASS zone expands when the market/player is volatile or model confidence is lower.

### 6. Model learning
Pregame projections are stored locally and settled after final box scores are available. Learning is market-specific and deliberately slow:
- minimum sample before projection bias is applied
- shrinkage toward zero for small samples
- hard cap on learned projection adjustment
- game-score weights update in small capped steps

### 7. Data honesty
If recent player data, defensive samples, weather or injury feeds are unavailable, the app exposes lower data health rather than inventing values. Season-leader fallback is clearly identified.
