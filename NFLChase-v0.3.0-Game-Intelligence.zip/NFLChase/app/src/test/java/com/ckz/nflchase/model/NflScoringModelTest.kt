package com.ckz.nflchase.model

import com.ckz.nflchase.data.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant

class NflScoringModelTest {
    private val model = NflScoringModel()

    @Test
    fun workhorseBackGradesAboveBackupAndHasStableRole() {
        val stats = listOf(
            rb("g1", "1", "Starter", 19.0, 86.0, 5.0, 34.0, 1.0),
            rb("g2", "1", "Starter", 21.0, 97.0, 4.0, 28.0, 0.0),
            rb("g3", "1", "Starter", 20.0, 92.0, 6.0, 41.0, 1.0),
            rb("g4", "1", "Starter", 22.0, 110.0, 5.0, 36.0, 1.0),
            rb("g1", "2", "Backup", 5.0, 21.0, 1.0, 5.0, 0.0),
            rb("g2", "2", "Backup", 4.0, 18.0, 1.0, 4.0, 0.0),
            rb("g3", "2", "Backup", 3.0, 13.0, 1.0, 2.0, 0.0),
            rb("g4", "2", "Backup", 4.0, 15.0, 1.0, 3.0, 0.0)
        )
        val profiles = model.buildUsageProfiles("CIN", stats)
        val starter = profiles.first { it.athleteId == "1" }
        val backup = profiles.first { it.athleteId == "2" }
        assertTrue(starter.carryShare > backup.carryShare)
        assertEquals("Workhorse back", starter.roleLabel)
        assertTrue(starter.roleStabilityScore >= 60)
        assertEquals(4, starter.recentValues.getValue(PropType.RUSH_YARDS).size)
    }

    @Test
    fun trailingTeamGetsPassChaseAndRange() {
        val game = NflGame("x", Instant.now(), GameStatus.SCHEDULED, "Scheduled", TeamRef("h", "CIN", "CIN"), TeamRef("a", "BAL", "BAL"))
        val home = TeamForm("CIN", 5, 4, 1, 29.0, 19.0, 30.0, 18.0, 4.0)
        val away = TeamForm("BAL", 5, 2, 3, 22.0, 26.0, 20.0, 28.0, 6.0)
        val script = model.projectGame(game, home, away, ModelWeights())
        assertTrue(script.passLeanAway > script.passLeanHome)
        assertTrue(script.homeScore > script.awayScore)
        assertTrue(script.totalLow < script.totalHigh)
    }

    @Test
    fun defenseProfileUsesPositionSpecificProduction() {
        val byGame = mapOf(
            "g1" to listOf(
                PlayerGameStat("g1", "q", "QB", "BAL", PositionGroup.QB, passCompletions = 25.0, passAttempts = 38.0, passYards = 286.0, passTds = 2.0),
                PlayerGameStat("g1", "r", "RB", "BAL", PositionGroup.RB, rushAttempts = 22.0, rushYards = 121.0, rushTds = 1.0, receptions = 4.0, receivingYards = 30.0)
            )
        )
        val d = model.buildDefenseProfile("CIN", listOf("g1"), byGame)
        assertEquals(286.0, d.passYardsAllowedAvg, .01)
        assertEquals(121.0, d.byPosition.getValue(PositionGroup.RB).rushYardsAvg, .01)
        assertEquals(30.0, d.byPosition.getValue(PositionGroup.RB).receivingYardsAvg, .01)
    }

    @Test
    fun marketLearningDetectsPositiveBias() {
        val records = (1..8).map { i ->
            PropPredictionRecord("$i", "g$i", "p", "P", PropType.RUSH_YARDS, 0L, 70.0, 63.5, 80, actual = 78.0, settled = true)
        }
        val summary = model.marketLearning(records).getValue(PropType.RUSH_YARDS)
        assertEquals(8, summary.settled)
        assertTrue(summary.meanBiasPct > 0)
        assertTrue(summary.thresholdHitRate > .9)
    }

    private fun rb(gameId: String, id: String, name: String, carries: Double, rushYards: Double, targets: Double, recYards: Double, rushTd: Double) =
        PlayerGameStat(gameId, id, name, "CIN", PositionGroup.RB, rushAttempts = carries, rushYards = rushYards, rushTds = rushTd, receptions = targets - 1, targets = targets, receivingYards = recYards)
}
