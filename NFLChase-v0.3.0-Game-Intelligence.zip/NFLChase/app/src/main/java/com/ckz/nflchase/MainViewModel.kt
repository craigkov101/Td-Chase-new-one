package com.ckz.nflchase

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ckz.nflchase.data.NflDashboard
import com.ckz.nflchase.data.PropTarget
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface LoadState {
    data object Loading : LoadState
    data class Ready(val dashboard: NflDashboard) : LoadState
    data class Error(val message: String) : LoadState
}

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = (application as NflChaseApplication).repository
    private val _state = MutableStateFlow<LoadState>(LoadState.Loading)
    val state: StateFlow<LoadState> = _state.asStateFlow()

    private val _tracked = MutableStateFlow(repository.loadTrackedIds())
    val tracked: StateFlow<Set<String>> = _tracked.asStateFlow()

    private val _manualLines = MutableStateFlow(repository.loadManualLines())
    val manualLines: StateFlow<Map<String, Double>> = _manualLines.asStateFlow()

    init { refresh() }

    fun refresh() {
        viewModelScope.launch {
            _state.value = LoadState.Loading
            _state.value = try {
                LoadState.Ready(repository.loadDashboard())
            } catch (t: Throwable) {
                LoadState.Error(t.message ?: "NFL data could not be loaded")
            }
        }
    }

    fun toggleTrack(target: PropTarget) {
        val updated = _tracked.value.toMutableSet().apply {
            if (!add(target.id)) remove(target.id)
        }
        _tracked.value = updated
        repository.saveTrackedIds(updated)
    }

    fun saveManualLine(targetId: String, line: Double?) {
        val updated = _manualLines.value.toMutableMap()
        if (line == null || line <= 0) updated.remove(targetId) else updated[targetId] = line
        _manualLines.value = updated
        repository.saveManualLines(updated)
    }
}
