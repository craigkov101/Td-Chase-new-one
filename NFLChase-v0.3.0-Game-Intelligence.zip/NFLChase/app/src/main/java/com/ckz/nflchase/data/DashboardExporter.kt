package com.ckz.nflchase.data

import org.json.JSONArray
import org.json.JSONObject

object DashboardExporter {
    fun toJson(d: NflDashboard, lines: Map<String, Double>, tracked: Set<String>): String {
        val root = JSONObject()
        root.put("app", "NFL Chase")
        root.put("modelVersion", d.modelVersion)
        root.put("exportedAtMillis", System.currentTimeMillis())
        root.put("lastUpdatedMillis", d.lastUpdatedMillis)
        root.put("dataHealth", JSONObject().apply {
            put("score", d.dataHealth.score)
            put("label", d.dataHealth.label)
            put("recentGameSummaries", d.dataHealth.recentGameSummaries)
            put("playerProfiles", d.dataHealth.playerProfiles)
            put("defensiveProfiles", d.dataHealth.defensiveProfiles)
        })
        root.put("games", JSONArray().apply {
            d.games.forEach { g ->
                val s = d.scripts[g.id]
                put(JSONObject().apply {
                    put("gameId", g.id)
                    put("away", g.away.abbreviation)
                    put("home", g.home.abbreviation)
                    put("kickoff", g.kickoff.toString())
                    put("status", g.status.name)
                    put("venue", g.venue ?: JSONObject.NULL)
                    put("weather", g.weather?.summary ?: JSONObject.NULL)
                    if (s != null) put("script", JSONObject().apply {
                        put("awayScore", s.awayScore)
                        put("homeScore", s.homeScore)
                        put("total", s.total)
                        put("totalRange", JSONArray(listOf(s.totalLow, s.totalHigh)))
                        put("environmentScore", s.environmentScore)
                        put("paceScore", s.paceScore)
                        put("volatilityScore", s.volatilityScore)
                        put("scriptConfidence", s.confidence)
                        put("awayPassLean", s.passLeanAway)
                        put("homePassLean", s.passLeanHome)
                        put("label", s.label)
                    })
                })
            }
        })
        root.put("targets", JSONArray().apply {
            d.targets.forEach { t ->
                put(JSONObject().apply {
                    put("id", t.id)
                    put("tracked", t.id in tracked)
                    put("player", t.playerName)
                    put("team", t.team)
                    put("opponent", t.opponent)
                    put("position", t.position.name)
                    put("market", t.propType.name)
                    put("projection", t.modelProjection)
                    put("attackOverAt", t.attackOverAt)
                    put("attackUnderAt", t.attackUnderAt)
                    put("floor", t.floorProjection)
                    put("ceiling", t.ceilingProjection)
                    put("chaseScore", t.chaseScore)
                    put("confidence", t.confidence)
                    put("tier", t.tier)
                    put("role", t.roleScore)
                    put("volume", t.volumeScore)
                    put("script", t.scriptScore)
                    put("matchup", t.matchupScore)
                    put("consistency", t.consistencyScore)
                    put("roleStability", t.roleStabilityScore)
                    put("efficiency", t.efficiencyScore)
                    put("dataConfidence", t.dataConfidence)
                    put("recentValues", JSONArray(t.recentValues))
                    put("manualSportsbookLine", lines[t.id] ?: JSONObject.NULL)
                    put("injuryStatus", t.injuryStatus ?: JSONObject.NULL)
                    put("matchupDetail", t.matchupDetail)
                })
            }
        })
        return root.toString(2)
    }
}
