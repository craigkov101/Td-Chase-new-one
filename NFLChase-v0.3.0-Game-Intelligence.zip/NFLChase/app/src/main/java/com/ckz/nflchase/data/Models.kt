package com.ckz.nflchase.data

import java.time.Instant

enum class GameStatus { SCHEDULED, LIVE, FINAL }
enum class PositionGroup { QB, RB, WR, TE, OTHER }
enum class PropType(val label: String, val shortLabel: String) {
    PASS_YARDS("Pass Yards", "Pass Yds"),
    PASS_COMPLETIONS("Completions", "Comp"),
    PASS_ATTEMPTS("Pass Attempts", "Pass Att"),
    PASS_TDS("Pass TDs", "Pass TD"),
    RUSH_YARDS("Rush Yards", "Rush Yds"),
    RUSH_ATTEMPTS("Carries", "Carries"),
    RECEIVING_YARDS("Receiving Yards", "Rec Yds"),
    RECEPTIONS("Receptions", "Rec"),
    ANYTIME_TD("Anytime TD", "TD")
}

data class WeatherContext(
    val summary: String = "",
    val temperatureF: Int? = null,
    val windMph: Int? = null,
    val outdoor: Boolean = true
) {
    val isAdverse: Boolean
        get() {
            if (!outdoor) return false
            val s = summary.lowercase()
            return (windMph ?: 0) >= 18 || s.contains("rain") || s.contains("snow") || s.contains("storm") || s.contains("wind")
        }
}

data class TeamRef(
    val id: String,
    val abbreviation: String,
    val name: String,
    val logoUrl: String? = null,
    val record: String? = null,
    val score: Int? = null
)

data class NflGame(
    val id: String,
    val kickoff: Instant,
    val status: GameStatus,
    val statusText: String,
    val home: TeamRef,
    val away: TeamRef,
    val venue: String? = null,
    val indoor: Boolean? = null,
    val weekLabel: String? = null,
    val weather: WeatherContext? = null
)

data class TeamForm(
    val team: String,
    val games: Int,
    val wins: Int,
    val losses: Int,
    val pointsForAvg: Double,
    val pointsAgainstAvg: Double,
    val recentPointsForAvg: Double,
    val recentPointsAgainstAvg: Double,
    val scoringStdDev: Double = 0.0,
    val homeGames: Int = 0,
    val roadGames: Int = 0
) {
    val winPct: Double get() = if (games == 0) .5 else wins.toDouble() / games
}

data class PlayerLeader(
    val athleteId: String,
    val name: String,
    val team: String,
    val position: PositionGroup,
    val category: String,
    val value: Double,
    val displayValue: String,
    val headshotUrl: String? = null
)

data class PlayerGameStat(
    val gameId: String,
    val athleteId: String,
    val name: String,
    val team: String,
    val position: PositionGroup,
    val headshotUrl: String? = null,
    val passCompletions: Double = 0.0,
    val passAttempts: Double = 0.0,
    val passYards: Double = 0.0,
    val passTds: Double = 0.0,
    val rushAttempts: Double = 0.0,
    val rushYards: Double = 0.0,
    val rushTds: Double = 0.0,
    val receptions: Double = 0.0,
    val targets: Double = 0.0,
    val receivingYards: Double = 0.0,
    val receivingTds: Double = 0.0
) {
    val totalTds: Double get() = passTds + rushTds + receivingTds
}

data class PlayerUsageProfile(
    val athleteId: String,
    val name: String,
    val team: String,
    val position: PositionGroup,
    val headshotUrl: String? = null,
    val games: Int,
    val averages: Map<PropType, Double>,
    val recentAverages: Map<PropType, Double>,
    val floors: Map<PropType, Double>,
    val ceilings: Map<PropType, Double>,
    val recentValues: Map<PropType, List<Double>> = emptyMap(),
    val targetShare: Double = 0.0,
    val recentTargetShare: Double = 0.0,
    val carryShare: Double = 0.0,
    val recentCarryShare: Double = 0.0,
    val usageTrendPct: Double = 0.0,
    val consistencyScore: Int = 50,
    val roleStabilityScore: Int = 50,
    val efficiencyScore: Int = 50,
    val roleLabel: String = "Rotation",
    val opportunitiesPerGame: Double = 0.0,
    val opportunityFloor: Double = 0.0,
    val opportunityCeiling: Double = 0.0,
    val touchdownRate: Double = 0.0,
    val catchRate: Double = 0.0,
    val yardsPerTarget: Double = 0.0,
    val yardsPerReception: Double = 0.0,
    val yardsPerCarry: Double = 0.0,
    val completionPct: Double = 0.0,
    val passYardsPerAttempt: Double = 0.0
)

data class PositionAllowance(
    val position: PositionGroup,
    val games: Int = 0,
    val rushAttemptsAvg: Double = 0.0,
    val rushYardsAvg: Double = 0.0,
    val receptionsAvg: Double = 0.0,
    val receivingYardsAvg: Double = 0.0,
    val touchdownsAvg: Double = 0.0
)

data class DefenseProfile(
    val team: String,
    val games: Int,
    val passYardsAllowedAvg: Double = 0.0,
    val completionsAllowedAvg: Double = 0.0,
    val passAttemptsAllowedAvg: Double = 0.0,
    val passTdsAllowedAvg: Double = 0.0,
    val rushYardsAllowedAvg: Double = 0.0,
    val rushAttemptsAllowedAvg: Double = 0.0,
    val receptionsAllowedAvg: Double = 0.0,
    val touchdownsAllowedAvg: Double = 0.0,
    val byPosition: Map<PositionGroup, PositionAllowance> = emptyMap()
)

data class InjuryNote(
    val athleteId: String?,
    val playerName: String,
    val team: String,
    val status: String,
    val detail: String? = null,
    val position: PositionGroup = PositionGroup.OTHER
)

data class GameScript(
    val gameId: String,
    val awayScore: Int,
    val homeScore: Int,
    val total: Int,
    val margin: Int,
    val awayLow: Int,
    val awayHigh: Int,
    val homeLow: Int,
    val homeHigh: Int,
    val totalLow: Int,
    val totalHigh: Int,
    val closeGameScore: Int,
    val shootoutScore: Int,
    val paceScore: Int,
    val environmentScore: Int,
    val volatilityScore: Int,
    val passLeanHome: Int,
    val passLeanAway: Int,
    val runLeanHome: Int,
    val runLeanAway: Int,
    val confidence: Int,
    val label: String,
    val summary: String,
    val drivers: List<String>
)

data class MarketLearningSummary(
    val propType: PropType,
    val settled: Int = 0,
    val thresholdHitRate: Double = 0.0,
    val meanBiasPct: Double = 0.0,
    val meanAbsoluteError: Double = 0.0
)

data class PropTarget(
    val id: String,
    val gameId: String,
    val athleteId: String,
    val playerName: String,
    val team: String,
    val opponent: String,
    val position: PositionGroup,
    val propType: PropType,
    val modelProjection: Double,
    val suggestedThreshold: Double,
    val attackOverAt: Double,
    val attackUnderAt: Double,
    val floorProjection: Double,
    val ceilingProjection: Double,
    val recentValues: List<Double>,
    val recentHitRate: Double,
    val chaseScore: Int,
    val roleScore: Int,
    val volumeScore: Int,
    val matchupScore: Int,
    val scriptScore: Int,
    val recentUsageScore: Int,
    val consistencyScore: Int,
    val roleStabilityScore: Int,
    val efficiencyScore: Int,
    val opportunityScore: Int,
    val dataConfidence: Int,
    val volatility: Int,
    val confidence: Int,
    val sampleSize: Int,
    val roleLabel: String,
    val matchupDetail: String,
    val marketHistoryCount: Int,
    val learnedAdjustmentPct: Double,
    val rationale: List<String>,
    val headshotUrl: String? = null,
    val injuryStatus: String? = null
) {
    val tier: String
        get() = when {
            confidence >= 84 && chaseScore >= 88 -> "ELITE"
            confidence >= 78 && chaseScore >= 83 -> "CORE"
            confidence >= 71 && chaseScore >= 77 -> "STRONG"
            confidence >= 63 && chaseScore >= 71 -> "WATCH"
            else -> "LEAN"
        }
}

data class DataHealth(
    val score: Int = 0,
    val label: String = "Collecting data",
    val recentGameSummaries: Int = 0,
    val playerProfiles: Int = 0,
    val defensiveProfiles: Int = 0,
    val injuryTeams: Int = 0,
    val notes: List<String> = emptyList()
)

data class ModelWeights(
    val recentOffense: Double = 0.34,
    val seasonOffense: Double = 0.20,
    val opponentDefense: Double = 0.28,
    val winStrength: Double = 0.08,
    val homeField: Double = 1.65,
    val learningRate: Double = 0.018
)

data class PredictionRecord(
    val gameId: String,
    val createdAtMillis: Long,
    val predictedHome: Int,
    val predictedAway: Int,
    val actualHome: Int? = null,
    val actualAway: Int? = null,
    val settled: Boolean = false
) {
    val absoluteError: Int?
        get() = if (actualHome == null || actualAway == null) null
        else kotlin.math.abs(predictedHome - actualHome) + kotlin.math.abs(predictedAway - actualAway)
}

data class PropPredictionRecord(
    val id: String,
    val gameId: String,
    val athleteId: String,
    val playerName: String,
    val propType: PropType,
    val createdAtMillis: Long,
    val projection: Double,
    val threshold: Double,
    val chaseScore: Int,
    val actual: Double? = null,
    val settled: Boolean = false
) {
    val thresholdHit: Boolean? get() = actual?.let { it >= threshold }
    val biasPct: Double?
        get() = actual?.let { a -> if (projection <= 0.0) null else (a - projection) / projection }
}

data class LearningSnapshot(
    val settledPredictions: Int = 0,
    val meanAbsoluteTeamError: Double = 0.0,
    val settledProps: Int = 0,
    val propThresholdHitRate: Double = 0.0,
    val lastUpdatedMillis: Long = 0L,
    val weights: ModelWeights = ModelWeights(),
    val marketLearning: Map<PropType, MarketLearningSummary> = emptyMap()
)

data class NflDashboard(
    val games: List<NflGame> = emptyList(),
    val scripts: Map<String, GameScript> = emptyMap(),
    val targets: List<PropTarget> = emptyList(),
    val injuries: List<InjuryNote> = emptyList(),
    val usageProfiles: List<PlayerUsageProfile> = emptyList(),
    val learning: LearningSnapshot = LearningSnapshot(),
    val dataHealth: DataHealth = DataHealth(),
    val lastUpdatedMillis: Long = 0L,
    val dataNote: String = "",
    val modelVersion: String = "0.3.0"
)
