package com.ckz.nflchase

import android.app.Application
import com.ckz.nflchase.data.AppPreferences
import com.ckz.nflchase.data.EspnApi
import com.ckz.nflchase.data.Repository
import com.ckz.nflchase.model.NflScoringModel

class NflChaseApplication : Application() {
    val repository: Repository by lazy {
        Repository(EspnApi(), AppPreferences(this), NflScoringModel())
    }
}
