package com.ckz.nflchase.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class AppPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("nfl_chase", Context.MODE_PRIVATE)

    fun loadWeights(): ModelWeights = ModelWeights(
        recentOffense = prefs.getFloat("w_recent", 0.34f).toDouble(),
        seasonOffense = prefs.getFloat("w_season", 0.20f).toDouble(),
        opponentDefense = prefs.getFloat("w_def", 0.28f).toDouble(),
        winStrength = prefs.getFloat("w_win", 0.08f).toDouble(),
        homeField = prefs.getFloat("w_home", 1.65f).toDouble(),
        learningRate = prefs.getFloat("w_lr", 0.018f).toDouble()
    )

    fun saveWeights(w: ModelWeights) {
        prefs.edit()
            .putFloat("w_recent", w.recentOffense.toFloat())
            .putFloat("w_season", w.seasonOffense.toFloat())
            .putFloat("w_def", w.opponentDefense.toFloat())
            .putFloat("w_win", w.winStrength.toFloat())
            .putFloat("w_home", w.homeField.toFloat())
            .putFloat("w_lr", w.learningRate.toFloat())
            .apply()
    }

    fun loadPredictions(): List<PredictionRecord> {
        val raw = prefs.getString("predictions", "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(
                        PredictionRecord(
                            gameId = o.getString("gameId"),
                            createdAtMillis = o.optLong("createdAt", 0L),
                            predictedHome = o.optInt("predHome", 0),
                            predictedAway = o.optInt("predAway", 0),
                            actualHome = if (o.has("actualHome") && !o.isNull("actualHome")) o.getInt("actualHome") else null,
                            actualAway = if (o.has("actualAway") && !o.isNull("actualAway")) o.getInt("actualAway") else null,
                            settled = o.optBoolean("settled", false)
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    fun savePredictions(records: List<PredictionRecord>) {
        val arr = JSONArray()
        records.takeLast(160).forEach { r ->
            arr.put(JSONObject().apply {
                put("gameId", r.gameId)
                put("createdAt", r.createdAtMillis)
                put("predHome", r.predictedHome)
                put("predAway", r.predictedAway)
                put("actualHome", r.actualHome ?: JSONObject.NULL)
                put("actualAway", r.actualAway ?: JSONObject.NULL)
                put("settled", r.settled)
            })
        }
        prefs.edit().putString("predictions", arr.toString()).apply()
    }

    fun loadPropPredictions(): List<PropPredictionRecord> {
        val raw = prefs.getString("prop_predictions", "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val type = runCatching { PropType.valueOf(o.getString("propType")) }.getOrNull() ?: continue
                    add(
                        PropPredictionRecord(
                            id = o.getString("id"),
                            gameId = o.getString("gameId"),
                            athleteId = o.getString("athleteId"),
                            playerName = o.optString("playerName"),
                            propType = type,
                            createdAtMillis = o.optLong("createdAt", 0L),
                            projection = o.optDouble("projection", 0.0),
                            threshold = o.optDouble("threshold", 0.0),
                            chaseScore = o.optInt("chaseScore", 0),
                            actual = if (o.has("actual") && !o.isNull("actual")) o.getDouble("actual") else null,
                            settled = o.optBoolean("settled", false)
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    fun savePropPredictions(records: List<PropPredictionRecord>) {
        val arr = JSONArray()
        records.takeLast(420).forEach { r ->
            arr.put(JSONObject().apply {
                put("id", r.id)
                put("gameId", r.gameId)
                put("athleteId", r.athleteId)
                put("playerName", r.playerName)
                put("propType", r.propType.name)
                put("createdAt", r.createdAtMillis)
                put("projection", r.projection)
                put("threshold", r.threshold)
                put("chaseScore", r.chaseScore)
                put("actual", r.actual ?: JSONObject.NULL)
                put("settled", r.settled)
            })
        }
        prefs.edit().putString("prop_predictions", arr.toString()).apply()
    }


    fun loadManualLines(): Map<String, Double> {
        val raw = prefs.getString("manual_lines", "{}") ?: "{}"
        return runCatching {
            val o = JSONObject(raw)
            buildMap {
                val keys = o.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val value = o.optDouble(key, Double.NaN)
                    if (!value.isNaN() && value > 0) put(key, value)
                }
            }
        }.getOrDefault(emptyMap())
    }

    fun saveManualLines(lines: Map<String, Double>) {
        val o = JSONObject()
        lines.forEach { (id, line) -> if (line > 0) o.put(id, line) }
        prefs.edit().putString("manual_lines", o.toString()).apply()
    }

    fun loadTrackedIds(): Set<String> = prefs.getStringSet("tracked_ids", emptySet()) ?: emptySet()

    fun saveTrackedIds(ids: Set<String>) {
        prefs.edit().putStringSet("tracked_ids", ids).apply()
    }
}
