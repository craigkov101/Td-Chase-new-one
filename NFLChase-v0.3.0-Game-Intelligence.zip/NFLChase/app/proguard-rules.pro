# NFL Chase prototype keeps full symbols for easier debugging.
