# NFL Chase v0.3.0 — Game Intelligence

This release turns the v0.2 usage prototype into a much more serious football research workflow.

## New
- Game score ranges, total ranges, close-game and shootout scores
- Four-game usage samples with role-stability grading
- Recent vs sample carry share / target share
- Position-aware defensive allowances for RB / WR / TE
- Player efficiency grading appropriate to role
- OVER / UNDER / PASS attack zones instead of one-sided over thresholds
- Persistent sportsbook line entry
- Verified-line Bet Builder
- Correlation-aware cards built only from non-PASS verified edges
- Searchable and filterable Prop Intelligence Board
- Data Health score with coverage transparency
- Improved injury board with position parsing
- Export / Share Analysis JSON for later ChatGPT integration
- 12-minute network response cache for faster repeat refreshes
- ELITE tier added above CORE

## Model safeguards
- Sportsbook lines are never generated or guessed
- Small-sample penalties remain active
- Learned adjustments require more settled samples and are capped tighter
- TD markets remain explicitly high variance
- Missing advanced data lowers confidence instead of being imputed as fake precision
