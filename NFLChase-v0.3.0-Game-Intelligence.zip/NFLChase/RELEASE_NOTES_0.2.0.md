# NFL Chase v0.2.0 — Usage Engine

This is the first serious model upgrade after the 0.1 foundation.

## Added
- seven-day NFL slate window instead of only the current scoreboard day
- recent player box-score usage engine
- carry share, target share, opportunity trend and consistency
- observed floor/ceiling ranges
- QB attempts and completions markets
- market-specific defensive allowance profiles
- stronger game environment, volatility and run/pass lean scoring
- weather-aware passing downgrade when source data reports adverse conditions
- CORE / STRONG / WATCH / LEAN target tiers
- persistent starred targets
- manual sportsbook Line Check
- player-prop settlement and market-specific model learning
- market calibration cards in Model Lab
- Safe / Balanced / Upside correlation-aware parlay modes
- custom NFL Chase launcher icon

## Model discipline
- recent outcomes never replace role/opportunity
- market-learning adjustments are shrunk and capped
- TDs remain explicitly high variance
- no sportsbook lines or prices are fabricated
- actual line entry is required for line comparison

## Still planned before a paid public release
- licensed production stats feed
- licensed odds/line movement feed
- snap share and route participation
- first-read share, air-yard share and aDOT
- red-zone/end-zone usage
- designed QB rush rate
- OL/pass-rush and pressure context
- coverage/man-zone splits
- richer weather feed
