# NFL Chase model notes — 0.2.0

## Principles carried over from the Chase / ULX workflow

- **Role over recency.** A player does not become a strong prop solely because the last game was big.
- **Opportunity is the foundation.** Attempts, carries, targets and role shares are weighted before outcomes.
- **Use a prop ladder.** Receptions, carries and attempts are lower-variance than yards; TDs stay at the high-variance end.
- **Game script first.** Passing and receiving volume gain in chase scripts. Rushing volume gains in control scripts.
- **Matchup must be market-specific.** Pass props use recent passing allowances; rush props use recent rushing allowances.
- **Weather and injuries are filters.** They can downgrade a profile, not magically create one.
- **Longshots need a profile.** A TD market receives a volatility penalty even when the player is a strong scoring candidate.
- **Odds are a separate value layer.** The model can judge a line, but a full value calculation needs the actual price.

## Chase Score — 0.2

Approximate blend before injury/high-variance penalties:

- role: 18%
- volume: 20%
- game-script fit: 18%
- market-specific matchup: 15%
- recent usage trend: 12%
- consistency: 8%
- data confidence: 9%

Small market-learning calibration may be added only after a minimum settled sample exists.

## Prop tiers

- **CORE** — high score + high confidence
- **STRONG** — clears strong score/confidence requirements
- **WATCH** — useful model lean but not top tier
- **LEAN** — remains visible for research, not elevated by the app

## Learning safeguards

- game-score learning uses recent settled predictions and a low learning rate
- player-prop learning is separated by market
- market bias is shrunk toward zero when the sample is small
- learned projection changes are capped
- TD calibration is not treated like a yardage bias

## Next production-grade inputs

A licensed data layer should eventually add:

- snap share and route participation
- targets per route run and first-read share
- air-yard share / aDOT
- red-zone/end-zone targets and goal-line carries
- designed QB rushes
- OL injuries and pressure/blitz rates
- man/zone and coverage-specific receiving splits
- neutral pace and situation-neutral pass rate
- EPA/success rate and explosive-play rates
- live sportsbook lines, prices and line movement
