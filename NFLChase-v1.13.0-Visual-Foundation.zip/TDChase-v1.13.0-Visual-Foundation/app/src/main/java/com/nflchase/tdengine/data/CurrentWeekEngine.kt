package com.nflchase.tdengine.data

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

/** An opportunity index, NOT an anytime-touchdown probability. */
data class WeekCandidate(
    val name: String,
    val team: String,
    val position: String,
    val status: String,
    val score: Int,
    val reason: String,
    val games: Int = 0,
    val recentTargets: Double = 0.0,
    val recentCarries: Double = 0.0,
    val fiveGameTouchdowns: Int = 0,
    val shortRushingTdFinishes: Int = 0,
    val opportunityTrend: Double = 0.0,
    /** ESPN athlete identifier for optional player headshots; empty means use initials. */
    val athleteId: String = ""
)
data class TeamGameForm(
    val team: String,
    val pointsScored: List<Int> = emptyList(),
    val pointsAllowed: List<Int> = emptyList(),
    val risk: TeamRiskMetrics = TeamRiskMetrics()
) {
    val games: Int get() = minOf(pointsScored.size, pointsAllowed.size)
    val averageScored: Double get() = if(pointsScored.isEmpty()) 0.0 else pointsScored.average()
    val averageAllowed: Double get() = if(pointsAllowed.isEmpty()) 0.0 else pointsAllowed.average()
}

data class VerifiedInjury(
    val team: String,
    val player: String,
    val position: String,
    val designation: String,
    val reportSource: String
)

data class WeekProjection(
    val gameId: String,
    val candidates: List<WeekCandidate>,
    val source: String,
    val error: String? = null,
    val defensiveNotes: List<String> = emptyList(),
    val injuryReportStatus: String = "Not checked",
    val gamesVerified: Int = 0,
    val checkedAt: String = "",
    val teamForms: List<TeamGameForm> = emptyList(),
    val injuries: List<VerifiedInjury> = emptyList(),
    val defensiveBacks: Map<String, List<String>> = emptyMap(),
    val rosterNotes: List<String> = emptyList(),
    val offensiveRoster: Map<String, List<String>> = emptyMap()
)

internal fun normalName(value: String): String = value.lowercase(Locale.US)
    .replace(Regex("[^a-z0-9 ]"), "").replace(Regex("\\s+"), " ").trim()

private fun defaultFetchJson(url: String): JSONObject {
    val c = (URL(url).openConnection() as HttpURLConnection).apply {
        connectTimeout = 8000
        readTimeout = 10000
        requestMethod = "GET"
        setRequestProperty("Accept", "application/json")
        setRequestProperty("User-Agent", "TDChase/1.13.0 (Android; player usage & injuries)")
    }
    return try {
        if (c.responseCode !in 200..299) error("ESPN HTTP ${c.responseCode}")
        JSONObject(c.inputStream.bufferedReader().use { it.readText() })
    } finally { c.disconnect() }
}

internal object EspnRosterParser {
    data class Athlete(val name: String, val position: String, val status: String, val rawStatus: String, val id: String = "")

    /** Never stringify JSONObject status: that was the raw JSON printed in v1.8.1. */
    fun statusText(athlete: JSONObject): String {
        val node = athlete.opt("status")
        return when (node) {
            is JSONObject -> node.optString("name", "").ifBlank { node.optString("description", "") }
                .ifBlank { node.optString("type", "") }
            is String -> node
            else -> ""
        }.take(45)
    }

    fun unavailable(status: String): Boolean {
        val s = status.trim().lowercase(Locale.US)
        return s in setOf("out", "inactive", "injured reserve", "ir", "reserve/injured", "pup", "suspended", "physically unable to perform") ||
            s.startsWith("injured reserve") || s.startsWith("reserve/injured") || s.startsWith("inactive")
    }

    fun parse(roster: JSONObject): List<Athlete> {
        val groups = roster.optJSONArray("athletes") ?: return emptyList()
        val result = mutableListOf<Athlete>()
        for (i in 0 until groups.length()) {
            val group = groups.optJSONObject(i) ?: continue
            // ESPN may return grouped athletes/items or a direct list of athletes.
            val items = group.optJSONArray("items") ?: JSONArray().put(group)
            for (j in 0 until items.length()) {
                val player = items.optJSONObject(j) ?: continue
                val name = player.optString("displayName", player.optString("fullName", "")).trim()
                val pos = player.optJSONObject("position")?.optString("abbreviation", "")?.uppercase(Locale.US) ?: ""
                if (name.isBlank() || pos !in setOf("RB", "WR", "TE", "QB")) continue
                val s = statusText(player)
                result += Athlete(name, pos, when {
                    unavailable(s) -> "OUT (roster status)"
                    s.isBlank() || s.equals("active", true) -> "Roster listed · game-day status unverified"
                    else -> "$s · verify final injury report"
                }, s, player.optString("id", "").takeIf { it.matches(Regex("[0-9]{1,12}")) } ?: "")
            }
        }
        return result.distinctBy { normalName(it.name) }
    }
}

internal object EspnPlayerStatsParser {
    data class Line(
        val name: String, val targets: Int = 0, val carries: Int = 0,
        val recYards: Int = 0, val rushYards: Int = 0,
        val recTd: Int = 0, val rushTd: Int = 0,
        val sourceCategories: Int = 0
    ) {
        val touchdowns: Int get() = recTd + rushTd
    }

    private fun column(section: JSONObject, row: JSONObject, vararg keys: String): Int {
        val labels = section.optJSONArray("labels") ?: return 0
        val stats = row.optJSONArray("stats") ?: return 0
        val positions = (0 until labels.length()).associate { labels.optString(it).uppercase(Locale.US).trim() to it }
        val index = keys.firstNotNullOfOrNull { positions[it] } ?: return 0
        val raw = stats.optString(index, "0").replace(",", "")
        return raw.toDoubleOrNull()?.roundToInt() ?: 0
    }

    /** Uses column labels rather than assumed array positions, which vary among ESPN feeds. */
    fun boxscore(summary: JSONObject, teamId: String, teamCode: String): Map<String, Line> {
        val players = summary.optJSONObject("boxscore")?.optJSONArray("players") ?: return emptyMap()
        val found = mutableMapOf<String, Line>()
        for (i in 0 until players.length()) {
            val team = players.optJSONObject(i) ?: continue
            val ref = team.optJSONObject("team")
            val id = ref?.optString("id", "") ?: ""
            val code = ref?.optString("abbreviation", "") ?: ""
            if (!((teamId.isNotBlank() && id == teamId) || sameTeam(code,teamCode))) continue
            val sections = team.optJSONArray("statistics") ?: continue
            for (j in 0 until sections.length()) {
                val section = sections.optJSONObject(j) ?: continue
                val category = section.optString("name", "").lowercase(Locale.US)
                val isReceiving = category.contains("receiv")
                val isRushing = category.contains("rush")
                if (!isReceiving && !isRushing) continue
                // An unlabelled stats array cannot be decoded safely.
                if (section.optJSONArray("labels") == null) continue
                val rows = section.optJSONArray("athletes") ?: continue
                for (k in 0 until rows.length()) {
                    val row = rows.optJSONObject(k) ?: continue
                    val athlete = row.optJSONObject("athlete") ?: continue
                    val name = athlete.optString("displayName", athlete.optString("fullName", ""))
                    val key = normalName(name)
                    if (key.isBlank()) continue
                    val old = found[key] ?: Line(name)
                    found[key] = if (isReceiving) old.copy(
                        targets = old.targets + column(section, row, "TGTS", "TGT", "TARGETS", "TAR", "TARGET"),
                        recYards = old.recYards + column(section, row, "YDS", "YARDS"),
                        recTd = old.recTd + column(section, row, "TD", "TDS"),
                        sourceCategories = old.sourceCategories + 1
                    ) else old.copy(
                        carries = old.carries + column(section, row, "CAR", "ATT", "CARRIES"),
                        rushYards = old.rushYards + column(section, row, "YDS", "YARDS"),
                        rushTd = old.rushTd + column(section, row, "TD", "TDS"),
                        sourceCategories = old.sourceCategories + 1
                    )
                }
            }
        }
        return found
    }
}

internal fun normalizedInjuryName(value: String): String = normalName(value)
    .replace("patrick surtain ii", "pat surtain ii")

internal object EspnInjuryParser {
    data class Report(val name: String, val position: String, val status: String, val detail: String)
    fun statusLabel(obj: JSONObject): String {
        val raw = obj.opt("status")
        val status = when (raw) {
            is JSONObject -> raw.optString("name", "").ifBlank { raw.optString("description", "") }
            is String -> raw
            else -> ""
        }
        val type = obj.optJSONObject("type")?.optString("name", "") ?: ""
        return status.ifBlank { type }.trim().take(45)
    }
    fun confirmedOut(value: String): Boolean = EspnRosterParser.unavailable(value) ||
        value.equals("ruled out", true)

    fun extract(json: JSONObject, teamCode: String): List<Report> {
        val results = mutableListOf<Report>()
        val visited = mutableSetOf<String>()
        fun add(injury: JSONObject) {
            val athlete = injury.optJSONObject("athlete") ?: return
            val name = athlete.optString("displayName", athlete.optString("fullName", "")).trim()
            if (name.isBlank()) return
            val pos = athlete.optJSONObject("position")?.optString("abbreviation", "") ?: ""
            val state = statusLabel(injury)
            if (state.isBlank()) return
            val detail = injury.optJSONObject("details")?.optString("type", "") ?: ""
            val unique = normalizedInjuryName(name) + state.lowercase(Locale.US)
            if (visited.add(unique)) results += Report(name, pos.uppercase(Locale.US), state, detail)
        }
        val groups = json.optJSONArray("injuries") ?: json.optJSONArray("items") ?: return emptyList()
        for (i in 0 until groups.length()) {
            val g = groups.optJSONObject(i) ?: continue
            val team = g.optJSONObject("team")
            val abbrev = team?.optString("abbreviation", "") ?: ""
            val items = g.optJSONArray("injuries") ?: g.optJSONArray("items")
            if (items != null) {
                if (abbrev.isNotBlank() && !sameTeam(abbrev,teamCode)) continue
                for (j in 0 until items.length()) items.optJSONObject(j)?.let(::add)
            } else add(g)
        }
        return results
    }
}

class CurrentWeekEngine(
    private val fetch: (String) -> JSONObject = ::defaultFetchJson,
    private val feedStatus: (String) -> FeedRecord? = { null }
) {
    private val cache = ConcurrentHashMap<String, Pair<Long, WeekProjection>>()
    private val summaryCache = ConcurrentHashMap<String, JSONObject>()
    private val teamCache = ConcurrentHashMap<String, Pair<Long, TeamContext>>()

    private fun loadTeamCached(code: String, snapshot: Boolean, kickoff: String, refresh: Boolean): TeamContext {
        val key = "$code:$snapshot:${kickoff.take(10)}"
        val now = System.currentTimeMillis()
        if (!refresh) teamCache[key]?.takeIf { now - it.first < 4 * 60_000 }?.let { return it.second }
        val loaded = loadTeam(code, snapshot, kickoff)
        if (loaded.roster.isNotEmpty() && loaded.byGame.isNotEmpty()) teamCache[key] = now to loaded
        return loaded
    }

    private fun officialOctober15Snapshot(code: String): List<EspnInjuryParser.Report> {
        // Published NFL.com Week 6 Oct 14, 2026. DATED fallback for this specific fixture,
        // not a live inactive report or a generic 2026 injury feed.
        fun report(name: String, pos: String, status: String) = EspnInjuryParser.Report(name, pos, status, "Official Week 6 game status")
        return when (code) {
            "DEN" -> listOf(report("Pat Surtain II", "CB", "Out"),
                report("Talanoa Hufanga", "S", "Out"), report("Riley Moss", "CB", "Questionable"))
            "SEA" -> listOf(report("Zach Charbonnet", "RB", "Out"),
                report("Drake Thomas", "LB", "Out"), report("Chazz Surratt", "LB", "Out"))
            else -> emptyList()
        }
    }

    private data class TeamContext(
        val code: String,
        val roster: List<EspnRosterParser.Athlete>,
        val byGame: List<Map<String, EspnPlayerStatsParser.Line>>,
        val injuries: List<EspnInjuryParser.Report>,
        val injuryStatus: String,
        val warnings: List<String>,
        val form: TeamGameForm = TeamGameForm(code),
        val defensiveBacks: List<String> = emptyList(),
        val rosterNotes: List<String> = emptyList(),
        val shortFinishes: Map<String,Int> = emptyMap()
    )

    private fun getSummary(id: String): JSONObject = summaryCache.computeIfAbsent(id) {
        fetch("https://site.api.espn.com/apis/site/v2/sports/football/nfl/summary?event=$it")
    }

    // ESPN game summaries can be slow: fetch recent game logs concurrently rather than
    // locking the UI for 5–10 sequential HTTP calls. Partial failures are surfaced.
    private fun prefetchSummaries(ids: List<String>, warnings: MutableList<String>): Map<String, JSONObject> {
        if(ids.isEmpty()) return emptyMap()
        val workers = Executors.newFixedThreadPool(minOf(ids.size,4))
        return try {
            val jobs=ids.distinct().associateWith { id -> workers.submit<JSONObject> { getSummary(id) } }
            jobs.mapNotNull { (id, job) ->
                try { id to job.get(23, TimeUnit.SECONDS) }
                catch(e:Exception) { warnings += "ESPN summary $id: ${e.message ?: "timeout"}"; null }
            }.toMap()
        } finally { workers.shutdownNow() }
    }

    private fun loadTeam(code: String, useWeekSixSnapshot: Boolean, kickoff: String): TeamContext {
        val warnings = mutableListOf<String>()
        val path = "https://site.api.espn.com/apis/site/v2/sports/football/nfl/teams/${teamSlug(code)}"
        var positions: Map<String, String> = emptyMap()
        val kickoffAt = runCatching { Instant.parse(kickoff) }.getOrDefault(Instant.now())
        val season = nflSeasonFor(kickoffAt)
        val officialArrivals = RosterTransactions.activeFor(code, kickoffAt)
        val officialDepartures = RosterTransactions.departedFrom(code, kickoffAt)
        val rosterNotes = mutableListOf<String>()
        var dbNames: List<String> = emptyList()
        val fetchedRoster = try {
            val json = fetch("$path/roster")
            val all = mutableMapOf<String, String>()
            val groups = json.optJSONArray("athletes")
            if (groups != null) for (i in 0 until groups.length()) {
                val items = groups.optJSONObject(i)?.optJSONArray("items") ?: continue
                for (j in 0 until items.length()) {
                    val a = items.optJSONObject(j) ?: continue
                    val name = a.optString("displayName", a.optString("fullName", ""))
                    val pos = a.optJSONObject("position")?.optString("abbreviation", "") ?: ""
                    if (name.isNotBlank() && pos.isNotBlank()) all[normalName(name)] = pos.uppercase(Locale.US)
                }
            }
            positions = all
            dbNames = all.entries.filter { it.value in setOf("CB", "DB", "S", "FS", "SS", "SAF") }.map { it.key }
            val parsed = EspnRosterParser.parse(json)
            if (feedStatus("$path/roster")?.state == "STALE CACHE") {
                warnings += "$code: roster is stale; no player game-day availability can be inferred"
                parsed.map { it.copy(status = "Stale cached roster · verify game-day availability", rawStatus = "Unverified cached status") }
            } else parsed
        } catch (e: Exception) { warnings += "$code roster: ${e.message}"; emptyList() }
        val roster = fetchedRoster.filterNot { athlete -> officialDepartures.any { normalName(it.player) == normalName(athlete.name) } }
            .toMutableList()
        officialDepartures.forEach { rosterNotes += "${it.player} moved to ${it.currentTeam} on 2026-10-12 (verified transaction); excluded from former roster." }
        officialArrivals.forEach { transaction ->
            if (roster.none { normalName(it.name) == normalName(transaction.player) }) {
                roster += EspnRosterParser.Athlete(transaction.player, transaction.position,
                    "Official transaction verified · final game-day availability not confirmed", "Active")
                rosterNotes += "Added ${transaction.player} to $code from an official transaction dated 2026-10-12; ESPN roster had not reflected the move."
            } else {
                rosterNotes += "${transaction.player}: $code team membership confirmed by official 2026-10-12 transaction."
            }
        }
        val byGame = mutableListOf<Map<String, EspnPlayerStatsParser.Line>>()
        val shortFinishes=mutableMapOf<String,Int>()
        var form = TeamGameForm(code)
        try {
            val schedule = fetch("$path/schedule?season=$season&seasontype=2")
            val cutoff = runCatching { Instant.parse(kickoff) }.getOrNull()
            val finals = EspnScoringParser.completedGames(schedule, code).filter { game ->
                cutoff == null || runCatching { Instant.parse(game.date) }
                    .recoverCatching { java.time.OffsetDateTime.parse(game.date).toInstant() }
                    .getOrNull()?.isBefore(cutoff) == true
            }
            val summaries=prefetchSummaries(finals.map { it.id },warnings)
            val verifiedScores = finals.mapNotNull { game ->
                if (game.teamPoints != null && game.opponentPoints != null)
                    game.teamPoints to game.opponentPoints
                else summaries[game.id]?.let { runCatching { EspnScoringParser.summaryFinalScore(it, code) }.getOrNull() }
            }
            val risks=finals.mapNotNull { g -> summaries[g.id]?.let { summary ->
                TeamRiskParser.read(summary,code,g.espnTeamId)
            } }
            form = TeamGameForm(code, verifiedScores.map { it.first }, verifiedScores.map { it.second },
                TeamRiskMetrics(risks.mapNotNull { it.sacksAllowed },risks.mapNotNull { it.giveaways }))
            if(form.games < 2) warnings += "$code: fewer than two games have verified final scores"
            for (game in finals) {
                val summary=summaries[game.id] ?: continue
                try {
                    ShortYardageParser.rushingTdFinishers(summary,code,game.espnTeamId).forEach { (player,count) ->
                        shortFinishes[player]=(shortFinishes[player] ?: 0)+count
                    }
                    val lines = EspnPlayerStatsParser.boxscore(summary, game.espnTeamId, code)
                    if (lines.isNotEmpty()) byGame += lines
                    else warnings += "$code: box-score labels missing for ${game.id}"
                } catch (e: Exception) { warnings += "$code: game ${game.id}: ${e.message}" }
            }
        } catch (e: Exception) { warnings += "$code schedule: ${e.message}" }

        // After a trade, the CURRENT team roster cannot supply the player's earlier games.
        // Retrieve only pre-transaction stats from his former team. Never mislabel those
        // box scores as games played with the new club.
        officialArrivals.forEach { move ->
            try {
                val oldPath = "https://site.api.espn.com/apis/site/v2/sports/football/nfl/teams/${teamSlug(move.priorTeam)}"
                val oldGames = EspnScoringParser.completedGames(fetch("$oldPath/schedule?season=$season&seasontype=2"), move.priorTeam)
                    .filter { g -> runCatching { Instant.parse(g.date).isBefore(move.effective) }.getOrDefault(false) }
                    .take(5)
                var count = 0
                val oldSummaries=prefetchSummaries(oldGames.map { it.id },warnings)
                oldGames.forEach { g ->
                    val summary = oldSummaries[g.id]
                    val row = if(summary == null) null else runCatching {
                        EspnPlayerStatsParser.boxscore(summary, g.espnTeamId, move.priorTeam)[normalName(move.player)]
                    }.getOrNull()
                    if (row != null && row.sourceCategories > 0) {
                        byGame += mapOf(normalName(move.player) to row); count++
                        if(summary!=null) {
                            val tdCount=ShortYardageParser.rushingTdFinishers(summary,move.priorTeam,g.espnTeamId)[normalName(move.player)] ?: 0
                            shortFinishes[normalName(move.player)]=(shortFinishes[normalName(move.player)] ?: 0)+tdCount
                        }
                    }
                }
                rosterNotes += "${move.player}: recovered $count 2026 pre-trade games with ${move.priorTeam}; historical team attribution preserved."
                if (count == 0) warnings += "${move.player}: previous-team usage unavailable; do not assume zero opportunity"
            } catch(e: Exception) { warnings += "${move.player} pre-trade games: ${e.message}" }
        }

        // League injury feed is a fallback. Never treat an empty list as a clean bill of health.
        var injuries: List<EspnInjuryParser.Report> = emptyList()
        var injuryStatus = "Injury feed unavailable — verify official report"
        for (endpoint in listOf("$path/injuries", "https://site.api.espn.com/apis/site/v2/sports/football/nfl/injuries?team=$code")) {
            try {
                val json = fetch(endpoint)
                val retrieved = EspnInjuryParser.extract(json, code)
                val state = feedStatus(endpoint)?.state
                if (state == "STALE CACHE") {
                    // Show old reports as evidence, but NEVER remove a player based on
                    // an old injury designation whose current validity is unknown.
                    injuries = retrieved.map { it.copy(status = "STALE: ${it.status}") }
                    injuryStatus = "STALE cached ESPN injuries — historical only, not verified current absences"
                } else {
                    injuries = retrieved
                    injuryStatus = if (injuries.isEmpty()) "ESPN injury feed returned no entries — not proof of availability" else "ESPN injury report (not final inactives)"
                }
                if (injuries.isNotEmpty()) break
            } catch (e: Exception) { warnings += "$code injuries: ${e.message?.take(90)}" }
        }
        injuries = injuries.map { item ->
            if (item.position.isBlank()) item.copy(position = positions[normalName(item.name)] ?: "") else item
        }
        if (useWeekSixSnapshot) {
            val official = officialOctober15Snapshot(code)
            // Official published game designations supersede ESPN's often stale generic roster status.
            injuries = (official + injuries).distinctBy { normalizedInjuryName(it.name) }
            injuryStatus = "NFL.com official Week 6 injury designations (published Oct 14, 2026) + ESPN; final inactives unverified"
        }
        return TeamContext(code, roster, byGame, injuries, injuryStatus, warnings, form,
            dbNames, rosterNotes, shortFinishes)
    }

    private fun scoreFor(athlete: EspnRosterParser.Athlete, team: TeamContext, defense: TeamContext): WeekCandidate? {
        val key = normalName(athlete.name)
        val played = team.byGame.mapNotNull { it[key] }.filter { it.sourceCategories > 0 }
        if (played.size < 2) return null // no invented starter role from a team roster
        val recent = played.take(3)
        val avgTargets = recent.sumOf { it.targets }.toDouble() / recent.size
        val avgCarries = recent.sumOf { it.carries }.toDouble() / recent.size
        val seasonTargets = played.sumOf { it.targets }.toDouble() / played.size
        val seasonCarries = played.sumOf { it.carries }.toDouble() / played.size
        val tds = played.sumOf { it.touchdowns }
        val shortTd = team.shortFinishes[key] ?: 0
        val opportunity = when (athlete.position) {
            "RB" -> avgCarries * 1.5 + avgTargets * 2.2
            "WR" -> avgTargets * 3.3
            "TE" -> avgTargets * 3.5
            "QB" -> avgCarries * 1.5 // passing touchdowns aren't QB anytime TDs
            else -> 0.0
        }
        // A few targets/carries in five weeks is not a credible scoring candidate.
        val relevant = when (athlete.position) {
            "RB" -> avgCarries >= 3.0 || avgTargets >= 2.0 || shortTd > 0
            "WR", "TE" -> avgTargets >= 1.5
            "QB" -> avgCarries >= 2.0
            else -> false
        }
        if (!relevant || EspnRosterParser.unavailable(athlete.rawStatus)) return null

        val injury = team.injuries.firstOrNull { normalizedInjuryName(it.name) == normalizedInjuryName(key) }
        if (injury != null && EspnInjuryParser.confirmedOut(injury.status)) return null
        val defendersOut = defense.injuries.filter { EspnInjuryParser.confirmedOut(it.status) }
        val dbOut = defendersOut.count { it.position in setOf("CB", "S", "SAF", "FS", "SS", "DB") }
        val frontOut = defendersOut.count { it.position in setOf("LB", "ILB", "OLB", "MLB", "DE", "DT", "DL", "NT") }
        val defenseEdge = when (athlete.position) {
            "WR", "TE" -> dbOut.coerceAtMost(2) * 2
            "RB", "QB" -> frontOut.coerceAtMost(2) * 2
            else -> 0
        }
        val recentTrend = when (athlete.position) {
            "RB", "QB" -> avgCarries - seasonCarries
            else -> avgTargets - seasonTargets
        }
        val trendScore = (recentTrend * 1.5).coerceIn(-5.0, 5.0)
        // A ranked opportunity index, not a probability. Scoring history is a SMALL component.
        val score = (opportunity.coerceAtMost(55.0) + 16 + tds.coerceAtMost(4) * 2 +
            defenseEdge + trendScore + shortTd.coerceAtMost(2)*4).roundToInt().coerceIn(1, 95)
        val status = if (injury != null) "${injury.status} · ESPN report; check game-day inactives"
            else athlete.status
        val recentYards = recent.sumOf { it.recYards + it.rushYards } / recent.size
        val usage = "Last ${recent.size} played: ${"%.1f".format(Locale.US, avgTargets)} targets/game, " +
            "${"%.1f".format(Locale.US, avgCarries)} carries/game, ~$recentYards yards/game."
        val trendLabel = if (recentTrend > 1.0) " Recent opportunity increasing." else if (recentTrend < -1.0) " Recent opportunity decreasing." else ""
        val defenseLabel = if (defenseEdge > 0) " ${defense.code}: $dbOut DB and $frontOut front-seven reported unavailable; alignment unverified." else ""
        val goalLineLabel = if(shortTd>0) " $shortTd recorded rushing TD finish(es) from 5 yards or closer; total goal-line carries unavailable." else ""
        val flag = if (injury != null) " Injury report: ${injury.status}." else ""
        return WeekCandidate(athlete.name, team.code, athlete.position, status, score,
            "$usage $tds recorded TDs across ${played.size} played games.$trendLabel$goalLineLabel$defenseLabel$flag",
            played.size, avgTargets, avgCarries, tds, shortTd, recentTrend, athlete.id)
    }

    fun load(game: LiveScheduleGame, force: Boolean = false): WeekProjection {
        val now = System.currentTimeMillis()
        if (!force) cache[game.id]?.let { (time, projection) -> if (now - time < 5 * 60_000) return projection }
        val teams = game.matchup.split(" @ ", " at ", limit = 2)
        if (teams.size != 2) return WeekProjection(game.id, emptyList(), "ESPN", "Cannot identify both teams")
        val executor = Executors.newFixedThreadPool(2)
        val contexts = try {
            val snapshot = game.matchup == "SEA @ DEN" && game.kickoff.startsWith("2026-10-16")
            val tasks = teams.map { team -> executor.submit<TeamContext> { loadTeamCached(team, snapshot, game.kickoff, force) } }
            tasks.mapIndexed { i, f ->
                try { f.get(55, TimeUnit.SECONDS) }
                catch (e: Exception) { TeamContext(teams[i], emptyList(), emptyList(), emptyList(), "Unavailable", listOf(e.message ?: "Timeout")) }
            }
        } finally { executor.shutdownNow() }
        val away = contexts[0]
        val home = contexts[1]
        val notes = contexts.flatMap { defensive ->
            defensive.injuries.filter { EspnInjuryParser.confirmedOut(it.status) && it.position in setOf("CB", "S", "SAF", "FS", "SS", "DB", "LB", "OLB", "ILB", "MLB", "DE", "DT", "DL", "NT") }
                .take(8).map { "${defensive.code}: ${it.name} (${it.position}) — ${it.status}; verify final availability" }
        }
        val candidates = (away.roster.mapNotNull { scoreFor(it, away, home) } +
            home.roster.mapNotNull { scoreFor(it, home, away) })
            .sortedWith(compareByDescending<WeekCandidate> { it.score }.thenByDescending { it.recentTargets + it.recentCarries }.thenBy { it.name })
            .take(10)
        val errors = contexts.flatMap { it.warnings }.take(5)
        val issues = when {
            candidates.isEmpty() -> "No players had sufficient verified recent box-score usage. " + errors.joinToString("; ")
            errors.isNotEmpty() -> "Some sources unavailable: ${errors.joinToString("; ")}"
            else -> null
        }
        val result = WeekProjection(game.id, candidates,
            "ESPN live roster + last 5 final game box scores; opportunity index, NOT TD probability",
            issues, notes,
            contexts.joinToString(" | ") { "${it.code}: ${it.injuryStatus}" },
            contexts.sumOf { it.byGame.size }, Instant.now().toString(),
            contexts.map { it.form },
            contexts.flatMap { c -> c.injuries.map { injury ->
                VerifiedInjury(c.code, injury.name, injury.position, injury.status, c.injuryStatus)
            } },
            contexts.associate { it.code to it.defensiveBacks },
            contexts.flatMap { it.rosterNotes },
            contexts.associate { it.code to it.roster.map { p -> "${p.name} (${p.position})" } }
        )
        if (candidates.isNotEmpty()) cache[game.id] = now to result
        return result
    }
}

/** Maps fixture abbreviations to ESPN endpoint slugs without altering displayed team names. */
internal fun sameTeam(a: String, b: String): Boolean = a.isNotBlank() && b.isNotBlank() && teamSlug(a)==teamSlug(b)
internal fun teamSlug(code: String): String = when (code.uppercase(Locale.US)) {
    "JAC", "JAX" -> "jax"
    "LA", "LAR" -> "lar"
    "WAS", "WSH" -> "wsh"
    else -> code.lowercase(Locale.US)
}

/** NFL's January/February playoff games belong to the previous season year. */
internal fun nflSeasonFor(instant: Instant): Int {
    val local = instant.atZone(java.time.ZoneId.of("America/New_York"))
    return if (local.monthValue <= 2) local.year - 1 else local.year
}
