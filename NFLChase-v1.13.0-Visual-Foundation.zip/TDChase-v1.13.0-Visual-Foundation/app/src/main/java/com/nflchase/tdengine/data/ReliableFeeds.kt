package com.nflchase.tdengine.data

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.time.Instant
import java.util.concurrent.ConcurrentHashMap

/**
 * Validated, last-known-good ESPN response cache. This does NOT make the underlying
 * provider authoritative or turn an old injury report into a final inactive list.
 * Every fallback is labeled with its age. No user data is transmitted by the cache.
 */
data class FeedRecord(
    val category: String,
    val state: String,
    val checkedAt: String,
    val ageMinutes: Long,
    val detail: String
)

object FeedPolicy {
    data class Policy(val freshMillis: Long, val staleMillis: Long, val category: String)
    fun forUrl(url: String): Policy = when {
        url.contains("/injuries") -> Policy(3 * 60_000, 3 * 60 * 60_000, "Injuries")
        url.contains("/scoreboard") -> Policy(2 * 60_000, 8 * 60 * 60_000, "Schedule")
        url.contains("/roster") -> Policy(10 * 60_000, 48 * 60 * 60_000, "Rosters")
        url.contains("/schedule") -> Policy(10 * 60_000, 24 * 60 * 60_000, "Game history")
        url.contains("/summary") -> Policy(60 * 60_000, 21 * 24 * 60 * 60_000L, "Box scores")
        else -> Policy(5 * 60_000, 4 * 60 * 60_000, "Other")
    }
    fun valid(url: String, json: JSONObject): Boolean {
        if (url.contains("/roster")) {
            val groups = json.optJSONArray("athletes") ?: return false
            return groups.length() > 0
        }
        if (url.contains("/scoreboard")) return json.optJSONArray("events") != null
        if (url.contains("/schedule")) return json.optJSONArray("events") != null
        if (url.contains("/summary")) return json.optJSONObject("boxscore") != null ||
            json.optJSONObject("header") != null || json.optJSONArray("scoringPlays") != null
        if (url.contains("/injuries")) return json.optJSONArray("injuries") != null ||
            json.optJSONArray("items") != null || json.optJSONObject("team") != null
        return json.length() > 0
    }
}

class ReliableFeeds(
    private val folder: File,
    private val network: (String) -> String = ::httpRead,
    private val clock: () -> Long = System::currentTimeMillis
) {
    // Internal files storage survives ordinary OS cache eviction. ESPN historical
    // data is never exposed outside the app's sandbox.
    constructor(context: Context): this(File(context.filesDir, "td-chase-espn-v2"))
    init {
        folder.mkdirs()
        val expiry = clock() - 45L * 24 * 60 * 60_000
        folder.listFiles()?.filter { it.isFile && it.lastModified() < expiry }?.forEach { it.delete() }
    }
    private val locks = ConcurrentHashMap<String, Any>()
    private val reports = ConcurrentHashMap<String, FeedRecord>()
    @Volatile private var bypassCacheUntil: Long = 0L

    fun forceRefresh() { bypassCacheUntil = clock() + 75_000L }
    fun health(): List<FeedRecord> = reports.values.sortedWith(compareBy({ it.category }, { it.checkedAt }))
    fun status(url: String): FeedRecord? {
        val key = MessageDigest.getInstance("SHA-256")
            .digest(url.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
        return reports[key]
    }
    fun cacheFiles(): Int = folder.listFiles()?.count { it.isFile && it.extension == "json" } ?: 0

    fun json(url: String): JSONObject = JSONObject(text(url))

    // Active-game summaries must bypass the normal historical box-score TTL.
    // The same validated cache remains available when a live request fails.
    fun urgentText(url: String): String = read(url, true)
    fun text(url: String): String = read(url, false)

    private fun read(url: String, urgent: Boolean): String {
        require(url.startsWith("https://site.api.espn.com/")) { "Unsupported feed host" }
        val key = MessageDigest.getInstance("SHA-256")
            .digest(url.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
        val policy = FeedPolicy.forUrl(url)
        val file = File(folder, "$key.json")
        val mutex = locks.computeIfAbsent(key) { Any() }
        synchronized(mutex) {
            val cached = runCatching {
                if (!file.exists()) null else file.readText().takeIf { data ->
                    FeedPolicy.valid(url, JSONObject(data))
                }
            }.getOrNull()
            val age = if (cached != null) (clock() - file.lastModified()).coerceAtLeast(0L) else Long.MAX_VALUE
            val now = Instant.ofEpochMilli(clock()).toString()
            if (cached != null && age <= policy.freshMillis && !urgent && clock() >= bypassCacheUntil) {
                reports[key] = FeedRecord(policy.category, "RECENT CACHE", now, age / 60_000, "Previously validated")
                return cached
            }
            var failure = "Network unavailable"
            repeat(2) { attempt ->
                try {
                    val response = network(url)
                    if (!FeedPolicy.valid(url, JSONObject(response))) error("Incomplete ${policy.category} response")
                    // Write temporary file first so interrupted writes never replace good data.
                    val tmp = File(folder, "$key.tmp")
                    tmp.writeText(response)
                    if (!tmp.renameTo(file)) {
                        file.writeText(response)
                        tmp.delete()
                    }
                    file.setLastModified(clock())
                    reports[key] = FeedRecord(policy.category, "LIVE", now, 0, "Verified JSON structure")
                    return response
                } catch (e: Exception) {
                    failure = e.message?.take(110) ?: e.javaClass.simpleName
                    if (attempt == 0) {
                        try { Thread.sleep(350) } catch (_: InterruptedException) {
                            Thread.currentThread().interrupt()
                            throw e
                        }
                    }
                }
            }
            if (cached != null && age <= policy.staleMillis) {
                reports[key] = FeedRecord(policy.category, "STALE CACHE", now, age / 60_000,
                    "Last known good response; current status unverified ($failure)")
                return cached
            }
            reports[key] = FeedRecord(policy.category, "FAILED", now, -1, failure)
            error("${policy.category} unavailable: $failure; no usable cached data")
        }
    }
}

private fun httpRead(url: String): String {
    val connection = (URL(url).openConnection() as HttpURLConnection).apply {
        connectTimeout = 5500
        readTimeout = 9000
        requestMethod = "GET"
        setRequestProperty("Accept", "application/json")
        setRequestProperty("User-Agent", "TDChase/1.13.0 (Android; sports statistics)")
    }
    return try {
        val status = connection.responseCode
        if (status !in 200..299) error("ESPN HTTP $status")
        connection.inputStream.bufferedReader().use { it.readText() }
    } finally { connection.disconnect() }
}
