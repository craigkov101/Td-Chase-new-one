"""Offline v1.13 source integrity checks, independent of external ESPN availability."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
src = ROOT / 'app/src/main/java/com/nflchase/tdengine'
main = (src / 'MainActivity.kt').read_text()
ui = (src / 'ChaseDesign.kt').read_text()
client = (src / 'data/LiveTdClient.kt').read_text()
feeds = (src / 'data/ReliableFeeds.kt').read_text()
rules = (src / 'data/VisualRules.kt').read_text()
player = (src / 'data/CurrentWeekEngine.kt').read_text()
build = (ROOT / 'app/build.gradle.kts').read_text()
workflow = (ROOT / '.github/workflows/build-apk.yml').read_text()
checks = {
    'Version is 1.13.0': 'versionName = "1.13.0"' in build,
    'Android Internet permission': 'android.permission.INTERNET' in (ROOT / 'app/src/main/AndroidManifest.xml').read_text(),
    'Dynamic schedule window': 'ScheduleWindow.days(now)' in client,
    'Legacy demo schedule removed from MainActivity': 'LocalDate.of(2026,10,15)' not in main,
    'ESPN disk-backed cache retained': 'td-chase-espn-v2' in feeds,
    'Stale data explicitly marked': 'STALE CACHE' in feeds,
    'Injured/uncertain signals retained': 'PlayerSignalTags' in main and 'STATUS CHECK' in rules,
    'Background simulations retained': 'withContext(Dispatchers.Default)' in main,
    'Data Connections screen retained': 'DATA CONNECTIONS' in main,
    'Unified premium palette': 'object ChaseColors' in ui,
    'Real player cards enabled': 'ChasePlayerCard(' in main,
    'Player drilldown enabled': 'ChaseInsightSheet(' in main,
    'No false TD % in new player cards': 'OPPORTUNITY INDEX' in ui and 'TD Probability' not in ui,
    'Safe optional ESPN athlete headshot': 'athleteId' in player and 'headshots/nfl/players/full/' in ui,
    'Position filters work': 'VisualRules.positionFilters' in main,
    'Live-status badges': 'VisualRules.gameBadge(game.state)' in main,
    'Real metadata only for venue/weather': 'game.venue.isNotBlank()' in main and 'comp?.optJSONObject("venue")' in client,
    'Visual rules unit tests present': (ROOT / 'app/src/test/java/com/nflchase/tdengine/data/VisualRulesTest.kt').exists(),
    'Prior data and integration tests retained': all((ROOT / f'app/src/test/java/com/nflchase/tdengine/data/{x}Test.kt').exists()
         for x in ('ReliableFeeds', 'IntegratedMatchup', 'ScheduleWindow', 'PlayerSignals')),
    'Workflow manually triggered only': 'workflow_dispatch:' in workflow and 'push:' not in workflow,
}
for k,v in checks.items(): print(f"{'PASS' if v else 'FAIL'}: {k}")
if not all(checks.values()): raise SystemExit('Release integrity checks failed')
print(f"PASS: {len(checks)} release-integrity checks")
