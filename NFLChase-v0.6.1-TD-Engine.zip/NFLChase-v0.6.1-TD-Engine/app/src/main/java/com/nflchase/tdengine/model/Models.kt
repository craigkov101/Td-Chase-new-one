package com.nflchase.tdengine.model

data class TdFactors(
    val opportunity: Double, val redZone: Double, val matchup: Double,
    val scheme: Double, val environment: Double, val roleInjury: Double,
    val explosive: Double
)

data class TdCandidate(
    val id: String, val name: String, val team: String, val opponent: String,
    val position: String, val factors: TdFactors, val goalLineShare: Int,
    val redZoneTouches: Int, val recentTd: Int, val reason: String,
    val status: String = "ACTIVE"
) {
    val score: Int get() = ((factors.opportunity*.20 + factors.redZone*.26 + factors.matchup*.20 +
            factors.scheme*.12 + factors.environment*.11 + factors.roleInjury*.06 + factors.explosive*.05)).toInt().coerceIn(0,100)
    val probability: Int get() = (12 + score * .58).toInt().coerceIn(8,72)
}

data class GameCard(val id:String, val away:String, val home:String, val kickoff:String, val environment:Int, val script:String, val candidates:List<TdCandidate>)

data class PredictionSnapshot(val playerId:String,val gameId:String,val score:Int,val probability:Int,val factors:TdFactors,val createdAt:Long,val resultTd:Boolean?=null)
