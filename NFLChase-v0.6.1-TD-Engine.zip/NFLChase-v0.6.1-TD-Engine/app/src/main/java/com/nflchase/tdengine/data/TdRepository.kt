package com.nflchase.tdengine.data

import com.nflchase.tdengine.model.*

/** Single source of truth. Replace DemoFeed with live nflverse/injury/environment adapters later. */
class TdRepository {
    private fun c(id:String,n:String,t:String,o:String,p:String,a:Double,b:Double,m:Double,s:Double,e:Double,r:Double,x:Double,g:Int,z:Int,rt:Int,why:String)=
        TdCandidate(id,n,t,o,p,TdFactors(a,b,m,s,e,r,x),g,z,rt,why)

    fun games(): List<GameCard> = listOf(
        GameCard("JAC-CIN","JAC","CIN","Sun 1:00 PM",82,"CIN skill players gain TD equity if game stays competitive.", listOf(
            c("cin1","Ja'Marr Chase","CIN","JAC","WR",94.0,92.0,84.0,91.0,82.0,95.0,91.0,24,7,2,"Elite target dominance plus strong scoring-area role."),
            c("cin2","Chase Brown","CIN","JAC","RB",88.0,95.0,82.0,86.0,82.0,92.0,78.0,61,10,2,"Goal-line workload drives the profile."),
            c("jac1","Brian Thomas Jr.","JAC","CIN","WR",86.0,80.0,79.0,84.0,78.0,90.0,94.0,11,5,1,"Explosive scoring path with strong route role."))),
        GameCard("NE-BUF","NE","BUF","Sun 1:00 PM",88,"BUF projects for repeated red-zone possessions.", listOf(
            c("buf1","James Cook","BUF","NE","RB",91.0,93.0,87.0,88.0,90.0,94.0,83.0,55,9,3,"High-value rushing role in a strong team scoring environment."),
            c("buf2","Josh Allen","BUF","NE","QB",89.0,96.0,86.0,95.0,90.0,97.0,92.0,42,8,2,"QB rushing TD profile only; designed/goal-line rushing matters."))),
        GameCard("GB-TB","GB","TB","Sun 1:00 PM",79,"Balanced scoring environment with multiple viable red-zone paths.", listOf(
            c("gb1","Josh Jacobs","GB","TB","RB",92.0,94.0,78.0,90.0,80.0,95.0,80.0,63,11,2,"Workhorse role and concentrated goal-line share."),
            c("tb1","Mike Evans","TB","GB","WR",84.0,91.0,80.0,89.0,79.0,92.0,88.0,18,7,2,"End-zone usage keeps TD ceiling high.")))
    )
    fun allCandidates() = games().flatMap { it.candidates }.filter { it.status == "ACTIVE" }.sortedByDescending { it.score }
}
