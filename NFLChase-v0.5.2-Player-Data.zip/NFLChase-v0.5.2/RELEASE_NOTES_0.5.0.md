# NFL Chase v0.5.0 — Adaptive

- Upcoming-only command center: completed games are retained for learning but hidden from the slate.
- Model scores are explicitly labeled projections; no silent 10-10 placeholder is used.
- Score projections use recent offense, season offense, opponent defense, team strength, home field and weather.
- Injury hard gate: OUT, IR, inactive and doubtful players are excluded from generated prop targets.
- Questionable / limited / DNP statuses reduce confidence and remain visible in rationale/injury board.
- Completed games settle preserved pregame score predictions and feed capped model-weight learning.
- Completed player outcomes settle saved prop predictions and calibrate market-specific projection bias.
- Model Lab continues to expose learned-game count, prop samples, error and calibration rather than claiming learning without measurements.
- New NFL Chase launcher artwork.

Data remains best-effort from public sources. Missing information is not fabricated.
