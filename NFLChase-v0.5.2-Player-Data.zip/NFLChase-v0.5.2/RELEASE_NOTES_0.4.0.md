# NFL Chase v0.4.0 — Live Data Reliability

- Hardened live ESPN scoreboard loading with three independent fallbacks (date range, full season, default scoreboard).
- Changed network identity to a browser-compatible Android user agent.
- Prevents a single failed scoreboard endpoint from blanking the entire dashboard.
- Full-season fallback is filtered locally to relevant recent/upcoming games.
- Retains live schedules, recent box scores, player usage, injuries, game scripts, defensive allowances, prop board, tracking, builder, calibration and data-health logic from v0.3.
- Version bumped to 0.4.0.

Data is best-effort and missing fields are not fabricated. NFL Chase reports partial coverage when a source does not supply a metric.
