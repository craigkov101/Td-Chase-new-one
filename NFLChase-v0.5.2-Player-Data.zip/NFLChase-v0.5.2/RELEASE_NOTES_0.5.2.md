# NFL Chase v0.5.2 — Player Data Pipeline

- Adds nflverse current-season weekly player statistics as the primary player-profile feed.
- Keeps ESPN box-score parsing as a fallback rather than the only player-stat source.
- Builds QB/RB/WR/TE usage profiles from the latest four games.
- Data Health now reports the number of nflverse player rows received.
- Keeps upcoming-slate filtering, injury gating, projection labeling, and adaptive postgame learning.
- Missing player data is not fabricated.
