package com.ckz.nflchase.model

import com.ckz.nflchase.data.*
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.round
import kotlin.math.roundToInt
import kotlin.math.sqrt

class NflScoringModel {
    fun teamForm(team: String, schedule: List<NflGame>): TeamForm {
        val finals = schedule.filter { it.status == GameStatus.FINAL && (it.home.abbreviation == team || it.away.abbreviation == team) }
            .sortedBy { it.kickoff }
        if (finals.isEmpty()) return TeamForm(team, 0, 0, 0, 22.8, 22.8, 22.8, 22.8, 7.0)

        var wins = 0
        var losses = 0
        var pf = 0.0
        var pa = 0.0
        var homeGames = 0
        var roadGames = 0
        val scoredList = mutableListOf<Double>()
        finals.forEach { g ->
            val isHome = g.home.abbreviation == team
            if (isHome) homeGames++ else roadGames++
            val scored = (if (isHome) g.home.score else g.away.score) ?: 0
            val allowed = (if (isHome) g.away.score else g.home.score) ?: 0
            pf += scored
            pa += allowed
            scoredList += scored.toDouble()
            if (scored > allowed) wins++ else if (scored < allowed) losses++
        }
        val recent = finals.takeLast(5)
        val recentPf = recent.map { if (it.home.abbreviation == team) it.home.score ?: 0 else it.away.score ?: 0 }.average()
        val recentPa = recent.map { if (it.home.abbreviation == team) it.away.score ?: 0 else it.home.score ?: 0 }.average()
        return TeamForm(
            team = team,
            games = finals.size,
            wins = wins,
            losses = losses,
            pointsForAvg = pf / finals.size,
            pointsAgainstAvg = pa / finals.size,
            recentPointsForAvg = recentPf,
            recentPointsAgainstAvg = recentPa,
            scoringStdDev = stdDev(scoredList),
            homeGames = homeGames,
            roadGames = roadGames
        )
    }

    fun projectGame(game: NflGame, homeForm: TeamForm, awayForm: TeamForm, weights: ModelWeights): GameScript {
        val coreWeight = weights.recentOffense + weights.seasonOffense + weights.opponentDefense
        fun rawScore(off: TeamForm, def: TeamForm, home: Boolean): Double {
            val blended = (
                off.recentPointsForAvg * weights.recentOffense +
                    off.pointsForAvg * weights.seasonOffense +
                    def.recentPointsAgainstAvg * weights.opponentDefense
                ) / max(0.01, coreWeight)
            val strength = (off.winPct - .5) * 5.0 * weights.winStrength
            return blended + strength + if (home) weights.homeField else 0.0
        }

        val weatherPenalty = when {
            game.indoor == true -> 0.0
            game.weather?.isAdverse == true -> 1.6
            else -> 0.0
        }
        val homeMean = (rawScore(homeForm, awayForm, true) - weatherPenalty).coerceIn(10.0, 38.0)
        val awayMean = (rawScore(awayForm, homeForm, false) - weatherPenalty).coerceIn(10.0, 38.0)
        val homeScore = homeMean.roundToInt()
        val awayScore = awayMean.roundToInt()
        val total = homeScore + awayScore
        val margin = homeScore - awayScore
        val environment = ((total - 34) * 2.25 + 48 - weatherPenalty * 4).roundToInt().coerceIn(25, 96)
        val pace = ((total - 32) * 2.0 + 43).roundToInt().coerceIn(28, 94)

        val homePassLean = passLeanForMargin(margin, total, game.weather)
        val awayPassLean = passLeanForMargin(-margin, total, game.weather)
        val homeRunLean = (100 - homePassLean).coerceIn(25, 70)
        val awayRunLean = (100 - awayPassLean).coerceIn(25, 70)

        val sample = min(homeForm.games, awayForm.games)
        val combinedSd = max(6.0, (homeForm.scoringStdDev + awayForm.scoringStdDev) / 2.0)
        val volatility = (combinedSd * 5.0 + if (abs(margin) <= 3) 7 else 0 + if (game.weather?.isAdverse == true) 5 else 0)
            .roundToInt().coerceIn(25, 92)
        val confidence = (58 + min(22, sample * 3) - volatility * .13 - if (sample < 3) 8 else 0)
            .roundToInt().coerceIn(44, 90)

        val homeBand = max(5.5, homeForm.scoringStdDev.takeIf { it > 0 } ?: 7.0)
        val awayBand = max(5.5, awayForm.scoringStdDev.takeIf { it > 0 } ?: 7.0)
        val homeLow = (homeMean - homeBand * .82).roundToInt().coerceAtLeast(3)
        val homeHigh = (homeMean + homeBand * .82).roundToInt().coerceAtMost(45)
        val awayLow = (awayMean - awayBand * .82).roundToInt().coerceAtLeast(3)
        val awayHigh = (awayMean + awayBand * .82).roundToInt().coerceAtMost(45)
        val totalLow = homeLow + awayLow
        val totalHigh = homeHigh + awayHigh
        val closeGameScore = (92 - abs(margin) * 5 - max(0, volatility - 50) * .18).roundToInt().coerceIn(20, 92)
        val shootoutScore = (environment * .78 + pace * .22 + max(0, totalHigh - 50) * .8).roundToInt().coerceIn(18, 96)

        val label = when {
            total >= 52 && abs(margin) <= 6 -> "Shootout / concentrated volume"
            total >= 49 -> "High-scoring environment"
            abs(margin) >= 10 -> if (margin > 0) "Home control / away pass chase" else "Road control / home pass chase"
            total <= 39 -> "Lower-volume possession game"
            else -> "Balanced script"
        }
        val drivers = buildList {
            add("Recent offense: ${fmt(homeForm.recentPointsForAvg)} ${game.home.abbreviation} / ${fmt(awayForm.recentPointsForAvg)} ${game.away.abbreviation}")
            add("Recent points allowed: ${fmt(homeForm.recentPointsAgainstAvg)} / ${fmt(awayForm.recentPointsAgainstAvg)}")
            add("Expected score range: ${game.away.abbreviation} $awayLow-$awayHigh • ${game.home.abbreviation} $homeLow-$homeHigh")
            if (game.indoor == true) add("Indoor venue removes wind/rain variance")
            game.weather?.takeIf { it.outdoor && it.summary.isNotBlank() }?.let { add("Weather: ${it.summary}${it.temperatureF?.let { t -> " • ${t}°F" } ?: ""}${it.windMph?.let { w -> " • ${w} mph" } ?: ""}") }
            if (game.weather?.isAdverse == true) add("Adverse outdoor conditions reduce deep passing confidence")
            if (abs(margin) >= 7) add("Projected margin creates second-half role pressure")
            if (total >= 48) add("Higher scoring environment supports more TD and receiving opportunity")
        }
        val summary = if (margin >= 0) {
            "${game.home.abbreviation} projects to control $homeScore-$awayScore. ${game.away.abbreviation} gets the stronger pass-volume chase path."
        } else {
            "${game.away.abbreviation} projects ahead $awayScore-$homeScore. ${game.home.abbreviation} gets the stronger pass-volume chase path."
        }
        return GameScript(
            gameId = game.id,
            awayScore = awayScore,
            homeScore = homeScore,
            total = total,
            margin = margin,
            awayLow = awayLow,
            awayHigh = awayHigh,
            homeLow = homeLow,
            homeHigh = homeHigh,
            totalLow = totalLow,
            totalHigh = totalHigh,
            closeGameScore = closeGameScore,
            shootoutScore = shootoutScore,
            paceScore = pace,
            environmentScore = environment,
            volatilityScore = volatility,
            passLeanHome = homePassLean,
            passLeanAway = awayPassLean,
            runLeanHome = homeRunLean,
            runLeanAway = awayRunLean,
            confidence = confidence,
            label = label,
            summary = summary,
            drivers = drivers
        )
    }

    fun buildUsageProfiles(team: String, stats: List<PlayerGameStat>): List<PlayerUsageProfile> {
        val teamStats = stats.filter { it.team == team }
        val gameIds = teamStats.map { it.gameId }.distinct()
        if (gameIds.isEmpty()) return emptyList()

        val teamRushByGame = gameIds.associateWith { gid -> teamStats.filter { it.gameId == gid }.sumOf { it.rushAttempts } }
        val teamTargetsByGame = gameIds.associateWith { gid -> teamStats.filter { it.gameId == gid }.sumOf { it.targets } }
        val players = teamStats.groupBy { it.athleteId }

        return players.mapNotNull { (athleteId, entries) ->
            val latest = entries.lastOrNull() ?: return@mapNotNull null
            val perGame = gameIds.map { gid -> entries.firstOrNull { it.gameId == gid } ?: zeroStat(gid, latest) }
            val averages = PropType.entries.associateWith { p -> perGame.map { statValue(it, p) }.averageOrZero() }
            val recent = perGame.takeLast(min(3, perGame.size))
            val recentAverages = PropType.entries.associateWith { p -> recent.map { statValue(it, p) }.averageOrZero() }
            val floors = PropType.entries.associateWith { p -> percentile(perGame.map { statValue(it, p) }, .20) }
            val ceilings = PropType.entries.associateWith { p -> percentile(perGame.map { statValue(it, p) }, .80) }
            val recentValues = PropType.entries.associateWith { p -> perGame.takeLast(5).map { statValue(it, p) } }

            fun shareFor(gid: String, type: String): Double {
                val player = perGame.first { it.gameId == gid }
                return if (type == "rush") {
                    val total = teamRushByGame[gid] ?: 0.0
                    if (total > 0) player.rushAttempts / total else 0.0
                } else {
                    val total = teamTargetsByGame[gid] ?: 0.0
                    if (total > 0) player.targets / total else 0.0
                }
            }
            val carryShares = gameIds.map { shareFor(it, "rush") }
            val targetShares = gameIds.map { shareFor(it, "target") }
            val carryShare = carryShares.averageOrZero()
            val targetShare = targetShares.averageOrZero()
            val recentCarryShare = carryShares.takeLast(min(3, carryShares.size)).averageOrZero()
            val recentTargetShare = targetShares.takeLast(min(3, targetShares.size)).averageOrZero()

            val oppSeries = perGame.map { opportunityValue(it, latest.position) }
            val oppAvg = oppSeries.averageOrZero()
            val recentOpp = oppSeries.takeLast(min(3, oppSeries.size)).averageOrZero()
            val trendPct = if (oppAvg > .1) ((recentOpp - oppAvg) / oppAvg * 100.0).coerceIn(-45.0, 60.0) else 0.0
            val consistency = consistencyScore(oppSeries)
            val stability = roleStabilityScore(oppSeries)
            val tdRate = perGame.map { it.rushTds + it.receivingTds }.averageOrZero()
            val role = roleLabel(latest.position, carryShare, targetShare, averages[PropType.PASS_ATTEMPTS] ?: 0.0)

            val totalTargets = perGame.sumOf { it.targets }
            val totalRec = perGame.sumOf { it.receptions }
            val totalRecYards = perGame.sumOf { it.receivingYards }
            val totalCarries = perGame.sumOf { it.rushAttempts }
            val totalRushYards = perGame.sumOf { it.rushYards }
            val totalPassAtt = perGame.sumOf { it.passAttempts }
            val totalComp = perGame.sumOf { it.passCompletions }
            val totalPassYards = perGame.sumOf { it.passYards }
            val catchRate = safeRate(totalRec, totalTargets)
            val ypt = safeRate(totalRecYards, totalTargets)
            val ypr = safeRate(totalRecYards, totalRec)
            val ypc = safeRate(totalRushYards, totalCarries)
            val compPct = safeRate(totalComp, totalPassAtt)
            val ypa = safeRate(totalPassYards, totalPassAtt)
            val efficiency = efficiencyScore(latest.position, ypc, ypt, catchRate, compPct, ypa)

            PlayerUsageProfile(
                athleteId = athleteId,
                name = latest.name,
                team = team,
                position = latest.position,
                headshotUrl = latest.headshotUrl,
                games = gameIds.size,
                averages = averages,
                recentAverages = recentAverages,
                floors = floors,
                ceilings = ceilings,
                recentValues = recentValues,
                targetShare = targetShare,
                recentTargetShare = recentTargetShare,
                carryShare = carryShare,
                recentCarryShare = recentCarryShare,
                usageTrendPct = trendPct,
                consistencyScore = consistency,
                roleStabilityScore = stability,
                efficiencyScore = efficiency,
                roleLabel = role,
                opportunitiesPerGame = oppAvg,
                opportunityFloor = percentile(oppSeries, .20),
                opportunityCeiling = percentile(oppSeries, .80),
                touchdownRate = tdRate,
                catchRate = catchRate,
                yardsPerTarget = ypt,
                yardsPerReception = ypr,
                yardsPerCarry = ypc,
                completionPct = compPct,
                passYardsPerAttempt = ypa
            )
        }.filter { profile ->
            profile.position in setOf(PositionGroup.QB, PositionGroup.RB, PositionGroup.WR, PositionGroup.TE) && profile.opportunitiesPerGame >= 1.0
        }.sortedByDescending { it.opportunitiesPerGame }
    }

    fun profilesFromLeaders(team: String, leaders: List<PlayerLeader>, seasonGames: Int): List<PlayerUsageProfile> {
        val games = max(1, seasonGames)
        return leaders.groupBy { it.athleteId }.mapNotNull { (id, rows) ->
            val first = rows.firstOrNull() ?: return@mapNotNull null
            val avgs = mutableMapOf<PropType, Double>()
            rows.forEach { row ->
                val normalized = normalize(row.category)
                val prop = when {
                    normalized.contains("passingyards") -> PropType.PASS_YARDS
                    normalized.contains("passingtouchdowns") -> PropType.PASS_TDS
                    normalized.contains("passingattempts") -> PropType.PASS_ATTEMPTS
                    normalized.contains("completions") -> PropType.PASS_COMPLETIONS
                    normalized.contains("rushingyards") -> PropType.RUSH_YARDS
                    normalized.contains("rushingattempts") || normalized.contains("carries") -> PropType.RUSH_ATTEMPTS
                    normalized.contains("receivingyards") -> PropType.RECEIVING_YARDS
                    normalized.contains("receptions") -> PropType.RECEPTIONS
                    else -> null
                }
                if (prop != null) avgs[prop] = row.value / games
            }
            if (avgs.isEmpty()) return@mapNotNull null
            val complete = PropType.entries.associateWith { avgs[it] ?: 0.0 }
            PlayerUsageProfile(
                athleteId = id,
                name = first.name,
                team = team,
                position = first.position,
                headshotUrl = first.headshotUrl,
                games = games,
                averages = complete,
                recentAverages = complete,
                floors = PropType.entries.associateWith { (avgs[it] ?: 0.0) * .72 },
                ceilings = PropType.entries.associateWith { (avgs[it] ?: 0.0) * 1.28 },
                recentValues = PropType.entries.associateWith { listOf(avgs[it] ?: 0.0) },
                consistencyScore = 52,
                roleStabilityScore = 50,
                efficiencyScore = 50,
                roleLabel = when (first.position) {
                    PositionGroup.QB -> "Primary QB"
                    PositionGroup.RB -> "Backfield leader"
                    PositionGroup.WR, PositionGroup.TE -> "Target leader"
                    else -> "Primary role"
                },
                opportunitiesPerGame = when (first.position) {
                    PositionGroup.QB -> avgs[PropType.PASS_ATTEMPTS] ?: 30.0
                    PositionGroup.RB -> avgs[PropType.RUSH_ATTEMPTS] ?: 10.0
                    else -> avgs[PropType.RECEPTIONS]?.times(1.5) ?: 4.0
                }
            )
        }
    }

    fun buildDefenseProfile(team: String, gameIds: List<String>, statsByGame: Map<String, List<PlayerGameStat>>): DefenseProfile {
        if (gameIds.isEmpty()) return DefenseProfile(team, 0)
        val perGame = gameIds.mapNotNull { gid ->
            val opponents = statsByGame[gid].orEmpty().filter { it.team != team }
            if (opponents.isEmpty()) null else DefenseGame(
                passYards = opponents.maxOfOrNull { it.passYards } ?: 0.0,
                completions = opponents.sumOf { it.passCompletions },
                passAttempts = opponents.sumOf { it.passAttempts },
                passTds = opponents.sumOf { it.passTds },
                rushYards = opponents.sumOf { it.rushYards },
                rushAttempts = opponents.sumOf { it.rushAttempts },
                receptions = opponents.sumOf { it.receptions },
                touchdowns = opponents.sumOf { it.rushTds + it.receivingTds }
            )
        }
        if (perGame.isEmpty()) return DefenseProfile(team, 0)

        val byPosition = listOf(PositionGroup.RB, PositionGroup.WR, PositionGroup.TE).associateWith { pos ->
            val rows = gameIds.mapNotNull { gid ->
                val players = statsByGame[gid].orEmpty().filter { it.team != team && it.position == pos }
                if (players.isEmpty()) null else PositionGame(
                    rushAttempts = players.sumOf { it.rushAttempts },
                    rushYards = players.sumOf { it.rushYards },
                    receptions = players.sumOf { it.receptions },
                    receivingYards = players.sumOf { it.receivingYards },
                    touchdowns = players.sumOf { it.rushTds + it.receivingTds }
                )
            }
            PositionAllowance(
                position = pos,
                games = rows.size,
                rushAttemptsAvg = rows.map { it.rushAttempts }.averageOrZero(),
                rushYardsAvg = rows.map { it.rushYards }.averageOrZero(),
                receptionsAvg = rows.map { it.receptions }.averageOrZero(),
                receivingYardsAvg = rows.map { it.receivingYards }.averageOrZero(),
                touchdownsAvg = rows.map { it.touchdowns }.averageOrZero()
            )
        }

        return DefenseProfile(
            team = team,
            games = perGame.size,
            passYardsAllowedAvg = perGame.map { it.passYards }.averageOrZero(),
            completionsAllowedAvg = perGame.map { it.completions }.averageOrZero(),
            passAttemptsAllowedAvg = perGame.map { it.passAttempts }.averageOrZero(),
            passTdsAllowedAvg = perGame.map { it.passTds }.averageOrZero(),
            rushYardsAllowedAvg = perGame.map { it.rushYards }.averageOrZero(),
            rushAttemptsAllowedAvg = perGame.map { it.rushAttempts }.averageOrZero(),
            receptionsAllowedAvg = perGame.map { it.receptions }.averageOrZero(),
            touchdownsAllowedAvg = perGame.map { it.touchdowns }.averageOrZero(),
            byPosition = byPosition
        )
    }

    fun buildTargets(
        game: NflGame,
        script: GameScript,
        homeForm: TeamForm,
        awayForm: TeamForm,
        homeProfiles: List<PlayerUsageProfile>,
        awayProfiles: List<PlayerUsageProfile>,
        homeDefense: DefenseProfile?,
        awayDefense: DefenseProfile?,
        injuries: List<InjuryNote>,
        marketLearning: Map<PropType, MarketLearningSummary>
    ): List<PropTarget> {
        return buildTeamTargets(game, script, game.home.abbreviation, game.away.abbreviation, awayForm, awayDefense, homeProfiles, injuries, true, marketLearning) +
            buildTeamTargets(game, script, game.away.abbreviation, game.home.abbreviation, homeForm, homeDefense, awayProfiles, injuries, false, marketLearning)
    }

    private fun buildTeamTargets(
        game: NflGame,
        script: GameScript,
        team: String,
        opponent: String,
        opponentForm: TeamForm,
        opponentDefense: DefenseProfile?,
        profiles: List<PlayerUsageProfile>,
        injuries: List<InjuryNote>,
        home: Boolean,
        marketLearning: Map<PropType, MarketLearningSummary>
    ): List<PropTarget> {
        if (profiles.isEmpty()) return emptyList()
        val passLean = if (home) script.passLeanHome else script.passLeanAway
        val runLean = if (home) script.runLeanHome else script.runLeanAway
        val injuryById = injuries.filter { it.athleteId != null }.associateBy { it.athleteId!! }
        val injuryByName = injuries.associateBy { it.playerName.lowercase() }
        val targets = mutableListOf<PropTarget>()

        profiles.forEach { profile ->
            val playerInjury = injuryById[profile.athleteId] ?: injuryByName[profile.name.lowercase()]
            // Availability is a hard gate. OUT/IR/inactive/doubtful players cannot leak into props or scripts.
            if (isUnavailable(playerInjury)) return@forEach
            marketsFor(profile).forEach marketLoop@ { prop ->
                val baseAvg = profile.averages[prop] ?: 0.0
                if (!qualifies(prop, baseAvg, profile)) return@marketLoop
                val recentAvg = profile.recentAverages[prop] ?: baseAvg
                val floorBase = profile.floors[prop] ?: baseAvg * .72
                val ceilingBase = profile.ceilings[prop] ?: baseAvg * 1.28
                val learning = marketLearning[prop] ?: MarketLearningSummary(prop)
                val learnedPct = learnedAdjustment(learning)
                val scriptMultiplier = scriptMultiplier(prop, passLean, runLean, script, game.weather)
                val recencyWeight = when {
                    profile.games >= 4 -> .42
                    profile.games >= 2 -> .32
                    else -> 0.0
                }
                val recencyBlend = baseAvg * (1.0 - recencyWeight) + recentAvg * recencyWeight
                val projection = if (prop == PropType.ANYTIME_TD) {
                    val lambda = max(.03, profile.touchdownRate * scriptMultiplier)
                    (1.0 - exp(-lambda)).coerceIn(.03, .82)
                } else {
                    max(0.1, recencyBlend * scriptMultiplier * (1.0 + learnedPct))
                }
                val floor = if (prop == PropType.ANYTIME_TD) 0.0 else max(0.0, floorBase * scriptMultiplier)
                val ceiling = if (prop == PropType.ANYTIME_TD) 1.0 else max(projection, ceilingBase * scriptMultiplier)

                val role = roleScore(profile, prop)
                val volume = volumeScore(profile, prop)
                val recentUsage = (65 + profile.usageTrendPct * .52).roundToInt().coerceIn(38, 96)
                val teamEnvMatchup = (62 + ((opponentForm.recentPointsAgainstAvg - 21.5) * 2.1).roundToInt()).coerceIn(40, 94)
                val positionalMatchup = defenseMatchupScore(prop, profile.position, opponentDefense)
                val matchup = if (opponentDefense != null && opponentDefense.games > 0) {
                    (teamEnvMatchup * .35 + positionalMatchup * .65).roundToInt().coerceIn(38, 96)
                } else teamEnvMatchup
                val scriptFit = scriptFitScore(prop, passLean, runLean, script, game.weather)
                val consistency = profile.consistencyScore
                val stability = profile.roleStabilityScore
                val efficiency = profile.efficiencyScore
                val opportunity = (role * .30 + volume * .34 + consistency * .16 + stability * .20).roundToInt().coerceIn(35, 97)
                val dataConfidence = (42 + min(40, profile.games * 10) + if (profile.targetShare > 0 || profile.carryShare > 0) 7 else 0)
                    .coerceIn(42, 95)
                val injury = playerInjury
                val injuryPenalty = injuryPenalty(injury)
                val volatility = marketVolatility(prop, consistency, stability)
                val learnedQuality = if (learning.settled >= 8) ((learning.thresholdHitRate - .5) * 14).roundToInt().coerceIn(-5, 5) else 0
                val rawScore = (
                    role * .17 +
                        volume * .18 +
                        scriptFit * .16 +
                        matchup * .16 +
                        recentUsage * .09 +
                        consistency * .07 +
                        stability * .07 +
                        efficiency * .05 +
                        dataConfidence * .05
                    ).roundToInt() + learnedQuality
                val samplePenalty = if (profile.games <= 1) 8 else if (profile.games == 2) 4 else 0
                val chase = (rawScore - injuryPenalty - samplePenalty - if (prop == PropType.ANYTIME_TD) 4 else 0).coerceIn(10, 98)
                val confidence = (chase - volatility * .10 + dataConfidence * .055 + stability * .025).roundToInt().coerceIn(20, 95)
                val threshold = suggestedThreshold(prop, projection)
                val (attackOver, attackUnder) = attackBand(prop, projection, volatility, confidence)
                val recentValues = profile.recentValues[prop].orEmpty()
                val recentHitRate = if (recentValues.isEmpty() || prop == PropType.ANYTIME_TD) 0.0 else recentValues.count { it >= attackOver }.toDouble() / recentValues.size
                val matchupDetail = matchupDetail(prop, profile.position, opponentDefense)

                val reasons = buildList {
                    add("${profile.roleLabel}: ${profile.games}-game usage sample • stability $stability/100")
                    when (profile.position) {
                        PositionGroup.RB -> if (profile.carryShare > 0) add("Carry share ${(profile.carryShare * 100).roundToInt()}% (${(profile.recentCarryShare * 100).roundToInt()}% recent) • ${fmt(profile.opportunitiesPerGame)} opp/game")
                        PositionGroup.WR, PositionGroup.TE -> if (profile.targetShare > 0) add("Target share ${(profile.targetShare * 100).roundToInt()}% (${(profile.recentTargetShare * 100).roundToInt()}% recent) • ${fmt(profile.opportunitiesPerGame)} opp/game")
                        PositionGroup.QB -> add("Pass volume ${fmt(profile.averages[PropType.PASS_ATTEMPTS] ?: 0.0)} attempts/game • ${fmt(profile.passYardsPerAttempt)} Y/A")
                        else -> Unit
                    }
                    add("Script fit $scriptFit/100 • ${if (prop in passingMarkets) "$passLean% pass lean" else "$runLean% run lean"}")
                    add("Usage trend ${signed(profile.usageTrendPct)}% • consistency $consistency/100 • efficiency $efficiency/100")
                    add(matchupDetail)
                    if (recentValues.isNotEmpty() && prop != PropType.ANYTIME_TD) add("Recent ${prop.shortLabel}: ${recentValues.joinToString(" • ") { fmt(it) }}")
                    if (learning.settled >= 6) add("Model calibrated on ${learning.settled} settled ${prop.shortLabel} samples (${(learning.thresholdHitRate * 100).roundToInt()}% historical attack-threshold hit)")
                    if (game.weather?.isAdverse == true && prop in passingMarkets) add("Weather downgrade applied to passing/receiving projection")
                    if (injury != null) add("Injury tag: ${injury.status}${injury.detail?.let { " — $it" } ?: ""}")
                }

                targets += PropTarget(
                    id = "${game.id}:${profile.athleteId}:${prop.name}",
                    gameId = game.id,
                    athleteId = profile.athleteId,
                    playerName = profile.name,
                    team = team,
                    opponent = opponent,
                    position = profile.position,
                    propType = prop,
                    modelProjection = roundForProp(prop, projection),
                    suggestedThreshold = threshold,
                    attackOverAt = attackOver,
                    attackUnderAt = attackUnder,
                    floorProjection = roundForProp(prop, floor),
                    ceilingProjection = roundForProp(prop, ceiling),
                    recentValues = recentValues,
                    recentHitRate = recentHitRate,
                    chaseScore = chase,
                    roleScore = role,
                    volumeScore = volume,
                    matchupScore = matchup,
                    scriptScore = scriptFit,
                    recentUsageScore = recentUsage,
                    consistencyScore = consistency,
                    roleStabilityScore = stability,
                    efficiencyScore = efficiency,
                    opportunityScore = opportunity,
                    dataConfidence = dataConfidence,
                    volatility = volatility,
                    confidence = confidence,
                    sampleSize = profile.games,
                    roleLabel = profile.roleLabel,
                    matchupDetail = matchupDetail,
                    marketHistoryCount = learning.settled,
                    learnedAdjustmentPct = learnedPct * 100.0,
                    rationale = reasons,
                    headshotUrl = profile.headshotUrl,
                    injuryStatus = injury?.status
                )
            }
        }
        return targets.distinctBy { "${it.athleteId}:${it.propType}" }
            .sortedWith(compareByDescending<PropTarget> { it.chaseScore }.thenByDescending { it.confidence })
            .take(26)
    }

    fun marketLearning(records: List<PropPredictionRecord>): Map<PropType, MarketLearningSummary> {
        return PropType.entries.associateWith { prop ->
            val settled = records.filter { it.settled && it.actual != null && it.propType == prop }.takeLast(100)
            if (settled.isEmpty()) MarketLearningSummary(prop)
            else {
                val hitRate = settled.count { it.thresholdHit == true }.toDouble() / settled.size
                val mae = settled.map { abs((it.actual ?: 0.0) - it.projection) }.averageOrZero()
                val bias = if (prop == PropType.ANYTIME_TD) {
                    val observed = settled.map { it.actual ?: 0.0 }.averageOrZero()
                    val expected = settled.map { it.projection }.averageOrZero()
                    observed - expected
                } else settled.mapNotNull { it.biasPct }.averageOrZero()
                MarketLearningSummary(prop, settled.size, hitRate, bias, mae)
            }
        }
    }

    fun actualValue(stat: PlayerGameStat, prop: PropType): Double = statValue(stat, prop)

    fun learn(weights: ModelWeights, settled: List<PredictionRecord>): ModelWeights {
        if (settled.isEmpty()) return weights
        val recent = settled.takeLast(40)
        val totalBias = recent.mapNotNull { r ->
            if (r.actualHome == null || r.actualAway == null) null
            else (r.actualHome + r.actualAway) - (r.predictedHome + r.predictedAway)
        }.map { it.toDouble() }.averageOrZero()
        val marginBias = recent.mapNotNull { r ->
            if (r.actualHome == null || r.actualAway == null) null
            else (r.actualHome - r.actualAway) - (r.predictedHome - r.predictedAway)
        }.map { it.toDouble() }.averageOrZero()
        val lr = weights.learningRate
        return weights.copy(
            recentOffense = (weights.recentOffense + totalBias * lr * 0.0035).coerceIn(0.26, 0.44),
            opponentDefense = (weights.opponentDefense + totalBias * lr * 0.0018).coerceIn(0.22, 0.36),
            homeField = (weights.homeField + marginBias * lr * 0.09).coerceIn(0.5, 3.0)
        )
    }

    private fun marketsFor(profile: PlayerUsageProfile): List<PropType> = when (profile.position) {
        PositionGroup.QB -> buildList {
            add(PropType.PASS_YARDS); add(PropType.PASS_COMPLETIONS); add(PropType.PASS_ATTEMPTS); add(PropType.PASS_TDS)
            if ((profile.averages[PropType.RUSH_YARDS] ?: 0.0) >= 10.0) add(PropType.RUSH_YARDS)
            if ((profile.averages[PropType.RUSH_ATTEMPTS] ?: 0.0) >= 3.0) add(PropType.RUSH_ATTEMPTS)
            if (profile.touchdownRate >= .20) add(PropType.ANYTIME_TD)
        }
        PositionGroup.RB -> buildList {
            add(PropType.RUSH_YARDS); add(PropType.RUSH_ATTEMPTS)
            if ((profile.averages[PropType.RECEIVING_YARDS] ?: 0.0) >= 10.0) add(PropType.RECEIVING_YARDS)
            if ((profile.averages[PropType.RECEPTIONS] ?: 0.0) >= 1.2) add(PropType.RECEPTIONS)
            add(PropType.ANYTIME_TD)
        }
        PositionGroup.WR, PositionGroup.TE -> listOf(PropType.RECEIVING_YARDS, PropType.RECEPTIONS, PropType.ANYTIME_TD)
        else -> emptyList()
    }

    private fun qualifies(prop: PropType, avg: Double, profile: PlayerUsageProfile): Boolean = when (prop) {
        PropType.PASS_YARDS -> avg >= 90
        PropType.PASS_COMPLETIONS -> avg >= 8
        PropType.PASS_ATTEMPTS -> avg >= 15
        PropType.PASS_TDS -> avg >= .25
        PropType.RUSH_YARDS -> avg >= 8
        PropType.RUSH_ATTEMPTS -> avg >= 3
        PropType.RECEIVING_YARDS -> avg >= 8
        PropType.RECEPTIONS -> avg >= 1
        PropType.ANYTIME_TD -> profile.touchdownRate >= .10 || profile.opportunitiesPerGame >= 8
    }

    private fun roleScore(profile: PlayerUsageProfile, prop: PropType): Int {
        val shareScore = when {
            prop in setOf(PropType.RUSH_YARDS, PropType.RUSH_ATTEMPTS) -> (profile.carryShare * 105 + 40).roundToInt()
            prop in setOf(PropType.RECEIVING_YARDS, PropType.RECEPTIONS) -> (profile.targetShare * 135 + 46).roundToInt()
            prop in setOf(PropType.PASS_YARDS, PropType.PASS_COMPLETIONS, PropType.PASS_ATTEMPTS, PropType.PASS_TDS) -> if (profile.position == PositionGroup.QB) 91 else 55
            prop == PropType.ANYTIME_TD -> (volumeScore(profile, prop) * .72 + 18).roundToInt()
            else -> 55
        }
        return (shareScore * .78 + profile.roleStabilityScore * .22).roundToInt().coerceIn(42, 97)
    }

    private fun volumeScore(profile: PlayerUsageProfile, prop: PropType): Int {
        val avg = profile.averages[prop] ?: 0.0
        return when (prop) {
            PropType.PASS_YARDS -> scale(avg, 150.0, 315.0)
            PropType.PASS_COMPLETIONS -> scale(avg, 14.0, 27.0)
            PropType.PASS_ATTEMPTS -> scale(avg, 24.0, 41.0)
            PropType.PASS_TDS -> scale(avg, .6, 2.5)
            PropType.RUSH_YARDS -> scale(avg, 30.0, 95.0)
            PropType.RUSH_ATTEMPTS -> scale(avg, 7.0, 20.0)
            PropType.RECEIVING_YARDS -> scale(avg, 25.0, 95.0)
            PropType.RECEPTIONS -> scale(avg, 2.5, 7.5)
            PropType.ANYTIME_TD -> scale(profile.opportunitiesPerGame + profile.touchdownRate * 12, 5.0, 22.0)
        }
    }

    private fun scriptFitScore(prop: PropType, passLean: Int, runLean: Int, script: GameScript, weather: WeatherContext?): Int {
        val weatherPenalty = if (weather?.isAdverse == true && prop in passingMarkets) 9 else 0
        val value = when (prop) {
            in passingMarkets -> 42 + passLean * .55 + if (script.total >= 48) 7 else 0 + if (script.closeGameScore >= 70) 3 else 0
            PropType.RUSH_YARDS, PropType.RUSH_ATTEMPTS -> 44 + runLean * .58 + if (runLean >= 52) 6 else 0
            PropType.ANYTIME_TD -> 38 + script.environmentScore * .49 + script.shootoutScore * .08
            else -> 55.0
        }
        return (value - weatherPenalty).roundToInt().coerceIn(38, 97)
    }

    private fun scriptMultiplier(prop: PropType, passLean: Int, runLean: Int, script: GameScript, weather: WeatherContext?): Double {
        var m = when (prop) {
            PropType.PASS_YARDS, PropType.PASS_COMPLETIONS, PropType.PASS_ATTEMPTS, PropType.RECEIVING_YARDS, PropType.RECEPTIONS -> .88 + passLean / 440.0 + if (script.total >= 49) .035 else 0.0
            PropType.PASS_TDS -> .82 + script.environmentScore / 510.0
            PropType.RUSH_YARDS, PropType.RUSH_ATTEMPTS -> .88 + runLean / 440.0
            PropType.ANYTIME_TD -> .82 + script.environmentScore / 430.0
        }
        if (weather?.isAdverse == true && prop in passingMarkets) m -= .07
        return m.coerceIn(.78, 1.20)
    }

    private fun suggestedThreshold(prop: PropType, projection: Double): Double = when (prop) {
        PropType.ANYTIME_TD -> .5
        PropType.PASS_TDS -> roundToHalf(max(.5, projection * .78))
        PropType.RECEPTIONS, PropType.PASS_COMPLETIONS, PropType.PASS_ATTEMPTS, PropType.RUSH_ATTEMPTS -> roundToHalf(projection * .90)
        else -> roundToHalf(projection * .91)
    }

    private fun attackBand(prop: PropType, projection: Double, volatility: Int, confidence: Int): Pair<Double, Double> {
        if (prop == PropType.ANYTIME_TD) return .5 to .5
        val uncertainty = (0.055 + volatility / 1500.0 + (82 - confidence).coerceAtLeast(0) / 1800.0).coerceIn(.06, .15)
        val over = projection * (1.0 - uncertainty)
        val under = projection * (1.0 + uncertainty)
        return marketRound(prop, over) to marketRound(prop, under)
    }

    private fun marketVolatility(prop: PropType, consistency: Int, stability: Int): Int {
        val base = when (prop) {
            PropType.RECEPTIONS, PropType.RUSH_ATTEMPTS, PropType.PASS_ATTEMPTS, PropType.PASS_COMPLETIONS -> 25
            PropType.PASS_YARDS, PropType.RUSH_YARDS, PropType.RECEIVING_YARDS -> 38
            PropType.PASS_TDS -> 58
            PropType.ANYTIME_TD -> 76
        }
        return (base + (100 - consistency) * .17 + (100 - stability) * .12).roundToInt().coerceIn(20, 90)
    }

    private fun isUnavailable(injury: InjuryNote?): Boolean {
        val s = injury?.status?.lowercase()?.trim().orEmpty()
        return s == "out" || s == "ir" || s.contains("injured reserve") || s.contains("inactive") || s == "doubtful"
    }

    private fun injuryPenalty(injury: InjuryNote?): Int = when {
        isUnavailable(injury) -> 100
        injury?.status?.lowercase()?.contains("questionable") == true -> 18
        injury?.status?.lowercase()?.contains("limited") == true -> 10
        injury?.status?.lowercase()?.contains("dnp") == true -> 16
        else -> 0
    }

    private fun learnedAdjustment(summary: MarketLearningSummary): Double {
        if (summary.settled < 6 || summary.propType == PropType.ANYTIME_TD) return 0.0
        val shrink = min(1.0, summary.settled / 24.0)
        return (summary.meanBiasPct * .28 * shrink).coerceIn(-.06, .06)
    }

    private fun defenseMatchupScore(prop: PropType, position: PositionGroup, defense: DefenseProfile?): Int {
        if (defense == null || defense.games == 0) return 62
        val split = defense.byPosition[position]
        return when (prop) {
            PropType.PASS_YARDS -> scale(defense.passYardsAllowedAvg, 175.0, 310.0)
            PropType.PASS_COMPLETIONS -> scale(defense.completionsAllowedAvg, 15.0, 29.0)
            PropType.PASS_ATTEMPTS -> scale(defense.passAttemptsAllowedAvg, 25.0, 43.0)
            PropType.PASS_TDS -> scale(defense.passTdsAllowedAvg, .5, 2.8)
            PropType.RUSH_YARDS -> if (split != null && split.games > 0 && position == PositionGroup.RB) scale(split.rushYardsAvg, 45.0, 130.0) else scale(defense.rushYardsAllowedAvg, 65.0, 155.0)
            PropType.RUSH_ATTEMPTS -> if (split != null && split.games > 0 && position == PositionGroup.RB) scale(split.rushAttemptsAvg, 11.0, 28.0) else scale(defense.rushAttemptsAllowedAvg, 17.0, 34.0)
            PropType.RECEIVING_YARDS -> if (split != null && split.games > 0) {
                val range = if (position == PositionGroup.TE) 25.0 to 85.0 else if (position == PositionGroup.RB) 15.0 to 65.0 else 75.0 to 190.0
                scale(split.receivingYardsAvg, range.first, range.second)
            } else scale(defense.passYardsAllowedAvg, 175.0, 310.0)
            PropType.RECEPTIONS -> if (split != null && split.games > 0) {
                val range = if (position == PositionGroup.TE) 3.0 to 8.0 else if (position == PositionGroup.RB) 2.0 to 7.0 else 6.0 to 15.0
                scale(split.receptionsAvg, range.first, range.second)
            } else scale(defense.receptionsAllowedAvg, 15.0, 29.0)
            PropType.ANYTIME_TD -> if (split != null && split.games > 0) scale(split.touchdownsAvg, .15, 1.5) else scale(defense.touchdownsAllowedAvg, .5, 3.0)
        }
    }

    private fun matchupDetail(prop: PropType, position: PositionGroup, defense: DefenseProfile?): String {
        if (defense == null || defense.games == 0) return "Opponent matchup uses team scoring environment; position allowance sample unavailable"
        val split = defense.byPosition[position]
        if (split != null && split.games > 0 && position in setOf(PositionGroup.RB, PositionGroup.WR, PositionGroup.TE)) {
            return when (prop) {
                PropType.RUSH_YARDS, PropType.RUSH_ATTEMPTS -> "${defense.team} allows ${fmt(split.rushYardsAvg)} rush yds / ${fmt(split.rushAttemptsAvg)} carries per game to ${position.name}s (${split.games}g split)"
                PropType.RECEIVING_YARDS, PropType.RECEPTIONS -> "${defense.team} allows ${fmt(split.receivingYardsAvg)} rec yds / ${fmt(split.receptionsAvg)} catches per game to ${position.name}s (${split.games}g split)"
                PropType.ANYTIME_TD -> "${defense.team} allows ${fmt(split.touchdownsAvg)} TDs/game to ${position.name}s in ${split.games} recent games"
                else -> "${defense.team} defensive sample: ${defense.games} games"
            }
        }
        return when (prop) {
            PropType.PASS_YARDS -> "${defense.team} allows ${fmt(defense.passYardsAllowedAvg)} passing yards/game (${defense.games}g)"
            PropType.PASS_COMPLETIONS, PropType.RECEPTIONS -> "${defense.team} allows ${fmt(defense.completionsAllowedAvg)} completions/game (${defense.games}g)"
            PropType.PASS_ATTEMPTS -> "${defense.team} faces ${fmt(defense.passAttemptsAllowedAvg)} pass attempts/game (${defense.games}g)"
            PropType.PASS_TDS -> "${defense.team} allows ${fmt(defense.passTdsAllowedAvg)} pass TDs/game (${defense.games}g)"
            PropType.RUSH_YARDS -> "${defense.team} allows ${fmt(defense.rushYardsAllowedAvg)} rushing yards/game (${defense.games}g)"
            PropType.RUSH_ATTEMPTS -> "${defense.team} faces ${fmt(defense.rushAttemptsAllowedAvg)} carries/game (${defense.games}g)"
            PropType.ANYTIME_TD -> "${defense.team} allows ${fmt(defense.touchdownsAllowedAvg)} offensive TDs/game (${defense.games}g)"
            else -> "${defense.team} defensive sample: ${defense.games} games"
        }
    }

    private fun passLeanForMargin(marginFromTeamPerspective: Int, total: Int, weather: WeatherContext?): Int {
        var lean = 50 + if (marginFromTeamPerspective < 0) abs(marginFromTeamPerspective) * 3 else -marginFromTeamPerspective * 2
        if (total >= 48) lean += 6
        if (weather?.isAdverse == true) lean -= 5
        return lean.coerceIn(30, 80)
    }

    private fun opportunityValue(stat: PlayerGameStat, position: PositionGroup): Double = when (position) {
        PositionGroup.QB -> stat.passAttempts + stat.rushAttempts
        PositionGroup.RB -> stat.rushAttempts + stat.targets
        PositionGroup.WR, PositionGroup.TE -> stat.targets + stat.rushAttempts
        else -> stat.rushAttempts + stat.targets
    }

    private fun roleLabel(position: PositionGroup, carryShare: Double, targetShare: Double, passAttempts: Double): String = when (position) {
        PositionGroup.QB -> if (passAttempts >= 24) "Starting QB" else "Low-volume QB"
        PositionGroup.RB -> when {
            carryShare >= .58 -> "Workhorse back"
            carryShare >= .40 -> "Lead back"
            carryShare >= .24 -> "Committee lead"
            else -> "Change-of-pace back"
        }
        PositionGroup.WR, PositionGroup.TE -> when {
            targetShare >= .26 -> "Alpha target"
            targetShare >= .19 -> "Primary target"
            targetShare >= .13 -> "Secondary target"
            else -> "Depth target"
        }
        else -> "Rotation"
    }

    private fun efficiencyScore(position: PositionGroup, ypc: Double, ypt: Double, catchRate: Double, compPct: Double, ypa: Double): Int = when (position) {
        PositionGroup.QB -> ((scale(ypa, 5.5, 9.0) * .58) + (scale(compPct, .56, .72) * .42)).roundToInt().coerceIn(40, 96)
        PositionGroup.RB -> ((scale(ypc, 3.2, 5.8) * .68) + (if (ypt > 0) scale(ypt, 4.0, 9.0) * .32 else 55.0)).roundToInt().coerceIn(40, 96)
        PositionGroup.WR, PositionGroup.TE -> ((scale(ypt, 5.0, 11.5) * .62) + (scale(catchRate, .50, .80) * .38)).roundToInt().coerceIn(40, 96)
        else -> 50
    }

    private fun statValue(stat: PlayerGameStat, prop: PropType): Double = when (prop) {
        PropType.PASS_YARDS -> stat.passYards
        PropType.PASS_COMPLETIONS -> stat.passCompletions
        PropType.PASS_ATTEMPTS -> stat.passAttempts
        PropType.PASS_TDS -> stat.passTds
        PropType.RUSH_YARDS -> stat.rushYards
        PropType.RUSH_ATTEMPTS -> stat.rushAttempts
        PropType.RECEIVING_YARDS -> stat.receivingYards
        PropType.RECEPTIONS -> stat.receptions
        PropType.ANYTIME_TD -> if (stat.rushTds + stat.receivingTds > 0) 1.0 else 0.0
    }

    private fun zeroStat(gameId: String, template: PlayerGameStat) = PlayerGameStat(
        gameId = gameId,
        athleteId = template.athleteId,
        name = template.name,
        team = template.team,
        position = template.position,
        headshotUrl = template.headshotUrl
    )

    private fun consistencyScore(values: List<Double>): Int {
        if (values.size < 2) return 52
        val mean = values.averageOrZero()
        if (mean <= .1) return 45
        val cv = stdDev(values) / mean
        return (92 - cv * 58).roundToInt().coerceIn(35, 94)
    }

    private fun roleStabilityScore(values: List<Double>): Int {
        if (values.size < 2) return 50
        val mean = values.averageOrZero()
        if (mean <= .1) return 42
        val cv = stdDev(values) / mean
        val recent = values.takeLast(min(3, values.size)).averageOrZero()
        val drift = abs(recent - mean) / mean
        return (94 - cv * 50 - drift * 24).roundToInt().coerceIn(35, 96)
    }

    private fun percentile(values: List<Double>, p: Double): Double {
        if (values.isEmpty()) return 0.0
        val sorted = values.sorted()
        if (sorted.size == 1) return sorted.first()
        val idx = ((sorted.size - 1) * p).roundToInt().coerceIn(0, sorted.lastIndex)
        return sorted[idx]
    }

    private fun stdDev(values: List<Double>): Double {
        if (values.size < 2) return 0.0
        val mean = values.average()
        return sqrt(values.sumOf { (it - mean).pow(2) } / values.size)
    }

    private fun safeRate(n: Double, d: Double): Double = if (d <= 0.0) 0.0 else n / d

    private fun scale(v: Double, low: Double, high: Double): Int {
        if (high <= low) return 50
        return (45 + ((v - low) / (high - low)).coerceIn(0.0, 1.0) * 50).roundToInt()
    }

    private fun roundForProp(prop: PropType, v: Double): Double = if (prop == PropType.ANYTIME_TD) round(v * 100.0) / 100.0 else round(v * 10.0) / 10.0
    private fun marketRound(prop: PropType, v: Double): Double = when (prop) {
        PropType.PASS_TDS, PropType.RECEPTIONS, PropType.PASS_COMPLETIONS, PropType.PASS_ATTEMPTS, PropType.RUSH_ATTEMPTS -> roundToHalf(v)
        PropType.ANYTIME_TD -> .5
        else -> roundToHalf(v)
    }
    private fun roundToHalf(v: Double): Double = round(v * 2.0) / 2.0
    private fun normalize(s: String) = s.lowercase().replace("_", "").replace("-", "").replace("/", "").replace(" ", "")
    private fun fmt(v: Double) = "%.1f".format(v)
    private fun signed(v: Double) = if (v >= 0) "+%.0f".format(v) else "%.0f".format(v)
    private fun List<Double>.averageOrZero() = if (isEmpty()) 0.0 else average()

    private data class DefenseGame(
        val passYards: Double,
        val completions: Double,
        val passAttempts: Double,
        val passTds: Double,
        val rushYards: Double,
        val rushAttempts: Double,
        val receptions: Double,
        val touchdowns: Double
    )

    private data class PositionGame(
        val rushAttempts: Double,
        val rushYards: Double,
        val receptions: Double,
        val receivingYards: Double,
        val touchdowns: Double
    )

    companion object {
        private val passingMarkets = setOf(
            PropType.PASS_YARDS,
            PropType.PASS_COMPLETIONS,
            PropType.PASS_ATTEMPTS,
            PropType.PASS_TDS,
            PropType.RECEIVING_YARDS,
            PropType.RECEPTIONS
        )
    }
}
