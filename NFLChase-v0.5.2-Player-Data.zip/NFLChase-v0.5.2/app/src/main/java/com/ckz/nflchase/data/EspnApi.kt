package com.ckz.nflchase.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.time.LocalDate
import java.time.OffsetDateTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.roundToInt

class EspnApi {
    private val base = "https://site.api.espn.com/apis/site/v2/sports/football/nfl"
    private val cache = ConcurrentHashMap<String, CachedJson>()

    fun fetchScoreboard(daysForward: Long = 7): List<NflGame> {
        val today = LocalDate.now()
        val from = today.format(DateTimeFormatter.BASIC_ISO_DATE)
        val to = today.plusDays(daysForward).format(DateTimeFormatter.BASIC_ISO_DATE)
        val candidates = listOf(
            "$base/scoreboard?dates=$from-$to&limit=100",
            "$base/scoreboard?dates=${today.year}&limit=1000",
            "$base/scoreboard?limit=100"
        )
        for (url in candidates) {
            val root = runCatching { getJson(url) }.getOrNull() ?: continue
            val parsed = parseEvents(root.optJSONArray("events") ?: JSONArray())
            if (parsed.isNotEmpty()) {
                val cutoff = Instant.now().minusSeconds(7 * 24 * 3600)
                return parsed.filter { it.kickoff.isAfter(cutoff) }.sortedBy { it.kickoff }.take(80)
            }
        }
        return emptyList()
    }

    fun fetchSeasonScoreboard(year: Int = LocalDate.now().year): List<NflGame> {
        val url = "$base/scoreboard?dates=$year&limit=1000"
        val root = getJson(url)
        return parseEvents(root.optJSONArray("events") ?: JSONArray())
    }

    fun fetchTeamSchedule(team: String): List<NflGame> {
        val root = getJson("$base/teams/${team.lowercase()}/schedule")
        return parseEvents(root.optJSONArray("events") ?: JSONArray())
    }

    fun fetchTeamLeaders(team: String): List<PlayerLeader> {
        val root = getJson("$base/teams/${team.lowercase()}/leaders")
        val output = mutableListOf<PlayerLeader>()
        walkLeaderNodes(root, team.uppercase(), output)
        return output.distinctBy { "${it.athleteId}:${it.category}" }.sortedByDescending { it.value }
    }

    fun fetchInjuries(team: String): List<InjuryNote> {
        val root = getJson("$base/teams/${team.lowercase()}/injuries")
        val out = mutableListOf<InjuryNote>()
        walkInjuries(root, team.uppercase(), out)
        return out.distinctBy { "${it.team}:${it.playerName}:${it.status}" }
    }

    fun fetchGamePlayerStats(gameId: String): List<PlayerGameStat> {
        val root = getJson("$base/summary?event=$gameId")
        val teams = root.optJSONObject("boxscore")?.optJSONArray("players") ?: return emptyList()
        val merged = linkedMapOf<String, MutablePlayerStat>()

        for (i in 0 until teams.length()) {
            val teamNode = teams.optJSONObject(i) ?: continue
            val team = teamNode.optJSONObject("team")?.optString("abbreviation")?.uppercase().orEmpty()
            if (team.isBlank()) continue
            val groups = teamNode.optJSONArray("statistics") ?: continue
            for (g in 0 until groups.length()) {
                val group = groups.optJSONObject(g) ?: continue
                val groupName = group.optString("name", group.optString("displayName")).lowercase()
                val labels = group.optJSONArray("labels") ?: JSONArray()
                val athletes = group.optJSONArray("athletes") ?: continue
                for (a in 0 until athletes.length()) {
                    val entry = athletes.optJSONObject(a) ?: continue
                    val athlete = entry.optJSONObject("athlete") ?: continue
                    val athleteId = athlete.optString("id")
                    val name = athlete.optString("displayName", athlete.optString("fullName"))
                    if (athleteId.isBlank() || name.isBlank()) continue
                    val key = "$team:$athleteId"
                    val stat = merged.getOrPut(key) {
                        MutablePlayerStat(
                            gameId = gameId,
                            athleteId = athleteId,
                            name = name,
                            team = team,
                            position = parsePosition(athlete.optJSONObject("position")?.optString("abbreviation") ?: athlete.optString("position")),
                            headshotUrl = athlete.optString("headshot").takeIf { it.isNotBlank() }
                                ?: athlete.optJSONObject("headshot")?.optString("href")?.takeIf { it.isNotBlank() }
                                ?: "https://a.espncdn.com/i/headshots/nfl/players/full/$athleteId.png"
                        )
                    }
                    val values = entry.optJSONArray("stats") ?: JSONArray()
                    applyStats(stat, groupName, labels, values)
                }
            }
        }
        return merged.values.map { it.toImmutable() }
    }

    private fun applyStats(stat: MutablePlayerStat, groupName: String, labels: JSONArray, values: JSONArray) {
        val count = minOf(labels.length(), values.length())
        for (i in 0 until count) {
            val label = labels.optString(i).uppercase().replace(" ", "")
            val raw = values.optString(i)
            when {
                groupName.contains("pass") && (label == "C/ATT" || label == "CMP/ATT") -> {
                    val parts = raw.split("/")
                    stat.passCompletions = parts.getOrNull(0).toNumber()
                    stat.passAttempts = parts.getOrNull(1).toNumber()
                }
                groupName.contains("pass") && label in setOf("CMP", "COMP") -> stat.passCompletions = raw.toNumber()
                groupName.contains("pass") && label in setOf("ATT", "PASSATT") -> stat.passAttempts = raw.toNumber()
                groupName.contains("pass") && label == "YDS" -> stat.passYards = raw.toNumber()
                groupName.contains("pass") && label == "TD" -> stat.passTds = raw.toNumber()

                groupName.contains("rush") && label in setOf("CAR", "ATT", "RUSHATT") -> stat.rushAttempts = raw.toNumber()
                groupName.contains("rush") && label == "YDS" -> stat.rushYards = raw.toNumber()
                groupName.contains("rush") && label == "TD" -> stat.rushTds = raw.toNumber()

                groupName.contains("receiv") && label in setOf("REC", "RECEPTIONS") -> stat.receptions = raw.toNumber()
                groupName.contains("receiv") && label in setOf("TGTS", "TGT", "TARGETS") -> stat.targets = raw.toNumber()
                groupName.contains("receiv") && label == "YDS" -> stat.receivingYards = raw.toNumber()
                groupName.contains("receiv") && label == "TD" -> stat.receivingTds = raw.toNumber()
            }
        }
    }

    private fun getJson(url: String): JSONObject {
        val now = System.currentTimeMillis()
        cache[url]?.takeIf { now - it.savedAtMillis <= ttlFor(url) }?.let { return JSONObject(it.body) }
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 8000
        connection.readTimeout = 10000
        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16) NFLChase/0.5.1")
        connection.setRequestProperty("Accept", "application/json")
        return try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = BufferedReader(InputStreamReader(stream)).use { it.readText() }
            if (code !in 200..299) error("HTTP $code from ESPN")
            cache[url] = CachedJson(now, body)
            JSONObject(body)
        } finally {
            connection.disconnect()
        }
    }

    private fun parseEvents(events: JSONArray): List<NflGame> {
        val out = mutableListOf<NflGame>()
        for (i in 0 until events.length()) {
            val e = events.optJSONObject(i) ?: continue
            val competition = e.optJSONArray("competitions")?.optJSONObject(0) ?: continue
            val competitors = competition.optJSONArray("competitors") ?: continue
            var home: TeamRef? = null
            var away: TeamRef? = null
            for (j in 0 until competitors.length()) {
                val c = competitors.optJSONObject(j) ?: continue
                val team = c.optJSONObject("team") ?: JSONObject()
                val ref = TeamRef(
                    id = team.optString("id"),
                    abbreviation = team.optString("abbreviation").uppercase(),
                    name = team.optString("displayName", team.optString("name")),
                    logoUrl = team.optString("logo").takeIf { it.isNotBlank() },
                    record = c.optJSONArray("records")?.optJSONObject(0)?.optString("summary")?.takeIf { it.isNotBlank() },
                    score = c.optString("score").toDoubleOrNull()?.roundToInt()
                )
                if (c.optString("homeAway") == "home") home = ref else away = ref
            }
            if (home == null || away == null) continue
            val statusType = competition.optJSONObject("status")?.optJSONObject("type") ?: JSONObject()
            val status = when (statusType.optString("state").lowercase()) {
                "in" -> GameStatus.LIVE
                "post" -> GameStatus.FINAL
                else -> GameStatus.SCHEDULED
            }
            val date = e.optString("date")
            val kickoff = runCatching { Instant.parse(date) }
                .getOrElse { runCatching { OffsetDateTime.parse(date).toInstant() }.getOrDefault(Instant.now()) }
            val venueObj = competition.optJSONObject("venue")
            val venue = venueObj?.optString("fullName")?.takeIf { it.isNotBlank() }
            val indoor = venueObj?.optBoolean("indoor").takeIf { venueObj?.has("indoor") == true }
            val weatherObj = competition.optJSONObject("weather")
            val weather = if (weatherObj != null) {
                WeatherContext(
                    summary = weatherObj.optString("displayValue", weatherObj.optString("conditionId")),
                    temperatureF = weatherObj.optString("temperature").toDoubleOrNull()?.roundToInt()
                        ?: weatherObj.optInt("temperature").takeIf { weatherObj.has("temperature") },
                    windMph = weatherObj.optString("windSpeed").filter { it.isDigit() || it == '.' }.toDoubleOrNull()?.roundToInt(),
                    outdoor = indoor != true
                )
            } else if (indoor == true) WeatherContext(summary = "Indoor", outdoor = false) else null
            out += NflGame(
                id = e.optString("id"),
                kickoff = kickoff,
                status = status,
                statusText = statusType.optString("shortDetail", statusType.optString("detail", "Scheduled")),
                home = home,
                away = away,
                venue = venue,
                indoor = indoor,
                weekLabel = e.optJSONObject("week")?.optString("text")?.takeIf { it.isNotBlank() },
                weather = weather
            )
        }
        return out.distinctBy { it.id }.sortedBy { it.kickoff }
    }

    private fun walkLeaderNodes(node: Any?, team: String, out: MutableList<PlayerLeader>, inheritedCategory: String = "") {
        when (node) {
            is JSONObject -> {
                val category = node.optString("displayName").ifBlank { node.optString("name") }.ifBlank { inheritedCategory }
                val athlete = node.optJSONObject("athlete")
                if (athlete != null) {
                    val value = when {
                        node.has("value") -> node.optDouble("value", Double.NaN)
                        node.has("statistics") -> parseFirstNumeric(node.optJSONArray("statistics"))
                        else -> node.optString("displayValue").filter { it.isDigit() || it == '.' || it == '-' }.toDoubleOrNull() ?: Double.NaN
                    }
                    val position = athlete.optJSONObject("position")?.optString("abbreviation") ?: athlete.optString("position")
                    if (!value.isNaN() && athlete.optString("displayName").isNotBlank()) {
                        out += PlayerLeader(
                            athleteId = athlete.optString("id"),
                            name = athlete.optString("displayName", athlete.optString("fullName")),
                            team = team,
                            position = parsePosition(position),
                            category = category,
                            value = value,
                            displayValue = node.optString("displayValue").ifBlank { value.toString() },
                            headshotUrl = athlete.optString("headshot").takeIf { it.isNotBlank() }
                                ?: athlete.optJSONObject("headshot")?.optString("href")?.takeIf { it.isNotBlank() }
                                ?: athlete.optString("id").takeIf { it.isNotBlank() }?.let { "https://a.espncdn.com/i/headshots/nfl/players/full/$it.png" }
                        )
                    }
                }
                val keys = node.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val child = node.opt(key)
                    if (child is JSONObject || child is JSONArray) {
                        val nextCategory = if (key.equals("leaders", true) || key.equals("statistics", true)) category else inheritedCategory.ifBlank { category }
                        walkLeaderNodes(child, team, out, nextCategory)
                    }
                }
            }
            is JSONArray -> for (i in 0 until node.length()) walkLeaderNodes(node.opt(i), team, out, inheritedCategory)
        }
    }

    private fun parseFirstNumeric(arr: JSONArray?): Double {
        if (arr == null) return Double.NaN
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val v = o.optDouble("value", Double.NaN)
            if (!v.isNaN()) return v
            val parsed = o.optString("displayValue").filter { it.isDigit() || it == '.' || it == '-' }.toDoubleOrNull()
            if (parsed != null) return parsed
        }
        return Double.NaN
    }

    private fun walkInjuries(node: Any?, team: String, out: MutableList<InjuryNote>) {
        when (node) {
            is JSONObject -> {
                val athlete = node.optJSONObject("athlete")
                val status = node.optString("status").ifBlank { node.optJSONObject("status")?.optString("name") ?: "" }
                if (athlete != null && athlete.optString("displayName").isNotBlank() && status.isNotBlank()) {
                    out += InjuryNote(
                        athleteId = athlete.optString("id").takeIf { it.isNotBlank() },
                        playerName = athlete.optString("displayName", athlete.optString("fullName")),
                        team = team,
                        status = status,
                        detail = node.optString("longComment").takeIf { it.isNotBlank() }
                            ?: node.optString("shortComment").takeIf { it.isNotBlank() },
                        position = parsePosition(athlete.optJSONObject("position")?.optString("abbreviation") ?: athlete.optString("position"))
                    )
                }
                val keys = node.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val child = node.opt(k)
                    if (child is JSONObject || child is JSONArray) walkInjuries(child, team, out)
                }
            }
            is JSONArray -> for (i in 0 until node.length()) walkInjuries(node.opt(i), team, out)
        }
    }

    private fun parsePosition(raw: String?): PositionGroup = when (raw?.uppercase()) {
        "QB" -> PositionGroup.QB
        "RB", "FB" -> PositionGroup.RB
        "WR" -> PositionGroup.WR
        "TE" -> PositionGroup.TE
        else -> PositionGroup.OTHER
    }

    private data class MutablePlayerStat(
        val gameId: String,
        val athleteId: String,
        val name: String,
        val team: String,
        val position: PositionGroup,
        val headshotUrl: String?,
        var passCompletions: Double = 0.0,
        var passAttempts: Double = 0.0,
        var passYards: Double = 0.0,
        var passTds: Double = 0.0,
        var rushAttempts: Double = 0.0,
        var rushYards: Double = 0.0,
        var rushTds: Double = 0.0,
        var receptions: Double = 0.0,
        var targets: Double = 0.0,
        var receivingYards: Double = 0.0,
        var receivingTds: Double = 0.0
    ) {
        fun toImmutable() = PlayerGameStat(
            gameId, athleteId, name, team, position, headshotUrl,
            passCompletions, passAttempts, passYards, passTds,
            rushAttempts, rushYards, rushTds, receptions, targets, receivingYards, receivingTds
        )
    }

    private fun ttlFor(url: String): Long = when {
        url.contains("summary?event=") -> 20 * 60 * 1000L
        url.contains("/schedule") -> 10 * 60 * 1000L
        url.contains("/leaders") -> 10 * 60 * 1000L
        else -> 3 * 60 * 1000L
    }

    private data class CachedJson(val savedAtMillis: Long, val body: String)

    private fun String?.toNumber(): Double = this?.filter { it.isDigit() || it == '.' || it == '-' }?.toDoubleOrNull() ?: 0.0
}
