package com.ckz.nflchase.data

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/** Primary player-stat feed. nflverse publishes current-season weekly player stats as CSV. */
class NflverseApi {
    fun fetchPlayerStats(season: Int): List<PlayerGameStat> {
        val url = "https://github.com/nflverse/nflverse-data/releases/download/stats_player/stats_player_week_${season}.csv"
        val text = getText(url)
        val rows = parseCsv(text)
        if (rows.size < 2) return emptyList()
        val header = rows.first().map { it.trim() }
        val idx = header.withIndex().associate { it.value to it.index }
        fun List<String>.v(vararg names: String): String {
            for (n in names) idx[n]?.let { i -> if (i in indices && this[i].isNotBlank()) return this[i] }
            return ""
        }
        fun String.num() = toDoubleOrNull() ?: 0.0
        return rows.drop(1).mapNotNull { r ->
            val id = r.v("player_id")
            val name = r.v("player_display_name", "player_name")
            val team = r.v("recent_team", "team").uppercase()
            val week = r.v("week")
            if (id.isBlank() || name.isBlank() || team.isBlank()) return@mapNotNull null
            val gameId = r.v("game_id").ifBlank { "NFLV-${season}-${week}-${team}" }
            PlayerGameStat(
                gameId = gameId,
                athleteId = id,
                name = name,
                team = team,
                position = parsePosition(r.v("position", "position_group")),
                passCompletions = r.v("completions").num(),
                passAttempts = r.v("attempts", "passing_attempts").num(),
                passYards = r.v("passing_yards").num(),
                passTds = r.v("passing_tds").num(),
                rushAttempts = r.v("carries", "rushing_attempts").num(),
                rushYards = r.v("rushing_yards").num(),
                rushTds = r.v("rushing_tds").num(),
                receptions = r.v("receptions").num(),
                targets = r.v("targets").num(),
                receivingYards = r.v("receiving_yards").num(),
                receivingTds = r.v("receiving_tds").num()
            )
        }
    }

    private fun parsePosition(raw: String): PositionGroup = when (raw.uppercase()) {
        "QB" -> PositionGroup.QB
        "RB", "FB" -> PositionGroup.RB
        "WR" -> PositionGroup.WR
        "TE" -> PositionGroup.TE
        "K", "PK" -> PositionGroup.K
        else -> PositionGroup.OTHER
    }

    private fun getText(url: String): String {
        var current = url
        repeat(6) {
            val c = URL(current).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 12000
            c.readTimeout = 20000
            c.setRequestProperty("User-Agent", "NFLChase/0.5.2 Android")
            c.setRequestProperty("Accept", "text/csv,*/*")
            val code = c.responseCode
            if (code in 300..399) {
                current = c.getHeaderField("Location") ?: error("nflverse redirect missing")
                c.disconnect()
            } else {
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val body = BufferedReader(InputStreamReader(stream)).use { it.readText() }
                c.disconnect()
                if (code !in 200..299) error("HTTP $code from nflverse")
                return body
            }
        }
        error("Too many nflverse redirects")
    }

    private fun parseCsv(text: String): List<List<String>> {
        val out = mutableListOf<List<String>>()
        var row = mutableListOf<String>(); val cell = StringBuilder(); var quoted = false; var i = 0
        while (i < text.length) {
            val ch = text[i]
            when {
                ch == '"' && quoted && i + 1 < text.length && text[i + 1] == '"' -> { cell.append('"'); i++ }
                ch == '"' -> quoted = !quoted
                ch == ',' && !quoted -> { row.add(cell.toString()); cell.setLength(0) }
                (ch == '\n' || ch == '\r') && !quoted -> {
                    if (ch == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++
                    row.add(cell.toString()); cell.setLength(0)
                    if (row.any { it.isNotEmpty() }) out.add(row)
                    row = mutableListOf()
                }
                else -> cell.append(ch)
            }
            i++
        }
        if (cell.isNotEmpty() || row.isNotEmpty()) { row.add(cell.toString()); out.add(row) }
        return out
    }
}
