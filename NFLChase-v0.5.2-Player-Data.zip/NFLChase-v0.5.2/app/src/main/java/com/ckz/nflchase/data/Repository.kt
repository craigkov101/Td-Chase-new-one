package com.ckz.nflchase.data

import com.ckz.nflchase.model.NflScoringModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

class Repository(
    private val api: EspnApi,
    private val nflverse: NflverseApi,
    private val preferences: AppPreferences,
    private val model: NflScoringModel
) {
    suspend fun loadDashboard(): NflDashboard = withContext(Dispatchers.IO) {
        val fetchedGames = api.fetchScoreboard(daysForward = 14)
        // The command center is forward-looking: never mix last week's finals into the current slate.
        // Keep live games and future scheduled games; completed games still come from team schedules for learning.
        val nowInstant = java.time.Instant.now()
        val allUpcoming = fetchedGames
            .filter { it.status == GameStatus.LIVE || (it.status == GameStatus.SCHEDULED && !it.kickoff.isBefore(nowInstant.minusSeconds(300))) }
            .sortedBy { it.kickoff }
        // Command Center shows one NFL slate/week at a time, not the next several weeks.
        val slateStart = allUpcoming.firstOrNull()?.kickoff
        val slateEnd = slateStart?.plusSeconds(6 * 24 * 3600 + 12 * 3600)
        val games = if (slateEnd == null) emptyList() else allUpcoming.filter { !it.kickoff.isAfter(slateEnd) }
        if (games.isEmpty()) return@withContext NflDashboard(dataNote = "No upcoming NFL games were returned for the next two weeks.", modelVersion = "0.5.2")

        val teams = games.flatMap { listOf(it.home.abbreviation, it.away.abbreviation) }.distinct()
        val (rawSchedules, injuriesByTeam, seasonGames) = coroutineScope {
            val schedulesDeferred = async { fetchTeamMap(teams) { api.fetchTeamSchedule(it) } }
            val injuriesDeferred = async { fetchTeamMap(teams) { api.fetchInjuries(it) } }
            val seasonDeferred = async { runCatching { api.fetchSeasonScoreboard() }.getOrDefault(emptyList()) }
            Triple(schedulesDeferred.await(), injuriesDeferred.await(), seasonDeferred.await())
        }
        // ESPN's team schedule route is not equally reliable on every device/season.
        // Fall back to the full-season scoreboard so recent finals still feed forms, box scores and profiles.
        val schedules = teams.associateWith { team ->
            val direct = rawSchedules[team].orEmpty()
            val season = seasonGames.filter { it.home.abbreviation == team || it.away.abbreviation == team }
            (direct + season).distinctBy { it.id }.sortedBy { it.kickoff }
        }
        val forms = teams.associateWith { team -> model.teamForm(team, schedules[team].orEmpty()) }
        val injuries = injuriesByTeam.values.flatten().distinctBy { "${it.team}:${it.playerName}:${it.status}" }

        var weights = preferences.loadWeights()
        val scripts = games.associate { g ->
            g.id to model.projectGame(
                g,
                forms[g.home.abbreviation] ?: model.teamForm(g.home.abbreviation, emptyList()),
                forms[g.away.abbreviation] ?: model.teamForm(g.away.abbreviation, emptyList()),
                weights
            )
        }

        val now = System.currentTimeMillis()
        var gameHistory = preferences.loadPredictions().toMutableList()
        val gameHistoryById = gameHistory.associateBy { it.gameId }.toMutableMap()
        val allKnownGames = schedules.values.flatten().associateBy { it.id } + games.associateBy { it.id }
        games.filter { it.status == GameStatus.SCHEDULED }.forEach { g ->
            val script = scripts[g.id] ?: return@forEach
            if (gameHistoryById[g.id] == null) {
                val record = PredictionRecord(g.id, now, script.homeScore, script.awayScore)
                gameHistory += record
                gameHistoryById[g.id] = record
            }
        }
        gameHistory = gameHistory.map { record ->
            val finalGame = allKnownGames[record.gameId]
            if (!record.settled && finalGame?.status == GameStatus.FINAL && finalGame.home.score != null && finalGame.away.score != null) {
                record.copy(actualHome = finalGame.home.score, actualAway = finalGame.away.score, settled = true)
            } else record
        }.toMutableList()
        preferences.savePredictions(gameHistory)
        val settledGames = gameHistory.filter { it.settled }
        val learnedWeights = model.learn(weights, settledGames)
        if (learnedWeights != weights) {
            weights = learnedWeights
            preferences.saveWeights(weights)
        }

        val upcomingTeams = games.filter { it.status != GameStatus.FINAL }
            .flatMap { listOf(it.home.abbreviation, it.away.abbreviation) }
            .distinct()

        // Four games gives a better floor/ceiling and role-stability read without turning refresh into a full-season scrape.
        val teamRecentGameIds = upcomingTeams.associateWith { team ->
            schedules[team].orEmpty()
                .filter { it.status == GameStatus.FINAL }
                .sortedBy { it.kickoff }
                .takeLast(4)
                .map { it.id }
        }

        var propHistory = preferences.loadPropPredictions().toMutableList()
        val unsettledFinalIds = propHistory
            .filter { !it.settled && allKnownGames[it.gameId]?.status == GameStatus.FINAL }
            .map { it.gameId }
            .distinct()
        val recentIds = teamRecentGameIds.values.flatten().distinct()
        val summaryIds = (recentIds + unsettledFinalIds).distinct()
        val summaryStats = fetchGameStatsMap(summaryIds)

        propHistory = propHistory.map { record ->
            if (record.settled || allKnownGames[record.gameId]?.status != GameStatus.FINAL) return@map record
            val stat = summaryStats[record.gameId].orEmpty().firstOrNull { it.athleteId == record.athleteId }
            if (stat == null) record else record.copy(actual = model.actualValue(stat, record.propType), settled = true)
        }.toMutableList()
        preferences.savePropPredictions(propHistory)
        val marketLearning = model.marketLearning(propHistory)

        val defenseProfiles = upcomingTeams.associateWith { team ->
            model.buildDefenseProfile(team, teamRecentGameIds[team].orEmpty(), summaryStats)
        }

        // Primary player pipeline: nflverse weekly player stats. ESPN summaries remain a fallback.
        // This breaks the old failure mode where schedules loaded but ESPN boxscore parsing produced 0 profiles.
        val season = games.first().kickoff.atZone(java.time.ZoneOffset.UTC).let { z -> if (z.monthValue <= 2) z.year - 1 else z.year }
        val nflverseStats = runCatching { nflverse.fetchPlayerStats(season) }.getOrDefault(emptyList())
        val profilesByTeam = upcomingTeams.associateWith { team ->
            val allTeam = nflverseStats.filter { it.team == team }
            val recentGameKeys = allTeam.map { it.gameId }.distinct().takeLast(4).toSet()
            val primary = allTeam.filter { it.gameId in recentGameKeys }
            val fallback = teamRecentGameIds[team].orEmpty().flatMap { gameId ->
                summaryStats[gameId].orEmpty().filter { it.team == team }
            }
            model.buildUsageProfiles(team, if (primary.isNotEmpty()) primary else fallback)
        }.toMutableMap()

        val missingProfileTeams = upcomingTeams.filter { profilesByTeam[it].isNullOrEmpty() }
        if (missingProfileTeams.isNotEmpty()) {
            val leaderFallbacks = fetchTeamMap(missingProfileTeams) { api.fetchTeamLeaders(it) }
            missingProfileTeams.forEach { team ->
                val fallback = model.profilesFromLeaders(team, leaderFallbacks[team].orEmpty(), forms[team]?.games ?: 1)
                if (fallback.isNotEmpty()) profilesByTeam[team] = fallback
            }
        }

        val targets = games.filter { it.status != GameStatus.FINAL }.flatMap { g ->
            val script = scripts[g.id] ?: return@flatMap emptyList()
            model.buildTargets(
                game = g,
                script = script,
                homeForm = forms[g.home.abbreviation] ?: model.teamForm(g.home.abbreviation, emptyList()),
                awayForm = forms[g.away.abbreviation] ?: model.teamForm(g.away.abbreviation, emptyList()),
                homeProfiles = profilesByTeam[g.home.abbreviation].orEmpty(),
                awayProfiles = profilesByTeam[g.away.abbreviation].orEmpty(),
                homeDefense = defenseProfiles[g.home.abbreviation],
                awayDefense = defenseProfiles[g.away.abbreviation],
                injuries = injuries.filter { it.team == g.home.abbreviation || it.team == g.away.abbreviation },
                marketLearning = marketLearning
            )
        }.sortedWith(compareByDescending<PropTarget> { it.chaseScore }.thenByDescending { it.confidence })

        val existingPropIds = propHistory.map { it.id }.toHashSet()
        targets.filter { it.chaseScore >= 68 && it.dataConfidence >= 52 }
            .groupBy { it.gameId }
            .values
            .flatMap { it.take(16) }
            .forEach { target ->
                if (target.id !in existingPropIds) {
                    propHistory += PropPredictionRecord(
                        id = target.id,
                        gameId = target.gameId,
                        athleteId = target.athleteId,
                        playerName = target.playerName,
                        propType = target.propType,
                        createdAtMillis = now,
                        projection = target.modelProjection,
                        threshold = target.attackOverAt,
                        chaseScore = target.chaseScore
                    )
                    existingPropIds += target.id
                }
            }
        preferences.savePropPredictions(propHistory)

        val finalMarketLearning = model.marketLearning(propHistory)
        val gameErrors = settledGames.mapNotNull { it.absoluteError }
        val settledProps = propHistory.filter { it.settled && it.actual != null }
        val learning = LearningSnapshot(
            settledPredictions = settledGames.size,
            meanAbsoluteTeamError = if (gameErrors.isEmpty()) 0.0 else gameErrors.average() / 2.0,
            settledProps = settledProps.size,
            propThresholdHitRate = if (settledProps.isEmpty()) 0.0 else settledProps.count { it.thresholdHit == true }.toDouble() / settledProps.size,
            lastUpdatedMillis = now,
            weights = weights,
            marketLearning = finalMarketLearning
        )

        val profileCount = profilesByTeam.values.sumOf { it.size }
        val defenseCount = defenseProfiles.values.count { it.games > 0 }
        val injuryTeamCount = injuriesByTeam.count { it.value.isNotEmpty() }
        val summaryCoverage = if (summaryIds.isEmpty()) 0.0 else summaryIds.count { summaryStats[it].orEmpty().isNotEmpty() }.toDouble() / summaryIds.size
        val teamCoverage = if (upcomingTeams.isEmpty()) 0.0 else upcomingTeams.count { profilesByTeam[it].orEmpty().isNotEmpty() }.toDouble() / upcomingTeams.size
        val dataHealthScore = (
            summaryCoverage * 38 +
                teamCoverage * 34 +
                (defenseCount.toDouble() / maxOf(1, upcomingTeams.size)) * 18 +
                (if (targets.isNotEmpty()) 10 else 0)
            ).roundToInt().coerceIn(0, 100)
        val dataHealth = DataHealth(
            score = dataHealthScore,
            label = when {
                dataHealthScore >= 88 -> "Excellent coverage"
                dataHealthScore >= 74 -> "Strong coverage"
                dataHealthScore >= 58 -> "Usable coverage"
                else -> "Partial coverage"
            },
            recentGameSummaries = summaryStats.count { it.value.isNotEmpty() },
            playerProfiles = profileCount,
            defensiveProfiles = defenseCount,
            injuryTeams = injuryTeamCount,
            notes = buildList {
                add("${(summaryCoverage * 100).roundToInt()}% of requested recent box scores parsed")
                add("${(teamCoverage * 100).roundToInt()}% of upcoming teams have player usage profiles")
                add("nflverse player rows: ${nflverseStats.size}")
                if (missingProfileTeams.isNotEmpty()) add("Leader fallback active for ${missingProfileTeams.size} team(s)")
                if (injuryTeamCount == 0) add("No injury feed entries were returned yet")
            }
        )

        NflDashboard(
            games = games,
            scripts = scripts,
            targets = targets,
            injuries = injuries,
            usageProfiles = profilesByTeam.values.flatten(),
            learning = learning,
            dataHealth = dataHealth,
            lastUpdatedMillis = now,
            dataNote = when {
                targets.isEmpty() -> "Game scripts loaded, but player usage data is still sparse. NFL Chase will not invent missing prop data."
                recentIds.isEmpty() -> "Rankings are using season-leader fallback data because recent box scores were unavailable."
                else -> "v0.5.2 Data Pipeline: upcoming-only slate, projected scores, injury-gated props, $profileCount player profiles, position-specific defensive allowances and postgame model learning. Projections are labeled and missing data is never fabricated."
            },
            modelVersion = "0.5.2"
        )
    }

    fun loadTrackedIds(): Set<String> = preferences.loadTrackedIds()
    fun saveTrackedIds(ids: Set<String>) = preferences.saveTrackedIds(ids)
    fun loadManualLines(): Map<String, Double> = preferences.loadManualLines()
    fun saveManualLines(lines: Map<String, Double>) = preferences.saveManualLines(lines)

    private suspend fun <T> fetchTeamMap(teams: List<String>, block: (String) -> List<T>): Map<String, List<T>> = coroutineScope {
        val semaphore = Semaphore(8)
        teams.map { team ->
            async(Dispatchers.IO) {
                val value = runCatching { semaphore.withPermit { block(team) } }.getOrDefault(emptyList())
                team to value
            }
        }.awaitAll().toMap()
    }

    private suspend fun fetchGameStatsMap(gameIds: List<String>): Map<String, List<PlayerGameStat>> = coroutineScope {
        val semaphore = Semaphore(7)
        gameIds.map { gameId ->
            async(Dispatchers.IO) {
                val value = runCatching { semaphore.withPermit { api.fetchGamePlayerStats(gameId) } }.getOrDefault(emptyList())
                gameId to value
            }
        }.awaitAll().toMap()
    }
}
