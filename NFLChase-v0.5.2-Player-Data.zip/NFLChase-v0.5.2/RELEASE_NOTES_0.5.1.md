# NFL Chase v0.5.1 — Data Recovery Patch

- Command Center now shows only the nearest upcoming NFL slate instead of several future weeks.
- Added full-season scoreboard fallback for team schedules so recent completed games can still feed team form, box-score summaries, defense profiles and player usage profiles when a team schedule endpoint fails.
- Preserves injury gating and adaptive postgame learning from v0.5.0.
- Corrected the visible app version badge to v0.5.1.
- Updated live-feed user agent/version.
- Missing prop data remains unavailable rather than fabricated.
