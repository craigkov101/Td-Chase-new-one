package com.nflchase.tdengine

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import java.util.Locale
import com.nflchase.tdengine.data.*
import com.nflchase.tdengine.model.*

private val Bg=Color(0xFF06111D); private val Card=Color(0xFF0C1927); private val Card2=Color(0xFF101F2F); private val Line=Color(0xFF1C3348); private val Blue=Color(0xFF45C8FF); private val Green=Color(0xFF52F35A); private val Muted=Color(0xFF91A0B2); private val Gold=Color(0xFFFFB84D)
class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{MaterialTheme(colorScheme=darkColorScheme(background=Bg,surface=Card,primary=Blue)){App()}}}}
enum class Tab(val title:String){GAMES("Games"),PICKS("Picks"),SCRIPTS("Scripts"),PARLAYS("Parlays"),MORE("More")}
@Composable fun App(){var tab by remember{mutableStateOf(Tab.GAMES)};var selected by remember{mutableStateOf<GameCard?>(null)};val repo=remember{TdRepository()};val learn=remember{LearningEngine()};val sim=remember{SimulationEngine(25000)};Scaffold(containerColor=Bg,bottomBar={NavigationBar(containerColor=Color(0xFF071522)){Tab.entries.forEach{t->NavigationBarItem(selected=tab==t,onClick={tab=t;selected=null},icon={Icon(when(t){Tab.GAMES->Icons.Default.SportsFootball;Tab.PICKS->Icons.Default.Star;Tab.SCRIPTS->Icons.Default.QueryStats;Tab.PARLAYS->Icons.Default.Casino;Tab.MORE->Icons.Default.MoreHoriz},null)},label={Text(t.title)},colors=NavigationBarItemDefaults.colors(selectedIconColor=Blue,indicatorColor=Blue.copy(.14f),selectedTextColor=Color.White,unselectedIconColor=Muted,unselectedTextColor=Muted))}}}){pad->Column(Modifier.padding(pad).fillMaxSize()){Header();when{selected!=null->GameDetail(selected!!,{selected=null},learn);tab==Tab.GAMES->GamesHome(repo.games(),sim){selected=it};tab==Tab.PICKS->SimBoard(repo.games(),sim);tab==Tab.SCRIPTS->Scripts(repo.games());tab==Tab.PARLAYS->Builder(repo.allCandidates());else->More(learn)}}}}
@Composable fun Header(){Row(Modifier.fillMaxWidth().padding(22.dp,18.dp),verticalAlignment=Alignment.CenterVertically){Surface(shape=CircleShape,color=Blue.copy(.08f),border=BorderStroke(1.dp,Blue.copy(.45f))){Icon(Icons.Default.SportsFootball,null,tint=Blue,modifier=Modifier.padding(12.dp).size(25.dp))};Spacer(Modifier.width(14.dp));Column(Modifier.weight(1f)){Row(verticalAlignment=Alignment.CenterVertically){Text("TD",fontSize=29.sp,fontWeight=FontWeight.Black,color=Blue);Text(" CHASE",fontSize=29.sp,fontWeight=FontWeight.Black)};Text("TOUCHDOWN INTELLIGENCE • built by Cxaig",color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold)};Surface(shape=RoundedCornerShape(18.dp),color=Color(0xFF161A39),border=BorderStroke(1.dp,Color(0xFF343B78))){Text("SIM ENGINE",color=Color(0xFF9E91FF),fontSize=10.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(10.dp,7.dp))}};HorizontalDivider(color=Line)}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun GamesHome(games:List<GameCard>,sim:SimulationEngine,open:(GameCard)->Unit){
    var remaining by remember{mutableStateOf(true)}
    var top5 by remember{mutableStateOf(true)}
    var best by remember{mutableStateOf(false)}
    var live by remember{mutableStateOf(LiveTdSnapshot(emptyList(),0,"—"))}
    var refreshing by remember{mutableStateOf(false)}
    var refreshTick by remember{mutableIntStateOf(0)}
    val client=remember{LiveTdClient()};val scope=rememberCoroutineScope()
    fun forceRefresh(){if(refreshing)return;refreshing=true;scope.launch{live=withContext(Dispatchers.IO){client.loadToday()};refreshTick++;refreshing=false}}
    LaunchedEffect(Unit){forceRefresh();while(isActive){delay(30000);forceRefresh()}}
    fun isLiveOut(p:TdCandidate)=live.unavailablePlayers.contains(p.name.lowercase(Locale.US).replace(Regex("[^a-z0-9 ]"),"").replace(Regex("\\s+")," ").trim())
    val liveGames=remember(games,live.unavailablePlayers,refreshTick){games.map{g->g.copy(candidates=g.candidates.map{p->if(isLiveOut(p))p.copy(status="OUT") else p})}}
    val sims=remember(liveGames,refreshTick){liveGames.associate{it.id to sim.simulate(it)}}
    val shown=remember(remaining,best,liveGames,refreshTick){
        val base=if(remaining) liveGames.filter{!it.kickoff.contains("FINAL",true)} else liveGames
        if(best) base.sortedByDescending{g->g.candidates.filter{it.status.uppercase() !in setOf("OUT","INACTIVE","IR","PUP","SUSPENDED")}.maxOfOrNull{p->sims[g.id]?.results?.get(p.id)?.tdRate?:0}?:0} else base
    }
    PullToRefreshBox(isRefreshing=refreshing,onRefresh={forceRefresh()},modifier=Modifier.fillMaxSize()){
     LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(bottom=24.dp)){
      item{Column(Modifier.padding(22.dp,16.dp,22.dp,8.dp)){
        Text("Sun, Oct 4",fontSize=26.sp,fontWeight=FontWeight.Black)
        Text("TODAY • ${shown.size} GAMES",color=Blue,fontWeight=FontWeight.Bold,fontSize=12.sp,modifier=Modifier.padding(top=5.dp))
        Text("Swipe down to refresh live injuries + simulations • ${live.updatedAt}",color=if(live.error==null)Green else Gold,fontSize=10.sp,modifier=Modifier.padding(top=5.dp))
        Spacer(Modifier.height(20.dp));Text("QUICK FILTERS",color=Muted,fontWeight=FontWeight.Black,fontSize=12.sp)
        Row(Modifier.padding(top=10.dp)){
          FilterChip(selected=remaining,onClick={remaining=!remaining},label={Text("Remaining")});Spacer(Modifier.width(7.dp))
          FilterChip(selected=top5,onClick={top5=!top5},label={Text(if(top5) "Top 5" else "All Picks")});Spacer(Modifier.width(7.dp))
          FilterChip(selected=best,onClick={best=!best},label={Text("Best Matchup")})
        }
        Text("${shown.size} matchups shown • ${if(top5) "5 scorers per game" else "all scorers"}",color=Blue,fontSize=11.sp,modifier=Modifier.padding(top=8.dp))
        if(live.unavailablePlayers.isNotEmpty())Text("LIVE ELIGIBILITY: current roster + OUT/inactive gate applied",color=Gold,fontWeight=FontWeight.Bold,fontSize=11.sp,modifier=Modifier.padding(top=7.dp))
        Spacer(Modifier.height(22.dp));Text("25,000× GAME SIMS",color=Blue,fontWeight=FontWeight.Black,fontSize=12.sp)
        Text("Most likely TD scorers",fontSize=29.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=6.dp))
        Text("Pregame and mid-game OUT players are removed on live refresh.",color=Muted,fontSize=13.sp,modifier=Modifier.padding(top=4.dp))
      }}
      items(shown){g->GameTileSim(g,sims[g.id]!!,if(top5)5 else 99,open)}
      item{Column(Modifier.padding(22.dp,28.dp,22.dp,10.dp)){
        Text("TODAY'S TOUCHDOWNS",color=Blue,fontWeight=FontWeight.Black,fontSize=12.sp)
        Text("Touchdown tracker",fontSize=29.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=8.dp))
        Text("Same refresh updates scoring plays and live player availability.",color=Muted,fontSize=13.sp,modifier=Modifier.padding(top=4.dp))
      }}
      item{TouchdownFeed(snapshot=live,loading=refreshing,onRefresh={forceRefresh()})}
     }
    }
}
@Composable fun GameTileSim(g:GameCard,s:GameSimulation,limit:Int,open:(GameCard)->Unit){
    val ranked=g.candidates.filter{it.status.uppercase() !in setOf("OUT","INACTIVE","IR","PUP","SUSPENDED")}.sortedByDescending{s.results[it.id]?.tdRate?:0}.take(limit)
    Surface(onClick={open(g)},color=Card,shape=RoundedCornerShape(24.dp),border=BorderStroke(1.dp,Line),modifier=Modifier.padding(horizontal=20.dp,vertical=7.dp)){
      Column(Modifier.padding(18.dp)){
        Row{Column(Modifier.weight(1f)){Text("${g.away}  @  ${g.home}",fontSize=21.sp,fontWeight=FontWeight.Black);Text(g.kickoff,color=Muted,fontSize=12.sp)}
          Surface(color=Blue.copy(.10f),shape=RoundedCornerShape(12.dp)){Text("${s.simulations/1000}K SIMS",color=Blue,fontWeight=FontWeight.Bold,fontSize=11.sp,modifier=Modifier.padding(8.dp,5.dp))}}
        Text("Sim avg ${"%.1f".format(s.avgTotalTds)} TDs • ${g.away} ${s.awayWinPct}% / ${g.home} ${s.homeWinPct}%",color=Muted,fontSize=12.sp,modifier=Modifier.padding(vertical=10.dp))
        HorizontalDivider(color=Line)
        ranked.forEachIndexed{i,p->val r=s.results[p.id]!!;Row(Modifier.padding(top=10.dp),verticalAlignment=Alignment.CenterVertically){
          Text("#${i+1}",color=if(i==0)Gold else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(30.dp))
          Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.Bold);Text("${p.position} • ${p.team} • ${shortReason(p)}",color=Muted,fontSize=11.sp)}
          Column(horizontalAlignment=Alignment.End){Text("${r.tdRate}%",color=if(i==0)Green else Blue,fontWeight=FontWeight.Black,fontSize=20.sp);Text("SIM TD",color=Muted,fontSize=9.sp)}
        }}
        Text("VIEW SIM + MATCHUP  ›",color=Blue,fontWeight=FontWeight.Black,fontSize=11.sp,modifier=Modifier.padding(top=14.dp))
      }
    }
}
@Composable fun SimBoard(games:List<GameCard>,sim:SimulationEngine){
    val rows=remember(games){games.flatMap{g->val s=sim.simulate(g);g.candidates.filter{it.status.uppercase() !in setOf("OUT","INACTIVE","IR","PUP","SUSPENDED")}.map{p->Triple(p,s.results[p.id]!!,g)}}.sortedByDescending{it.second.tdRate}}
    Title("Simulation TD Board","25,000 possession-level simulations per matchup. Ranked by how often each player scores.")
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
      itemsIndexed(rows){i,row->val p=row.first;val r=row.second;Surface(color=Card,shape=RoundedCornerShape(18.dp),border=BorderStroke(1.dp,Line)){
        Row(Modifier.fillMaxWidth().padding(15.dp),verticalAlignment=Alignment.CenterVertically){Text("#${i+1}",color=Gold,fontWeight=FontWeight.Black);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.Black,fontSize=18.sp);Text("${p.team} • ${p.position} vs ${p.opponent}",color=Muted,fontSize=12.sp);Text(shortReason(p),color=Blue,fontSize=11.sp)};Column(horizontalAlignment=Alignment.End){Text("${r.tdRate}%",color=Green,fontSize=25.sp,fontWeight=FontWeight.Black);Text("${r.multiTdRate}% 2+ TD",color=Muted,fontSize=10.sp)}}}}
    }
}
@Composable fun TouchdownFeed(snapshot:LiveTdSnapshot,loading:Boolean,onRefresh:()->Unit){
 Surface(color=Card,shape=RoundedCornerShape(24.dp),border=BorderStroke(1.dp,Line),modifier=Modifier.padding(horizontal=20.dp).fillMaxWidth()){Column(Modifier.padding(18.dp)){
  Row(verticalAlignment=Alignment.CenterVertically){Surface(shape=CircleShape,color=Blue.copy(.12f)){Icon(Icons.Default.SportsFootball,null,tint=Blue,modifier=Modifier.padding(10.dp))};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text("TODAY • LIVE FEED",color=Blue,fontWeight=FontWeight.Black,fontSize=12.sp);Text(if(snapshot.liveGames>0)"${snapshot.liveGames} LIVE" else "NFL touchdown tracker",fontSize=19.sp,fontWeight=FontWeight.Black)};Text("${snapshot.events.size} TD",color=if(snapshot.events.isNotEmpty())Green else Muted,fontWeight=FontWeight.Bold)}
  Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.padding(top=10.dp)){if(loading)CircularProgressIndicator(modifier=Modifier.size(14.dp),strokeWidth=2.dp,color=Blue);Text("  Auto 30 sec • swipe to force • ${snapshot.updatedAt}",color=Muted,fontSize=10.sp);Spacer(Modifier.weight(1f));TextButton(onClick=onRefresh,enabled=!loading){Text("REFRESH",fontSize=10.sp)}}
  HorizontalDivider(color=Line,modifier=Modifier.padding(vertical=14.dp))
  snapshot.error?.let{Text("Live feed temporarily unavailable",color=Gold,fontWeight=FontWeight.Bold);Text(it,color=Muted,fontSize=11.sp)}
  if(snapshot.error==null&&snapshot.events.isEmpty())Text("No touchdowns recorded yet today.",color=Muted,fontWeight=FontWeight.Bold)
  snapshot.events.take(40).forEachIndexed{i,td->if(i>0)HorizontalDivider(color=Line.copy(.55f),modifier=Modifier.padding(vertical=10.dp));Row{Surface(color=Blue.copy(.10f),shape=RoundedCornerShape(10.dp)){Text(td.team.ifBlank{"TD"},color=Blue,fontWeight=FontWeight.Black,modifier=Modifier.padding(8.dp,5.dp))};Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(td.text,fontWeight=FontWeight.Bold,fontSize=14.sp);Text("${td.game} • Q${td.quarter} ${td.clock}",color=Muted,fontSize=11.sp,modifier=Modifier.padding(top=3.dp))}}}
 }}}
@Composable fun GameTile(g:GameCard,open:(GameCard)->Unit){val top=g.candidates.sortedByDescending{it.score}.take(5);Surface(onClick={open(g)},color=Card,shape=RoundedCornerShape(24.dp),border=BorderStroke(1.dp,Line),modifier=Modifier.padding(horizontal=20.dp,vertical=7.dp)){Column(Modifier.padding(18.dp)){Row{Column(Modifier.weight(1f)){Text("${g.away}  @  ${g.home}",fontSize=21.sp,fontWeight=FontWeight.Black);Text(g.kickoff,color=Muted,fontSize=12.sp)};Surface(color=Blue.copy(.10f),shape=RoundedCornerShape(12.dp)){Text("ENV ${g.environment}",color=Blue,fontWeight=FontWeight.Bold,fontSize=11.sp,modifier=Modifier.padding(8.dp,5.dp))}};Text(smartSummary(g),color=Muted,fontSize=12.sp,modifier=Modifier.padding(vertical=10.dp));HorizontalDivider(color=Line);top.forEachIndexed{i,p->Row(Modifier.padding(top=10.dp),verticalAlignment=Alignment.CenterVertically){Text("#${i+1}",color=if(i==0)Gold else Muted,fontWeight=FontWeight.Black,modifier=Modifier.width(30.dp));Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.Bold);Text("${p.position} • ${p.team}  •  ${shortReason(p)}",color=Muted,fontSize=11.sp)};Text("${p.score}",color=if(i==0)Green else Blue,fontWeight=FontWeight.Black,fontSize=20.sp)}};Text("VIEW FULL MATCHUP  ›",color=Blue,fontWeight=FontWeight.Black,fontSize=11.sp,modifier=Modifier.padding(top=14.dp))}}}
fun smartSummary(g:GameCard):String{val p=g.candidates.maxByOrNull{it.score}?:return g.script;val e=p.exploit?:return g.script;val lane=when(p.position){"RB","QB"->"rushing/front-seven";"WR"->"secondary";"TE"->"red-zone coverage";else->"overall"};return "${p.team} has the strongest $lane TD edge. ${p.name} leads the model; opponent grades: front ${e.frontSeven}, secondary ${e.secondary}, red zone ${e.redZoneDefense}."}
fun shortReason(p:TdCandidate):String{val e=p.exploit;return when(p.position){"RB","QB"->if((e?.frontSeven?:0)>=75)"front-7 edge + usage" else "goal-line/usage edge";"WR"->if((e?.secondary?:0)>=75)"secondary edge + targets" else "targets + red-zone role";"TE"->if((e?.redZoneDefense?:0)>=75)"red-zone coverage edge" else "TE scoring role";else->"model edge"}}
@Composable fun Board(c:List<TdCandidate>){Title("Best TD picks","League-wide ranking driven by usage, red zone and matchup.");LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){itemsIndexed(c){i,p->CandidateRow(i+1,p)}}}
@Composable fun Title(a:String,b:String){Column(Modifier.padding(20.dp,14.dp)){Text(a,fontSize=28.sp,fontWeight=FontWeight.Black);Text(b,color=Muted,fontSize=13.sp)}}
@Composable fun CandidateRow(rank:Int,p:TdCandidate){Surface(color=Card,shape=RoundedCornerShape(18.dp),border=BorderStroke(1.dp,Line)){Row(Modifier.fillMaxWidth().padding(15.dp),verticalAlignment=Alignment.CenterVertically){Text("#$rank",color=Gold,fontWeight=FontWeight.Black);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.Black,fontSize=18.sp);Text("${p.team} • ${p.position} vs ${p.opponent}",color=Muted,fontSize=12.sp);Text(shortReason(p),color=Blue,fontSize=11.sp,modifier=Modifier.padding(top=4.dp))};Column(horizontalAlignment=Alignment.End){Text("${p.score}",color=Green,fontSize=25.sp,fontWeight=FontWeight.Black);Text("${p.probability}% TD",color=Muted,fontSize=11.sp)}}}}
@Composable fun GameDetail(g:GameCard,onBack:()->Unit,learn:LearningEngine){LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{TextButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null);Text("All games")};Text("${g.away} @ ${g.home}",fontSize=30.sp,fontWeight=FontWeight.Black);Text(smartSummary(g),color=Muted,modifier=Modifier.padding(top=5.dp));Row(Modifier.padding(top=12.dp)){Metric("Environment",g.environment.toString());Spacer(Modifier.width(8.dp));Metric("TD looks",g.candidates.size.toString())};Button(onClick={learn.freeze(g)},modifier=Modifier.padding(top=12.dp)){Text("FREEZE PREGAME SNAPSHOT")}};itemsIndexed(g.candidates.filter{it.status.uppercase() !in setOf("OUT","INACTIVE","IR","PUP","SUSPENDED")}.sortedByDescending{it.score}){i,p->Surface(color=Card,shape=RoundedCornerShape(22.dp),border=BorderStroke(1.dp,if(i==0)Blue else Line)){Column(Modifier.padding(18.dp)){Row{Column(Modifier.weight(1f)){Text("#${i+1}  ${p.name}",fontSize=21.sp,fontWeight=FontWeight.Black);Text("${p.position} • ${p.team}",color=Muted)};Text("${p.score}",color=Green,fontSize=30.sp,fontWeight=FontWeight.Black)};Text("MODEL TD ${p.probability}%",color=Gold,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));Factor("Red zone",p.factors.redZone);Factor("Opportunity",p.factors.opportunity);Factor("Matchup",p.effectiveMatchup);Factor("Scheme",p.factors.scheme);Factor("Environment",p.factors.environment);Spacer(Modifier.height(10.dp));p.exploit?.let{ExploitPanel(p.position,it)};MatchupReasons(p);Text(p.reason,modifier=Modifier.padding(top=9.dp))}}}}}
@Composable fun MatchupReasons(p:TdCandidate){val e=p.exploit?:return;val r=buildList{when(p.position){"RB","QB"->{if(e.frontSeven>=75)add("Attackable front seven");if(e.redZoneDefense>=75)add("Favorable goal-line defense")};"WR"->{if(e.secondary>=75)add("Attackable secondary");if(e.redZoneDefense>=75)add("Favorable red-zone coverage")};"TE"->{if(e.secondary>=72)add("Coverage weakness helps TE routes");if(e.redZoneDefense>=75)add("Favorable red-zone matchup")}};if(e.personnelImpact>=70)add("Defensive personnel/injury edge");if(p.goalLineShare>=65)add("Strong goal-line share (${p.goalLineShare}%)");if(p.factors.opportunity>=90)add("Elite projected usage");if(p.factors.redZone>=90)add("Elite scoring-area role")}.take(5);if(r.isNotEmpty()){Text("WHY THIS PICK",color=Blue,fontWeight=FontWeight.Black,fontSize=12.sp,modifier=Modifier.padding(top=12.dp));r.forEach{Text("• $it",fontSize=12.sp,modifier=Modifier.padding(top=3.dp))}}}
@Composable fun ExploitPanel(position:String,e:DefensiveExploit){val edge=when(position){"RB","QB"->((e.frontSeven*.55)+(e.redZoneDefense*.30)+(e.personnelImpact*.15)).toInt();"WR"->((e.secondary*.60)+(e.redZoneDefense*.25)+(e.personnelImpact*.15)).toInt();"TE"->((e.secondary*.35)+(e.redZoneDefense*.45)+(e.personnelImpact*.20)).toInt();else->e.score};Surface(color=Card2,shape=RoundedCornerShape(14.dp),border=BorderStroke(1.dp,Line)){Column(Modifier.fillMaxWidth().padding(12.dp)){Row{Text("DEFENSIVE EXPLOIT",color=Gold,fontWeight=FontWeight.Black);Spacer(Modifier.weight(1f));Text("$edge/100",color=Green,fontWeight=FontWeight.Black)};Text("Front 7 ${e.frontSeven} • Secondary ${e.secondary} • Red zone ${e.redZoneDefense} • Personnel ${e.personnelImpact}",color=Muted,fontSize=11.sp,modifier=Modifier.padding(top=5.dp));Text(e.note,fontSize=12.sp,modifier=Modifier.padding(top=6.dp))}}}
@Composable fun Factor(n:String,v:Double){Row(Modifier.padding(vertical=2.dp)){Text(n,color=Muted,modifier=Modifier.width(100.dp));LinearProgressIndicator(progress={v.toFloat()/100},modifier=Modifier.weight(1f).height(7.dp),color=Blue,trackColor=Line);Text(" ${v.toInt()}",fontWeight=FontWeight.Bold)}}
@Composable fun Metric(n:String,v:String){Surface(color=Card,shape=RoundedCornerShape(15.dp),border=BorderStroke(1.dp,Line)){Column(Modifier.padding(15.dp)){Text(v,fontSize=22.sp,fontWeight=FontWeight.Black,color=Blue);Text(n,color=Muted,fontSize=11.sp)}}}
@Composable fun Scripts(g:List<GameCard>){Title("Game scripts","Projected flow and where touchdowns should come from.");LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){items(g){x->Surface(color=Card,shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(17.dp)){Text("${x.away} @ ${x.home}",fontWeight=FontWeight.Black,fontSize=19.sp);Text(smartSummary(x),color=Muted,modifier=Modifier.padding(top=6.dp));Text("Environment ${x.environment}/100",color=Blue,modifier=Modifier.padding(top=8.dp))}}}}}
@Composable fun Builder(c:List<TdCandidate>){var legs by remember{mutableStateOf(3)};Title("TD Parlays","Build 1–5 leg combinations from the model board.");Column(Modifier.padding(16.dp)){Row{(1..5).forEach{n->FilterChip(selected=legs==n,onClick={legs=n},label={Text("$n")});Spacer(Modifier.width(5.dp))}};Spacer(Modifier.height(14.dp));c.take(legs).forEachIndexed{i,p->CandidateRow(i+1,p)};Text("Avoid blindly stacking players competing for the same scoring share.",color=Muted,modifier=Modifier.padding(top=12.dp))}}
@Composable fun More(l:LearningEngine){Title("More","Model learning, snapshots and calibration.");Column(Modifier.padding(16.dp)){Surface(color=Card,shape=RoundedCornerShape(22.dp),border=BorderStroke(1.dp,Line)){Column(Modifier.padding(20.dp)){Text("MODEL LAB",color=Blue,fontWeight=FontWeight.Bold);Row(Modifier.padding(top=12.dp)){Metric("Snapshots",l.samples().toString());Spacer(Modifier.width(8.dp));Metric("Graded",l.graded().toString())};Text("Red Zone 26% • Opportunity 20% • Matchup 20% • Scheme 12% • Environment 11% • Role/Injury 6% • Explosive 5%",color=Muted,modifier=Modifier.padding(top=16.dp))}}}}
