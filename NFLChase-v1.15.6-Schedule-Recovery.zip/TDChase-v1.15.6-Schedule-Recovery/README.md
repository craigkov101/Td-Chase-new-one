# TD Chase v1.13.0 — Visual Foundation

Modern Android Jetpack Compose UI for NFL TD intelligence. Based on v1.12.0 Reliable Data + Player Signals; retains validated cache, verified rosters, current-week game reports, and live touchdowns.

## Build
Upload the source ZIP to your GitHub repository root and add the provided `build-nfl-chase-v1.13.0.yml` as the repository workflow. Run **Actions → Run workflow**. GitHub Actions installs Java/Gradle, checks source, runs `testDebugUnitTest`, builds `assembleDebug`, and uploads the APK when successful.

## Release
See `RELEASE-NOTES-v1.13.0.md` for new screens, semantic player colors, player insights, game state/venue display, source limitations, and full test status.

**Opportunity index is not a touchdown probability.** Visual design does not imply data-provider completeness; refer to More → Data Connections for freshness and error information.
