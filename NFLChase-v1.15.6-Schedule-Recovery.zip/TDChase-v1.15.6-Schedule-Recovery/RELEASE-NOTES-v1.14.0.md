# TD Chase v1.14.0 — Evidence & Audit Foundation

## What changed

1. **Injury feed recovery:** The ESPN site-v2 `/injuries` routes repeatedly returned errors (26 failures observed in the prior installed app). These are not consulted in production. The app now extracts non-active statuses from the already-validated ESPN roster, including defensive positions. The source is marked **PARTIAL**, not an official practice/game designation. Stale status can NEVER exclude a player or create a matchup advantage. An archived NFL Week 6 published injury snapshot still applies ONLY to its specifically dated game.
2. **Automatic matchup context:** More now includes a roster-backed defensive-secondary panel across available games, with opponent DB names and reported availability. This is NOT a claim of per-route shadow coverage, target separation, or true WR-vs-CB charting. Licensed CSV import remains the only way to add measured route assignments.
3. **Model Lab actually persists:** In addition to existing validated ESPN response caches, v1.14 saves top-ten TD opportunity rankings before kickoff to an atomic on-device JSON ledger. An observed scenario score is attached when ready before kickoff. Snapshots are not fabricated retroactively. On launch, every ~30 min while foregrounded, or when pressing the grading button, completed games are checked. Grading requires a FINAL summary AND both full team rushing/receiving boxscore sections. Displays saved, pending, graded, top-3 hits, top-10 hits, and projected-vs-actual error where a predicted score was captured. It does not silently mislabel the opportunity index as a probability or claim automatic calibration.
4. **Data panel labels:** Data Connections differentiates LIVE / RECENT CACHE / STALE CACHE / FAILED / PARTIAL; a roster-only injury signal is PARTIAL.
5. **More tab preloading:** Automatically loads current-week matchup projections in small batches even without opening each game.
6. **Version:** v1.14.0 with the app header updated; retained v1.13 premium cards and visual signals.

## Deliberate limits

- No officially confirmed game-day inactives can be inferred from ESPN's general roster status alone; user must consult the authoritative team/NFL report.
- Proprietary WR/CB charting still requires an authorized provider/feed. Automatic roster context is not route-charted coverage.
- A new install has 0 saved pregame audits until at least one upcoming game's data loads. The app cannot ethically backfill predictions after kickoff. The audit runs when the app is open, not from a guaranteed OS background schedule.
- Probabilities are not historically calibrated; the 0–100 index is an opportunity score.
- Source and Kotlin audit module are preflight-checked, but the complete Compose/Android app must compile in GitHub Actions and be checked on device. No full APK build is asserted here.

## Tests and QA

- New tests: `ModelAuditStoreTest` for atomic persistence, pregame-only freeze, verified finals, incomplete score rejection.
- Added `CurrentWeekEngineTest` stale-roster status safeguards.
- Existing model, ESPN scoreboard, game simulation, and integration tests retained; synthetic fixture injection now opts in explicitly to retired ESPN injury URLs.
- GitHub workflow runs `check_project_integrity.py`, `testDebugUnitTest`, then `assembleDebug` before uploading APK; SDK step verifies installed API 35/Build Tools 35 without `android-actions/setup-android@v3` or assuming sdkmanager is on PATH.
