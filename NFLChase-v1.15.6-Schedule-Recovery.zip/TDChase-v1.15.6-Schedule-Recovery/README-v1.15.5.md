# TD Chase v1.15.5 — Unit test regression repair

This release follows v1.15.4 with the same quarterback / confidence logic. GitHub Actions v1.15.4 ran 80 tests and failed two tests because their expected UI copy was from older builds. The updated tests now assert the new documented output and still validate that numerical risk is identified as observed sacks/turnovers rather than measured pressure, and that traded receiver projections are explicitly estimated.

## Build

Upload `NFLChase-v1.15.5-Test-Regressions-Fixed.zip` to the repository root and replace `.github/workflows/build-nfl-chase-v0.3.0.yml` with the matching workflow YAML. Manually dispatch `Build TD Chase v1.15.5`. The workflow now saves unit-test XML and HTML reports even if tests fail. An actual Android APK build and phone verification are still necessary; no tests are skipped.
