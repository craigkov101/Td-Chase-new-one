# TD Chase v1.15.1 — Scripts scrolling/performance hotfix

## Performance and stability changes

- Replaced image-heavy Scripts preview scoreboards with small text scorecards (no network requests or 500px logo decoding during flings). Team logos are still available in full game details and elsewhere in the app.
- Removed full-screen Crossfade composition of both previous and next tabs; a fast Scripts tab is no longer rendered concurrently with another screen during transitions.
- LazyColumn now retains scroll state, uses an item content type, and guards against duplicate or blank feed keys; accidental taps are disabled during active scroll gestures.
- Background game simulation scheduling now runs with one bounded worker, a short feed-update debounce, and per-game cancellation of stale queued jobs. During active Scripts scrolling, uncompleted simulation jobs are cancelled and rescheduled on idle. Completed reports remain visible. The 5,000-trial simulation settings and projection calculations are unchanged.
- All existing game previews, game scripts, eligibility logic, injury evidence, scoring history, WR/CB coverage and audit functions remain in the project.

## Checks

- `python3 tools/check_project_integrity.py` now includes eight new Scripts-specific checks.
- `ScriptsPerformanceTest.kt` exercises duplicate and blank-ID defensive behavior.
- A real Android device fling stress test is still needed to verify the fix in the environment where the crash happened. An Android SDK/emulator is not available in this editing environment. GitHub Actions must compile and run the full Android unit tests.

## Build

Upload `NFLChase-v1.15.1-Scripts-Stability-Fix.zip` to the repository root and replace the GitHub workflow with the supplied `build-nfl-chase-v1.15.1.yml`. Run the workflow manually. Use the artifact `TD-Chase-v1.15.1` and install the APK on your phone.
