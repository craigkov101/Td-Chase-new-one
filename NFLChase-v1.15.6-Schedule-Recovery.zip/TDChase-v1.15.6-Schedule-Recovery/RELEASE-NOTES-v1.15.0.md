# TD Chase v1.15.0 — Upcoming Slate + Real Usage + Matchup Context

## User-requested features

- Header and launcher use the provided TD CHASE artwork, not a placeholder football glyph. The image is packaged locally, so it loads offline.
- The active board hides FINAL/POST and all stale SCHEDULED games whose kickoff is already past. The selected date defaults to the **first remaining game day**, so on Saturday October 17 the first available Week 6 Sunday fixture appears instead of the Thursday game. Live in-progress games remain accessible.
- Logo tiles standardized to 52dp with proportional ESPN NFL images and an abbreviated offline fallback. No artificial/distorted team logo composites were created. Official artwork is fetched from ESPN; unavailable connections render the readable abbreviation instead.
- Player profiles now retain *up to five dated box-score rows* (targets, carries, receiving/rushing yards, TD), separately attributed to the source team. New-team arrivals do not lose their former-team stats.
- Houston's game detail has a dedicated Marvin Harrison Jr./C.J. Stroud panel. Last verified Arizona usage contributes to an **illustrative target and receiving-yards range** constrained by verified Texans team volume, with a list of teammates' recently recorded target opportunities. Because it is a trade and role uncertainty is large, the app does not claim to know future routes, snaps, chemistry, or TD probabilities.
- A tentative WR/CB matchup list now uses actual receiving candidates and reported opposing secondary names from ESPN rosters, prioritizing roster entries marked starters when available. It is explicitly **not** measured coverage, a shadow-assignment confirmation, or an input that secretly boosts TD probabilities. Licensed charting import remains supported.
- v1.14.0 data-health statuses, ESPN response caching, injury fallback, pregame audit freeze, postgame grading, Model Lab and pre-existing modules are retained.

## Technical tests

- `SlateAndUsageTest.kt` verifies completed/past fixtures are hidden, live games persist, Sunday's date auto-selects, traded receiver history is preserved, target ranges require data, and coverage projections carry uncertainty labels.
- Existing integration tests remain in the package.
- Static project checks: `python3 tools/check_project_integrity.py` (28 checks).
- Pure Kotlin slate + usage + coverage smoke test and Kotlin source compilation for the data modules passed using isolated JSON stubs. This is NOT an Android compilation or a live-feed integration test.

## Important verification still required

- Run manual GitHub Actions `testDebugUnitTest` and `assembleDebug` in the Android SDK environment, then install and test on a real phone. There is no Android SDK, online ESPN feed, or live Android emulator in the source-editing environment.
- Validate launcher icon, date rollover, logos, Texans coverage/target data and all five tabs on device. Real-time injury/roster statuses, unofficial projections and individual corner assignments remain limited by source availability.
- Github Workflow triggers **manual only**. No `push`, `pull_request`, timer or auto-run triggers.
