# TD Chase v1.15.2 — on-demand Scripts stability

The previous v1.15.1 GitHub build succeeded but crashes/lag persisted on the Android device. This update changes the architecture of Scripts rather than attempting another cosmetic list optimization.

## What changed

- Opening **Scripts** now shows lightweight matchup cards immediately. The app does **not** download player statistics or run 5,000-trial simulations for the whole NFL slate merely because this tab is selected.
- To calculate an individual game script, **tap a matchup**. The data requests for its teams then run on the I/O dispatcher; its simulation runs on the Default dispatcher.
- One selected-game job replaces the previous multi-game queue. When changing games, coroutine cancellation interrupts the Monte Carlo loop every 128 trials.
- The full game report now gives each narrative section and scorer a **separate lazy-list item**. Heavy off-screen content is not laid out during fast flings.
- Existing player intelligence, roster context, coverage import, injuries, team scoring trends, and Model Lab remain intact.
- Under **More → Crash Diagnostics**, after a Java/Kotlin uncaught exception you can tap **Copy Last Crash Report** and paste it into ChatGPT. No diagnostics are uploaded automatically. Out-of-memory kills, ANRs and native crashes might not be captured.

## Verification

- Kotlin script engine compiled against the prior data-model test stubs.
- Deterministic simulation and interruption smoke test passed.
- Project-integrity checks passed.
- **A complete Android APK compilation / device fast-fling regression has not been run in the authoring environment**. Run the included GitHub workflow and test on an Android device; if it still closes, share More → Crash Diagnostics or Android logcat.

## Build

Upload the outer `NFLChase-v1.15.2-OnDemand-Scripts-Fix.zip` to the repository root, then install the supplied `build-nfl-chase-v1.15.2.yml` into your existing GitHub Actions workflow and run it manually.
