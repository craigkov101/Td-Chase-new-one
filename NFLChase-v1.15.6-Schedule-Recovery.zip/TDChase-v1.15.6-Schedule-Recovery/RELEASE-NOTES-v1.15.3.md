# TD Chase v1.15.3 — Android System Back Navigation

- Android system Back button navigates from an opened matchup to the originating tab and through visited bottom tabs in reverse order.
- Switching tabs while reading a matchup preserves that matchup as a history destination, so Back returns to it.
- Re-selecting the current tab does not create duplicate history entries. History is bounded to 40 destinations.
- Finished/removed games in history gracefully restore their parent tab.
- Android handles Back normally on the launch Games page with no prior navigation.
- On-screen game detail Back uses exactly the same navigation logic.
- All v1.15.2 on-demand Scripts stability and crash diagnostics are retained.

## Tests

Five navigation unit tests plus source-integrity checks are included. Full Android APK and actual hardware Back testing must occur in GitHub Actions and on a phone.
