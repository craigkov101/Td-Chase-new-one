# TD Chase v1.11.0 — Drive Insights & Visual Refresh

## What changed after the Seattle–Denver postgame audit

- **Retain what worked:** recent target/carry usage is still the primary player-opportunity signal (JSN volume, Wilson workload), with the top-10 limited to players with verified recent usage. Historical receiver/CB charting, injury status, and the Houston roster transaction integration are retained.
- **Protection/turnover context:** where ESPN box-score team statistics explicitly include `sacksYardsLost` and `turnovers`, the app measures last-five sacks *allowed* and giveaways. Missing or ambiguous fields stay missing, not zero. These are proxies; they do NOT measure QB pressure rate, defender-specific impact, or PFF pass-block grades.
- **Possession-based Monte Carlo:** 5,000 reproducible scenario trials with 8–14 simulated offensive possessions per team and TD, FG, turnover, or no-score outcomes. Turnovers may create a short-field opportunity for the other team. The model is a transparent heuristic, **not** historically calibrated. The source inputs and sample sizes appear in each script.
- **Short-yardage touchdown evidence:** reads touchdown-finishers on rushing plays of five yards or less when identifiable in ESPN game summaries and matched to a team/player. A small bonus gives proven finishers (including low-volume backs) visibility; this is NOT a complete measure of short-yardage carries, personnel packages or scoring probability. Nonmatching plays yield no claims.
- **More cautious injury heuristics:** confirmed defensive-back and front-seven absences contribute smaller, capped scoring adjustments. Questionable players are not treated as out. WR/CB per-route assignment still requires legitimate imported charting.
- **Visual redesign:** dark blue-gray surfaces, subtle gradient header, sea-glass green data successes, blue action accents, amber model opportunities, coral injuries/risks, low-intensity purple coverage highlights, team-colored matchup stripes, clear game-script sections, clean projected score tiles, top-3 player cards, and more readable date navigation.

## What is NOT yet solved

- Fully charted next-game WR/CB assignments are unavailable without licensed data; they can only be projected before a game.
- The app cannot infer pressure rates, goal-line *attempt* shares, or final game-day inactives from box scores alone.
- The learning engine remains a prototype; the 5,000 scenario frequencies are NOT verified anytime-TD probabilities or market-beating predictions.
- This package was checked with a local Kotlin data-layer compilation and synthetic fixtures. Full Compose Android compilation, device layout/scroll tests and live ESPN feeds have NOT been verified locally and must pass GitHub Actions before claiming it works on-device.

## QA checklist

1. Run `testDebugUnitTest` and `assembleDebug` from the manual GitHub Action.
2. Launch the v1.11.0 app on device, navigate Thursday and Sunday slate, tap multiple games, return/back, rotate if supported, and pull-to-refresh.
3. Inspect script and TOP 10: no raw JSON, correct source labels, injury status, player usage, risk-proxy sample sizes, complete top-3 write-up and final score.
4. Confirm that games with no risk stats show *unavailable*, not 0. Confirm goal-line attempts are explicitly NOT claimed.
5. Compare one game against official final results; do not adjust weights using only a single example.

VersionCode 1110 / versionName 1.11.0. GitHub workflow dispatch only.
