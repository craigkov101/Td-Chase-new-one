# TD Chase v1.15.4 – Quarterback and data-confidence cleanup

- Fixes QB1 selection based on array ordering. Requires fresh roster starter evidence or repeated recent team-matched passing attempts; otherwise shows Starter TBD.
- Projection outlook exposes the evidence type and uses *recorded* team targets, never claims that backup QBs are starters.
- Retains verified former-team receiver histories when an officially reconciled trade exists.
- Hides unsupported pressure-rate, goal-line-share, licensed coverage, and injury scenario sections instead of rendering a giant uncertainty paragraph. Source limitations are retained behind expandable data notes.
- Preserves Scripts on-demand loading, crash diagnostics and Android system Back navigation from v1.15.3.
- Adds quarterback-specific regression fixtures; source checks do not replace a device test.
