"""Read-only ESPN roster/game-log sample preflight for the v1.15.0 manual build.

This catches empty roster, missing boxscore player stats, and ESPN schema changes.
It tests network access from GitHub Actions, not the user's device network.
"""
import json
import sys
from datetime import datetime
from zoneinfo import ZoneInfo

NOW = datetime.now(ZoneInfo("America/New_York"))
SEASON = NOW.year - 1 if NOW.month <= 2 else NOW.year
from urllib.request import Request, urlopen

BASE = "https://site.api.espn.com/apis/site/v2/sports/football/nfl/"


def get(path):
    req = Request(BASE + path, headers={"Accept": "application/json", "User-Agent": "TDChase/1.15.0 QA (GitHub Actions)"})
    with urlopen(req, timeout=22) as response:
        if response.status != 200:
            raise RuntimeError(f"ESPN HTTP {response.status}: {path}")
        return json.load(response)


def verify(team):
    slug = team.lower()
    roster = get(f"teams/{slug}/roster")
    players = [p for group in roster.get("athletes", []) for p in group.get("items", [])]
    offense = [p for p in players if p.get("position", {}).get("abbreviation") in {"QB", "RB", "WR", "TE"}]
    if len(offense) < 8:
        raise RuntimeError(f"{team}: only {len(offense)} offensive roster players; roster schema possibly changed")
    unusual_status = [p.get("status") for p in offense if isinstance(p.get("status"), dict)]
    print(f"{team} offensive roster: {len(offense)}; object-format status samples: {unusual_status[:1]}")
    schedule = get(f"teams/{slug}/schedule?season={SEASON}&seasontype=2")
    final = []
    for event in schedule.get("events", []):
        competition = (event.get("competitions") or [{}])[0]
        kind = competition.get("status", {}).get("type", {}) or event.get("status", {}).get("type", {})
        if kind.get("completed") or "FINAL" in kind.get("name", ""):
            final.append(event)
    final.sort(key=lambda x:x.get("date", ""), reverse=True)
    if len(final) < 2:
        raise RuntimeError(f"{team}: {len(final)} final games; cannot rank recent player usage")
    games_verified = 0
    score_games = 0
    usage_lines = 0
    def points(entry):
        score = entry.get("score")
        if isinstance(score, dict):
            score = score.get("displayValue",score.get("value"))
        try:
            return int(float(score))
        except (TypeError, ValueError):
            return None
    for event in final[:3]:
        competition = (event.get("competitions") or [{}])[0]
        match = next((c for c in competition.get("competitors", []) if c.get("team", {}).get("abbreviation", "").upper() == team), None)
        if not match:
            raise RuntimeError(f"{team}: game {event.get('id')} competitor abbreviation mismatch")
        team_id = str(match.get("team", {}).get("id", match.get("id", "")))
        summary = get(f"summary?event={event['id']}")
        comps = competition.get("competitors", [])
        values = [points(c) for c in comps]
        if len(values) < 2 or None in values:
            from_summary = ((summary.get("header") or {}).get("competitions") or [{}])[0]
            values = [points(c) for c in from_summary.get("competitors", [])]
        if len(values) >= 2 and all(v is not None for v in values):
            score_games += 1
        boxteams = summary.get("boxscore", {}).get("players", [])
        matching = [x for x in boxteams if str(x.get("team", {}).get("id", "")) == team_id or x.get("team", {}).get("abbreviation", "").upper() == team]
        if not matching:
            raise RuntimeError(f"{team}: game {event['id']} team boxscore not found")
        for box in matching:
            for section in box.get("statistics", []):
                name = section.get("name", "").lower()
                if "receiv" not in name and "rush" not in name:
                    continue
                labels = [str(x).upper() for x in section.get("labels", [])]
                if not labels or not any(x in labels for x in ("TGTS", "TGT", "CAR", "ATT", "REC")):
                    raise RuntimeError(f"{team}: game {event['id']} missing required labeled usage columns for {name}: {labels}")
                usage_lines += len(section.get("athletes", []))
        games_verified += 1
    if score_games < 2:
        raise RuntimeError(f"{team}: only {score_games} usable final score pairs; simulated scripts need both teams' scores")
    if usage_lines < 8:
        raise RuntimeError(f"{team}: {usage_lines} player usage entries in {games_verified} game boxes; data incomplete")
    print(f"{team}: PASS — {games_verified} recent summaries, {usage_lines} verifiable player stat rows, {score_games} score pairs")


if __name__ == "__main__":
    try:
        for code in ("HOU", "JAX", "ARI", "SEA"):
            verify(code)
        if SEASON == 2026:
            hou = get("teams/hou/roster")
            hou_names = {p.get("displayName", "").lower().rstrip(".")
                for group in hou.get("athletes", []) for p in group.get("items", [])}
            if "marvin harrison jr" not in hou_names:
                print("WARN: ESPN Houston roster lacks Marvin Harrison Jr.; dated official transaction fallback applies")
            else:
                print("PASS: ESPN Houston roster includes Marvin Harrison Jr.")
        print("PASS: Sample of four ESPN rosters and game logs readable from GitHub environment (not an all-team guarantee)")
    except Exception as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        sys.exit(1)
