# TD Chase v1.15.6 — Schedule Recovery

Fixes blank NFL slate when ESPN scoreboard returns HTTP 400.

- Removes fragile multi-day date-range request; tries season/week plus each week day (including Monday).
- If scoreboard is empty or blocked, attempts up to 32 ESPN team schedule feeds in a bounded pool, accepting only current-week events and deduplicating IDs.
- Adds a dated, official Week 6 Monday-night fixture (Washington at San Francisco, 2026-10-19 8:15 p.m. Eastern) to the emergency fixture backup, clearly labeled as not a verified live status.
- Simplifies user-facing schedule-failure messaging.
- Adds regression tests for Monday night visibility and recovery from team schedules.
- Preserves Scripts performance, Back navigation, QB confidence checks, and all preceding features.

Network verification and Android APK unit tests must still be run in GitHub. ESPN team schedule recovery is not an independent live provider. If providers fail, static fixture backup may show a matchup without player projections.
