package com.nflchase.tdengine.data

import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.time.Instant
import java.util.concurrent.atomic.AtomicInteger

class ReliableFeedsTest {
    private val url="https://site.api.espn.com/apis/site/v2/sports/football/nfl/teams/sea/roster"
    private val roster="""{"athletes":[{"items":[{"displayName":"A"}]}]}"""
    private fun folder():File=java.nio.file.Files.createTempDirectory("feedtest").toFile().apply{deleteOnExit()}

    @Test fun `live request writes validated cache and avoids duplicate network request`() {
        var now=100_000L
        val calls=AtomicInteger()
        val feed=ReliableFeeds(folder(),{ calls.incrementAndGet(); roster },{now})
        assertEquals(roster,feed.text(url))
        assertEquals(roster,feed.text(url))
        assertEquals(1,calls.get())
        assertEquals("RECENT CACHE",feed.status(url)?.state)
    }
    @Test fun `active game summary bypasses fresh cache while preserving fallback`() {
        var now=100_000L
        val calls=AtomicInteger()
        var offline=false
        val summaryUrl="https://site.api.espn.com/apis/site/v2/sports/football/nfl/summary?event=123"
        val response="""{"boxscore":{"players":[]}}"""
        val feed=ReliableFeeds(folder(),{calls.incrementAndGet(); if(offline)error("offline") else response},{now})
        feed.text(summaryUrl)
        feed.text(summaryUrl)
        assertEquals(1,calls.get())
        feed.urgentText(summaryUrl)
        assertEquals(2,calls.get())
        offline=true
        assertEquals(response,feed.urgentText(summaryUrl))
        assertEquals("STALE CACHE",feed.status(summaryUrl)?.state)
    }
    @Test fun `network failure uses last good cached result with stale label`() {
        var now=100_000L
        var failing=false
        val feed=ReliableFeeds(folder(),{ if(failing)error("offline") else roster },{now})
        feed.text(url)
        now+=12*60_000
        failing=true
        assertEquals(roster,feed.text(url))
        assertEquals("STALE CACHE",feed.status(url)?.state)
        assertTrue((feed.status(url)?.ageMinutes ?: 0)>0)
    }
    @Test fun `too old cache is never treated as current`() {
        var now=100_000L
        var failing=false
        val feed=ReliableFeeds(folder(),{ if(failing)error("offline") else roster },{now})
        feed.text(url)
        now+=72*60*60_000L
        failing=true
        try { feed.text(url);fail("Must reject expired roster") }
        catch(e:IllegalStateException){assertTrue(e.message!!.contains("no usable cached data"))}
    }
    @Test fun `corrupted response is not persisted`() {
        val feed=ReliableFeeds(folder(),{ "{not json" },{100_000L})
        try{feed.text(url);fail("Must reject malformed payload")}
        catch(_:IllegalStateException){}
        assertEquals(0,feed.cacheFiles())
    }
    @Test fun `force refresh bypasses otherwise fresh cache`() {
        val calls=AtomicInteger()
        val feed=ReliableFeeds(folder(),{ calls.incrementAndGet(); roster },{100_000L})
        feed.text(url)
        feed.forceRefresh()
        feed.text(url)
        assertEquals(2,calls.get())
    }
    @Test fun `fixed October dates are not part of future schedule windows`() {
        val november=ScheduleWindow.days(Instant.parse("2026-11-02T22:00:00Z"))
        assertEquals("2026-10-29",november.first().toString())
        assertFalse(november.any { it.toString()=="2026-10-15" })
    }
    @Test fun `injury reports are never cached for a whole day as fresh`() {
        val policy=FeedPolicy.forUrl("https://site.api.espn.com/apis/site/v2/sports/football/nfl/teams/den/injuries")
        assertTrue(policy.freshMillis<=5*60_000)
        assertTrue(policy.staleMillis<=3*60*60_000)
    }
}
