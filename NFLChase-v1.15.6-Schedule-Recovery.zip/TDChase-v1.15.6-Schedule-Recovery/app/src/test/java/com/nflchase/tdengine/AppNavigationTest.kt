package com.nflchase.tdengine

import org.junit.Assert.*
import org.junit.Test

class AppNavigationTest {
    @Test fun gameDetailBackReturnsToOriginatingScriptsTab() {
        val history=AppPageHistory()
        val games=AppPage(Tab.GAMES)
        val scripts=AppPage(Tab.SCRIPTS)
        val opened=AppPage(Tab.SCRIPTS,"nfl-matchup-123")
        assertTrue(history.record(games,scripts))
        assertTrue(history.record(scripts,opened))
        assertEquals(scripts,history.pop())
        assertEquals(games,history.pop())
        assertFalse(history.hasPrevious)
        assertNull(history.pop())
    }

    @Test fun bottomTabsReturnThroughVisitedTabsInOrder() {
        val history=AppPageHistory()
        val games=AppPage(Tab.GAMES)
        val picks=AppPage(Tab.PICKS)
        val parlays=AppPage(Tab.PARLAYS)
        val more=AppPage(Tab.MORE)
        history.record(games,picks)
        history.record(picks,parlays)
        history.record(parlays,more)
        assertEquals(parlays,history.pop())
        assertEquals(picks,history.pop())
        assertEquals(games,history.pop())
    }

    @Test fun backRestoresGameDetailWhenSwitchingTabsFromIt() {
        val history=AppPageHistory()
        val root=AppPage(Tab.GAMES)
        val game=AppPage(Tab.GAMES,"game1")
        history.record(root,game)
        history.record(game,AppPage(Tab.MORE))
        assertEquals(game,history.pop())
        assertEquals(root,history.pop())
    }

    @Test fun selectingTheSamePageDoesNotPushDuplicateHistory() {
        val history=AppPageHistory()
        val page=AppPage(Tab.SCRIPTS)
        assertFalse(history.record(page,page))
        assertNull(history.pop())
        val game=AppPage(Tab.SCRIPTS,"game-1")
        assertTrue(history.record(page,game))
        assertFalse(history.record(game,game))
        assertEquals(page,history.pop())
    }

    @Test fun longNavigationSessionsAreBounded() {
        val history=AppPageHistory(maxEntries=3)
        val pages=listOf(Tab.GAMES,Tab.PICKS,Tab.SCRIPTS,Tab.PARLAYS,Tab.MORE)
        for(i in 0 until pages.lastIndex) history.record(AppPage(pages[i]),AppPage(pages[i+1]))
        assertEquals(AppPage(Tab.PARLAYS),history.pop())
        assertEquals(AppPage(Tab.SCRIPTS),history.pop())
        assertEquals(AppPage(Tab.PICKS),history.pop())
        assertNull(history.pop())
    }
}
