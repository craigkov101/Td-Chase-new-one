package com.nflchase.tdengine.data

import org.junit.Assert.*
import org.junit.Test
import org.json.JSONObject

class QuarterbackEvidenceTest {
    private fun qb(name:String,starter:Boolean=false) =
        EspnRosterParser.Athlete(name,"QB","Roster listed","Active","",starter)

    @Test fun `backup appearing first never becomes starter`() {
        val roster=listOf(qb("Davis Mills"),qb("C.J. Stroud",true))
        val resolved=EspnQuarterbackEvidence.resolve(roster,emptyList(),"LIVE")
        assertEquals("C.J. Stroud",resolved.name)
        assertTrue(resolved.evidence.contains("roster-listed"))
    }

    @Test fun `strong repeat passing evidence beats unranked QB list`() {
        val roster=listOf(qb("Davis Mills"),qb("C.J. Stroud"))
        val games=listOf(mapOf("cj stroud" to 31,"davis mills" to 0),
            mapOf("cj stroud" to 29,"davis mills" to 0))
        assertEquals("C.J. Stroud",EspnQuarterbackEvidence.resolve(roster,games,"LIVE").name)
    }

    @Test fun `no proof gives no quarterback name`() {
        val roster=listOf(qb("Davis Mills"),qb("C.J. Stroud"))
        assertNull(EspnQuarterbackEvidence.resolve(roster,emptyList(),"LIVE").name)
        assertNull(EspnQuarterbackEvidence.resolve(roster,listOf(mapOf("cj stroud" to 30)),"LIVE").name)
    }

    @Test fun `stale roster cannot confirm projected starter`() {
        assertNull(EspnQuarterbackEvidence.resolve(listOf(qb("C.J. Stroud",true)),emptyList(),"STALE CACHE").name)
    }

    @Test fun `passing parser accepts ESPN attempts and rejects other team`() {
        val fixture=JSONObject("""{"boxscore":{"players":[
          {"team":{"id":"34","abbreviation":"HOU"},"statistics":[{"name":"passing","labels":["C/ATT","YDS"],"athletes":[
            {"athlete":{"displayName":"C.J. Stroud"},"stats":["22/32","271"]},
            {"athlete":{"displayName":"Davis Mills"},"stats":["0/0","0"]}]}]},
          {"team":{"id":"30","abbreviation":"JAX"},"statistics":[{"name":"passing","labels":["C/ATT"],"athletes":[
            {"athlete":{"displayName":"Opponent"},"stats":["21/25"]}]}]}
         ]}}""")
        val parsed=EspnQuarterbackEvidence.passingAttempts(fixture,"34","HOU")
        assertEquals(32,parsed["cj stroud"])
        assertFalse(parsed.containsKey("opponent"))
    }
}
