package com.nflchase.tdengine.data

import org.junit.Assert.*
import org.junit.Test

class PlayerSignalsTest {
    private fun player(name: String="Player", pos: String="WR", games: Int=5,
                       targets: Double=0.0, carries: Double=0.0, goalLine: Int=0,
                       status: String="Roster listed", trend:Double=0.0):WeekCandidate =
        WeekCandidate(name, "SEA", pos, status, 55, "Observed", games, targets, carries, 0, goalLine, trend)

    @Test fun `elite receiver target volume has blue usage signal`() {
        assertTrue(PlayerSignals.classify(player(targets=8.2)).any { it.kind==SignalKind.VOLUME })
    }
    @Test fun `recorded short rushing touchdowns create gold goal line signal`() {
        assertTrue(PlayerSignals.classify(player(pos="RB",carries=4.0,goalLine=1)).any { it.kind==SignalKind.GOAL_LINE })
    }
    @Test fun `questionable and stale status are warnings not positive matchup`() {
        val signals=PlayerSignals.classify(player(status="Questionable"))
        assertTrue(signals.any { it.kind==SignalKind.AVAILABILITY })
    }
    @Test fun `small sample never appears as a calibrated breakout signal`() {
        val kinds=PlayerSignals.classify(player(games=2,trend=5.0)).map { it.kind }
        assertTrue(SignalKind.SMALL_SAMPLE in kinds)
        assertFalse(SignalKind.RISING in kinds)
    }
    @Test fun `high role growth requires historical sample`() {
        assertTrue(PlayerSignals.classify(player(games=5,trend=2.0)).any { it.kind==SignalKind.RISING })
    }
}
