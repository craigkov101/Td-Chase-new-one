package com.nflchase.tdengine.data

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class IntegratedMatchupTest {
 @Test fun `usage injury and scoring simulation stay aligned`() {
  fun verify(condition:Boolean, label:String) { assertTrue(label,condition) }
 val rosterSea="""{"athletes":[{"items":[{"displayName":"Receiver One","position":{"abbreviation":"WR"},"status":{"name":"Active"}},{"displayName":"Running One","position":{"abbreviation":"RB"},"status":{"name":"Active"}}]}]}"""
 val rosterDen="""{"athletes":[{"items":[{"displayName":"Receiver Two","position":{"abbreviation":"WR"},"status":{"name":"Active"}},{"displayName":"Running Two","position":{"abbreviation":"RB"},"status":{"name":"Active"}}]}]}"""
 val schedule="""{"events":[
 {"id":"101","date":"2026-10-04T20:00:00Z","competitions":[{"status":{"type":{"completed":true,"name":"STATUS_FINAL"}},"competitors":[{"team":{"id":"26","abbreviation":"SEA"},"score":24},{"team":{"id":"7","abbreviation":"DEN"},"score":17}]}]},
 {"id":"102","date":"2026-10-11T20:00:00Z","competitions":[{"status":{"type":{"completed":true,"name":"STATUS_FINAL"}},"competitors":[{"team":{"id":"26","abbreviation":"SEA"},"score":21},{"team":{"id":"7","abbreviation":"DEN"},"score":20}]}]}
 ]}"""
 val summary="""{"boxscore":{"players":[
 {"team":{"id":"26","abbreviation":"SEA"},"statistics":[
  {"name":"receiving","labels":["REC","YDS","TD","TGTS"],"athletes":[{"athlete":{"displayName":"Receiver One"},"stats":["7","98","1","10"]}]},
  {"name":"rushing","labels":["CAR","YDS","TD"],"athletes":[{"athlete":{"displayName":"Running One"},"stats":["14","68","0"]}]}]},
 {"team":{"id":"7","abbreviation":"DEN"},"statistics":[
  {"name":"receiving","labels":["REC","YDS","TD","TGTS"],"athletes":[{"athlete":{"displayName":"Receiver Two"},"stats":["6","92","1","8"]}]},
  {"name":"rushing","labels":["CAR","YDS","TD"],"athletes":[{"athlete":{"displayName":"Running Two"},"stats":["17","75","1"]}]}]}
 ]},"header":{"competitions":[{"competitors":[{"team":{"abbreviation":"SEA"},"score":24},{"team":{"abbreviation":"DEN"},"score":17}]}]},"scoringPlays":[]}"""
 val injDen="""{"injuries":[{"team":{"abbreviation":"DEN"},"injuries":[{"athlete":{"displayName":"Defensive Corner","position":{"abbreviation":"CB"}},"status":"Out"}]}]}"""
 val injSea="""{"injuries":[{"team":{"abbreviation":"SEA"},"injuries":[{"athlete":{"displayName":"Running One","position":{"abbreviation":"RB"}},"status":"Out"}]}]}"""
 val fetch:(String)->JSONObject={url->when{
  url.contains("/sea/roster")->JSONObject(rosterSea)
  url.contains("/den/roster")->JSONObject(rosterDen)
  url.contains("/schedule?")->JSONObject(schedule)
  url.contains("/summary?")->JSONObject(summary)
  url.contains("/den/injuries")->JSONObject(injDen)
  url.contains("/sea/injuries")->JSONObject(injSea)
  else->error("Unknown fixture URL $url")
 }}
 val engine=CurrentWeekEngine(fetch, useLegacyInjuryEndpoints=true)
 val game=LiveScheduleGame("game1","SEA @ DEN","2026-10-23T00:15:00Z","SCHEDULED")
 val projection=engine.load(game)
 verify(projection.candidates.isNotEmpty(),"nonempty player pool")
 verify(projection.candidates.none{it.name=="Running One"},"confirmed out offensive player excluded")
 verify(projection.candidates.any{it.name=="Receiver One"},"actual high-volume receiver included")
 verify(projection.candidates.any{it.name=="Running Two"},"active goal-line rusher retained")
 verify(projection.defensiveNotes.any{it.contains("Defensive Corner")},"specific missing corner reported")
 verify(projection.teamForms.all{it.games>=2},"two final games for both teams")
 verify(projection.candidates.none{it.status.contains("{")},"no raw JSON on player status")
 val script=GameScriptEngine.simulate(game.matchup,projection,trials=400)
 verify(script!=null,"game script simulated")
 verify(script!!.awayScore>0&&script.homeScore>0,"score projection computed")
 verify(script.scorers.size==3,"top three TD looks")
 verify(script.sections.any{it.title.contains("INJUR")},"injury explanation included")

 }
}
