package com.nflchase.tdengine.data

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import java.nio.file.Files
import java.time.Instant

class ModelAuditStoreTest {
    private val kickoff="2026-10-18T20:00:00Z"
    private val pregame=Instant.parse("2026-10-18T18:00:00Z").toEpochMilli()
    private val after=Instant.parse("2026-10-19T02:00:00Z").toEpochMilli()
    private val game=LiveScheduleGame("401999900", "SEA @ DEN", kickoff, "STATUS_SCHEDULED")
    private val projection=WeekProjection(game.id,
        listOf(
            WeekCandidate("Receiver One","SEA","WR","Roster listed",82,"Top usage"),
            WeekCandidate("Running One","SEA","RB","Roster listed",75,"Carries"),
            WeekCandidate("Receiver Two","DEN","WR","Roster listed",72,"Targets")
        ),"Verified ESPN box scores", gamesVerified=4)
    private val finished=JSONObject("""{
      "header":{"competitions":[{
        "status":{"type":{"name":"STATUS_FINAL", "completed":true}},
        "competitors":[
          {"team":{"abbreviation":"SEA"},"score":21},
          {"team":{"abbreviation":"DEN"},"score":17}
        ]
      }]},
      "boxscore":{"players":[
        {"team":{"abbreviation":"SEA"},"statistics":[
          {"name":"receiving","labels":["REC","YDS","TD","TGTS"],"athletes":[
            {"athlete":{"displayName":"Receiver One"},"stats":["7","100","1","9"]},
            {"athlete":{"displayName":"Receiver Three"},"stats":["2","30","0","3"]},
            {"athlete":{"displayName":"Receiver Four"},"stats":["3","40","0","4"]}]},
          {"name":"rushing","labels":["CAR","YDS","TD"],"athletes":[
            {"athlete":{"displayName":"Running One"},"stats":["18","60","0"]}]}]},
        {"team":{"abbreviation":"DEN"},"statistics":[
          {"name":"receiving","labels":["REC","YDS","TD","TGTS"],"athletes":[
            {"athlete":{"displayName":"Receiver Two"},"stats":["8","70","0","9"]},
            {"athlete":{"displayName":"Receiver Five"},"stats":["3","25","0","4"]},
            {"athlete":{"displayName":"Receiver Six"},"stats":["2","14","0","3"]}]},
          {"name":"rushing","labels":["CAR","YDS","TD"],"athletes":[
            {"athlete":{"displayName":"Running Two"},"stats":["12","40","1"]}]}]}
      ]}
    }""")
    @Test fun `persist pregame prediction and grade only after full final`() {
        val file=Files.createTempDirectory("tdchase-audit").resolve("history.json").toFile()
        var now=pregame
        val store=ModelAuditStore(file,{finished},{now})
        assertTrue(store.freeze(game,projection,null))
        assertFalse(store.freeze(game,projection,null))
        assertEquals(1,store.overview().snapshots)
        // Don't cheat by grading before the game, even if somebody hands us a final-shaped fixture.
        assertFalse(store.grade(game.id,finished))
        now=after
        val unfinished=JSONObject(finished.toString())
        unfinished.getJSONObject("header").getJSONArray("competitions").getJSONObject(0)
            .put("status",JSONObject().put("type",JSONObject().put("name","STATUS_IN_PROGRESS").put("completed",false)))
        assertFalse(store.grade(game.id,unfinished))
        assertTrue(store.grade(game.id,finished))
        val reopened=ModelAuditStore(file,{finished},{now})
        assertEquals(1,reopened.overview().gradedGames)
        assertEquals(1,reopened.overview().topThreeHits)
        assertEquals(1,reopened.overview().topTenHits)
        assertFalse(reopened.grade(game.id,finished))
    }
    @Test fun `never creates retrospective predictions`() {
        val file=Files.createTempDirectory("tdchase-audit").resolve("history.json").toFile()
        val store=ModelAuditStore(file,{finished},{after})
        assertFalse(store.freeze(game,projection,null))
        assertEquals(0,store.overview().snapshots)
    }
    @Test fun `summary missing team stats cannot be graded`() {
        val file=Files.createTempDirectory("tdchase-audit").resolve("history.json").toFile()
        var now=pregame
        val store=ModelAuditStore(file,{finished},{now})
        assertTrue(store.freeze(game,projection,null))
        now=after
        val broken=JSONObject(finished.toString()).put("boxscore",JSONObject().put("players",org.json.JSONArray()))
        assertFalse(store.grade(game.id,broken))
        assertEquals(1,store.overview().pendingGames)
    }
}
