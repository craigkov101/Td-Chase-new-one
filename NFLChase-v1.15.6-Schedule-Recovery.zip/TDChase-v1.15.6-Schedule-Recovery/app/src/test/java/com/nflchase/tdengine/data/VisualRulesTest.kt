package com.nflchase.tdengine.data

import org.junit.Assert.*
import org.junit.Test

class VisualRulesTest {
    private fun player(pos: String = "WR", games: Int = 5, status: String = "Roster listed", short: Int = 0, targets: Double = 8.0) =
        WeekCandidate("Sample Player", "SEA", pos, status, 72, "Verified usage", games, targets, 0.0, 0, short)

    @Test fun warningTakesPriorityOverOpportunity() {
        val badge = VisualRules.badge(player(status = "Questionable", short = 1))
        assertEquals(EvidenceTone.WARNING, badge.tone)
        assertEquals("STATUS CHECK", badge.label)
    }
    @Test fun limitedSampleDoesNotBecomeHighConfidence() {
        assertEquals("LIMITED DATA", VisualRules.badge(player(games = 1)).label)
        assertEquals("LIMITED DATA", VisualRules.badge(player(games = 5), partial = true).label)
    }
    @Test fun shortFinishShowsDocumentedGoalLineEvidence() {
        assertEquals("GOAL-LINE", VisualRules.badge(player(short = 2)).label)
    }
    @Test fun recognizedAndUnknownGameStatesAreHonest() {
        assertEquals("LIVE", VisualRules.gameBadge("IN").label)
        assertEquals("UPCOMING", VisualRules.gameBadge("scheduled").label)
        assertEquals("FINAL", VisualRules.gameBadge("FINAL").label)
        assertEquals("STATUS UNVERIFIED", VisualRules.gameBadge("mystery").label)
    }
    @Test fun positionFiltersAndScoresAreDeterministic() {
        val rb = player("RB").copy(name="Back", score=52)
        val wr = player().copy(name="Wideout", score=82)
        assertEquals(listOf("Wideout", "Back"), VisualRules.filtered(listOf(rb,wr),"ALL").map { it.name })
        assertEquals(listOf("Back"), VisualRules.filtered(listOf(rb,wr),"RB").map { it.name })
        assertFalse(VisualRules.OPPORTUNITY_CAPTION.contains("PROBABILITY"))
    }
    @Test fun espnAthleteIdDefaultsToSafePlaceholder() {
        assertEquals("", player().athleteId)
    }
}

// Additional parsing coverage belongs to the same test package; this checks that
// optional headshot IDs are taken from verified roster JSON, never inferred from names.
class VisualRosterIdTest {
    @Test fun validEspnIdIsPreserved() {
        val payload = org.json.JSONObject("""{"athletes":[{"items":[{"id":"3981234","displayName":"Sample Receiver","position":{"abbreviation":"WR"},"status":"active"}]}]}""")
        assertEquals("3981234", EspnRosterParser.parse(payload).single().id)
    }
    @Test fun unsafeIdIsNotUsedAsImageUrl() {
        val payload = org.json.JSONObject("""{"athletes":[{"items":[{"id":"not/numeric","displayName":"Sample Receiver","position":{"abbreviation":"WR"},"status":"active"}]}]}""")
        assertEquals("", EspnRosterParser.parse(payload).single().id)
    }
}
