package com.nflchase.tdengine.data

import org.json.JSONObject
import org.json.JSONArray
import org.junit.Assert.*
import org.junit.Test

class DriveEvidenceTest {
    private fun summary():JSONObject {
        val teams=JSONArray().put(JSONObject()
            .put("team", JSONObject().put("id","7").put("abbreviation","DEN"))
            .put("statistics",JSONArray()
                .put(JSONObject().put("name","sacksYardsLost").put("displayValue","5-38"))
                .put(JSONObject().put("name","turnovers").put("displayValue","3"))))
        val plays=JSONArray()
            .put(JSONObject().put("team",JSONObject().put("id","7"))
                .put("type",JSONObject().put("text","Rushing Touchdown"))
                .put("text","J.K. Dobbins 4 Yd Run (Kick Good)"))
            .put(JSONObject().put("team",JSONObject().put("id","7"))
                .put("type",JSONObject().put("text","Rushing Touchdown"))
                .put("text","RJ Harvey 1 Yd Run (Kick Good)"))
            .put(JSONObject().put("team",JSONObject().put("id","26"))
                .put("type",JSONObject().put("text","Rushing Touchdown"))
                .put("text","George Holani 1 Yd Run (Kick Good)"))
            .put(JSONObject().put("team",JSONObject().put("id","7"))
                .put("type",JSONObject().put("text","Rushing Touchdown"))
                .put("text","Other Runner 14 Yd Run (Kick Good)"))
            .put(JSONObject().put("team",JSONObject().put("id","7"))
                .put("type",JSONObject().put("text","Field Goal"))
                .put("text","Kicker 23 Yd Field Goal"))
        return JSONObject().put("boxscore",JSONObject().put("teams",teams)).put("scoringPlays",plays)
    }
    @Test fun `team boxscore risks do not confuse defensive sack stats`() {
        val r=TeamRiskParser.read(summary(),"DEN","7")
        assertEquals(5,r.sacksAllowed)
        assertEquals(3,r.giveaways)
        val other=TeamRiskParser.read(summary(),"SEA","26")
        assertNull(other.sacksAllowed)
        assertNull(other.giveaways)
    }
    @Test fun `observed short rushing touchdowns are correctly assigned`() {
        val den=ShortYardageParser.rushingTdFinishers(summary(),"DEN","7")
        assertEquals(1,den[normalName("J.K. Dobbins")])
        assertEquals(1,den[normalName("RJ Harvey")])
        assertFalse(den.containsKey(normalName("Other Runner")))
        val sea=ShortYardageParser.rushingTdFinishers(summary(),"SEA","26")
        assertEquals(1,sea[normalName("George Holani")])
        assertFalse(sea.containsKey(normalName("RJ Harvey")))
    }
    @Test fun `missing data stays missing not fabricated zero`() {
        val r=TeamRiskParser.read(JSONObject(),"DEN")
        assertNull(r.sacksAllowed)
        assertNull(r.giveaways)
        assertTrue(ShortYardageParser.rushingTdFinishers(JSONObject(),"DEN").isEmpty())
    }
}
