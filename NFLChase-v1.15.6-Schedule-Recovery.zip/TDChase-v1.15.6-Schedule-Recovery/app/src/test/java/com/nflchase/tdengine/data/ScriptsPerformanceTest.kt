package com.nflchase.tdengine.data

import org.junit.Assert.*
import org.junit.Test

class ScriptsPerformanceTest {
    @Test fun `repeated feed ids cannot cause a lazy list key crash`() {
        val rows = listOf(
            LiveScheduleGame("a", "SEA @ DEN", "2026-10-18T17:00:00Z", "SCHEDULED"),
            LiveScheduleGame("b", "HOU @ JAX", "2026-10-18T17:00:00Z", "SCHEDULED"),
            LiveScheduleGame("a", "SEA @ DEN", "2026-10-18T17:00:00Z", "SCHEDULED")
        )
        val clean = ScriptsPerformance.uniqueGames(rows)
        assertEquals(2,clean.size)
        assertEquals(2,clean.map(ScriptsPerformance::key).toSet().size)
    }
    @Test fun `blank ids use stable matchup and kickoff fallback`() {
        val one=LiveScheduleGame("", "SEA @ DEN", "2026-10-18T17:00:00Z", "SCHEDULED")
        val other=LiveScheduleGame("", "HOU @ JAX", "2026-10-18T17:00:00Z", "SCHEDULED")
        assertNotEquals(ScriptsPerformance.key(one),ScriptsPerformance.key(other))
        assertEquals(2,ScriptsPerformance.uniqueGames(listOf(one,other,one)).size)
    }
}
