package com.nflchase.tdengine.data

import org.junit.Assert.*
import org.junit.Test
import java.time.Instant

class ScheduleWindowTest {
 @Test fun `weeks are computed dynamically and include Monday night`() {
  val now=Instant.parse("2026-10-16T15:00:00Z")
  val days=ScheduleWindow.days(now)
  assertEquals("2026-10-15",days.first().toString())
  assertTrue(days.any{it.toString()=="2026-10-19"})
 }
 @Test fun `following Thursday becomes new slate after Tuesday`() {
  assertEquals("2026-10-22",ScheduleWindow.start(Instant.parse("2026-10-20T19:00:00Z")).toString())
 }
 @Test fun `January games use preceding NFL season`() {
  assertEquals(2026,nflSeasonFor(Instant.parse("2027-01-20T20:00:00Z")))
 }
 @Test fun `schedule loader does not invent next month fixture backup`() {
  val now=Instant.parse("2026-11-06T15:00:00Z")
  val client=LiveTdClient(fetchText={ error("Simulated offline") })
  val state=client.loadToday(now)
  assertTrue(state.schedule.isEmpty())
  assertTrue(state.error!!.contains("no current backup"))
 }
 @Test fun `scoreboard supports current live fixture without hardcoded dates`() {
  val response="""{"events":[
    {"id":"201","date":"2026-11-05T23:15:00Z","shortName":"SEA @ DEN","status":{"type":{"name":"STATUS_SCHEDULED"}},"competitions":[]},
    {"id":"202","date":"2026-11-08T18:00:00Z","shortName":"HOU @ JAX","status":{"type":{"name":"STATUS_SCHEDULED"}},"competitions":[]}
  ]}"""
  val client=LiveTdClient(fetchText={ response })
  val state=client.loadToday(Instant.parse("2026-11-05T17:00:00Z"))
  assertEquals(2,state.schedule.size)
  assertTrue(state.schedule.any{it.matchup=="SEA @ DEN"})
  assertTrue(state.schedule.none{it.id.startsWith("week6-")})
 }
 @Test fun `in progress touchdown feed bypasses historical summary cache`() {
  val scoreboard="""{"events":[{"id":"301","date":"2026-11-05T23:15:00Z","shortName":"SEA @ DEN",
   "status":{"type":{"name":"STATUS_IN_PROGRESS"}},"competitions":[{"status":{"type":{"name":"STATUS_IN_PROGRESS"}},
   "competitors":[]}]}]}"""
  val summary="""{"scoringPlays":[{"id":"td1","text":"Running Back 2 Yd Run Touchdown",
   "type":{"text":"Rushing Touchdown"},"team":{"abbreviation":"SEA"},"period":{"number":1}}]}"""
  var prioritySummaryCalls=0
  val client=LiveTdClient(fetchText={ _ -> scoreboard },fetchCurrent={ _ -> prioritySummaryCalls++;summary })
  val state=client.loadToday(Instant.parse("2026-11-05T23:30:00Z"))
  assertEquals(1,prioritySummaryCalls)
  assertEquals(1,state.events.size)
 }

 @Test fun `week six verified backup contains Monday night fixture with Eastern kickoff`() {
  val client=LiveTdClient(fetchText={ error("ESPN HTTP 400") })
  val snapshot=client.loadToday(Instant.parse("2026-10-19T21:50:00Z"))
  val monday=snapshot.schedule.firstOrNull { it.matchup=="WAS @ SF" }
  assertNotNull("MNF should remain visible when scoreboard fails",monday)
  assertEquals("2026-10-20T00:15:00Z",monday!!.kickoff)
  assertTrue(SlatePolicy.isActive(monday,Instant.parse("2026-10-19T21:50:00Z")))
  assertFalse(SlatePolicy.isActive(monday,Instant.parse("2026-10-20T00:16:00Z")))
  assertTrue(snapshot.error!!.contains("dated Week 6"))
 }
 @Test fun `team schedule route recovers games when scoreboard refuses dates`() {
  val event="""{"events":[{"id":"987123","date":"2026-10-20T00:15:00Z",
   "shortName":"WAS @ SF","status":{"type":{"name":"STATUS_SCHEDULED"}},"competitions":[]}]}"""
  val client=LiveTdClient(fetchText={url->
   if(url.contains("/teams/") && url.contains("/schedule")) event else error("ESPN HTTP 400")
  })
  val result=client.loadToday(Instant.parse("2026-10-19T22:00:00Z"))
  assertEquals(1,result.schedule.size)
  assertEquals("987123",result.schedule.first().id)
  assertTrue(result.error!!.contains("Team schedule recovery"))
 }

 @Test fun `partial Sunday scoreboard cannot hide Monday night fixture`() {
  val partial="""{"events":[{"id":"sunday-final","date":"2026-10-18T17:00:00Z",
    "shortName":"CHI @ ATL","status":{"type":{"name":"STATUS_FINAL"}},"competitions":[]}]}"""
  val client=LiveTdClient(fetchText={url->
   if(url.contains("scoreboard")) partial else error("ESPN HTTP 400")
  })
  val now=Instant.parse("2026-10-19T22:00:00Z")
  val state=client.loadToday(now)
  assertEquals(listOf("WAS @ SF"),SlatePolicy.upcoming(state.schedule,now).map {it.matchup})
  assertTrue(state.error.orEmpty().contains("Dated Week 6 fixture backup"))
 }

}
