package com.nflchase.tdengine.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.Instant

/** Disk-backed, pregame-only model audit. Never converts an opportunity index into a TD probability.
 * Snapshots are written BEFORE kickoff; box scores are graded only after verified final status.
 * There is no secret "model retraining" here: this is a transparent evidence ledger.
 */
data class AuditRow(
    val matchup: String,
    val state: String,
    val savedAt: String,
    val correctTopThree: Int,
    val actualTopTenTdScorers: Int,
    val projectedScore: String,
    val actualScore: String,
    val scoreError: Int?
)

data class AuditOverview(
    val snapshots: Int,
    val gradedGames: Int,
    val pendingGames: Int,
    val topThreeHits: Int,
    val topTenHits: Int,
    val averageScoreError: Double?,
    val lastError: String?,
    val recent: List<AuditRow>
)

class ModelAuditStore(
    private val destination: File,
    private val fetch: (String) -> JSONObject,
    private val clock: () -> Long = System::currentTimeMillis
) {
    private val lock = Any()
    private var lastNetworkError: String? = null

    private fun load(): JSONObject = runCatching {
        JSONObject(destination.readText()).takeIf { it.optInt("schema", 0) == 1 }
    }.getOrNull() ?: JSONObject().put("schema", 1).put("games", JSONObject())

    private fun writeSafely(root: JSONObject) {
        destination.parentFile?.mkdirs()
        val tmp = File(destination.parentFile, "${destination.name}.tmp")
        tmp.writeText(root.toString())
        if(!tmp.renameTo(destination)) {
            // Preserve the previous valid file if atomic replacement fails.
            tmp.delete()
            error("Could not persist TD Chase model audit")
        }
    }

    /** Freeze the first verified ranking, and attach the score estimate if it arrives pregame.
     * No after-the-fact backfills; no fabricated historical predictions.
     */
    fun freeze(game: LiveScheduleGame, projection: WeekProjection, report: SimulationReport?): Boolean = synchronized(lock) {
        val kickoff = runCatching { Instant.parse(game.kickoff).toEpochMilli() }.getOrNull() ?: return@synchronized false
        if(clock() >= kickoff || !game.id.matches(Regex("[0-9]{5,15}"))) return@synchronized false
        if(projection.gameId != game.id || projection.candidates.size < 3 || projection.gamesVerified < 2) return@synchronized false
        val root = load()
        val games = root.getJSONObject("games")
        val existing = games.optJSONObject(game.id)
        if(existing != null) {
            if(existing.has("prediction") || report == null) return@synchronized false
            existing.put("prediction", JSONObject().put("away",report.awayScore).put("home",report.homeScore))
            writeSafely(root)
            return@synchronized true
        }
        val sides = game.matchup.split(" @ ", " at ",limit=2)
        if(sides.size != 2) return@synchronized false
        val entries = JSONArray()
        projection.candidates.take(10).forEach { p ->
            entries.put(JSONObject().put("name",p.name).put("team",p.team)
                .put("position",p.position).put("opportunity",p.score))
        }
        val snapshot = JSONObject()
            .put("gameId",game.id).put("matchup",game.matchup)
            .put("kickoff",game.kickoff).put("savedAt",Instant.ofEpochMilli(clock()).toString())
            .put("source",projection.source).put("candidates",entries)
            .put("state","PENDING")
        if(report!=null) snapshot.put("prediction",JSONObject().put("away",report.awayScore).put("home",report.homeScore))
        games.put(game.id,snapshot)
        writeSafely(root)
        true
    }

    /** The grader refuses incomplete game summaries, missing team box scores, or nonfinal games. */
    fun grade(gameId:String, summary:JSONObject): Boolean = synchronized(lock) {
        val root=load()
        val games=root.getJSONObject("games")
        val stored=games.optJSONObject(gameId) ?: return@synchronized false
        if(stored.optString("state") != "PENDING") return@synchronized false
        if(clock() < runCatching{Instant.parse(stored.getString("kickoff")).toEpochMilli()}.getOrDefault(Long.MAX_VALUE)) return@synchronized false
        val competition=summary.optJSONObject("header")?.optJSONArray("competitions")?.optJSONObject(0)
            ?: return@synchronized false
        val status=competition.optJSONObject("status")?.optJSONObject("type")
            ?: competition.optJSONObject("status")
            ?: return@synchronized false
        val completed=status.optBoolean("completed",false) ||
            status.optString("name","").contains("FINAL",true)
        if(!completed) return@synchronized false
        val sides=stored.getString("matchup").split(" @ "," at ",limit=2)
        if(sides.size!=2) return@synchronized false
        val away=sides[0];val home=sides[1]
        val awayLines=EspnPlayerStatsParser.boxscore(summary,"",away)
        val homeLines=EspnPlayerStatsParser.boxscore(summary,"",home)
        // Both sides must have a plausible set of individually verified rushing/receiving rows.
        if(awayLines.size < 3 || homeLines.size < 3) return@synchronized false
        val candidates=stored.getJSONArray("candidates")
        val results=JSONArray()
        var hits3=0
        var hits10=0
        for(i in 0 until candidates.length()) {
            val p=candidates.getJSONObject(i)
            val team=p.optString("team")
            val rows=when { sameTeam(team,away)->awayLines; sameTeam(team,home)->homeLines; else->return@synchronized false }
            val scored=(rows[normalName(p.getString("name"))]?.touchdowns ?: 0) > 0
            if(scored) { hits10++; if(i<3) hits3++ }
            results.put(JSONObject().put("player",p.getString("name"))
                .put("team",team).put("scored",scored))
        }
        stored.put("results",results)
        stored.put("gradedAt",Instant.ofEpochMilli(clock()).toString())
        stored.put("state","GRADED")
        stored.put("topThreeHits",hits3)
        stored.put("topTenHits",hits10)
        val actual = EspnScoringParser.summaryFinalScore(summary,away)
        if(actual!=null) stored.put("actual",JSONObject().put("away",actual.first).put("home",actual.second))
        writeSafely(root)
        true
    }

    /** Refresh a small number of historical predictions on launch/refresh; no need for a
     * perpetual background service. At most 5 summaries per invocation.
     */
    fun gradePending(maxChecks:Int=5):Int {
        val ids=synchronized(lock) {
            val games=load().getJSONObject("games")
            games.keys().asSequence().mapNotNull { id ->
                val g=games.optJSONObject(id) ?: return@mapNotNull null
                if(g.optString("state")!="PENDING") return@mapNotNull null
                val kickoff=runCatching{Instant.parse(g.getString("kickoff")).toEpochMilli()}.getOrNull() ?: return@mapNotNull null
                if(clock() < kickoff+2*60*60_000 || clock()-kickoff>21L*24*60*60_000) return@mapNotNull null
                id
            }.take(maxChecks.coerceIn(1,10)).toList()
        }
        var count=0
        for(id in ids) {
            try {
                val summary=fetch("https://site.api.espn.com/apis/site/v2/sports/football/nfl/summary?event=$id")
                if(grade(id,summary)) count++
                lastNetworkError=null
            } catch(e:Exception) {
                lastNetworkError="Game $id: ${e.message?.take(110) ?: "feed unavailable"}"
            }
        }
        return count
    }

    fun overview():AuditOverview=synchronized(lock) {
        val games=load().getJSONObject("games")
        val rows=mutableListOf<AuditRow>()
        val errors=mutableListOf<Int>()
        var hit3=0;var hit10=0;var graded=0
        for(id in games.keys()) {
            val g=games.optJSONObject(id) ?: continue
            val state=g.optString("state","PENDING")
            if(state=="GRADED") {graded++;hit3+=g.optInt("topThreeHits");hit10+=g.optInt("topTenHits")}
            val expected=g.optJSONObject("prediction")
            val actual=g.optJSONObject("actual")
            val error=if(expected!=null && actual!=null) {
                kotlin.math.abs(expected.optInt("away")-actual.optInt("away"))+
                    kotlin.math.abs(expected.optInt("home")-actual.optInt("home"))
            }else null
            if(error!=null)errors+=error
            fun score(o:JSONObject?):String=if(o==null)"Unavailable" else "${o.optInt("away")}-${o.optInt("home")}" 
            rows+=AuditRow(g.optString("matchup"),state,g.optString("savedAt"),g.optInt("topThreeHits"),g.optInt("topTenHits"),score(expected),score(actual),error)
        }
        AuditOverview(rows.size,graded,rows.size-graded,hit3,hit10,
            errors.takeIf{it.isNotEmpty()}?.average(),lastNetworkError,
            rows.sortedByDescending{it.savedAt}.take(8))
    }
}
