package com.nflchase.tdengine.data

import org.json.JSONObject
import java.util.Locale

/** Recent observed *box-score* risks. Sacks allowed are only a pass-protection proxy;
 * this data does not claim to contain pressure rates or defender-level tracking. */
data class TeamRiskMetrics(
    val sacksAllowed: List<Int> = emptyList(),
    val giveaways: List<Int> = emptyList()
) {
    val sacksGames: Int get() = sacksAllowed.size
    val turnoverGames: Int get() = giveaways.size
    val averageSacksAllowed: Double? get() = sacksAllowed.takeIf { it.isNotEmpty() }?.average()
    val averageGiveaways: Double? get() = giveaways.takeIf { it.isNotEmpty() }?.average()
}

internal object TeamRiskParser {
    internal data class Record(val sacksAllowed: Int?, val giveaways: Int?)

    /** Read only team-level offense statistics. ESPN also reports defensive sack totals;
     * those are deliberately NOT treated as sacks allowed. */
    fun read(summary: JSONObject, abbreviation: String, teamId: String = ""): Record {
        val teams=summary.optJSONObject("boxscore")?.optJSONArray("teams") ?: return Record(null,null)
        for(i in 0 until teams.length()) {
            val row=teams.optJSONObject(i) ?: continue
            val team=row.optJSONObject("team") ?: continue
            val id=team.optString("id", "")
            val code=team.optString("abbreviation", "")
            if(!(sameTeam(code,abbreviation) || (teamId.isNotBlank() && id == teamId))) continue
            val stats=row.optJSONArray("statistics") ?: return Record(null,null)
            var sacks: Int?=null;var turnovers: Int?=null
            for(j in 0 until stats.length()) {
                val item=stats.optJSONObject(j) ?: continue
                val key=item.optString("name", "").lowercase(Locale.US)
                    .replace(Regex("[^a-z]"), "")
                val display=item.optString("displayValue", "").trim()
                val first=Regex("^\\d+").find(display)?.value?.toIntOrNull()
                when(key) {
                    "sacksyardslost", "sacksallowed", "times sacked".replace(" ", "") -> if(first!=null) sacks=first
                    "turnovers", "totalturnovers", "giveaways" -> if(first!=null) turnovers=first
                }
            }
            return Record(sacks,turnovers)
        }
        return Record(null,null)
    }
}

/** Observed short rushing-TD finishes, not total goal-line carries or snaps. */
internal object ShortYardageParser {
    private val run=Regex("(?i)^(.+?)\\s+(\\d{1,2})\\s*(?:yd|yards?)\\s*(?:run|rush)(?:\\b|\\s)")
    fun rushingTdFinishers(summary: JSONObject, code: String, teamId: String=""): Map<String,Int> {
        val plays=summary.optJSONArray("scoringPlays") ?: return emptyMap()
        val result=mutableMapOf<String,Int>()
        for(i in 0 until plays.length()) {
            val play=plays.optJSONObject(i) ?: continue
            val team=play.optJSONObject("team") ?: continue
            val matches=sameTeam(team.optString("abbreviation", ""),code) ||
                (teamId.isNotBlank() && team.optString("id", "")==teamId)
            if(!matches) continue
            val text=play.optString("text", "").trim()
            val category=EspnScoringParser.touchdownType(play.optJSONObject("type")?.optString("text", "") ?: "",text)
            if(category!="rushing") continue
            val match=run.find(text) ?: continue
            val yards=match.groupValues[2].toIntOrNull() ?: continue
            if(yards !in 0..5) continue
            val name=normalName(match.groupValues[1])
            if(name.isNotBlank())result[name]=(result[name] ?: 0)+1
        }
        return result
    }
}
