package com.nflchase.tdengine.data

/** Semantic player highlights. These are observations, never promises or TD probabilities. */
enum class SignalKind { VOLUME, RISING, GOAL_LINE, MATCHUP, AVAILABILITY, SMALL_SAMPLE }
data class PlayerSignal(val label: String, val kind: SignalKind, val evidence: String)

object PlayerSignals {
    fun classify(player: WeekCandidate, partialData: Boolean = false): List<PlayerSignal> {
        val result = mutableListOf<PlayerSignal>()
        val status = player.status.lowercase()
        if (listOf("questionable", "doubtful", "day-to-day", "stale", "unverified cached").any { it in status })
            result += PlayerSignal("STATUS CHECK", SignalKind.AVAILABILITY,
                "Availability unresolved: ${player.status.take(90)}")
        if (player.shortRushingTdFinishes > 0)
            result += PlayerSignal("GOAL-LINE", SignalKind.GOAL_LINE,
                "${player.shortRushingTdFinishes} documented rushing TD finishes from five yards or closer; not all goal-line attempts")
        val highVolume = when (player.position) {
            "RB" -> player.recentCarries >= 14 || (player.recentCarries >= 9 && player.recentTargets >= 3)
            "WR", "TE" -> player.recentTargets >= 7
            "QB" -> player.recentCarries >= 6
            else -> false
        }
        if (highVolume) result += PlayerSignal("HIGH USAGE", SignalKind.VOLUME,
            "Recent verified carries ${player.recentCarries} / game and targets ${player.recentTargets} / game")
        if (player.games >= 4 && player.opportunityTrend >= 1.2)
            result += PlayerSignal("RISING ROLE", SignalKind.RISING,
                "Recent opportunity increasing by ${"%.1f".format(java.util.Locale.US,player.opportunityTrend)} per game versus five-game baseline")
        if (player.reason.contains("reported unavailable") && !partialData)
            result += PlayerSignal("INJURY EDGE", SignalKind.MATCHUP,
                "Opponent has reported defensive absences; receiver alignment is not confirmed")
        if (player.games < 3 || partialData)
            result += PlayerSignal("LIMITED DATA", SignalKind.SMALL_SAMPLE,
                "${player.games} verified played games; some requested sources may be incomplete")
        return result.take(3)
    }
}
