package com.nflchase.tdengine.data

import org.json.JSONObject
import java.util.Locale

/** A depth chart's array order is NOT starter evidence. Never infer QB1 from first entry. */
internal object EspnQuarterbackEvidence {
    data class Choice(val name: String?, val evidence: String)

    /** Extract passing attempts from the proper TEAM's ESPN box-score passing category. */
    fun passingAttempts(summary: JSONObject, teamId: String, code: String): Map<String, Int> {
        val players=summary.optJSONObject("boxscore")?.optJSONArray("players") ?: return emptyMap()
        val attempts=mutableMapOf<String,Int>()
        for (i in 0 until players.length()) {
            val team=players.optJSONObject(i) ?: continue
            val ref=team.optJSONObject("team") ?: continue
            val id=ref.optString("id", "")
            val abbr=ref.optString("abbreviation", "")
            if (!sameTeam(abbr,code) && (teamId.isBlank() || id!=teamId)) continue
            val categories=team.optJSONArray("statistics") ?: continue
            for (j in 0 until categories.length()) {
                val section=categories.optJSONObject(j) ?: continue
                if (!section.optString("name", "").lowercase(Locale.US).contains("pass")) continue
                val labels=section.optJSONArray("labels") ?: continue
                val column=(0 until labels.length()).firstOrNull {
                    labels.optString(it).uppercase(Locale.US).trim() in setOf("C/ATT","CMP/ATT","COMP/ATT","ATT")
                } ?: continue
                val label=labels.optString(column).uppercase(Locale.US).trim()
                val rows=section.optJSONArray("athletes") ?: continue
                for (k in 0 until rows.length()) {
                    val row=rows.optJSONObject(k) ?: continue
                    val name=row.optJSONObject("athlete")?.optString("displayName", "")?.let(::normalName).orEmpty()
                    if (name.isBlank()) continue
                    val cell=row.optJSONArray("stats")?.optString(column, "").orEmpty().replace(",", "")
                    val raw=if (label=="ATT") cell else cell.substringAfter('/', "")
                    val count=raw.trim().toIntOrNull() ?: continue
                    if (count in 0..90) attempts[name]=maxOf(attempts[name] ?: 0,count)
                }
            }
        }
        return attempts
    }

    /** Require a fresh roster PLUS either one unambiguous starter flag or repeat observed passing leads. */
    fun resolve(roster: List<EspnRosterParser.Athlete>, games: List<Map<String,Int>>, feedState: String): Choice {
        if (feedState != "LIVE" && feedState != "RECENT CACHE") return Choice(null,"Roster needs refresh")
        val eligible=roster.filter { it.position=="QB" && !EspnRosterParser.unavailable(it.rawStatus) }
        if (eligible.isEmpty()) return Choice(null,"No eligible QB on fresh roster")
        val flagged=eligible.filter { it.rosterStarter }
        if (flagged.size==1) return Choice(flagged.first().name,"ESPN roster-listed starter; game-day status pending")
        // A single start, two part-time passers, or a tied sample cannot establish QB1.
        val recent=games.take(3)
        val leaders=recent.mapNotNull { game ->
            val ranked=eligible.map { it to (game[normalName(it.name)] ?: 0) }.sortedByDescending { it.second }
            if (ranked.isNotEmpty() && ranked[0].second >= 15 &&
                (ranked.size==1 || ranked[0].second > ranked[1].second*2)) ranked[0].first else null
        }
        val mostRecent=leaders.firstOrNull() ?: return Choice(null,"Starter not determined from current roster and recent passing")
        if (leaders.count { normalName(it.name)==normalName(mostRecent.name) } >= 2)
            return Choice(mostRecent.name,"Recent primary passer in multiple completed games; next start not confirmed")
        return Choice(null,"No reliable multi-game QB evidence")
    }
}
