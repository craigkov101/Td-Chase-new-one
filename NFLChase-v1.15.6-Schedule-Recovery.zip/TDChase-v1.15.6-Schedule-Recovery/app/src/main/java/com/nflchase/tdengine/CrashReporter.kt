package com.nflchase.tdengine

import android.content.Context
import android.os.Build
import android.util.Log
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.time.Instant

/** Persists only the latest Java/Kotlin uncaught exception for user-initiated sharing.
 * Never sends diagnostics anywhere and delegates to Android's original crash handler.
 * An ANR or force-kill may not generate an exception report.
 */
object CrashReporter {
    private const val NAME = "tdchase-last-crash.txt"
    @Volatile private var installed = false
    fun install(context: Context) {
        if (installed) return
        synchronized(this) {
            if (installed) return
            val appContext = context.applicationContext
            val original = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { thread, error ->
                try {
                    val stack = StringWriter().also { error.printStackTrace(PrintWriter(it)) }.toString()
                    val record = "TD Chase crash\nTime: ${Instant.now()}\nAndroid: ${Build.VERSION.SDK_INT}\nThread: ${thread.name}\n$stack"
                    File(appContext.filesDir, NAME).writeText(record.take(22000))
                    Log.e("TDChase", "Uncaught exception", error)
                } catch (_: Throwable) { /* Never interfere with the operating system's crash handling */ }
                if (original != null) original.uncaughtException(thread, error)
                else android.os.Process.killProcess(android.os.Process.myPid())
            }
            installed = true
        }
    }
    fun last(context: Context): String? = runCatching {
        File(context.filesDir, NAME).takeIf { it.isFile }?.readText()
    }.getOrNull()
    fun clear(context: Context) { runCatching { File(context.filesDir, NAME).delete() } }
}
