package com.nflchase.tdengine

/** The bottom navigation and opened matchups use one shared history. */
enum class Tab(val title: String) {
    GAMES("Games"), PICKS("Picks"), SCRIPTS("Scripts"), PARLAYS("Parlays"), MORE("More")
}

/** gameId is null for a top-level tab, set for an opened matchup in that tab. */
internal data class AppPage(val tab: Tab, val gameId: String? = null)

/** Pure navigation history, independent of Android so it can be unit-tested. */
internal class AppPageHistory(private val maxEntries: Int = 40) {
    init { require(maxEntries > 0) }

    private val previousPages = java.util.ArrayDeque<AppPage>()
    val hasPrevious: Boolean get() = previousPages.isNotEmpty()

    /** Return false for repeat selections, avoiding duplicate Back destinations. */
    fun record(current: AppPage, next: AppPage): Boolean {
        if (current == next) return false
        previousPages.addLast(current)
        if (previousPages.size > maxEntries) previousPages.removeFirst()
        return true
    }

    /** Returns null at the launch page; Android can then handle exiting normally. */
    fun pop(): AppPage? = if (previousPages.isEmpty()) null else previousPages.removeLast()
}
