package com.nflchase.tdengine.data

import java.util.Locale

/** Display-only decisions: never convert opportunity indexes into probability estimates. */
enum class EvidenceTone { INFO, SUCCESS, OPPORTUNITY, MATCHUP, WARNING, NEUTRAL }
data class DisplayBadge(val label: String, val tone: EvidenceTone, val explanation: String)

object VisualRules {
    const val OPPORTUNITY_CAPTION = "OPPORTUNITY INDEX · NOT TD %"
    val positionFilters = listOf("ALL", "RB", "WR", "TE", "QB")

    fun badge(candidate: WeekCandidate, partial: Boolean = false): DisplayBadge {
        val signals = PlayerSignals.classify(candidate, partial)
        val chosen = signals.firstOrNull { it.kind == SignalKind.AVAILABILITY }
            ?: signals.firstOrNull { it.kind == SignalKind.SMALL_SAMPLE }
            ?: signals.firstOrNull { it.kind == SignalKind.GOAL_LINE }
            ?: signals.firstOrNull { it.kind == SignalKind.RISING }
            ?: signals.firstOrNull { it.kind == SignalKind.VOLUME }
            ?: signals.firstOrNull { it.kind == SignalKind.MATCHUP }
        return when (chosen?.kind) {
            SignalKind.AVAILABILITY -> DisplayBadge("STATUS CHECK", EvidenceTone.WARNING, chosen.evidence)
            SignalKind.SMALL_SAMPLE -> DisplayBadge("LIMITED DATA", EvidenceTone.NEUTRAL, chosen.evidence)
            SignalKind.GOAL_LINE -> DisplayBadge("GOAL-LINE", EvidenceTone.OPPORTUNITY, chosen.evidence)
            SignalKind.RISING -> DisplayBadge("RISING ROLE", EvidenceTone.SUCCESS, chosen.evidence)
            SignalKind.VOLUME -> DisplayBadge("HIGH USAGE", EvidenceTone.INFO, chosen.evidence)
            SignalKind.MATCHUP -> DisplayBadge("INJURY EDGE", EvidenceTone.MATCHUP, chosen.evidence)
            null -> DisplayBadge("USAGE TRACKED", EvidenceTone.NEUTRAL, "Uses available completed-game box scores")
        }
    }

    /** Only recognized states are emphasized. No invented final scores or implied availability. */
    fun gameBadge(state: String): DisplayBadge = when (state.trim().uppercase(Locale.US)) {
        "IN", "LIVE", "IN PROGRESS", "STATUS_IN_PROGRESS" -> DisplayBadge("LIVE", EvidenceTone.SUCCESS, "Game marked in progress by scoreboard")
        "POST", "FINAL", "COMPLETE", "STATUS_FINAL" -> DisplayBadge("FINAL", EvidenceTone.NEUTRAL, "Game marked completed by scoreboard")
        "PRE", "SCHEDULED", "STATUS_SCHEDULED" -> DisplayBadge("UPCOMING", EvidenceTone.INFO, "Game marked scheduled by scoreboard")
        else -> DisplayBadge("STATUS UNVERIFIED", EvidenceTone.NEUTRAL, "Game state not recognized: ${state.take(36)}")
    }

    fun sampleCaption(player: WeekCandidate, partial: Boolean): String = when {
        partial -> "Partial feed · verify before relying on this ranking"
        player.games < 3 -> "Limited sample: ${player.games} played games"
        else -> "${player.games} verified played games · historical usage"
    }

    fun filtered(candidates: List<WeekCandidate>, position: String): List<WeekCandidate> =
        candidates.filter { position == "ALL" || it.position == position }
            .sortedWith(compareByDescending<WeekCandidate> { it.score }.thenByDescending { it.recentTargets + it.recentCarries }.thenBy { it.name })
}
