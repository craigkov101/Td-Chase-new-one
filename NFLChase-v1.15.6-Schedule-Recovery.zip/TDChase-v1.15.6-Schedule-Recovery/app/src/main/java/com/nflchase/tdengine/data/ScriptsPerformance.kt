package com.nflchase.tdengine.data

/** Pure list policy: Compose lazy lists require unique, repeatable keys. */
object ScriptsPerformance {
    fun key(game: LiveScheduleGame): String = game.id.takeIf { it.isNotBlank() }
        ?: "${game.kickoff}|${game.matchup}"

    fun uniqueGames(games: List<LiveScheduleGame>): List<LiveScheduleGame> =
        games.distinctBy(::key)
}
