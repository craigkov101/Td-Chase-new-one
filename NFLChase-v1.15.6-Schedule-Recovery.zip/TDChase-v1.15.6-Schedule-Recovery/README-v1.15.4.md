# TD Chase v1.15.4 — Data Confidence Cleanup

Update of v1.15.3 retaining Android Back and the Scripts lazy report fix.

## Improvements

- Team rosters are **not depth charts**. QB outlook prioritizes a fresh ESPN roster starter flag or a quarterback repeatedly leading his team's observed passing attempts. If unsupported, **Starter TBD** is shown rather than a backup name.
- Projection team-target baselines are labeled as **recorded** recent box-score usage instead of a certified pass-attempt total.
- Receiver history for an official trade keeps the former-team attribution.
- Unsupported route charting, pass-pressure rates, short-yardage carry shares and offensive/defensive injury details are no longer described as verified metrics in the main Scripts panels. Limited-source explanations remain accessible via **Data notes · view sources**, the feed health details in **More**, and Crash Diagnostics.
- Existing simulation uses observed points, sacks allowed and turnovers where supported; it does not invent missing pressure data.

## Builds

Use `NFLChase-v1.15.4-Data-Confidence-Cleanup.zip` with the separately provided manual GitHub workflow. The GitHub CI runner must compile and run Android unit tests. Device-level runtime tests remain necessary.
