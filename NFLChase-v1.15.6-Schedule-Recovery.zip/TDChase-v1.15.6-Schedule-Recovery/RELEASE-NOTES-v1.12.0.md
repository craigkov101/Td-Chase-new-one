# TD Chase v1.12.0 — Reliable Data & Evidence Signals

## Fixes and improvements

- Removed fixed-date ESPN scoreboard retries. The current weekly window is calculated in Eastern time each time the schedule refreshes. The October 2026 fixture list is now used only for its explicitly dated week if every scoreboard request fails.
- Kept active-game touchdown summaries on an urgent refresh path that bypasses historical summary caching; offline requests can still use a visibly stale last-valid response.
- Added resilient read-only ESPN retrieval with a persistent last-validated-response store in app-private files, retries, structural JSON checks and per-endpoint freshness rules.
- Feed categories now report **LIVE**, **RECENT CACHE**, **STALE CACHE**, or **FAILED** in More → Data Connections. Detailed error/age information can be expanded.
- Injury responses sourced from stale disk data are labeled **STALE** and cannot exclude offensive players or add defensive-injury boosts as though they were current.
- Improved ESPN team slug aliases for JAX/JAC, LA/LAR and WAS/WSH; calendar-driven regular-season request year including January/February NFL season rollover.
- Removed recursive generic status extraction that could turn raw ESPN JSON objects into visible injury labels.
- Added color-coded, evidence-based player labels: blue **HIGH USAGE**; mint **RISING ROLE**; amber **GOAL-LINE**; purple **INJURY EDGE**; coral **STATUS CHECK**; neutral **LIMITED DATA**.
- Matchup and top scorer cards use restrained borders matched to those player labels, without pretending the 0–100 opportunity index is a calibrated TD probability.
- Picks and Scripts preload the current slate in bounded batches; Scripts progressively retrieves recent scoring tendencies for all scheduled teams.
- Offloaded 5,000-trial game simulations to background threads with signature validation and at most two simulations running at once, reducing interface stalls.
- Internal saved data survives ordinary Android temporary-cache eviction; responses older than 45 days are pruned from local storage.
- Added unit/integration tests for data freshness, network loss, injured-player filtering, player labels, current and future schedule windows, and coherent scripts.

## Important boundaries

- This release does **not** provide guaranteed network uptime, automatic paid per-route coverage data, verified shadow assignments, or trained touchdown probabilities.
- If a feed is unavailable on a first install, no cached response may exist. The screen must report unavailable data rather than invent a ranking.
- Cached roster and injury data may become stale after transactions or new designations. Stale reports are never treated as current availability.
- ESPN's publicly accessible endpoints are not guaranteed stable and are not an official SLA-backed product feed. For a commercially reliable app, obtain licensed, supported data feeds and a managed backend with health monitoring.
- Full Android/Compose build and on-device data verification must be completed in the GitHub Actions/manual APK test stage; local QA cannot certify them.

## Local QA performed

- Data/model Kotlin modules compiled using local test-support stubs for Android Context and JSON/JUnit. These support syntactic and controlled behavioral checks; they are not substitutes for the Android SDK.
- 50 local unit and integration tests completed three successive runs with no failures.
- 12 deterministic offline source/workflow integrity checks passed.
- Live ESPN endpoint requests could not be made from this build environment. GitHub workflow retains the upstream sample diagnostic as an advisory artifact.

## Installing and troubleshooting

Upload `NFLChase-v1.12.0-Reliable-Data-Signals.zip` to the repository root and use the accompanying manual-only workflow YAML. A successful workflow must run Android unit tests and compile the debug APK.

In the installed app, open **More → Data Connections** to review feed status. Swipe down on Games or open a matchup and use the refresh action to request new roster and injuries. If problems persist, capture the Data Connections details and the failing game screen.
