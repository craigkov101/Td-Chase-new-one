# TD Chase v1.14.0 (Evidence & Audit Fix)

Upload the whole `NFLChase-v1.14.0-Evidence-Audit-Fix.zip` to the ROOT of your GitHub repository.
Replace `.github/workflows/build-nfl-chase-v0.3.0.yml` in the GitHub repository with the supplied `build-nfl-chase-v1.14.0.yml` text. Commit. In Actions > Build TD Chase v1.14.0 > Run workflow, run a MANUAL build. Download the debug APK artifact after tests and compile pass.

For current data, open **More > Data Connections** and **More > Automatic Secondary Context**. Injury statuses are a PARTIAL roster-based fallback and MUST NOT be treated as official game-day inactives. Game-day inactives and paid route coverage do not become available automatically by installing this update.

**Model Lab:** It is expected to start with 0 audits. The app can only save verified upcoming-game pregame rankings while it is open and the feed responds, then grade those saved rankings from ESPN after final. The grading process runs when the app is open (not a guaranteed scheduled background task).

See `RELEASE-NOTES-v1.14.0.md` for design limits, tests and source details.
