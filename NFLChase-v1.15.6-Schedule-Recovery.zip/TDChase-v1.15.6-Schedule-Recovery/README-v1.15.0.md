# TD Chase v1.15.0 — Manual Build

1. Upload **NFLChase-v1.15.0-Sunday-Usage-Coverage.zip** to your GitHub repository's root (do not unpack it there).
2. Open `.github/workflows/build-nfl-chase-v0.3.0.yml` on GitHub; replace its contents with the separately supplied `build-nfl-chase-v1.15.0.yml`, then commit the edit.
3. In GitHub **Actions**, select **Build TD Chase v1.15.0**, press **Run workflow**. This is manual; uploading the ZIP will NOT automatically run the workflow.
4. A green build uploads artifact **TD-Chase-v1.15.0** containing **TD-Chase-v1.15.0.apk**. Download the artifact ZIP, extract the APK, and install it on Android.
5. Check Games, Picks, Scripts, Parlays, More, including Sunday auto-selection, team logos, Houston game detail, and player's actual game logs and projected workload. Check More > Data Connections for feed quality.

**Note:** The downloadable source ZIP is an implementation package, not a successfully compiled APK. The Android compile, test pass, and real-device verification happen only after manual Actions run. Keep source-verified history, predictions and partial injury/coverage context clearly distinguished.
