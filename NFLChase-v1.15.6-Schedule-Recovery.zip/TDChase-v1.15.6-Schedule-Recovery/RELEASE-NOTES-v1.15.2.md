# v1.15.2 — Scripts runtime stability
- On-demand per-game data/simulation; no background full-slate scripts.
- Virtualized full report sections and scorer rows for low-churn fling scrolling.
- Cooperative cancellation for CPU-bound Monte Carlo work.
- User-copyable, locally stored last uncaught-exception report in More.
- No automatic telemetry; requires new APK to confirm device-level stability.
