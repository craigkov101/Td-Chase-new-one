# TD Chase v1.13.0 — Visual Foundation

Build from v1.12.0 Reliable Data + Player Signals. **This is a source-code release; Android APK compilation and installation require GitHub Actions.**

## Actual Android UI changes

- One shared dark-navy design palette with ice-blue actions, mint rising-role signals, amber documented goal-line evidence, purple defender-absence opportunity, coral status warnings, and neutral gray insufficient-data states.
- Reusable, clickable `ChasePlayerCard`, semantic `ChaseSignalChip`, and animated-compatible Material 3 `ChaseOpportunityMeter` display opportunity scores as **indices, never touchdown probabilities**.
- The Picks page now combines verified candidates across loaded games, ranks them by opportunity score, offers ALL/RB/WR/TE/QB filters, and opens a player insight bottom sheet.
- Player detail sheet includes optional ESPN athlete headshot with team-initials fallback, workload bars showing actual recent per-game targets/carries (not invented game-by-game chart points), rank context, explanatory evidence, and a link to the full matchup.
- Team-colored game cards display recognized game state and optional ESPN-supplied stadium/weather; they **do not invent missing records or weather**.
- Simulation summaries display a shared logo-based score preview with the game trial count and an explicit disclaimer that the estimate is uncalibrated.
- Data Connections diagnostic, disk-backed feed cache, current-week scoring, and background simulation remain from 1.12.0.
- Unused demo Composables with fixed Oct 15/18 game dates and stale static model predictions have been removed from `MainActivity`.

## Limits

- Android Compose compilation and on-device rendering **not verified locally** (Android SDK/Gradle unavailable in preparation environment). GitHub workflow runs Android unit tests and `assembleDebug` before uploading an APK.
- No licensed route-level WR/CB charting or novel external dataset added. Historical route charting still requires authorized CSV import.
- Player images load opportunistically from official ESPN CDN using IDs observed in ESPN roster JSON; if unavailable the app shows initials.
- Recent targets/carries are averages, not complete per-game time-series. No fictitious sparklines or TD probabilities are rendered.
- Unit tests cover visual badges, sample/risk priority, player-position filtering, optional ESPN roster IDs, existing feed/cache behavior; full integration gated by GitHub Actions.

## Manual GitHub build

1. Upload `NFLChase-v1.13.0-Visual-Foundation.zip` at repository root (do **not** extract before uploading).
2. In your GitHub repository, replace the existing `.github/workflows/...yml` workflow file with the provided `build-nfl-chase-v1.13.0.yml` text. Keep the actual GitHub workflow path you are already using.
3. Commit the changes, open Actions → your TD Chase workflow → Run workflow.
4. If unit tests and Gradle succeed, download the `TD-Chase-v1.13.0` artifact ZIP and install its `TD-Chase-v1.13.0.apk` on Android.
5. If a step fails, inspect the **first** Kotlin `e: file://` message or Gradle exception before retrying. Do not change the build just because the optional ESPN live-probe fails.
