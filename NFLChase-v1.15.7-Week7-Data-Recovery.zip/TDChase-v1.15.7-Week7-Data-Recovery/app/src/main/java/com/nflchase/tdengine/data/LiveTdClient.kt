package com.nflchase.tdengine.data

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.DayOfWeek
import java.time.temporal.TemporalAdjusters
import java.time.format.DateTimeFormatter

data class LiveTdEvent(val id:String,val game:String,val team:String,val text:String,val quarter:Int,val clock:String)
data class LivePlayerStatus(val name:String,val status:String,val detail:String,val gameId:String)
data class LiveScheduleGame(
 val id:String, val matchup:String, val kickoff:String, val state:String,
 // Optional ESPN venue/weather metadata; never infer stadium conditions.
 val venue:String = "", val weather:String = ""
)
data class LiveTdSnapshot(
    val events:List<LiveTdEvent>,
    val liveGames:Int,
    val updatedAt:String,
    val unavailablePlayers:Set<String> = emptySet(),
    val playerStatuses:List<LivePlayerStatus> = emptyList(),
    val rosterPlayersByTeam:Map<String,Set<String>> = emptyMap(),
    val error:String?=null,
    val schedule:List<LiveScheduleGame> = emptyList()
)

// NFL 2026 Week 6 fixture backup. This is a dated schedule snapshot, not live data.
// It keeps navigation available when the ESPN scoreboard is empty or unreachable.
private fun weekSixBackup():List<LiveScheduleGame> = listOf(
 LiveScheduleGame("week6-sea-den","SEA @ DEN","2026-10-16T00:15:00Z","SCHEDULED"),
 LiveScheduleGame("week6-hou-jax","HOU @ JAX","2026-10-18T13:30:00Z","SCHEDULED"),
 LiveScheduleGame("week6-chi-atl","CHI @ ATL","2026-10-18T17:00:00Z","SCHEDULED"),
 LiveScheduleGame("week6-bal-cle","BAL @ CLE","2026-10-18T17:00:00Z","SCHEDULED"),
 LiveScheduleGame("week6-ten-ind","TEN @ IND","2026-10-18T17:00:00Z","SCHEDULED"),
 LiveScheduleGame("week6-nyj-ne","NYJ @ NE","2026-10-18T17:00:00Z","SCHEDULED"),
 LiveScheduleGame("week6-no-nyg","NO @ NYG","2026-10-18T17:00:00Z","SCHEDULED"),
 LiveScheduleGame("week6-car-phi","CAR @ PHI","2026-10-18T17:00:00Z","SCHEDULED"),
 LiveScheduleGame("week6-pit-tb","PIT @ TB","2026-10-18T17:00:00Z","SCHEDULED"),
 LiveScheduleGame("week6-ari-lar","ARI @ LAR","2026-10-18T20:05:00Z","SCHEDULED"),
 LiveScheduleGame("week6-lac-kc","LAC @ KC","2026-10-18T20:25:00Z","SCHEDULED"),
 LiveScheduleGame("week6-buf-lv","BUF @ LV","2026-10-18T20:25:00Z","SCHEDULED"),
 LiveScheduleGame("week6-dal-gb","DAL @ GB","2026-10-19T00:20:00Z","SCHEDULED"),
 // NFL Week 6 official fixture: Monday October 19, 8:15 PM Eastern.
 LiveScheduleGame("week6-was-sf","WAS @ SF","2026-10-20T00:15:00Z","SCHEDULED")
)


// Official NFL 2026 Week 7 fixtures (Oct 22-26), verified against NFL.com.
// Offline schedule is not a live status feed, injury report or game box score.
// STATUS_UNVERIFIED remains visible briefly after kickoff until live status is recovered.
private fun weekSevenBackup():List<LiveScheduleGame> = listOf(
 LiveScheduleGame("week7-ne-chi","NE @ CHI","2026-10-23T00:15:00Z","STATUS_UNVERIFIED"),
 LiveScheduleGame("week7-pit-no","PIT @ NO","2026-10-25T13:30:00Z","STATUS_UNVERIFIED"), // Paris
 LiveScheduleGame("week7-sf-atl","SF @ ATL","2026-10-25T17:00:00Z","STATUS_UNVERIFIED"),
 LiveScheduleGame("week7-cin-bal","CIN @ BAL","2026-10-25T17:00:00Z","STATUS_UNVERIFIED"),
 LiveScheduleGame("week7-tb-car","TB @ CAR","2026-10-25T17:00:00Z","STATUS_UNVERIFIED"),
 LiveScheduleGame("week7-nyg-hou","NYG @ HOU","2026-10-25T17:00:00Z","STATUS_UNVERIFIED"),
 LiveScheduleGame("week7-ind-min","IND @ MIN","2026-10-25T17:00:00Z","STATUS_UNVERIFIED"),
 LiveScheduleGame("week7-mia-nyj","MIA @ NYJ","2026-10-25T17:00:00Z","STATUS_UNVERIFIED"),
 LiveScheduleGame("week7-cle-ten","CLE @ TEN","2026-10-25T17:00:00Z","STATUS_UNVERIFIED"),
 LiveScheduleGame("week7-den-ari","DEN @ ARI","2026-10-25T20:05:00Z","STATUS_UNVERIFIED"),
 LiveScheduleGame("week7-gb-det","GB @ DET","2026-10-25T20:25:00Z","STATUS_UNVERIFIED"),
 LiveScheduleGame("week7-lar-lv","LAR @ LV","2026-10-25T20:25:00Z","STATUS_UNVERIFIED"),
 LiveScheduleGame("week7-kc-sea","KC @ SEA","2026-10-26T00:20:00Z","STATUS_UNVERIFIED"),
 LiveScheduleGame("week7-dal-phi","DAL @ PHI","2026-10-27T00:15:00Z","STATUS_UNVERIFIED")
)

internal object VerifiedFixtures {
 fun forWeek(thursday:LocalDate):List<LiveScheduleGame> = when(thursday) {
  LocalDate.of(2026,10,15) -> weekSixBackup()
  LocalDate.of(2026,10,22) -> weekSevenBackup()
  else -> emptyList()
 }
 /** A team schedule can supply the true ESPN game ID for fallback matchups.
  * Check the next upcoming fixture first, avoiding 32 simultaneous lookups when
  * we already have the NFL's published week schedule. */
 fun priorityTeams(fixtures:List<LiveScheduleGame>, now:Instant):List<String> =
  fixtures.asSequence().filter { runCatching { Instant.parse(it.kickoff) }.getOrNull()?.isAfter(now.minusSeconds(4*3600)) == true }
   .sortedBy { it.kickoff }.firstOrNull()?.matchup?.split(" @ ")?.takeIf { it.size==2 }.orEmpty()
}

class LiveTdClient(
 private val fetchText:(String)->String = ::espnText,
 private val fetchCurrent:(String)->String = fetchText
) {
 private fun get(u:String):String = fetchText(u)
 private fun norm(s:String)=s.lowercase(Locale.US).replace(Regex("[^a-z0-9 ]"),"").replace(Regex("\\s+")," ").trim()
 private fun unavailable(s:String):Boolean {
  val x=s.trim().lowercase(Locale.US)
  return EspnRosterParser.unavailable(x) || Regex("\\bruled out\\b|\\bwill not return\\b|\\bdoubtful to return\\b").containsMatchIn(x)
 }
 private fun collectInjuries(summary:JSONObject,eventId:String,out:MutableList<LivePlayerStatus>){
  fun add(o:JSONObject){
   val athlete=o.optJSONObject("athlete")
   val name=athlete?.optString("displayName")?.takeIf{it.isNotBlank()}
       ?:o.optString("displayName").takeIf{it.isNotBlank()}
       ?:o.optString("name").takeIf{it.isNotBlank()}
   val status=EspnInjuryParser.statusLabel(o).ifBlank { o.optString("description","").take(90) }
   if(name!=null && status.isNotBlank()) out+=LivePlayerStatus(name,status,status,eventId)
  }
  val injuries=summary.optJSONArray("injuries")
  if(injuries!=null) for(i in 0 until injuries.length()){
   val team=injuries.optJSONObject(i)?:continue
   val arr=team.optJSONArray("injuries") ?: team.optJSONArray("items")
   if(arr!=null) for(j in 0 until arr.length()) arr.optJSONObject(j)?.let{add(it)}
  }
  val direct=summary.optJSONObject("injuries")
  if(direct!=null){val arr=direct.optJSONArray("items");if(arr!=null)for(i in 0 until arr.length())arr.optJSONObject(i)?.let{add(it)}}
 }
 private fun loadRoster(team:String):Pair<Set<String>,List<LivePlayerStatus>> {
  val names=mutableSetOf<String>(); val statuses=mutableListOf<LivePlayerStatus>()
  return try{
   val j=JSONObject(get("https://site.api.espn.com/apis/site/v2/sports/football/nfl/teams/${teamSlug(team)}/roster"))
   val groups=j.optJSONArray("athletes")
   if(groups!=null) for(i in 0 until groups.length()){
    val group=groups.optJSONObject(i)?:continue
    val items=group.optJSONArray("items")?:continue
    for(k in 0 until items.length()){
     val a=items.optJSONObject(k)?:continue
     val name=a.optString("displayName",a.optString("fullName",a.optString("name","")))
     if(name.isBlank()) continue
     names+=norm(name)
     // The ESPN field can be an object: only extract its readable value.
     val status=EspnRosterParser.statusText(a)
     if(status.isNotBlank()) statuses+=LivePlayerStatus(name,status,"Roster status: $status","roster-$team")
    }
   }
   names to statuses
  }catch(_:Throwable){emptySet<String>() to emptyList()}
 }
 /** Secondary ESPN route: individual team schedules, independent of scoreboard query shape.
  * Only games with a parseable kickoff inside the selected NFL week are accepted.
  * Queries are parallel and bounded to avoid blocking the loading spinner indefinitely.
  * Team schedules are ESPN data, not a second independent injury or live-status provider.
  */
 internal fun teamScheduleRecovery(weekDates:List<LocalDate>, season:Int, prioritized:List<String> = emptyList()):List<JSONObject> {
  val teams=listOf("ARI","ATL","BAL","BUF","CAR","CHI","CIN","CLE","DAL","DEN","DET","GB",
   "HOU","IND","JAX","KC","LV","LAC","LAR","MIA","MIN","NE","NO","NYG","NYJ",
   "PHI","PIT","SF","SEA","TB","TEN","WAS")
  val allowed=weekDates.toSet()
  val eastern=ZoneId.of("America/New_York")
  val pool=Executors.newFixedThreadPool(8)
  try {
   val selected=if(prioritized.isEmpty()) teams else prioritized.distinct().filter { it in teams }
   val tasks=selected.map { code -> Callable {
    runCatching {
     val url="https://site.api.espn.com/apis/site/v2/sports/football/nfl/teams/${teamSlug(code)}/schedule?season=$season&seasontype=2"
     val arr=JSONObject(get(url)).optJSONArray("events") ?: JSONArray()
     (0 until arr.length()).mapNotNull { i ->
      val event=arr.optJSONObject(i) ?: return@mapNotNull null
      val day=runCatching { Instant.parse(event.optString("date")).atZone(eastern).toLocalDate() }.getOrNull()
      if(day in allowed && event.optString("id").isNotBlank()) event else null
     }
    }.getOrDefault(emptyList<JSONObject>())
   } }
   return pool.invokeAll(tasks,18L,TimeUnit.SECONDS).flatMap { task ->
    if(task.isCancelled) emptyList() else runCatching {task.get()}.getOrDefault(emptyList())
   }.distinctBy { it.optString("id") }
  } finally { pool.shutdownNow() }
 }
 fun loadToday(now:Instant=Instant.now()):LiveTdSnapshot {
  val eastern=ZoneId.of("America/New_York")
  val weekStart=ScheduleWindow.start(now)
  val weekDates=ScheduleWindow.days(now)
  val dateKeys=weekDates.map { it.format(DateTimeFormatter.BASIC_ISO_DATE) }
  val eventsById=linkedMapOf<String,JSONObject>()
  val problems=mutableListOf<String>()
  fun merge(url:String){
   try {
    val json=JSONObject(get(url))
    val arr=json.optJSONArray("events") ?: error("Schedule response omitted events")
    for(i in 0 until arr.length()){
     val event=arr.optJSONObject(i) ?: continue
     val id=event.optString("id")
     val eventDay=runCatching { Instant.parse(event.optString("date")).atZone(eastern).toLocalDate() }.getOrNull()
     if(id.isNotBlank() && eventDay in weekDates) eventsById[id]=event
    }
   } catch(e:Exception){problems+=e.message?.take(90) ?: "ESPN request failed"}
  }
  // ESPN's scoreboard rejects certain date ranges with HTTP 400. Use season/week
  // and individual days instead of relying on a single range expression.
  val season=nflSeasonFor(now)
  val backup=VerifiedFixtures.forWeek(weekStart)
  val nflWeek=run {
   // The published 2026 NFL season opened Thursday, September 10; derive a
   // prospective week number from the selected Thursday, clamped to 1..18.
   // A wrong week never manufactures games: event dates must still match.
   val seasonStart=if(season==2026) LocalDate.of(2026,9,10) else
    LocalDate.of(season,9,1).with(TemporalAdjusters.nextOrSame(DayOfWeek.THURSDAY))
   (java.time.temporal.ChronoUnit.WEEKS.between(seasonStart,weekStart)+1).toInt().coerceIn(1,18)
  }
  merge("https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard?dates=$season&seasontype=2&week=$nflWeek&limit=100")
  if(eventsById.size < 8) {
   // Include Monday (index 4); a Sunday-only recovery silently loses MNF.
   dateKeys.forEach { day ->
    merge("https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard?dates=$day&limit=100")
   }
  }
  if(eventsById.isEmpty()) merge("https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard?limit=100")
  var recoveredFromTeams=false
  val hasUnfinishedWeekGame=eventsById.values.any { event ->
   val kickoff=runCatching { Instant.parse(event.optString("date")) }.getOrNull()
   val state=event.optJSONObject("status")?.optJSONObject("type")?.optString("name", "") ?: ""
   (kickoff != null && kickoff.isAfter(now)) || state.contains("IN_PROGRESS",true)
  }
  if(!hasUnfinishedWeekGame) {
   val recovered=teamScheduleRecovery(weekDates,season,VerifiedFixtures.priorityTeams(backup,now))
   recovered.forEach { event -> eventsById[event.optString("id")]=event }
   recoveredFromTeams=recovered.isNotEmpty()
  }
  if(eventsById.isEmpty()) return LiveTdSnapshot(
   emptyList(),0,SimpleDateFormat("h:mm:ss a",Locale.US).format(Date()),
   error=if(backup.isEmpty()) "Live schedule unavailable. Retry when connected; no current backup exists."
    else "Verified Week ${nflWeek} fixture schedule only. Live status unavailable; player projections require separately verified roster and box-score feeds.",
   schedule=backup
  )
  val tdOut=mutableListOf<LiveTdEvent>()
  val statuses=mutableListOf<LivePlayerStatus>()
  val activeTeams=mutableSetOf<String>()
  var liveCount=0
  val schedule=mutableListOf<LiveScheduleGame>()
  for(event in eventsById.values){
   val eventId=event.optString("id")
   val matchup=event.optString("shortName", event.optString("name", ""))
   val kickoff=event.optString("date", "")
   if(eventId.isBlank() || matchup.isBlank() || kickoff.isBlank())continue
   val competitions=event.optJSONArray("competitions")
   val comp=competitions?.optJSONObject(0)
   val gameState=comp?.optJSONObject("status")?.optJSONObject("type")?.optString("name", "")
    ?.takeIf{it.isNotBlank()} ?: event.optJSONObject("status")?.optJSONObject("type")?.optString("name", "") ?: "UNKNOWN"
   val venue = comp?.optJSONObject("venue")?.optString("fullName", "")?.trim().orEmpty().take(65)
   val weather = (comp?.optJSONObject("weather")?.optString("displayValue", "")
    ?.takeIf { it.isNotBlank() } ?: event.optJSONObject("weather")?.optString("displayValue", "")).orEmpty().trim().take(70)
   schedule+=LiveScheduleGame(eventId,matchup,kickoff,gameState,venue,weather)
   val isLive=gameState.contains("IN_PROGRESS",true) || gameState.contains("IN PROGRESS",true)
   if(isLive){
    liveCount++
    val opponents=comp?.optJSONArray("competitors")
    if(opponents!=null)for(i in 0 until opponents.length()){
     opponents.optJSONObject(i)?.optJSONObject("team")?.optString("abbreviation", "")?.takeIf{it.isNotBlank()}?.let(activeTeams::add)
    }
   }
   val completed=gameState.contains("FINAL",true) || gameState.contains("POST",true)
   if(!isLive && !completed)continue
   val startTime=runCatching{Instant.parse(kickoff)}.getOrNull() ?: continue
   if(startTime.isBefore(now.minusSeconds(40*3600)))continue
   try {
    val summaryUrl="https://site.api.espn.com/apis/site/v2/sports/football/nfl/summary?event=$eventId"
    val summary=JSONObject(if(isLive)fetchCurrent(summaryUrl) else get(summaryUrl))
    collectInjuries(summary,eventId,statuses)
    // Never recursively turn arbitrary JSON status/type objects into player strings.
    val plays=summary.optJSONArray("scoringPlays")
    if(plays!=null)for(j in 0 until plays.length()){
     val play=plays.optJSONObject(j) ?: continue
     val text=play.optString("text", "")
     val kind=play.optJSONObject("type")?.optString("text", "") ?: ""
     val scoring=play.optJSONObject("scoringType")?.optString("name", "") ?: ""
     if(EspnScoringParser.touchdownType("$kind $scoring",text)=="ignore")continue
     tdOut+=LiveTdEvent(play.optString("id", "$eventId-$j"),matchup,
      play.optJSONObject("team")?.optString("abbreviation", "") ?: "",
      text,play.optJSONObject("period")?.optInt("number",0) ?: 0,
      play.optJSONObject("clock")?.optString("displayValue", "") ?: "")
    }
   }catch(e:Exception){problems+="Game summary $eventId: ${e.message?.take(60)}"}
  }
  // Published fixture backup fills any missing future matchups after partial ESPN
  // responses, including Thursday, Sunday and Monday. Never duplicate live IDs.
  var usedDatedBackup=false
  if(backup.isNotEmpty()) {
   fun teams(g:LiveScheduleGame)=g.matchup.split(" @ "," at ",limit=2).map(::teamSlug)
   val known=schedule.map(::teams).toSet()
   backup.filter { game ->
    val kickoff=runCatching { Instant.parse(game.kickoff) }.getOrNull()
    kickoff!=null && kickoff.isAfter(now) && teams(game) !in known
   }.forEach { game -> schedule.add(game); usedDatedBackup=true }
  }
  val rosters=mutableMapOf<String,Set<String>>()
  for(team in activeTeams.take(2)){
   val (names,playerStatuses)=loadRoster(team)
   if(names.isNotEmpty())rosters[team]=names
   statuses+=playerStatuses
  }
  val notAvailable=statuses.filter{unavailable(it.status)}.map{norm(it.name)}.filter{it.isNotBlank()}.toSet()
  return LiveTdSnapshot(tdOut.distinctBy{it.id}.reversed(),liveCount,
   SimpleDateFormat("h:mm:ss a",Locale.US).format(Date()),notAvailable,
   statuses.distinctBy{norm(it.name)+it.status},rosters,
   error=if(usedDatedBackup) "Verified Week $nflWeek fixture backup used; live game status not confirmed. Player data depends on separate feeds."
    else if(recoveredFromTeams) "Team schedule recovery active; live scoring may be delayed."
    else if(problems.isNotEmpty()) "Some ESPN requests failed; showing recovered schedule data." else null,
   schedule=schedule.sortedBy{it.kickoff})
 }
}

/** NFL schedule selection computed at runtime, never fixed to one week. */
object ScheduleWindow {
 private val zone=ZoneId.of("America/New_York")
 fun start(instant:Instant):LocalDate {
  val current=instant.atZone(zone).toLocalDate()
  return if(current.dayOfWeek==DayOfWeek.TUESDAY || current.dayOfWeek==DayOfWeek.WEDNESDAY)
   current.with(TemporalAdjusters.next(DayOfWeek.THURSDAY))
  else current.with(TemporalAdjusters.previousOrSame(DayOfWeek.THURSDAY))
 }
 fun days(instant:Instant):List<LocalDate> = (0L..6L).map { start(instant).plusDays(it) }
}

private fun espnText(url:String):String {
 val conn=(URL(url).openConnection() as HttpURLConnection).apply {
  connectTimeout=5500;readTimeout=9000;requestMethod="GET"
  setRequestProperty("Accept","application/json")
  setRequestProperty("User-Agent","TDChase/1.15.7")
 }
 return try {
  if(conn.responseCode !in 200..299)error("ESPN HTTP ${conn.responseCode}")
  conn.inputStream.bufferedReader().use { it.readText() }
 } finally {conn.disconnect()}
}
