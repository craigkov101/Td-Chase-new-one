package com.nflchase.tdengine.data

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** Only scheduled/upcoming and currently in-progress games belong on the active board.
 * A cached SCHEDULED result from yesterday must never resurrect a completed matchup.
 */
object SlatePolicy {
    private val eastern = ZoneId.of("America/New_York")
    fun isActive(game: LiveScheduleGame, now: Instant): Boolean {
        val state = game.state.uppercase()
        if (listOf("FINAL", "POST", "COMPLETE", "CANCEL", "STATUS_END").any { state.contains(it) }) return false
        if (listOf("IN_PROGRESS", "IN PROGRESS", "HALFTIME", "STATUS_LIVE").any { state.contains(it) }) return true
        val kickoff = runCatching { Instant.parse(game.kickoff) }.getOrNull() ?: return false
        // A published fixture is not a live-status provider. Keep that fixture on
        // screen through the likely game window, but NEVER label it as confirmed LIVE.
        if (state == "STATUS_UNVERIFIED") {
            return !kickoff.isAfter(now.plusSeconds(7 * 24 * 3600)) && now.isBefore(kickoff.plusSeconds(4 * 3600))
        }
        // ESPN scheduled states from yesterday must not resurrect completed games.
        return !kickoff.isBefore(now)
    }
    fun upcoming(games: List<LiveScheduleGame>, now: Instant): List<LiveScheduleGame> =
        games.filter { isActive(it, now) }.distinctBy { it.id }.sortedBy { it.kickoff }
    fun gameDay(game: LiveScheduleGame): LocalDate? = runCatching {
        Instant.parse(game.kickoff).atZone(eastern).toLocalDate()
    }.getOrNull()
    fun preferredDay(games: List<LiveScheduleGame>): LocalDate? = games.mapNotNull(::gameDay).minOrNull()
}
