# TD Chase 1.15.7 — Week 7 schedule and data recovery

- Added NFL.com-verified Week 7 fixture slate, including Patriots at Bears Thursday Oct 22 2026 8:15 PM ET, followed by Sunday and Monday. All 14 fixtures have explicit UTC kickoff times.
- The backup is schedule-only; it never asserts a game is actually in progress, claims confirmed injuries, or supplies invented player statistics.
- During a temporary ESPN outage a fixture stays available until four hours after scheduled kickoff with a **STATUS UNVERIFIED** label.
- Recover true ESPN game IDs from priority teams (NE/CHI tonight), avoiding costly 32-team recovery fanout when a verified schedule exists.
- If ESPN supplies only some Week 7 games, merge the missing future NFL fixtures without duplicating games from the same matchup.
- Player usage, receiver target history, rosters and projections still require validated ESPN team, box-score and summary feeds. No data available -> do not fabricate stats.
- Preserves Android Back navigation, demand-driven Scripts, injury caveats and developer diagnostics.

Verification: source integrity, offline fixture tests and Kotlin compile checks in this environment. Full APK and live provider responses must be tested on device/GitHub Actions.
