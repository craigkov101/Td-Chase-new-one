package com.ckz.nflchase.data

import com.ckz.nflchase.model.NflScoringModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

class Repository(
    private val api: EspnApi,
    private val preferences: AppPreferences,
    private val model: NflScoringModel
) {
    suspend fun loadDashboard(): NflDashboard = withContext(Dispatchers.IO) {
        val games = api.fetchScoreboard(daysForward = 7)
        if (games.isEmpty()) return@withContext NflDashboard(dataNote = "No NFL games were returned for the next seven days.")

        val teams = games.flatMap { listOf(it.home.abbreviation, it.away.abbreviation) }.distinct()
        val (schedules, injuriesByTeam) = coroutineScope {
            val schedulesDeferred = async { fetchTeamMap(teams) { api.fetchTeamSchedule(it) } }
            val injuriesDeferred = async { fetchTeamMap(teams) { api.fetchInjuries(it) } }
            schedulesDeferred.await() to injuriesDeferred.await()
        }
        val forms = teams.associateWith { team -> model.teamForm(team, schedules[team].orEmpty()) }
        val injuries = injuriesByTeam.values.flatten().distinctBy { "${it.team}:${it.playerName}:${it.status}" }

        var weights = preferences.loadWeights()
        val scripts = games.associate { g ->
            g.id to model.projectGame(
                g,
                forms[g.home.abbreviation] ?: model.teamForm(g.home.abbreviation, emptyList()),
                forms[g.away.abbreviation] ?: model.teamForm(g.away.abbreviation, emptyList()),
                weights
            )
        }

        val now = System.currentTimeMillis()
        var gameHistory = preferences.loadPredictions().toMutableList()
        val gameHistoryById = gameHistory.associateBy { it.gameId }.toMutableMap()
        val allKnownGames = schedules.values.flatten().associateBy { it.id } + games.associateBy { it.id }
        games.filter { it.status == GameStatus.SCHEDULED }.forEach { g ->
            val script = scripts[g.id] ?: return@forEach
            if (gameHistoryById[g.id] == null) {
                val record = PredictionRecord(g.id, now, script.homeScore, script.awayScore)
                gameHistory += record
                gameHistoryById[g.id] = record
            }
        }
        gameHistory = gameHistory.map { record ->
            val finalGame = allKnownGames[record.gameId]
            if (!record.settled && finalGame?.status == GameStatus.FINAL && finalGame.home.score != null && finalGame.away.score != null) {
                record.copy(actualHome = finalGame.home.score, actualAway = finalGame.away.score, settled = true)
            } else record
        }.toMutableList()
        preferences.savePredictions(gameHistory)
        val settledGames = gameHistory.filter { it.settled }
        val learnedWeights = model.learn(weights, settledGames)
        if (learnedWeights != weights) {
            weights = learnedWeights
            preferences.saveWeights(weights)
        }

        val upcomingTeams = games.filter { it.status != GameStatus.FINAL }
            .flatMap { listOf(it.home.abbreviation, it.away.abbreviation) }
            .distinct()

        // Four games gives a better floor/ceiling and role-stability read without turning refresh into a full-season scrape.
        val teamRecentGameIds = upcomingTeams.associateWith { team ->
            schedules[team].orEmpty()
                .filter { it.status == GameStatus.FINAL }
                .sortedBy { it.kickoff }
                .takeLast(4)
                .map { it.id }
        }

        var propHistory = preferences.loadPropPredictions().toMutableList()
        val unsettledFinalIds = propHistory
            .filter { !it.settled && allKnownGames[it.gameId]?.status == GameStatus.FINAL }
            .map { it.gameId }
            .distinct()
        val recentIds = teamRecentGameIds.values.flatten().distinct()
        val summaryIds = (recentIds + unsettledFinalIds).distinct()
        val summaryStats = fetchGameStatsMap(summaryIds)

        propHistory = propHistory.map { record ->
            if (record.settled || allKnownGames[record.gameId]?.status != GameStatus.FINAL) return@map record
            val stat = summaryStats[record.gameId].orEmpty().firstOrNull { it.athleteId == record.athleteId }
            if (stat == null) record else record.copy(actual = model.actualValue(stat, record.propType), settled = true)
        }.toMutableList()
        preferences.savePropPredictions(propHistory)
        val marketLearning = model.marketLearning(propHistory)

        val defenseProfiles = upcomingTeams.associateWith { team ->
            model.buildDefenseProfile(team, teamRecentGameIds[team].orEmpty(), summaryStats)
        }

        val profilesByTeam = upcomingTeams.associateWith { team ->
            val stats = teamRecentGameIds[team].orEmpty().flatMap { gameId ->
                summaryStats[gameId].orEmpty().filter { it.team == team }
            }
            model.buildUsageProfiles(team, stats)
        }.toMutableMap()

        val missingProfileTeams = upcomingTeams.filter { profilesByTeam[it].isNullOrEmpty() }
        if (missingProfileTeams.isNotEmpty()) {
            val leaderFallbacks = fetchTeamMap(missingProfileTeams) { api.fetchTeamLeaders(it) }
            missingProfileTeams.forEach { team ->
                val fallback = model.profilesFromLeaders(team, leaderFallbacks[team].orEmpty(), forms[team]?.games ?: 1)
                if (fallback.isNotEmpty()) profilesByTeam[team] = fallback
            }
        }

        val targets = games.filter { it.status != GameStatus.FINAL }.flatMap { g ->
            val script = scripts[g.id] ?: return@flatMap emptyList()
            model.buildTargets(
                game = g,
                script = script,
                homeForm = forms[g.home.abbreviation] ?: model.teamForm(g.home.abbreviation, emptyList()),
                awayForm = forms[g.away.abbreviation] ?: model.teamForm(g.away.abbreviation, emptyList()),
                homeProfiles = profilesByTeam[g.home.abbreviation].orEmpty(),
                awayProfiles = profilesByTeam[g.away.abbreviation].orEmpty(),
                homeDefense = defenseProfiles[g.home.abbreviation],
                awayDefense = defenseProfiles[g.away.abbreviation],
                injuries = injuries.filter { it.team == g.home.abbreviation || it.team == g.away.abbreviation },
                marketLearning = marketLearning
            )
        }.sortedWith(compareByDescending<PropTarget> { it.chaseScore }.thenByDescending { it.confidence })

        val existingPropIds = propHistory.map { it.id }.toHashSet()
        targets.filter { it.chaseScore >= 68 && it.dataConfidence >= 52 }
            .groupBy { it.gameId }
            .values
            .flatMap { it.take(16) }
            .forEach { target ->
                if (target.id !in existingPropIds) {
                    propHistory += PropPredictionRecord(
                        id = target.id,
                        gameId = target.gameId,
                        athleteId = target.athleteId,
                        playerName = target.playerName,
                        propType = target.propType,
                        createdAtMillis = now,
                        projection = target.modelProjection,
                        threshold = target.attackOverAt,
                        chaseScore = target.chaseScore
                    )
                    existingPropIds += target.id
                }
            }
        preferences.savePropPredictions(propHistory)

        val finalMarketLearning = model.marketLearning(propHistory)
        val gameErrors = settledGames.mapNotNull { it.absoluteError }
        val settledProps = propHistory.filter { it.settled && it.actual != null }
        val learning = LearningSnapshot(
            settledPredictions = settledGames.size,
            meanAbsoluteTeamError = if (gameErrors.isEmpty()) 0.0 else gameErrors.average() / 2.0,
            settledProps = settledProps.size,
            propThresholdHitRate = if (settledProps.isEmpty()) 0.0 else settledProps.count { it.thresholdHit == true }.toDouble() / settledProps.size,
            lastUpdatedMillis = now,
            weights = weights,
            marketLearning = finalMarketLearning
        )

        val profileCount = profilesByTeam.values.sumOf { it.size }
        val defenseCount = defenseProfiles.values.count { it.games > 0 }
        val injuryTeamCount = injuriesByTeam.count { it.value.isNotEmpty() }
        val summaryCoverage = if (summaryIds.isEmpty()) 0.0 else summaryIds.count { summaryStats[it].orEmpty().isNotEmpty() }.toDouble() / summaryIds.size
        val teamCoverage = if (upcomingTeams.isEmpty()) 0.0 else upcomingTeams.count { profilesByTeam[it].orEmpty().isNotEmpty() }.toDouble() / upcomingTeams.size
        val dataHealthScore = (
            summaryCoverage * 38 +
                teamCoverage * 34 +
                (defenseCount.toDouble() / maxOf(1, upcomingTeams.size)) * 18 +
                (if (targets.isNotEmpty()) 10 else 0)
            ).roundToInt().coerceIn(0, 100)
        val dataHealth = DataHealth(
            score = dataHealthScore,
            label = when {
                dataHealthScore >= 88 -> "Excellent coverage"
                dataHealthScore >= 74 -> "Strong coverage"
                dataHealthScore >= 58 -> "Usable coverage"
                else -> "Partial coverage"
            },
            recentGameSummaries = summaryStats.count { it.value.isNotEmpty() },
            playerProfiles = profileCount,
            defensiveProfiles = defenseCount,
            injuryTeams = injuryTeamCount,
            notes = buildList {
                add("${(summaryCoverage * 100).roundToInt()}% of requested recent box scores parsed")
                add("${(teamCoverage * 100).roundToInt()}% of upcoming teams have player usage profiles")
                if (missingProfileTeams.isNotEmpty()) add("Leader fallback active for ${missingProfileTeams.size} team(s)")
                if (injuryTeamCount == 0) add("No injury feed entries were returned yet")
            }
        )

        NflDashboard(
            games = games,
            scripts = scripts,
            targets = targets,
            injuries = injuries,
            usageProfiles = profilesByTeam.values.flatten(),
            learning = learning,
            dataHealth = dataHealth,
            lastUpdatedMillis = now,
            dataNote = when {
                targets.isEmpty() -> "Game scripts loaded, but player usage data is still sparse. NFL Chase will not invent missing prop data."
                recentIds.isEmpty() -> "Rankings are using season-leader fallback data because recent box scores were unavailable."
                else -> "v0.4 Live Data: $profileCount player profiles use up to four recent box scores, position-specific defensive allowances, role stability, efficiency, game scripts, injuries and calibrated model history. Sportsbook lines are never fabricated."
            },
            modelVersion = "0.4.0"
        )
    }

    fun loadTrackedIds(): Set<String> = preferences.loadTrackedIds()
    fun saveTrackedIds(ids: Set<String>) = preferences.saveTrackedIds(ids)
    fun loadManualLines(): Map<String, Double> = preferences.loadManualLines()
    fun saveManualLines(lines: Map<String, Double>) = preferences.saveManualLines(lines)

    private suspend fun <T> fetchTeamMap(teams: List<String>, block: (String) -> List<T>): Map<String, List<T>> = coroutineScope {
        val semaphore = Semaphore(8)
        teams.map { team ->
            async(Dispatchers.IO) {
                val value = runCatching { semaphore.withPermit { block(team) } }.getOrDefault(emptyList())
                team to value
            }
        }.awaitAll().toMap()
    }

    private suspend fun fetchGameStatsMap(gameIds: List<String>): Map<String, List<PlayerGameStat>> = coroutineScope {
        val semaphore = Semaphore(7)
        gameIds.map { gameId ->
            async(Dispatchers.IO) {
                val value = runCatching { semaphore.withPermit { api.fetchGamePlayerStats(gameId) } }.getOrDefault(emptyList())
                gameId to value
            }
        }.awaitAll().toMap()
    }
}
