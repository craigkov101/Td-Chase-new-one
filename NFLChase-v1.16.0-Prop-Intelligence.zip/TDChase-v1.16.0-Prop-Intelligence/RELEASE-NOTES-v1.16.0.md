# TD Chase v1.16.0 — Prop Intelligence overhaul

Replaces the original Picks ranking screen with an evidence-based Player Prop Research lab inspired by the *concepts* in the four ULX screenshots (not a reproduction of their proprietary artwork or branding).

## What works
- Four families: passing, receiving, rushing, and touchdowns.
- Ten markets: passing yards / attempts / completions / passing TDs, receptions / receiving yards / longest reception, carries / rushing yards, and anytime touchdown.
- JSON-labeled ESPN passing C/ATT, completions, passing yards, passing touchdowns, receptions, and longest reception are decoded in addition to existing rushing / receiving columns.
- Every prop profile displays the latest five available real game-level observations (with source dates), recent volume, sample count, five research pillars, market-specific heuristic checklist, contextual team points information, and user-entered sportsbook line with historical over counts.
- Numeric estimates require >=3 actual stat observations and are explicitly **uncalibrated sample-weighted scenarios**. TD cards show historical hit counts only, not fabricated touchdown probabilities. The optional user line is compared to *past results*, not priced or declared a betting edge.
- Unavailable snap%, route participation, air yards, ADOT, defense-vs-position, pressure rates, blocking grades, complete target share, weather, pace and sportsbook odds are explicitly NOT SOURCED and never faked or used for quantitative adjustments.
- Existing authorized charting CSV import can add **historical** WR–CB coverage context, not assured future assignments.
- Keeps the previous v1.15.8 scoreboard/schedule recovery, simulated score, Scripts stability, QB resolver, crash diagnostics, and Android Back navigation.

## Limits before commercialization
ESPN endpoints currently provide public statistics but are not an assured commercial redistribution license or production SLA. Obtain a licensed commercial feed and permission before publishing a paid app. No gambling profits or model-calibration claims are made. Historical prop over-counts are not predictive probabilities. Thresholds taken from the screenshots are hypothesis-generation prompts; validate them out of sample before treating them as useful.

## Build and test
Upload `NFLChase-v1.16.0-Prop-Intelligence.zip` to the root of your GitHub repo and replace `.github/workflows/build-nfl-chase-v0.3.0.yml` with the included `build-nfl-chase-v1.16.0.yml`. Manually run the workflow. An Android SDK and Gradle are required for full APK testing; source-integrity checks do not substitute for compiling/running the app.
