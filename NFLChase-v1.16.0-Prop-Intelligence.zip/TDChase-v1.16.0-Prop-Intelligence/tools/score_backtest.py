#!/usr/bin/env python3
"""Score model QA: evaluate SAVED PREGAME projections against completed actuals.
CSV columns: date,away_team,home_team,away_pred,home_pred,away_actual,home_actual,
             away_win_prob,home_win_prob,tie_prob.
Predictions must be timestamped before kickoff; backtesting revised-on-final projections is invalid.
"""
import csv,sys
from pathlib import Path

def main(filename):
    with Path(filename).open(newline='') as f:
        rows=list(csv.DictReader(f))
    if not rows: raise SystemExit('No pregame predictions supplied')
    n=len(rows)
    abs_error=0.0; margin_error=0.0; wins=0; sq=0.0; predicted_ties=0; actual_ties=0
    for r in rows:
        pa,ph,aa,ah=[float(r[k]) for k in ('away_pred','home_pred','away_actual','home_actual')]
        ap,hp,tp=[float(r[k]) for k in ('away_win_prob','home_win_prob','tie_prob')]
        if min(ap,hp,tp)<0 or abs(ap+hp+tp-1)>0.02: raise ValueError(f'Invalid probability triplet: {r}')
        abs_error+=(abs(pa-aa)+abs(ph-ah))/2
        margin_error+=abs((pa-ph)-(aa-ah))
        actual=1 if aa>ah else (-1 if ah>aa else 0)
        predicted=1 if pa>ph else (-1 if ph>pa else 0)
        wins+=(predicted==actual)
        sq+=(ap-float(actual==1))**2+(hp-float(actual==-1))**2+(tp-float(actual==0))**2
        predicted_ties+=(predicted==0)
        actual_ties+=(actual==0)
    print(f'Count={n}; team score MAE={abs_error/n:.3f}; margin MAE={margin_error/n:.3f}; winner/tie hit rate={wins/n:.3%}; 3-way Brier={sq/n:.4f}; predicted ties={predicted_ties}; actual ties={actual_ties}')

if __name__=='__main__':
    if len(sys.argv)!=2: raise SystemExit('Usage: python tools/score_backtest.py saved_pregame_forecasts.csv')
    main(sys.argv[1])
