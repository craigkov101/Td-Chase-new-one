# TD Chase — Four-reference prop blueprint

The uploaded ULX pages provide **research heuristics** only, not player data, event odds, proven predictive coefficients, or licenses to replicate branded content. TD Chase uses original UI and clear evidence classifications.

| Reference focus | Factors discussed | v1.16 status |
| --- | --- | --- |
| NFL betting basics | moneyline, spread, total, parlay correlation, recent form, injuries, weather, game script and disciplined bankroll | Research-only framing; user-entered line; game scoring/script already in project; no odds, bankroll, bets or auto-parlays |
| QB passing | pass volume, opponent pass defense, game script, protection/pressure, pace/total, WR/TE availability | ESPN pass attempts/completions/yards/TDs and recent team points added; opponent pass DvP, pressure, OL, pace not sourced |
| WR/TE receiving | targets, route%, snap%, target share, ADOT, coverage, red-zone role, efficiency | ESPN targets/receptions/yards/longest and derived recent catch rate added; route/slot/air/red-zone inputs absent without licensed charting |
| RB rushing | carries, role, snaps/early-downs, OL/run defense, script | ESPN carries/yards, current injury context, game script; snaps/line grades unavailable |
| RB receiving | routes, targets, third down, trailing script, defense RB reception allowance | ESPN targets/receptions/yards for RB where reported; third-down routes and positional defense metrics unavailable |
| Anytime TD | short-yardage opportunities, red-zone targets, personnel, team implied points | existing 5-yard rushing TD finishes and TD history; no fake anytime TD probability; goal-line opportunities/market team total unavailable |
| Longest reception | air-yards, ADOT, explosive passes, coverage vs WR | ESPN labeled LG if present, plus historical receiving yards; air yards and true explosive allowance not sourced |
| QB rushing | designed rushes, scrambles, opponent pressure/man coverage, red-zone share | ESPN rushing attempts/yards; no designed-vs-scramble split or man coverage rates |
| Reception five pillars | target share, route participation, air yards, target quality, opportunity | labels and observed target/catch proxies, missing inputs explicitly classified |

## Markets now exposed
Passing yards, attempts, completions, passing TDs; receptions, receiving yards, longest reception; rushing attempts, rushing yards; anytime TD history. Users may enter a market line and see observed over counts, not price/expected value. Some line sources may not include longest catches, so that market correctly displays missing data.

## Confidence and source integrity
A box-score category is only counted when observed for that player; a missing receiving row does **not** count as 0 receptions. Numeric scenario estimates need at least three sourced games; goal-line TD occurrence is descriptive only. Imported coverage data remains historical and labeled user-supplied. Nothing is rated a betting 'value' play without calibrated probabilities and bookmaker odds.

## Future inputs and rights
Legitimately licensed third-party feeds would be needed for route/snap %, aDOT, air yards, complete target share, red-zone snaps/targets/carries, DvP, pressure rate, offensive-line grades, pace, weather and sportsbook prices. Before commercial release acquire appropriate rights and conduct historical out-of-sample evaluation.
