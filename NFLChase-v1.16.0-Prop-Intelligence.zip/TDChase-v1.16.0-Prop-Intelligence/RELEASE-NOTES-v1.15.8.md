# TD Chase v1.15.8 — Score Recalibration

## Root cause
Prior builds rounded independent away/home Monte Carlo means; those numbers could be equal even when simulated finals almost never tied. Prior runs did not simulate overtime. The displayed result was a rounded mean, not a representative NFL final.

## Fixes
* 5,000 seeded trials remain on-demand; output uses a **real observed simulated final** from the side winning the most trials. No artificial +1 or force-win applied to a trial.
* Regulation ties receive a simplified 2025+ overtime process, both teams get initial possession. Regular-season ties remain possible, postseason mode has no ties. The 10-minute clock itself is not play-by-play simulated; conditional unresolved-OT chance is a *heuristic prior*, not a fitted parameter.
* Win shares now sum with tie shares to 100%; user can see all three. Both mean final points and representative final are labeled separately.
* ESPN completed scoring form is chronological and capped to latest five played games.
* Kept injury/roster checks, Scripts performance, diagnostics, and Android hardware Back navigation.

## Limitations
**This is a model realism correction, not demonstrated improvement in forecasting skill.** It still uses public verified points scored/allowed and bounded turnover/injury priors, not historical play-by-play EPA or licensed pressure grades. Need rigorous out-of-sample backtests, comparing MAE, winner hit rate, Brier calibration and tie frequency before claiming improved accuracy. No guarantee of results or wagers.
