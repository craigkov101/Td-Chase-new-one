package com.nflchase.tdengine.data

import java.util.Random

/**
 * Distinguishes average POINTS from a displayable representative FINAL.
 * Overtime is a reproducible possession-level approximation, not a full clock
 * or play-by-play engine. Conditional tie persistence is a bounded heuristic;
 * prospective game-by-game accuracy must be measured in the model audit.
 */
internal object ScoreForecastPolicy {
    fun overtime(
        rng: Random, away: Int, home: Int,
        awayStrength: Double, homeStrength: Double,
        postseason: Boolean = false,
        possession: (points: Double, giveaways: Double?) -> Int
    ): Pair<Int,Int> {
        if (away != home) return away to home
        var a = away
        var h = home
        // Both teams get their initial opportunity even when the first scores
        // a TD (the 2025+ regular-season format). No claim of clock precision.
        val firstAway = rng.nextBoolean()
        val first = possession(if(firstAway)awayStrength else homeStrength,null)
        val second = possession(if(firstAway)homeStrength else awayStrength,null)
        if(firstAway){a += first.coerceAtLeast(0);h += second.coerceAtLeast(0)}
        else {h += first.coerceAtLeast(0);a += second.coerceAtLeast(0)}
        if (a != h) return a to h
        // Only a small fraction of level OTs are left unresolved when the
        // 10-minute clock expires. This is a prior, not a calibrated estimate.
        if(!postseason && rng.nextDouble() < 0.075) return a to h
        // Sudden death once both sides have had their first opportunity.
        // The limited drive model does not simulate the actual OT clock.
        val awayAdvantage = (awayStrength / (awayStrength + homeStrength).coerceAtLeast(1.0))
            .coerceIn(0.25,0.75)
        val awayScoresNext = rng.nextDouble() < awayAdvantage
        // No extra-point attempt after a sudden-death TD.
        val nextScore = if(rng.nextDouble() < 0.72) 3 else 6
        return if(awayScoresNext) a+nextScore to h else a to h+nextScore
    }

    /** Nearest observed final on the most frequent winning side, not a fabricated +1. */
    fun representativeFinal(
        away: IntArray,home:IntArray,awayWins:Int,homeWins:Int,
        awayMean:Double,homeMean:Double
    ): Pair<Int,Int> {
        require(away.size==home.size && away.isNotEmpty())
        // When neither side has a positive lead, preserve the genuine all-tie
        // distribution rather than inventing a win (e.g. a preseason contest).
        val preferredSign=when { awayWins>homeWins -> 1; homeWins>awayWins -> -1; else -> 0 }
        var selected=-1
        var smallest=Double.POSITIVE_INFINITY
        for(i in away.indices){
            val diff=away[i]-home[i]
            if(diff==0 && awayWins+homeWins>0) continue
            if(preferredSign>0 && diff<=0) continue
            if(preferredSign<0 && diff>=0) continue
            val distance=(away[i]-awayMean)*(away[i]-awayMean) +
                (home[i]-homeMean)*(home[i]-homeMean)
            if(distance<smallest){smallest=distance;selected=i}
        }
        if(selected<0) {
            // Exact 50/50 splits: select closest non-tied observed final.
            for(i in away.indices){
                if(away[i]==home[i] && awayWins+homeWins>0) continue
                val distance=(away[i]-awayMean)*(away[i]-awayMean)+
                    (home[i]-homeMean)*(home[i]-homeMean)
                if(distance<smallest){smallest=distance;selected=i}
            }
        }
        return if(selected>=0)away[selected] to home[selected] else away[0] to home[0]
    }
}
