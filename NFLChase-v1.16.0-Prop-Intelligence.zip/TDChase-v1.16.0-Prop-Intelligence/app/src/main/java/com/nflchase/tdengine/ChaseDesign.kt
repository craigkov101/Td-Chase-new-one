package com.nflchase.tdengine

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NorthEast
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.nflchase.tdengine.data.*
import java.util.Locale

/** Accessible, restrained palette for all new screens. No red/green alone communicates availability. */
internal object ChaseColors {
    val background = Color(0xFF090F1C)
    val panel = Color(0xFF121F31)
    val inset = Color(0xFF1B2B42)
    val border = Color(0xFF2A3B52)
    val ice = Color(0xFF75CAF5)
    val mint = Color(0xFF75D9B6)
    val amber = Color(0xFFF7BD6B)
    val purple = Color(0xFFBDABFF)
    val coral = Color(0xFFF68D98)
    val muted = Color(0xFFB2C2D5)
    val white = Color(0xFFF3F7FC)
}

internal fun toneColor(tone: EvidenceTone): Color = when (tone) {
    EvidenceTone.INFO -> ChaseColors.ice
    EvidenceTone.SUCCESS -> ChaseColors.mint
    EvidenceTone.OPPORTUNITY -> ChaseColors.amber
    EvidenceTone.MATCHUP -> ChaseColors.purple
    EvidenceTone.WARNING -> ChaseColors.coral
    EvidenceTone.NEUTRAL -> ChaseColors.muted
}

@Composable internal fun ChaseSignalChip(badge: DisplayBadge) {
    val tint = toneColor(badge.tone)
    Surface(
        color = tint.copy(alpha = 0.11f),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, tint.copy(alpha = 0.35f))
    ) {
        Text(badge.label, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold,
            color = tint, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp))
    }
}

@Composable internal fun ChasePlayerPortrait(player: WeekCandidate, size: Int = 51) {
    val avatar = player.athleteId.takeIf { it.matches(Regex("[0-9]{1,12}")) }
    Box(modifier = Modifier.size(size.dp).clip(RoundedCornerShape(13.dp))
        .background(Brush.linearGradient(listOf(teamAccent(player.team).copy(alpha = 0.72f), ChaseColors.inset))),
        contentAlignment = Alignment.Center) {
        Text(player.name.split(' ').filter { it.isNotBlank() }.take(2).joinToString("") { it.take(1) }.uppercase(Locale.US),
            color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp)
        // Missing licensed imagery or network access falls back to initials.
        if (avatar != null) AsyncImage(
            model = "https://a.espncdn.com/i/headshots/nfl/players/full/$avatar.png",
            contentDescription = "Portrait of ${player.name}",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable internal fun ChaseOpportunityMeter(value: Int, modifier: Modifier = Modifier) {
    val bounded = value.coerceIn(0, 100)
    val tint = when {
        bounded >= 75 -> ChaseColors.amber
        bounded >= 55 -> ChaseColors.ice
        else -> ChaseColors.muted
    }
    Column(modifier, verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("OPPORTUNITY INDEX", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = ChaseColors.muted,
                modifier = Modifier.weight(1f))
            Text("$bounded / 100", color = tint, fontSize = 12.sp, fontWeight = FontWeight.Black)
        }
        LinearProgressIndicator(progress = { bounded / 100f },
            color = tint, trackColor = ChaseColors.border,
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape))
    }
}

@Composable internal fun ChasePlayerCard(
    player: WeekCandidate, rank: Int, partial: Boolean, onOpen: () -> Unit,
    modifier: Modifier = Modifier
) {
    val badge = VisualRules.badge(player, partial)
    val tint = toneColor(badge.tone)
    Surface(onClick = onOpen, modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp), color = ChaseColors.panel,
        border = BorderStroke(1.dp, tint.copy(alpha = 0.28f))) {
        Row {
            Box(Modifier.width(4.dp).height(124.dp).background(tint))
            Column(Modifier.weight(1f).padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ChasePlayerPortrait(player)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("#$rank · ${player.position} / ${player.team}", color = teamAccent(player.team), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(player.name, color = ChaseColors.white, fontSize = 16.sp,
                            fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        ChaseSignalChip(badge)
                    }
                    Icon(Icons.Default.NorthEast, contentDescription = "Open ${player.name} profile", tint = ChaseColors.ice, modifier = Modifier.size(20.dp))
                }
                ChaseOpportunityMeter(player.score)
                Text(VisualRules.sampleCaption(player, partial), color = ChaseColors.muted, fontSize = 10.sp)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable internal fun ChaseInsightSheet(player: WeekCandidate, partial: Boolean, onDismiss: () -> Unit, onMatchup: () -> Unit) {
    val badge = VisualRules.badge(player, partial)
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = ChaseColors.panel, dragHandle = {
        Box(Modifier.padding(top = 12.dp, bottom = 12.dp).width(36.dp).height(4.dp).clip(CircleShape).background(ChaseColors.border))
    }) {
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp).padding(bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(15.dp)) {
                ChasePlayerPortrait(player, 72)
                Column(Modifier.weight(1f)) {
                    Text(player.name, fontSize = 24.sp, color = ChaseColors.white, fontWeight = FontWeight.Black)
                    Text("${player.team} · ${player.position} · ${player.games} verified games", color = ChaseColors.muted, fontSize = 12.sp)
                    Spacer(Modifier.height(6.dp)); ChaseSignalChip(badge)
                }
            }
            Surface(color = ChaseColors.inset, shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ChaseOpportunityMeter(player.score)
                    Text(VisualRules.OPPORTUNITY_CAPTION, color = ChaseColors.muted, fontSize = 10.sp)
                }
            }
            Text("RECENT WORKLOAD", color = ChaseColors.ice, fontSize = 12.sp, fontWeight = FontWeight.Black)
            ChaseWorkloadRow("Targets / game", player.recentTargets, ChaseColors.ice)
            ChaseWorkloadRow("Carries / game", player.recentCarries, ChaseColors.mint)
            Text("ACTUAL RECENT GAME LOG", color = ChaseColors.ice, fontSize = 12.sp, fontWeight = FontWeight.Black)
            if(player.recentGameLog.isEmpty()) Text("No verified game-level box scores available.",color=ChaseColors.muted,fontSize=11.sp)
            player.recentGameLog.forEach { game ->
                Surface(color=ChaseColors.inset,shape=RoundedCornerShape(11.dp)) {
                    Row(Modifier.fillMaxWidth().padding(9.dp),verticalAlignment=Alignment.CenterVertically){
                        Column(Modifier.weight(1f)) {
                            Text("${game.gameDate} · ${game.sourceTeam}",color=ChaseColors.white,fontSize=11.sp,fontWeight=FontWeight.Bold)
                            Text("${game.receivingYards} REC YDS · ${game.rushingYards} RUSH YDS · ${game.touchdowns} TD",color=ChaseColors.muted,fontSize=9.sp)
                        }
                        Text("${game.targets} TGT  /  ${game.carries} CAR",color=ChaseColors.ice,fontSize=12.sp,fontWeight=FontWeight.Bold)
                    }
                }
            }
            player.targetOutlook?.let { outlook ->
                Text("NEXT-GAME TARGET ESTIMATE",color=ChaseColors.amber,fontSize=12.sp,fontWeight=FontWeight.Black)
                Surface(color=ChaseColors.inset,shape=RoundedCornerShape(14.dp)) {
                    Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                        Text("${outlook.low}–${outlook.high} targets · ${outlook.receivingYardsLow}–${outlook.receivingYardsHigh} rec yds",fontSize=17.sp,fontWeight=FontWeight.Black,color=ChaseColors.amber)
                        Text("Projected scenario ranges; NOT observed or calibrated betting props",color=ChaseColors.muted,fontSize=10.sp)
                        Text("${outlook.quarterback?.let { "QB outlook: $it" } ?: "QB outlook: starter TBD"} · ${"%.1f".format(Locale.US,outlook.teamTargetsPerGame)} recorded team targets/game",fontSize=11.sp,color=ChaseColors.white)
                        if (outlook.quarterbackEvidence.isNotBlank()) Text(outlook.quarterbackEvidence,fontSize=10.sp,color=ChaseColors.muted)
                        Text(outlook.explanation,fontSize=11.sp,color=ChaseColors.muted)
                        if(outlook.targetCompetition.isNotEmpty()) {
                            Text("OTHER RECENT TARGET LEADERS",fontSize=10.sp,color=ChaseColors.ice,fontWeight=FontWeight.Bold)
                            outlook.targetCompetition.forEach { weapon -> Text(weapon,fontSize=11.sp,color=ChaseColors.white) }
                        }
                    }
                }
            }
            Text("WHY THEY STAND OUT", color = ChaseColors.amber, fontSize = 12.sp, fontWeight = FontWeight.Black)
            Text(badge.explanation, color = ChaseColors.white, fontSize = 12.sp, lineHeight = 18.sp)
            Text(player.reason, color = ChaseColors.muted, fontSize = 12.sp, lineHeight = 18.sp)
            if (partial) Text("Limited inputs · check final game-day availability", color = ChaseColors.muted, fontSize = 11.sp)
            Button(onClick = onMatchup, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = ChaseColors.ice, contentColor = ChaseColors.background)) {
                Text("OPEN FULL MATCHUP", fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable private fun ChaseWorkloadRow(title: String, average: Double, tint: Color) {
    val display = "%.1f".format(Locale.US, average.coerceAtLeast(0.0))
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = ChaseColors.muted, fontSize = 12.sp, modifier = Modifier.width(116.dp))
        LinearProgressIndicator(progress = { (average / 20.0).coerceIn(0.0, 1.0).toFloat() }, color = tint,
            trackColor = ChaseColors.border, modifier = Modifier.weight(1f).height(7.dp).clip(CircleShape))
        Text(display, color = ChaseColors.white, fontWeight = FontWeight.Bold,
            fontSize = 12.sp, modifier = Modifier.padding(start = 9.dp))
    }
}

@Composable internal fun ChaseHighlightsLegend() {
    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Text("PLAYER SIGNALS", fontWeight = FontWeight.Black, color = ChaseColors.white, fontSize = 12.sp)
        val entries = listOf(
            DisplayBadge("HIGH USAGE", EvidenceTone.INFO, "Strong verified workload"),
            DisplayBadge("RISING ROLE", EvidenceTone.SUCCESS, "Opportunity trending upward"),
            DisplayBadge("GOAL-LINE", EvidenceTone.OPPORTUNITY, "Recorded short rushing TD finishes"),
            DisplayBadge("INJURY EDGE", EvidenceTone.MATCHUP, "Reported defensive absence; matchup uncertain"),
            DisplayBadge("STATUS CHECK", EvidenceTone.WARNING, "Player availability needs verification"),
            DisplayBadge("LIMITED DATA", EvidenceTone.NEUTRAL, "Sample or feed completeness is limited")
        )
        entries.forEach { badge ->
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ChaseSignalChip(badge)
                Text(badge.explanation, color = ChaseColors.muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable internal fun ChaseProjectedScore(away: String, awayScore: Int, home: String, homeScore: Int, sims: Int) {
    Surface(color = ChaseColors.inset, shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, ChaseColors.ice.copy(alpha = 0.19f)), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("REPRESENTATIVE FINAL", color = ChaseColors.mint, fontSize = 10.sp,
                    fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                Text("${"%,d".format(Locale.US, sims)} TRIALS", color = ChaseColors.muted,
                    fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    TeamLogo(away)
                    Text(away, color = teamAccent(away), fontWeight = FontWeight.Black, fontSize = 13.sp)
                    Text("$awayScore", color = ChaseColors.white, fontSize = 28.sp, fontWeight = FontWeight.Black)
                }
                Text("—", color = ChaseColors.muted, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    TeamLogo(home)
                    Text(home, color = teamAccent(home), fontWeight = FontWeight.Black, fontSize = 13.sp)
                    Text("$homeScore", color = ChaseColors.white, fontSize = 28.sp, fontWeight = FontWeight.Black)
                }
            }
            Text("Most central simulated winning outcome · heuristic, not betting odds",
                color = ChaseColors.muted, fontSize = 10.sp)
        }
    }
}
