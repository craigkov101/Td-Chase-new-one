package com.nflchase.tdengine.data

import java.util.Locale
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.roundToInt

/** Only ESPN-observed box scores are used for numeric estimates. A historical hit rate is NOT a future win probability. */
enum class PropFamily(val display: String) { PASSING("Passing"), RECEIVING("Receiving"), RUSHING("Rushing"), TD("Touchdowns") }

enum class PropMarket(val title: String, val short: String, val unit: String, val family: PropFamily, val positions: Set<String>) {
    PASS_YARDS("Passing yards", "Pass yds", "yds", PropFamily.PASSING, setOf("QB")),
    PASS_ATTEMPTS("Pass attempts", "Pass att", "att", PropFamily.PASSING, setOf("QB")),
    COMPLETIONS("Completions", "Completions", "cmp", PropFamily.PASSING, setOf("QB")),
    PASS_TDS("Passing TDs", "Pass TD", "TD", PropFamily.PASSING, setOf("QB")),
    RECEPTIONS("Receptions", "Recs", "rec", PropFamily.RECEIVING, setOf("WR","TE","RB")),
    RECEIVING_YARDS("Receiving yards", "Rec yds", "yds", PropFamily.RECEIVING, setOf("WR","TE","RB")),
    LONGEST_RECEPTION("Longest reception", "Long rec", "yds", PropFamily.RECEIVING, setOf("WR","TE","RB")),
    RUSH_ATTEMPTS("Rush attempts", "Carries", "att", PropFamily.RUSHING, setOf("RB","QB","WR")),
    RUSH_YARDS("Rushing yards", "Rush yds", "yds", PropFamily.RUSHING, setOf("RB","QB","WR")),
    ANYTIME_TD("Anytime touchdown", "Anytime TD", "TD", PropFamily.TD, setOf("RB","QB","WR","TE"))
}

enum class EvidenceLevel { VERIFIED, CONTEXT, MISSING }
data class PropEvidence(val pillar: String, val level: EvidenceLevel, val detail: String)

data class PropResult(
    val market: PropMarket,
    val player: WeekCandidate,
    val observed: List<Int>,
    val sampleDates: List<String>,
    val representative: Double?,
    val lower: Int?, val upper: Int?,
    val evidence: List<PropEvidence>,
    val warnings: List<String>,
    val label: String
) {
    val games: Int get() = observed.size
    val recentAverage: Double? get() = observed.takeIf { it.isNotEmpty() }?.average()
    // This is a descriptive sample frequency. It makes no claim of prediction calibration.
    fun lineHistory(line: Double): Pair<Int,Int>? = if (!line.isFinite() || line < 0 || observed.isEmpty()) null
        else observed.count { it > line } to observed.size
    val dataQuality: String get() = when {
        games < 2 -> "INSUFFICIENT"
        warnings.isNotEmpty() || games < 4 -> "LIMITED"
        else -> "OBSERVED"
    }
}

/** User-supplied infographic thresholds are research prompts, not calibrated betting rules. */
enum class ChecklistStatus { MET, BELOW, NOT_MEASURED }
data class PropChecklistItem(val label:String,val criterion:String,val observed:String,val status:ChecklistStatus)

object PropGuidelines {
    private fun metric(label:String,criterion:String,number:Double?,threshold:Double,suffix:String=""):PropChecklistItem {
        val ok=number?.let{it>=threshold}
        return PropChecklistItem(label,criterion,if(number==null)"Not sourced" else
            String.format(Locale.US,"%.1f%s",number,suffix),
            when(ok){true->ChecklistStatus.MET;false->ChecklistStatus.BELOW;null->ChecklistStatus.NOT_MEASURED})
    }
    private fun unknown(label:String,criterion:String)=PropChecklistItem(label,criterion,"Needs a verified source",ChecklistStatus.NOT_MEASURED)
    fun forMarket(player:WeekCandidate,market:PropMarket,report:SimulationReport?=null):List<PropChecklistItem> {
        val recent=player.recentGameLog.sortedByDescending{it.gameDate}.take(3)
        val passes=recent.filter{it.hasPassingBoxscore}
        val targets=recent.filter{it.hasReceivingBoxscore}
        val rushes=recent.filter{it.hasRushingBoxscore}
        fun passAvg(value:(WeekGameUsage)->Int)=passes.takeIf{it.size>=2}?.map(value)?.average()
        fun recvAvg(value:(WeekGameUsage)->Int)=targets.takeIf{it.size>=2}?.map(value)?.average()
        fun rushAvg(value:(WeekGameUsage)->Int)=rushes.takeIf{it.size>=2}?.map(value)?.average()
        val recentCatchRate=targets.takeIf{it.size>=2 && it.sumOf {g->g.targets}>0}?.let{games->
            100.0*games.sumOf{it.receptions}/games.sumOf{it.targets}
        }
        val total=report?.let{it.awayExpected+it.homeExpected}
        val t=mutableListOf<PropChecklistItem>()
        when(market.family){
            PropFamily.PASSING -> {
                t+=metric("Volume","About 30+ pass attempts/game",passAvg{it.passAttempts},30.0)
                t+=metric("Game environment","Illustrative total 50+",total,50.0)
                t+=unknown("Defense","Opponent pass YPA, completions & pass TD allowed")
                t+=unknown("Pocket","Measured pressure %, sacks and pass-blocking grade")
                if(market==PropMarket.PASS_YARDS)t+=unknown("Air attack","Pass depth, air yards and high-value weapons")
            }
            PropFamily.RECEIVING -> {
                t+=metric("Targets","Recent 7+ targets/game",recvAvg{it.targets},7.0)
                t+=metric("Catch efficiency","Historical catch rate 65%+",recentCatchRate,65.0,"%")
                t+=unknown("Routes","Verified route participation 70%+")
                t+=unknown("Target share","Share of COMPLETE team targets 15%+")
                t+=unknown("Air yards","20+ air yards / verified aDOT")
                t+=unknown("Coverage","Defender matchup and position receptions allowed")
            }
            PropFamily.RUSHING -> {
                val cutoff=if(player.position=="QB")6.0 else 14.0
                t+=metric("Carries","Recent ${cutoff.toInt()}+ attempts/game",rushAvg{it.carries},cutoff)
                t+=unknown("Run share","Snap%, early-down and goal-line attempt share")
                t+=unknown("Blocking","Measured offensive line and run-defense matchup")
                t+=unknown("Game state","Measured pass/run rate when favored or trailing")
            }
            PropFamily.TD -> {
                t+=unknown("Scoring role","Verified red-zone targets / goal-line attempts and snap share")
                t+=unknown("Opponent","Defense TDs allowed by position and goal-to-go role")
                t+=unknown("Injury","Current verified game-day active status")
            }
        }
        return t
    }
}

object PropIntelligence {
    private fun applicable(market: PropMarket, player: WeekCandidate) = player.position in market.positions
    private fun observedValue(market: PropMarket, log: WeekGameUsage): Int? = when(market) {
        PropMarket.PASS_YARDS -> log.passingYards.takeIf { log.hasPassingBoxscore }
        PropMarket.PASS_ATTEMPTS -> log.passAttempts.takeIf { log.hasPassingBoxscore }
        PropMarket.COMPLETIONS -> log.passCompletions.takeIf { log.hasPassingBoxscore }
        PropMarket.PASS_TDS -> log.passingTouchdowns.takeIf { log.hasPassingBoxscore }
        PropMarket.RECEPTIONS -> log.receptions.takeIf { log.hasReceivingBoxscore }
        PropMarket.RECEIVING_YARDS -> log.receivingYards.takeIf { log.hasReceivingBoxscore }
        PropMarket.LONGEST_RECEPTION -> log.longestReception.takeIf { log.hasReceivingBoxscore }
        PropMarket.RUSH_ATTEMPTS -> log.carries.takeIf { log.hasRushingBoxscore }
        PropMarket.RUSH_YARDS -> log.rushingYards.takeIf { log.hasRushingBoxscore }
        PropMarket.ANYTIME_TD -> (if(log.touchdowns > 0) 1 else 0)
            .takeIf { log.hasReceivingBoxscore || log.hasRushingBoxscore }
    }
    private fun d(value:Double): String = String.format(Locale.US,"%.1f",value)
    private fun opponent(team: String,matchup:String):String? = matchup.split(" @ "," at ",limit=2)
        .firstOrNull { it.isNotBlank() }?.let { first ->
            val teams=matchup.split(" @ "," at ", limit=2)
            if(teams.size!=2) null else if(sameTeam(first,team)) teams[1] else if(sameTeam(teams[1],team))first else null
        }

    fun assess(player: WeekCandidate, market: PropMarket, projection: WeekProjection? = null,
               matchup: String = "", report: SimulationReport? = null,
               coverage: CoverageOverview? = null): PropResult {
        val history=if(applicable(market,player)) player.recentGameLog.sortedByDescending { it.gameDate }.take(5) else emptyList()
        val found=history.mapNotNull { game -> observedValue(market,game)?.let { game.gameDate to it } }
        val values=found.map{it.second}
        val lastThree=values.take(3)
        val avg=values.takeIf{it.size>=2}?.average()
        // Small-sample forecast: observed sample mean blended with recent mean; no betting-probability fitting.
        val estimate=if(market==PropMarket.ANYTIME_TD || values.size<3) null
            else ((lastThree.average()*.60)+(values.average()*.40)).coerceAtLeast(0.0)
        val sorted=values.sorted()
        val lo=if(estimate!=null) floor((sorted.first()*.8 + estimate*.2).coerceAtLeast(0.0)).toInt() else null
        val hi=if(estimate!=null) ceil(sorted.last()*.8+estimate*.2).toInt() else null
        val warnings=mutableListOf<String>()
        if(values.size < 3) warnings += "Less than 3 games have this verified stat; no numerical forecast"
        if(player.status.contains("questionable",true) || player.status.contains("doubtful",true) ||
            player.status.contains("stale",true) || player.status.contains("unverified",true))
            warnings += "Game-day availability requires confirmation"
        if(history.any { !sameTeam(it.sourceTeam,player.team) })
            warnings += "Some history is from a different team; new role may differ"
        if(projection?.error != null) warnings += "Some live or historical feeds are incomplete"
        val indicators=mutableListOf<PropEvidence>()
        if(avg!=null) indicators += PropEvidence("1 · Opportunity",EvidenceLevel.VERIFIED,
            "${values.size} recent verified game(s); ${d(avg)} ${market.unit}/game. Last 3: ${d(lastThree.average())}.")
        else indicators += PropEvidence("1 · Opportunity",EvidenceLevel.MISSING,
            "Not enough labeled ESPN box-score results for ${market.title.lowercase(Locale.US)}.")
        val recentTargets=player.recentTargets
        val recentCarries=player.recentCarries
        val roleNote=when(market.family){
            PropFamily.PASSING -> "Observed QB pass volume available for this market; planned dropbacks, pass protection and designed runs not charted."
            PropFamily.RECEIVING -> "${d(recentTargets)} recent targets/game; snap%, route participation, air yards, aDOT and red-zone target share need charted data."
            PropFamily.RUSHING -> "${d(recentCarries)} recent carries/game; snap%, early-down share, run blocking and goal-line attempt share need charted data."
            PropFamily.TD -> "${player.fiveGameTouchdowns} recorded rush/receiving TDs in the available player sample; goal-line touch share not charted."
        }
        indicators += PropEvidence("2 · Role", if(values.isNotEmpty())EvidenceLevel.CONTEXT else EvidenceLevel.MISSING,roleNote)
        val form=projection?.teamForms?.firstOrNull{sameTeam(it.team,player.team)}
        val opp=opponent(player.team,matchup)
        val def=projection?.teamForms?.firstOrNull{opp!=null && sameTeam(it.team,opp)}
        if(report!=null) {
            val teamProjected=if(sameTeam(report.away,player.team)) report.awayExpected else report.homeExpected
            indicators += PropEvidence("3 · Game script",EvidenceLevel.CONTEXT,
                "Possession-model team points ${d(teamProjected)}; game total ${d(report.awayExpected+report.homeExpected)}. No verified play pace or Vegas total.")
        } else if(form!=null && form.games>=2){
            indicators += PropEvidence("3 · Game script",EvidenceLevel.CONTEXT,
                "Team averaged ${d(form.averageScored)} points across ${form.games} recent games. Future pass/run split and Vegas total not verified.")
        } else indicators+=PropEvidence("3 · Game script",EvidenceLevel.MISSING,"Open a matchup for a game simulation; verified team recent scoring is unavailable.")
        if(def!=null && def.games>=2){
            indicators += PropEvidence("4 · Matchup",EvidenceLevel.CONTEXT,
                "${def.team} allowed ${d(def.averageAllowed)} points/game (${def.games} games). This is NOT position-specific yards, catch rate or pressure data.")
        } else indicators += PropEvidence("4 · Matchup",EvidenceLevel.MISSING,
            "No verified opponent defense split. Do not assume a weak positional matchup.")
        if(market.family==PropFamily.RECEIVING){
            val matched=coverage?.forReceiver(player.name).orEmpty()
            if(matched.isNotEmpty())indicators += PropEvidence("Coverage chart",EvidenceLevel.VERIFIED,
                "Imported history: ${matched.sumOf{it.routesObserved}} routes across ${matched.size} charted matchup(s); future assignments remain estimated.")
            else indicators += PropEvidence("Coverage chart",EvidenceLevel.MISSING,
                "Routes, shadow coverage, defender catch rate and receptions allowed require authorized charting.")
        }
        indicators += PropEvidence("5 · Prop line",EvidenceLevel.CONTEXT,
            "Enter a sportsbook line to compare over/under with VERIFIED recent results. The hit count is not a future probability or an edge without odds.")
        val label=when {
            values.isEmpty() -> "No verified samples"
            market==PropMarket.ANYTIME_TD -> "${values.count{it>0}} TD games / ${values.size} observed"
            estimate==null -> "${d(avg ?: 0.0)} historical average"
            else -> "${d(estimate)} estimated ${market.unit}"
        }
        return PropResult(market,player,values,found.map{it.first},estimate,lo,hi,indicators,warnings,label)
    }
    fun marketsFor(player:WeekCandidate):List<PropMarket> = PropMarket.entries.filter{it.positions.contains(player.position)}
}
