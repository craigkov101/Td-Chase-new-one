package com.nflchase.tdengine.data

import org.junit.Assert.*
import org.junit.Test
import java.util.Random

class ScoreForecastPolicyTest {
    @Test fun `mean tie displays observed non-tied score instead`() {
        val away=intArrayOf(24,24,24,21,21)
        val home=intArrayOf(21,21,21,26,26)
        // Both team means round to 23 even though none of the games tied.
        val outcome=ScoreForecastPolicy.representativeFinal(away,home,3,2,22.8,23.0)
        assertEquals(24 to 21,outcome)
        assertTrue((away.indices).any { away[it]==outcome.first && home[it]==outcome.second })
    }
    @Test fun `majority winner determines representative side`() {
        val away=intArrayOf(27,24,17,17)
        val home=intArrayOf(24,21,24,27)
        val outcome=ScoreForecastPolicy.representativeFinal(away,home,2,2,21.25,24.0)
        assertNotEquals(outcome.first,outcome.second)
        val homeFavored=ScoreForecastPolicy.representativeFinal(away,home,1,3,21.25,24.0)
        assertTrue(homeFavored.second>homeFavored.first)
    }
    @Test fun `actual all-tied sample is not secretly changed`() {
        assertEquals(20 to 20, ScoreForecastPolicy.representativeFinal(intArrayOf(20,20),intArrayOf(20,20),0,0,20.0,20.0))
    }
    @Test fun `regular season overtime resolves most ties but retains rare genuine ties`() {
        val random=Random(22L)
        var ties=0
        var wins=0
        repeat(10000) {
            val (a,h)=ScoreForecastPolicy.overtime(random,20,20,22.0,22.0,false){_,_->0}
            if(a==h)ties++ else wins++
        }
        assertTrue(ties in 500..1000)
        assertTrue(wins>9000)
    }
    @Test fun `postseason overtime cannot finish tied`() {
        val random=Random(99L)
        repeat(2000){
            val result=ScoreForecastPolicy.overtime(random,17,17,19.0,24.0,true){_,_->0}
            assertNotEquals(result.first,result.second)
        }
    }
    @Test fun `overtime respects scoring on the first two drives`() {
        val first=ScoreForecastPolicy.overtime(Random(12L),21,21,22.0,22.0,false){strength,_-> if(strength>0)7 else 0}
        // When both possessions score equally, any winner is from sudden death.
        assertTrue(first.first >= 28 && first.second >= 28)
    }
}
