package com.nflchase.tdengine.data

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class PropIntelligenceTest {
    private fun usage(date:String, targets:Int=8,recs:Int=6,recYds:Int=78,
                      carries:Int=0,rushYds:Int=0,passAtt:Int=0,comp:Int=0,passYds:Int=0,
                      passedTd:Int=0,receiving:Boolean=true,rushing:Boolean=false,passing:Boolean=false,
                      team:String="NE",tds:Int=0, long:Int?=24) =
        WeekGameUsage(date,team,targets,carries,recYds,rushYds,tds,recs,passAtt,comp,passYds,passedTd,long,
            receiving,rushing,passing)
    private fun player(position:String="WR",logs:List<WeekGameUsage>):WeekCandidate =
        WeekCandidate("Test Player","NE",position,"Active",73,"Verified",logs.size,8.0,15.0,
            0,0,0.0,"",logs)

    @Test fun `passing attempts completions and yards decoded from labeled ESPN C ATT`() {
        val json=JSONObject("""{"boxscore":{"players":[{"team":{"id":"17","abbreviation":"NE"},"statistics":[
          {"name":"passing","labels":["C/ATT","YDS","TD","INT"],"athletes":[
            {"athlete":{"displayName":"QB One"},"stats":["23/36","268","2","1"]}]},
          {"name":"receiving","labels":["REC","YDS","TD","LG","TGTS"],"athletes":[
            {"athlete":{"displayName":"WR One"},"stats":["6","77","1","31","8"]}]}
        ]}]}}""")
        val lines=EspnPlayerStatsParser.boxscore(json,"17","NE")
        val passer=lines[normalName("QB One")]!!
        assertEquals(23,passer.passCompletions)
        assertEquals(36,passer.passAttempts)
        assertEquals(268,passer.passingYards)
        assertEquals(2,passer.passingTouchdowns)
        assertEquals(0,passer.touchdowns) // QB passing TDs are not anytime TDs
        assertTrue(passer.passingObserved)
        assertFalse(passer.receivingObserved)
        val receiver=lines[normalName("WR One")]!!
        assertEquals(6,receiver.receptions)
        assertEquals(8,receiver.targets)
        assertEquals(31,receiver.longestReception)
        assertTrue(receiver.receivingObserved)
    }

    @Test fun `prop over uses strictly greater not tied line and is historical only`() {
        val p=player(logs=listOf(
            usage("2026-10-19",recs=5),usage("2026-10-12",recs=7),usage("2026-10-05",recs=5),
            usage("2026-09-28",recs=8),usage("2026-09-21",recs=4)
        ))
        val r=PropIntelligence.assess(p,PropMarket.RECEPTIONS)
        assertEquals(listOf(5,7,5,8,4),r.observed)
        assertEquals(2 to 5,r.lineHistory(5.0))
        assertEquals(4 to 5,r.lineHistory(4.5))
        assertNull(r.lineHistory(-1.0))
        assertNotNull(r.representative)
        assertTrue(r.evidence.any{it.pillar.startsWith("5")})
    }

    @Test fun `missing receiving category cannot become fake zero catches`() {
        val p=player(logs=listOf(
            usage("2026-10-19",recs=0,receiving=false),
            usage("2026-10-12",recs=4),usage("2026-10-05",recs=2)
        ))
        val r=PropIntelligence.assess(p,PropMarket.RECEPTIONS)
        assertEquals(listOf(4,2),r.observed)
        assertNull(r.representative)
        assertEquals(1 to 2,r.lineHistory(3.0))
    }

    @Test fun `longest reception requires actual labeled long statistic`() {
        val p=player(logs=listOf(
            usage("2026-10-19",long=null),usage("2026-10-12",long=17),usage("2026-10-05",long=null)
        ))
        val r=PropIntelligence.assess(p,PropMarket.LONGEST_RECEPTION)
        assertEquals(listOf(17),r.observed)
        assertNull(r.representative)
    }

    @Test fun `anytime TD excludes QB passing TDs and no numerical TD probability`() {
        val p=player("QB",listOf(
            usage("2026-10-19",passAtt=31,comp=20,passYds=250,passedTd=3,receiving=false,rushing=true,passing=true),
            usage("2026-10-12",passAtt=36,comp=25,passYds=280,passedTd=2,receiving=false,rushing=true,passing=true),
            usage("2026-10-05",passAtt=35,comp=20,passYds=240,passedTd=4,receiving=false,rushing=true,passing=true)
        ))
        val td=PropIntelligence.assess(p,PropMarket.ANYTIME_TD)
        assertEquals(listOf(0,0,0),td.observed)
        assertNull(td.representative)
        val passing=PropIntelligence.assess(p,PropMarket.PASS_TDS)
        assertEquals(listOf(3,2,4),passing.observed)
        assertNotNull(passing.representative)
    }

    @Test fun `traded player is warned about prior team stats`() {
        val p=player(logs=listOf(usage("2026-10-19",team="ARI"),usage("2026-10-12",team="ARI"),usage("2026-10-05",team="ARI")))
        val result=PropIntelligence.assess(p,PropMarket.RECEIVING_YARDS)
        assertTrue(result.warnings.any{it.contains("different team")})
    }

    @Test fun `five screenshot pillars and missing pressure never masquerade as measured`() {
        val p=player(logs=listOf(usage("2026-10-19"),usage("2026-10-12"),usage("2026-10-05")))
        val result=PropIntelligence.assess(p,PropMarket.RECEIVING_YARDS)
        assertTrue(result.evidence.any{it.pillar.startsWith("1") && it.level==EvidenceLevel.VERIFIED})
        assertTrue(result.evidence.any{it.pillar.startsWith("2") && it.detail.contains("route participation")})
        assertTrue(result.evidence.any{it.pillar.startsWith("3")})
        assertTrue(result.evidence.any{it.pillar.startsWith("4") && it.level==EvidenceLevel.MISSING})
        assertTrue(result.evidence.any{it.pillar.startsWith("5")})
        assertTrue(result.evidence.any{it.pillar=="Coverage chart" && it.level==EvidenceLevel.MISSING})
        assertFalse(result.evidence.any{it.detail.contains("Verified pressure rate")})
    }

    @Test fun `guide only marks passing volume when passing boxes are measured`() {
        val missing=player("QB",listOf(usage("2026-10-19",receiving=false),usage("2026-10-12",receiving=false)))
        val unknown=PropGuidelines.forMarket(missing,PropMarket.PASS_YARDS)
        assertEquals(ChecklistStatus.NOT_MEASURED,unknown.first().status)
        val known=player("QB",listOf(
            usage("2026-10-19",passAtt=34,comp=20,passing=true,receiving=false),
            usage("2026-10-12",passAtt=36,comp=21,passing=true,receiving=false),
            usage("2026-10-05",passAtt=35,comp=23,passing=true,receiving=false)
        ))
        assertEquals(ChecklistStatus.MET,PropGuidelines.forMarket(known,PropMarket.PASS_YARDS).first().status)
    }

    @Test fun `only observed receiving targets support the catch efficiency heuristic`() {
        val p=player(logs=listOf(
            usage("2026-10-19",targets=10,recs=7),usage("2026-10-12",targets=10,recs=8)
        ))
        val rules=PropGuidelines.forMarket(p,PropMarket.RECEPTIONS)
        assertEquals(ChecklistStatus.MET,rules.first{it.label=="Catch efficiency"}.status)
        assertEquals(ChecklistStatus.NOT_MEASURED,rules.first{it.label=="Routes"}.status)
    }

}
